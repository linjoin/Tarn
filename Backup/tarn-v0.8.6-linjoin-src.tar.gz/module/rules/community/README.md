# Tarn 社区清理规则包

> 全网搜集整理的 Android 缓存清理规则, 按类别分文件, 即导即用.
>
> 规则来源:
> - [WeirdMidas/BasicCleaner](https://github.com/WeirdMidas/BasicCleaner) (Magisk 清理模块, 系统级路径清单)
> - [DEMONNICA/Clear-Optimization](https://github.com/DEMONNICA/Clear-Optimization) (Magisk 优化模块)
> - [Cai-Ming-Yu/CMY-CacheCleaner](https://github.com/Cai-Ming-Yu/CMY-CacheCleaner) (KernelSU 缓存清理)
> - [d4rken-org/sdmaid-se](https://github.com/d4rken-org/sdmaid-se) (SD Maid SE, 最专业的 Android 清理工具)
> - 知乎/百度经验/CSDN 教程 (国内 App 缓存路径汇总)
> - Android 官方文档 (getCacheDir()/getExternalCacheDir() 规范)

---

## 规则包清单

| 文件 | 覆盖范围 | 规则数 | 默认启用 | 风险 |
|------|----------|--------|----------|------|
| `system-junk.toml` | 系统日志/ANR/dropbox/临时文件 | 4 | 全部启用 | low |
| `app-cache.toml` | 所有 App 通用缓存 (通配符) | 5 | 部分 (激进规则默认关) | low |
| `tencent-apps.toml` | 微信/QQ/腾讯视频 | 7 | 全部启用 | low~medium |
| `social-apps.toml` | 抖音/快手/小红书/知乎/头条/微博/贴吧 | 12 | 全部启用 | low |
| `ecommerce-apps.toml` | 淘宝/京东/拼多多/美团/饿了么/携程/唯品会 | 12 | 全部启用 | low |
| `media-apps.toml` | B站/网易云/爱奇艺/优酷/芒果TV/喜马拉雅/YouTube/Spotify | 12 | 全部启用 (离线缓存关) | low~medium |
| `browsers.toml` | Chrome/Edge/Firefox/夸克/UC/QQ/百度/Via 浏览器 | 10 | 全部启用 | low |
| `utility-apps.toml` | 支付宝/高德/百度地图/滴滴/12306/点评/WPS/钉钉/企微/飞书 | 13 | 全部启用 | low |

**总计: 75 条规则, 覆盖 50+ 常用 App**

---

## 快速使用

### 方式 1: WebUI 导入 (推荐)

1. 打开 WebUI (`http://127.0.0.1:8080`, token 在 `/data/adb/tarn/run/token`)
2. 顶部菜单 → **规则** → **导入**
3. 选择需要的 `.toml` 文件 (可多选)
4. 导入后可逐条启用/禁用/编辑

### 方式 2: 手动复制

```sh
# 把规则包复制到配置目录
cp /data/adb/modules/tarn/rules/community/*.toml /data/adb/tarn/config/

# 合并到 blacklist.toml (Tarn 目前只读 blacklist.toml)
cat /data/adb/tarn/config/*.toml >> /data/adb/tarn/config/blacklist.toml

# 热重载
/data/adb/modules/tarn/tarn reload
```

### 方式 3: 单独用某个规则包

只想清微信? 只导入 `tencent-apps.toml` 即可, 其他文件不导入.

---

## 规则设计原则

### 1. 安全第一: 只清 cache, 不碰 data

- 所有规则默认只清理 `cache` / `code_cache` 目录 (Android 设计为可被系统回收)
- **不删** `databases` / `files` / `shared_prefs` (App 核心数据)
- **不删** 聊天记录 / 账号信息 / 离线下载 (除非规则明确标 `enabled = false`)

### 2. 风险分级: 激进规则默认关

| 风险 | 含义 | 默认状态 |
|------|------|----------|
| `low` | 只清 cache, App 自动重建 | 启用 |
| `medium` | 可能删用户数据 (如离线视频缓存) | **关闭**, 用户自评后开 |
| `high` | 删整个目录, 高风险 | 本规则包不含 |

### 3. 定时策略: 高频 App 每日, 低频 App 每周

- 每日清理 (`0 3 * * *`): 微信/QQ/抖音/淘宝 等高频使用 App
- 每周清理 (`0 3 * * 0`): 系统日志/聊天图片缩略图/地图瓦片 等低频增长项
- 离线缓存: 默认关, 用户开了后按 30~90 天清理

### 4. older_than_days 防误删热数据

- 视频/音频播放缓存: `older_than_days = 3` (只清 3 天前的)
- 图片缩略图: `older_than_days = 14~30`
- 系统日志: `older_than_days = 3~7` (留最近几天的排查用)
- 离线下载: `older_than_days = 30~90` (用户的主动下载, 给足时间)

---

## 各 App 包名速查表

### 腾讯系
| App | 包名 |
|-----|------|
| 微信 | `com.tencent.mm` |
| QQ | `com.tencent.mobileqq` |
| 腾讯视频 | `com.tencent.qqlive` |
| 王者荣耀 | `com.tencent.tmgp.sgame` |
| 全民K歌 | `com.tencent.karaoke` |
| 企业微信 | `com.tencent.wework` |
| QQ浏览器 | `com.tencent.mtt` |

### 社交短视频
| App | 包名 |
|-----|------|
| 抖音 | `com.ss.android.ugc.aweme` |
| 抖音极速版 | `com.ss.android.ugc.aweme.lite` |
| 快手 | `com.smile.gifmaker` |
| 快手极速版 | `com.kuaishou.nebula` |
| 小红书 | `com.xingin.xhs` |
| 知乎 | `com.zhihu.android` |
| 今日头条 | `com.ss.android.article.news` |
| 微博 | `com.sina.weibo` |
| 百度贴吧 | `com.baidu.tieba` |

### 电商
| App | 包名 |
|-----|------|
| 淘宝 | `com.taobao.taobao` |
| 天猫 | `com.tmall.wireless` |
| 京东 | `com.jingdong.app.mall` |
| 拼多多 | `com.xunmeng.pinduoduo` |
| 美团 | `com.sankuai.meituan` |
| 美团外卖 | `com.sankuai.meituan.takeoutnew` |
| 饿了么 | `me.ele` |
| 携程 | `ctrip.android.view` |
| 飞猪 | `com.taobao.trip` |
| 唯品会 | `com.achievo.vipshop` |

### 长视频音频
| App | 包名 |
|-----|------|
| 哔哩哔哩 | `tv.danmaku.bili` |
| 网易云音乐 | `com.netease.cloudmusic` |
| 爱奇艺 | `com.qiyi.video` |
| 优酷 | `com.youku.phone` |
| 芒果TV | `com.hunantv.imgo.activity` |
| 喜马拉雅 | `com.ximalaya.ting.android` |
| YouTube | `com.google.android.youtube` |
| Spotify | `com.spotify.music` |

### 浏览器
| App | 包名 |
|-----|------|
| Chrome | `com.android.chrome` |
| Edge | `com.microsoft.emmx` |
| Firefox | `org.mozilla.firefox` |
| 夸克 | `com.quark.browser` |
| UC浏览器 | `com.UCMobile` |
| QQ浏览器 | `com.tencent.mtt` |
| 百度浏览器 | `com.baidu.browser.apps` |
| Via | `mark.via` |

### 工具生活
| App | 包名 |
|-----|------|
| 支付宝 | `com.eg.android.alipaygphone` |
| 高德地图 | `com.autonavi.minimap` |
| 百度地图 | `com.baidu.BaiduMap` |
| 滴滴出行 | `com.sdu.didi.psnger` |
| 12306 | `com.MobileTicket` |
| 大众点评 | `com.dianping.v1` |
| WPS Office | `cn.wps.moffice_eng` |
| 钉钉 | `com.alibaba.android.rimet` |
| 飞书 | `com.ss.android.lark` |

---

## 自定义指南

### 加一个本规则包没覆盖的 App

以"酷安" (`com.coolapk.market`) 为例, 复制下面的模板到 `blacklist.toml`:

```toml
[[rule]]
id = "coolapk-cache"
name = "酷安缓存"
enabled = true
priority = 70
risk = "low"

[rule.trigger]
on = ["manual", "cron"]
cron_expr = "0 3 * * *"   # 每天凌晨 3 点

[[rule.targets]]
path = "/data/data/com.coolapk.market"
glob = "{cache,code_cache}"
mode = "clear_dirs"

[[rule.targets]]
path = "/storage/emulated/0/Android/data/com.coolapk.market"
glob = "cache"
mode = "clear_dirs"
```

改 3 处: `id` / `name` / `path` 里的包名.

### 调整清理频率

改 `cron_expr`:
- `0 3 * * *` = 每天凌晨 3 点
- `0 3 * * 0` = 每周日凌晨 3 点
- `0 3 * * 1,4` = 每周一、周四凌晨 3 点
- `0 */6 * * *` = 每 6 小时一次
- `0 0 1 * *` = 每月 1 号

### 只手动触发, 不定时

```toml
[rule.trigger]
on = ["manual"]   # 去掉 cron 和 boot
```

---

## 验证规则

导入规则后, **先 dry-run 预览** 再真删:

```sh
# 预览所有规则会删什么 (不真删)
/data/adb/modules/tarn/tarn run --dry-run --json

# 只跑某条规则
/data/adb/modules/tarn/tarn run --rule wechat-internal-cache --dry-run

# 确认无误后真删
/data/adb/modules/tarn/tarn run
```

WebUI 也有 "预览" 按钮 (绿色眼睛图标), 点一下看会删哪些文件.

---

## 常见问题

### Q: 为什么有的规则默认 enabled = false?

A: 两种情况:
1. **激进规则** (如"所有 App 内部缓存"): 通配符匹配所有 App, 万一某个 App 的 cache 里有重要东西会误删, 默认关让你评估后开
2. **离线缓存清理** (如"B站离线缓存"): 会删用户主动下载的视频, 默认关

### Q: 清完 cache 后 App 会变慢吗?

A: 会有短暂的冷启动慢 (App 要重建缓存), 但运行一会就恢复. 对微信/QQ 这类高频 App, 建议夜里定时清, 早上用正好是冷启动, 用一会就热了.

### Q: 清理会删聊天记录吗?

A: **不会**. 聊天记录在 `databases/` 目录, 规则只清 `cache/` 目录. 但 `chatpic` (聊天图片缩略图) 规则会删 30 天前的缩略图, 原图在 `image2/` 不动. 如果连缩略图都不想删, 把 `wechat-chatpic-cache` 和 `qq-chatpic-cache` 两条规则关掉.

### Q: 规则没生效?

检查:
1. `enabled = true` 了吗?
2. 规则的 `path` 在 Tarn 允许的根目录内吗? (见文档「允许清理的根目录」)
3. 改完 toml 后 `tarn reload` 了吗?
4. `tarn run --dry-run` 看有匹配到文件吗? 没有可能是 glob 写错或文件不存在

### Q: 想贡献新规则?

欢迎补充! 提 issue 或 PR 到 Tarn 仓库, 标注:
- App 名称和包名
- 缓存目录路径 (从 `adb shell ls` 或 root 文件管理器确认)
- 风险等级 (清完会不会让 App 崩溃)
- 来源 (哪里看到的路径)
