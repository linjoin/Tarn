//! 错误通知 + 诊断收集 (真·Rust 原生实现, 不走 shell 字符串)
//!
//! ## 设计
//! 当 Tarn 出现错误时 (daemon 启动失败 / cron 清理失败 / panic / 配置重载失败等):
//! 1. 执行 `debug.sh` 收集诊断快照 (日志 / 配置 / 系统 / 进程信息)
//! 2. 发送 Android 系统通知提醒用户
//!
//! ## 真原生实现 (与上一版的区别)
//! 旧版: `Command::new("su").arg("2000").arg("-c").arg(<shell 字符串>)`
//!       本质仍是 `su -c` 包装 shell 字符串, 有 shell 转义/注入风险。
//!
//! 新版: `Command::new("/system/bin/cmd")` 直接 exec cmd 二进制
//!       + `pre_exec` 中 Rust 端调用 `setsid + setgroups + setgid + setuid(2000)`
//!         切换到 shell 用户身份 (等价 `su 2000`, 但不依赖 su 二进制)
//!       + 参数全部走 argv 传递 (无 shell 字符串, 无注入风险, 无需转义)
//!       + 通知 ID 由 Rust 端生成 (替代 shell `$RANDOM`)
//!
//! ## 为什么需要 setuid(2000)
//! Android 通知服务 (NotificationManager) 需要调用方有合法 uid。
//! daemon 以 root 跑, 直接以 root uid 发通知会被部分 ROM 拒绝或显示异常。
//! 切到 AID_SHELL (2000) 是 Android shell 用户的 uid, 与 `su 2000` 等价,
//! 通知能正常投递且显示为 "Shell" 应用。
//!
//! ## setgroups/setgid/setuid 顺序
//! Linux 要求: setgroups → setgid → setuid
//!   - 先清附加组 (否则 setgid 后仍可能在补充组里有 root gid)
//!   - 再 setgid (改主组)
//!   - 最后 setuid (改主用户, 之后失去 CAP_SETUID 无法再改)
//!
//! ## 脱离父进程 (detached spawn)
//! `pre_exec(setsid)` 让子进程成为新会话组长, 脱离控制终端 + 进程组,
//! 父进程 exit/abort 后子进程继续运行完成通知投递 (panic 场景关键)。
//! stdin/stdout/stderr 全部 → /dev/null, 避免管道阻塞。
//!
//! ## 速率限制
//! 同一类错误短时间内可能反复触发 (如 cron 每分钟失败), 用文件时间戳限制:
//! 默认 5 分钟内最多 1 条通知, 避免通知轰炸。
//! debug.sh 不限速 (每次错误都收集, 方便排查)。
//!
//! ## fallback 策略
//! 若 `/system/bin/cmd` 不存在 (非 Android 环境, 如开发机测试),
//! 自动 fallback 到 `Command::new("su")...` 旧路径, 保证 spawn 不失败。
//! 真机上 cmd 一定存在, fallback 只在开发/测试环境触发。

use anyhow::Result;
use std::fs;
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicU32, Ordering};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

/// MODPATH 固定路径 (与 module_prop.rs / webroot.rs 一致)
const MODPATH: &str = "/data/adb/modules/tarn";

/// Android cmd 二进制路径 (notification manager 命令入口)
const ANDROID_CMD: &str = "/system/bin/cmd";

/// Android AID_SHELL = 2000 (shell 用户 uid, su 2000 切换的目标)
const SHELL_UID: u32 = 2000;

/// 速率限制窗口 (秒): 同一错误 5 分钟内最多 1 条通知
const NOTIFY_RATE_LIMIT_SECS: u64 = 300;

/// 通知 ID 序列 (配合时间戳 + pid 生成唯一 id, 模拟 shell $RANDOM 但保证不重复)
static NOTIF_SEQ: AtomicU32 = AtomicU32::new(0);

/// debug.sh 路径
pub fn debug_sh_path() -> PathBuf {
    PathBuf::from(MODPATH).join("debug.sh")
}

/// 生成通知 ID (u32 全范围, 替代 shell `$RANDOM` 的 0..32768)
///
/// 不引入 rand crate 依赖, 用 SystemTime 纳秒 + pid + 全局自增序号异或。
/// - 同进程多次调用: seq 自增保证几乎不重复 (u32 全范围, 冲突概率 ~1/4G)
/// - 跨进程: pid 不同保证不同
/// - 跨重启: SystemTime 单调递增
///
/// 注意: Android `cmd notification post` 的通知 ID 参数接受任意 32 位整数,
/// 不必限制在 shell $RANDOM 的 0..32768 范围。
fn random_notification_id() -> u32 {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.subsec_nanos())
        .unwrap_or(0);
    let pid = std::process::id();
    let seq = NOTIF_SEQ.fetch_add(1, Ordering::Relaxed);
    let raw = nanos ^ (pid << 8) ^ (seq << 3) ^ 0x9E3779B9u32;
    raw
}

/// 在 pre_exec 闭包中执行身份切换 (setgroups + setgid + setuid + setsid)
///
/// 所有调用都用 `let _ =` 吞掉错误:
/// - setsid 失败: 可能已是会话组长, 不影响后续
/// - setgroups/setgid/setuid 失败: 非 root 时 EPERM, 仍尝试 exec (可能仍能投递通知)
/// - 这些都是 async-signal-safe 的 syscall, 在 pre_exec 中调用安全
unsafe fn drop_privileges_and_detach() {
    let _ = libc::setsid();
    // 顺序: setgroups → setgid → setuid (Linux 要求, 否则 setgid 可能 EPERM)
    let _ = libc::setgroups(0, std::ptr::null::<libc::gid_t>());
    let _ = libc::setgid(SHELL_UID);
    let _ = libc::setuid(SHELL_UID);
}

/// 发送 Android 系统通知 (真·Rust 原生, 完全脱离父进程)
///
/// 实现: 直接 exec `/system/bin/cmd notification post ...` 二进制,
/// 在 pre_exec 中 setsid + setuid(2000) 切到 shell 用户身份。
/// 参数全部走 argv, 无 shell 注入风险。
///
/// 非阻塞: spawn 后立即返回, 不等待通知投递完成。
/// 失败静默 (cmd 不存在 / 非 root / 通知服务不可用 都只返回 Err, 由调用方决定是否记日志)。
///
/// fallback: 若 `/system/bin/cmd` 不存在, 回退到 `su 2000 -c "..."` 旧路径
/// (仅开发/测试环境触发, 真机上 cmd 一定存在)。
pub fn send_notification(title: &str, msg: &str) -> Result<()> {
    let notif_id = random_notification_id().to_string();
    let message_arg = format!("{}:{}", title, msg);

    if Path::new(ANDROID_CMD).exists() {
        // 真原生路径: 直接 exec cmd 二进制 + Rust 端 setuid
        let mut cmd = Command::new(ANDROID_CMD);
        cmd.arg("notification")
            .arg("post")
            .arg("-S")
            .arg("messaging")
            .arg("--conversation")
            .arg(title)
            .arg("--message")
            .arg(&message_arg)
            .arg("Tarn")
            .arg(&notif_id);
        cmd.env_clear();
        cmd.stdin(Stdio::null());
        cmd.stdout(Stdio::null());
        cmd.stderr(Stdio::null());
        unsafe {
            cmd.pre_exec(|| {
                drop_privileges_and_detach();
                Ok(())
            });
        }
        cmd.spawn()?;
    } else {
        // fallback: 非 Android 环境 (开发机), 走 su 但仍用 argv 直传 (无 shell 字符串)
        // su -c 必须接 shell 字符串, 这里用 exec 避免 shell 解析参数
        let mut cmd = Command::new("su");
        cmd.arg("2000")
            .arg("-c")
            .arg(format!(
                "exec {} notification post -S messaging --conversation {} --message {} Tarn {}",
                ANDROID_CMD,
                shell_quote(title),
                shell_quote(&message_arg),
                notif_id
            ));
        cmd.stdin(Stdio::null());
        cmd.stdout(Stdio::null());
        cmd.stderr(Stdio::null());
        unsafe {
            cmd.pre_exec(|| {
                let _ = libc::setsid();
                Ok(())
            });
        }
        cmd.spawn()?;
    }
    Ok(())
}

/// shell 单引号转义 (仅 fallback 路径用, 主路径不需要)
fn shell_quote(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('\'');
    for ch in s.chars() {
        if ch == '\'' {
            out.push_str("'\\''");
        } else {
            out.push(ch);
        }
    }
    out.push('\'');
    out
}

/// 执行 debug.sh 收集诊断快照 (脱离父进程, 非阻塞)
///
/// debug.sh (v5) 自身把诊断结果打包到 /data/adb/tarn/logs/debug-<ts>.tar.gz,
/// 内含 diagnostic.txt (诊断文本, 17 章检测结果 + 摘要, 不转储规则内容) +
/// configs/ (settings/blacklist/whitelist/rules/*.toml 原样副本, 每个附 .meta) +
/// logs/ + state/ + system/ + meta/ (module.prop/service.sh/uninstall.sh + 环境元信息) +
/// MANIFEST.txt。
/// v5 起 diagnostic.txt 不再转储清理规则内容 (社区规则包可达数千行, 会撑爆诊断文本),
/// 只列规则清单 (文件名/行数/字节); 规则原文副本仍在压缩包 configs/rules/ (取证用)。
/// 这里只负责 spawn, 不收集 stdout。
///
/// stderr 处理 (v2 加固): 重定向到 logs/debug-sh.err 固定文件。
/// 旧版把 stderr 全 null, debug.sh 自身有语法错/busybox 缺失时完全静默,
/// 排查时误以为"没出错所以没快照"。现在脚本自身的报错会留痕, 便于定位。
/// 该文件每次 spawn 覆盖 (只保留最近一次脚本启动错误)。
pub fn run_debug_sh() -> Result<()> {
    let script = debug_sh_path();
    if !script.exists() {
        return Err(anyhow::anyhow!("debug.sh 不存在: {}", script.display()));
    }

    // debug.sh stderr 落盘路径 (与 debug.sh 写的 debug-<ts>.tar.gz 同目录)
    let stderr_path = std::path::Path::new("/data/adb/tarn/logs/debug-sh.err");
    // 确保目录存在 (正常 service.sh 已建, 这里兜底)
    let _ = fs::create_dir_all(stderr_path.parent().unwrap_or(std::path::Path::new("/data/adb/tarn/logs")));

    let stderr_file = fs::OpenOptions::new()
        .create(true)
        .write(true)
        .truncate(true)
        .open(stderr_path);

    let mut cmd = Command::new("sh");
    cmd.arg(&script);
    cmd.stdin(Stdio::null());
    cmd.stdout(Stdio::null());
    // stderr 优先落到文件; 打开失败则降级 null (不让 spawn 因 stderr 失败)
    // Stdio: From<File>, 这里把 File move 进 Stdio (无需 try_clone)
    match stderr_file {
        Ok(f) => {
            cmd.stderr(Stdio::from(f));
        }
        Err(_) => {
            cmd.stderr(Stdio::null());
        }
    }
    unsafe {
        cmd.pre_exec(|| {
            let _ = libc::setsid();
            Ok(())
        });
    }

    match cmd.spawn() {
        Ok(_) => Ok(()),
        Err(e) => {
            // spawn 失败 (fork 失败/sh 不可用): 把错误写入 debug-sh.err
            // 不依赖 logger (panic 场景 logger 可能不可用), 用 fs::write 兜底
            let ts = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0);
            let msg = format!(
                "[{}] run_debug_sh spawn 失败: {}\n  script: {}\n  (可能原因: OOM fork 失败 / sh 不可用 / /data 只读)\n",
                ts,
                e,
                script.display()
            );
            let _ = fs::write(stderr_path, msg);
            Err(anyhow::anyhow!("debug.sh spawn 失败: {}", e))
        }
    }
}

/// 读取上次通知时间戳 (Unix 秒), 文件不存在返回 None
fn read_last_notify(config_dir: &Path) -> Option<u64> {
    let p = config_dir.join("run/last_notify.ts");
    fs::read_to_string(&p)
        .ok()
        .and_then(|s| s.trim().parse::<u64>().ok())
}

/// 写入当前通知时间戳
fn write_last_notify(config_dir: &Path) {
    let p = config_dir.join("run/last_notify.ts");
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let _ = fs::create_dir_all(p.parent().unwrap_or(Path::new(".")));
    let _ = fs::write(&p, now.to_string());
}

/// 判断是否在速率限制窗口内 (true = 被限速, 应跳过通知)
fn is_rate_limited(config_dir: &Path) -> bool {
    match read_last_notify(config_dir) {
        Some(last) => {
            let now = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0);
            now.saturating_sub(last) < NOTIFY_RATE_LIMIT_SECS
        }
        None => false,
    }
}

/// 错误聚合入口: 跑 debug.sh + 发通知 (带速率限制)
///
/// 调用场景: daemon 运行时检测到错误 (cron 失败 / 配置重载失败 / panic hook 等)。
///
/// 行为:
/// 1. 始终 spawn debug.sh (不限速, 每次错误都收集诊断)
/// 2. 速率限制窗口内 (默认 5 分钟) 跳过通知, 避免轰炸
/// 3. 通知失败只 log, 不影响主流程
///
/// `config_dir`: /data/adb/tarn, 用于读/写 last_notify.ts
/// `logger`: 可选, 用于记录通知发送情况 (None 时静默)
pub fn on_error(
    title: &str,
    msg: &str,
    config_dir: &Path,
    logger: Option<&crate::logger::AsyncLogger>,
) {
    if let Err(e) = run_debug_sh() {
        if let Some(l) = logger {
            l.warn("notify", &format!("debug.sh 启动失败: {}", e));
        }
    }

    if is_rate_limited(config_dir) {
        if let Some(l) = logger {
            l.debug(
                "notify",
                &format!("通知被速率限制 ({} 秒内已发过), 跳过: {}", NOTIFY_RATE_LIMIT_SECS, title),
            );
        }
        return;
    }

    match send_notification(title, msg) {
        Ok(()) => {
            write_last_notify(config_dir);
            if let Some(l) = logger {
                l.info("notify", &format!("已发送错误通知: {} - {}", title, msg));
            }
        }
        Err(e) => {
            if let Some(l) = logger {
                l.warn("notify", &format!("发送通知失败 (非 root / cmd 不可用 / 通知服务异常): {}", e));
            }
        }
    }
}

/// 强制发送通知 (不限速), 供 CLI `tarn notify-error` 手动触发用
pub fn send_notification_force(title: &str, msg: &str) -> Result<()> {
    send_notification(title, msg)
}

/// 清除速率限制 (供 `tarn notify-error` 手动触发时调用, 确保一定能发出)
pub fn reset_rate_limit(config_dir: &Path) {
    let p = config_dir.join("run/last_notify.ts");
    let _ = fs::remove_file(&p);
}

/// 距离上次通知的时长 (用于诊断), 返回 None 表示从未发过
pub fn time_since_last_notify(config_dir: &Path) -> Option<Duration> {
    let last = read_last_notify(config_dir)?;
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    Some(Duration::from_secs(now.saturating_sub(last)))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_random_notification_id_range() {
        for _ in 0..1000 {
            let id = random_notification_id();
            // u32 全范围, 仅验证返回了有效 u32 (不 panic, 不溢出)
            let _ = id;
        }
    }

    #[test]
    fn test_random_notification_id_unique_in_process() {
        let mut ids = std::collections::HashSet::new();
        for _ in 0..10000 {
            ids.insert(random_notification_id());
        }
        // u32 全范围 + seq 自增, 10000 次冲突概率极低
        assert!(ids.len() > 9900, "同进程内通知 id 应几乎不重复, 实际唯一数: {}", ids.len());
    }

    #[test]
    fn test_shell_quote_empty() {
        assert_eq!(shell_quote(""), "''");
    }

    #[test]
    fn test_shell_quote_plain() {
        assert_eq!(shell_quote("hello"), "'hello'");
    }

    #[test]
    fn test_shell_quote_with_single_quote() {
        assert_eq!(shell_quote("a'b"), "'a'\\''b'");
    }

    #[test]
    fn test_shell_quote_with_special() {
        let s = shell_quote("hello $world `cmd` $(sub)");
        assert!(s.starts_with('\''));
        assert!(s.ends_with('\''));
        assert!(s.contains('$'));
    }

    #[test]
    fn test_rate_limit_logic() {
        let tmp = std::env::temp_dir().join("tarn_notify_test_rl_native");
        let _ = std::fs::remove_dir_all(&tmp);
        std::fs::create_dir_all(tmp.join("run")).unwrap();
        assert!(!is_rate_limited(&tmp));
        write_last_notify(&tmp);
        assert!(is_rate_limited(&tmp));
        reset_rate_limit(&tmp);
        assert!(!is_rate_limited(&tmp));
        let _ = std::fs::remove_dir_all(&tmp);
    }

    #[test]
    fn test_send_notification_fallback_no_crash() {
        // 在非 Android 环境 (无 /system/bin/cmd), send_notification 走 fallback 路径
        // spawn su 可能失败 (su 不存在), 但函数本身不应 panic
        let result = send_notification("test_title", "test_msg");
        // 允许 Err (su 不存在), 但不应 panic
        let _ = result;
    }

    #[test]
    fn test_message_arg_format() {
        // 验证 --message 参数格式 "title:msg"
        let title = "Tarn 启动失败";
        let msg = "daemon 退出码 1";
        let message_arg = format!("{}:{}", title, msg);
        assert_eq!(message_arg, "Tarn 启动失败:daemon 退出码 1");
    }
}
