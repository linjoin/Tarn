//! run / list / show / doctor / daemon / enable / disable / config / log 等命令实现

use crate::cli::{Command, ConfigAction};
use anyhow::Result;
use tarn_core::{
    config::{Blacklist, Settings, Whitelist},
    daemon::{self, DaemonContext},
    executor::{Executor, RunOptions, Trigger},
    is_target_allowed,
    logger::{AsyncLogger, LogLevel},
    notify,
    reload,
    state::StateManager,
    sysutil,
    CONFIG_SCHEMA_VERSION, VERSION,
};
use std::path::PathBuf;
use std::sync::Arc;

pub fn default_config_dir() -> PathBuf {
    // 优先环境变量, 其次 /data/adb/tarn (Android), 最后 ./tarn-data (开发)
    if std::env::var("TARN_CONFIG_DIR").is_ok() {
        return PathBuf::from(std::env::var("TARN_CONFIG_DIR").unwrap());
    }
    let android_path = PathBuf::from("/data/adb/tarn");
    if android_path.exists() {
        return android_path;
    }
    PathBuf::from("./tarn-data")
}

/// 确保配置目录存在, 初始化默认配置
///
/// 配置文件统一放在 config/ 子目录 (与 customize.sh 部署位置一致),
/// 启动时自动迁移数据目录根的散落配置到 config/。
pub fn ensure_config_dir(config_dir: &PathBuf) -> Result<()> {
    std::fs::create_dir_all(config_dir)?;
    std::fs::create_dir_all(config_dir.join("config"))?;
    std::fs::create_dir_all(config_dir.join("logs"))?;
    std::fs::create_dir_all(config_dir.join("run"))?;
    std::fs::create_dir_all(config_dir.join("rules"))?;

    // === 迁移: 数据目录根的散落配置 → config/ 子目录 ===
    migrate_legacy_config(config_dir);

    // 写默认配置 (若不存在)
    let settings_path = config_dir.join("config/settings.toml");
    if !settings_path.exists() {
        let default = Settings::default();
        let toml = toml::to_string_pretty(&default)
            .map_err(|e| anyhow::anyhow!("序列化默认 settings 失败: {}", e))?;
        std::fs::write(&settings_path, toml)?;
    }
    let blacklist_path = config_dir.join("config/blacklist.toml");
    if !blacklist_path.exists() {
        std::fs::write(&blacklist_path, "# Tarn 黑名单规则\n")?;
    }
    let whitelist_path = config_dir.join("config/whitelist.toml");
    if !whitelist_path.exists() {
        std::fs::write(&whitelist_path, "# Tarn 白名单保护\n")?;
    }
    Ok(())
}

/// 迁移根目录散落配置: 若 settings/blacklist/whitelist.toml 在数据目录根,
/// 移到 config/ 子目录 (仅在 config/ 中不存在时迁移, 不覆盖)。
fn migrate_legacy_config(config_dir: &PathBuf) {
    let config_subdir = config_dir.join("config");
    for f in &["settings.toml", "blacklist.toml", "whitelist.toml"] {
        let legacy = config_dir.join(f);
        let target = config_subdir.join(f);
        if legacy.exists() && !target.exists() {
            if let Err(e) = std::fs::rename(&legacy, &target) {
                // rename 失败 (跨设备?), 尝试 copy + remove
                if std::fs::copy(&legacy, &target).is_ok() {
                    let _ = std::fs::remove_file(&legacy);
                } else {
                    eprintln!("[WARN] 迁移 {} 失败: {}", legacy.display(), e);
                }
            }
        } else if legacy.exists() && target.exists() {
            // config/ 已有, 删除根目录残留
            let _ = std::fs::remove_file(&legacy);
        }
    }
}

pub fn run_command(cmd: Command, config_dir: PathBuf, verbose: bool) -> Result<()> {
    // 确保配置目录存在
    if !matches!(cmd, Command::Version) {
        let _ = ensure_config_dir(&config_dir);
    }

    match cmd {
        Command::Run {
            rule, trigger, dry_run, json,
        } => run_clean(config_dir, rule, trigger, dry_run, json, verbose),
        Command::Version => {
            println!("tarn {}", VERSION);
            println!("config schema: v{}", CONFIG_SCHEMA_VERSION);
            println!("target: {}", std::env::consts::ARCH);
            Ok(())
        }
        Command::Doctor => run_doctor(config_dir),
        Command::List { pack: _, enabled_only } => run_list(config_dir, enabled_only),
        Command::Show { rule_id } => run_show(config_dir, rule_id),
        Command::Stats => run_stats(config_dir),
        Command::Reload => run_reload(config_dir),
        Command::Webui { bind, port } => run_webui(config_dir, bind, port),
        Command::Daemon => run_daemon_cmd(config_dir),
        Command::Enable { rule_id } => run_enable(config_dir, rule_id, true),
        Command::Disable { rule_id } => run_enable(config_dir, rule_id, false),
        Command::Config { action } => run_config(config_dir, action),
        Command::Log { tail } => run_log(config_dir, tail),
        Command::NotifyError { title, msg, force } => run_notify_error(config_dir, title, msg, force),
        Command::Debug => run_debug_cmd(config_dir),
    }
}

fn make_logger(config_dir: &PathBuf, settings: &Settings) -> Result<Arc<AsyncLogger>> {
    let log_dir = config_dir.join("logs");
    // 相对路径转绝对
    let log_dir = if log_dir.is_absolute() {
        log_dir
    } else {
        std::env::current_dir()?.join(&log_dir)
    };
    let file_name = if settings.log.file.is_empty() {
        "tarn.log"
    } else {
        &settings.log.file
    };
    let logger = AsyncLogger::new(
        log_dir,
        file_name,
        settings.log.channel_capacity,
        LogLevel::from_str(&settings.log.level),
    )?;
    Ok(Arc::new(logger))
}

fn run_clean(
    config_dir: PathBuf,
    rule_filter: Option<Vec<String>>,
    trigger: String,
    dry_run: bool,
    json: bool,
    verbose: bool,
) -> Result<()> {
    let handle = reload::init_config(config_dir.clone())?;
    let cfg = handle.read();
    let settings = cfg.settings.clone();
    let logger = make_logger(&config_dir, &settings).ok();

    let trig = match trigger.as_str() {
        "boot" => Trigger::Boot,
        "cron" => Trigger::Cron,
        "event" => Trigger::Event,
        _ => Trigger::Manual,
    };

    let opts = RunOptions {
        dry_run,
        trigger: trig,
        json,
        verbose,
        rule_filter,
        timeout_sec: settings.schedule.default_rule_timeout_sec,
    };

    let mut executor = Executor::new(
        cfg.settings.clone(),
        cfg.blacklist.clone(),
        cfg.protect.clone(),
    );
    if let Some(log) = &logger {
        executor = executor.with_logger(log.clone());
    }
    drop(cfg);

    let result = executor.run(&opts);

    // 记录状态 (带轮转检查)
    let state_path = config_dir.join("state.json");
    let state = StateManager::new(state_path);
    let _rotation = state.record_run_with_rotation(
        &result,
        settings.state.rotate_after_files,
        settings.state.rotate_after_bytes,
        settings.state.keep_rotation_history,
    );

    if json {
        let audit = if verbose || dry_run {
            serde_json::to_value(&result.audit_trail).unwrap_or(serde_json::Value::Null)
        } else {
            serde_json::Value::Null
        };
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({
            "status": if result.exit_code == 0 { "success" } else { "failed" },
            "dry_run": result.dry_run,
            "run_id": result.run_id,
            "trigger": result.trigger,
            "ts_start": result.ts_start,
            "ts_end": result.ts_end,
            "metrics": {
                "rules_planned": result.rules_planned,
                "rules_executed": result.rules_executed,
                "rules_failed": result.rules_failed,
                "rules_skipped": result.rules_skipped,
                "freed_bytes": result.freed_bytes,
                "files_deleted": result.files_deleted,
                "files_blocked": result.files_blocked,
                "files_scanned": result.files_scanned,
                "dirs_removed": result.dirs_removed,
                "duration_ms": result.duration_ms,
            },
            "rules": result.rules.iter().map(|r| serde_json::json!({
                "id": r.rule_id,
                "name": r.rule_name,
                "status": r.status.as_str(),
                "freed_bytes": r.freed_bytes,
                "files_deleted": r.files_deleted,
                "files_blocked": r.files_blocked,
                "files_skipped": r.files_skipped,
                "files_scanned": r.files_scanned,
                "dirs_removed": r.dirs_removed,
                "duration_ms": r.duration_ms,
                "error": r.error,
            })).collect::<Vec<_>>(),
            "audit": audit,
        }))?);
    } else {
        if dry_run {
            println!("[Tarn] 预览完成（未实际删除）");
        } else {
            println!("[Tarn] 清理完成");
        }
        println!("   触发:     {}", result.trigger);
        println!("   规则:     {}/{} (失败 {}, 跳过 {})",
            result.rules_executed, result.rules_planned, result.rules_failed, result.rules_skipped);
        println!("   扫描文件: {}", result.files_scanned);
        let verb = if dry_run { "将删除" } else { "已删除" };
        println!("   {}文件: {}", verb, result.files_deleted);
        println!("   {}空目录: {}", if dry_run { "将清空" } else { "已清空" }, result.dirs_removed);
        println!("   保护拦截: {}", result.files_blocked);
        let total_skipped: u64 = result.rules.iter().map(|r| r.files_skipped).sum();
        println!("   跳过文件: {}", total_skipped);
        println!("   {}空间: {}", if dry_run { "将释放" } else { "已释放" }, format_bytes(result.freed_bytes));
        println!("   耗时:     {} ms", result.duration_ms);
        println!("   run_id:   {}", result.run_id);
        if dry_run {
            println!("   模式:     预览 (dry_run), 以上为\"将要\"清理的量, 未实际删除");
        }
        if verbose || dry_run {
            if !result.audit_trail.is_empty() {
                println!();
                println!("   审计轨迹 (前 50 条):");
                for a in result.audit_trail.iter().take(50) {
                    println!("     [{}] {} ({}) rule={} {}",
                        a.action, a.path, format_bytes(a.size), a.rule_id,
                        a.reason.as_ref().map(|r| format!("reason={}", r)).unwrap_or_default());
                }
            }
        }
    }

    // std::process::exit 跳过所有 Drop, logger 后台线程 channel 里
    // 可能还有未写盘的审计日志。显式 shutdown 确保 join 后台线程刷盘后再退出。
    if let Some(log) = &logger {
        log.shutdown();
    }
    std::process::exit(result.exit_code);
}

fn run_doctor(config_dir: PathBuf) -> Result<()> {
    println!("[Tarn] 自检");
    println!("   version:    {}", VERSION);
    println!("   schema:     v{}", CONFIG_SCHEMA_VERSION);
    println!("   target:     {}", std::env::consts::ARCH);
    println!("   config_dir: {}", config_dir.display());

    // 1. 配置目录
    if config_dir.exists() {
        println!("[OK] 配置目录存在");
    } else {
        println!("[WARN] 配置目录不存在: {}", config_dir.display());
    }

    // 2. 三文件 (位于 config_dir/config/ 子目录)
    let config_subdir = config_dir.join("config");
    for f in &["settings.toml", "blacklist.toml", "whitelist.toml"] {
        let p = config_subdir.join(f);
        if p.exists() {
            println!("[OK] {} 存在", f);
        } else {
            println!("[WARN] {} 不存在 (将用默认值)", f);
        }
    }

    // 3. (Magisk 模块必定 root, 跳过 root 检查)

    // 4. timerfd 可用性
    match tarn_core::scheduler::DozeTimer::new() {
        Ok(t) => {
            println!("[OK] timerfd + CLOCK_BOOTTIME_ALARM 可用 (fd={})", t.raw_fd());
            let _ = t.disarm();
        }
        Err(e) => println!("[FAIL] timerfd 不可用: {} (定时功能将降级)", e),
    }

    // 5. wake_lock
    if std::path::Path::new("/sys/power/wake_lock").exists() {
        println!("[OK] /sys/power/wake_lock 可写");
    } else {
        println!("[WARN] /sys/power/wake_lock 不存在");
    }

    // 6. nice / CPU 亲和性 (不做 ionice — 绝大多数 Android 设备上是空操作)
    if let Err(e) = sysutil::set_nice(19) {
        println!("[WARN] nice(19) 失败: {}", e);
    } else {
        println!("[OK] nice(19) 成功");
    }
    let little = sysutil::detect_little_cores();
    println!("[INFO] 检测到小核: {:?}", little);

    // 7. 加载配置测试 + 规则 target 路径白名单自检
    match reload::init_config(config_dir.clone()) {
        Ok(h) => {
            let cfg = h.read();
            println!("[OK] 配置加载成功: {} 条规则, {} 项保护",
                cfg.blacklist.rule.len(),
                cfg.whitelist.protect.len() + cfg.whitelist.protect_package.len()
                    + cfg.whitelist.protect_ext.len() + cfg.whitelist.protect_mtime.len());
            // 7.5 检查所有规则 target 路径是否在白名单内 (运行时会被 is_target_allowed 拒绝)
            let mut bad_targets = 0usize;
            for r in &cfg.blacklist.rule {
                for t in &r.targets {
                    if let Err(reason) = is_target_allowed(&t.path) {
                        if bad_targets == 0 {
                            println!("[WARN] 以下规则 target 路径不在白名单内, 运行时会被跳过:");
                        }
                        println!("    rule={} target={} reason={}", r.id, t.path, reason);
                        bad_targets += 1;
                    }
                }
            }
            if bad_targets == 0 {
                println!("[OK] 所有规则 target 路径都在白名单内 ({} 条规则)",
                    cfg.blacklist.rule.len());
            } else {
                println!("[WARN] 共 {} 个 target 路径不在白名单内", bad_targets);
            }
        }
        Err(e) => println!("[FAIL] 配置加载失败: {}", e),
    }

    // 8. daemon 状态
    let pidfile = config_dir.join("run/tarn.pid");
    if let Some(pid) = sysutil::read_pidfile(&pidfile) {
        if sysutil::pid_alive(pid) && sysutil::pid_cmdline_contains(pid, "tarn") {
            println!("[OK] daemon 运行中 (pid={})", pid);
        } else {
            println!("[WARN] pidfile 残留 (pid={} 不存活或非 tarn)", pid);
        }
    } else {
        println!("[INFO] daemon 未运行");
    }

    Ok(())
}

fn run_list(config_dir: PathBuf, enabled_only: bool) -> Result<()> {
    let handle = reload::init_config(config_dir)?;
    let cfg = handle.read();
    println!("[Tarn] 黑名单规则 ({} 条)", cfg.blacklist.rule.len());
    for r in &cfg.blacklist.rule {
        if enabled_only && !r.enabled {
            continue;
        }
        let status = if r.enabled { "[ON] " } else { "[OFF]" };
        let cron_tag = r.trigger.on.iter().find_map(|t| t.strip_prefix("cron:"))
            .map(|e| format!(" cron={}", e)).unwrap_or_default();
        println!("  {} [{}] {} (priority={}, targets={}{})",
            status, r.id, r.name, r.priority, r.targets.len(), cron_tag);
    }
    println!();
    let total_protect = cfg.whitelist.protect.len() + cfg.whitelist.protect_package.len()
        + cfg.whitelist.protect_ext.len() + cfg.whitelist.protect_mtime.len();
    println!("[Tarn] 白名单保护 ({} 项)", total_protect);
    for p in &cfg.whitelist.protect {
        let kind = if p.is_glob() { "通配符" } else { "prefix" };
        println!("  [path:{}] {} → {}", kind, p.id, p.path);
    }
    for p in &cfg.whitelist.protect_package {
        let only = if p.only.is_empty() { "(全保护)".to_string() } else { format!("(仅 {:?})", p.only) };
        println!("  [package] {} {}", p.package, only);
    }
    for p in &cfg.whitelist.protect_ext {
        let scope = if p.scope.is_empty() || p.scope == "global" { "global".to_string() } else { p.scope.clone() };
        println!("  [ext] {} (scope={})", p.extensions.join(","), scope);
    }
    for p in &cfg.whitelist.protect_mtime {
        let scope = if p.scope.is_empty() || p.scope == "global" { "global".to_string() } else { p.scope.clone() };
        println!("  [mtime] {} 天内 (scope={})", p.within_days, scope);
    }
    Ok(())
}

fn run_show(config_dir: PathBuf, rule_id: String) -> Result<()> {
    let handle = reload::init_config(config_dir)?;
    let cfg = handle.read();
    let rule = cfg.blacklist.rule.iter().find(|r| r.id == rule_id);
    match rule {
        Some(r) => {
            println!("[Tarn] 规则详情");
            println!("  id:       {}", r.id);
            println!("  name:     {}", r.name);
            println!("  enabled:  {}", r.enabled);
            println!("  priority: {}", r.priority);
            println!("  trigger:  on={:?} min_free_mb={}", r.trigger.on, r.trigger.min_free_mb);
            if let Some(cron) = r.trigger.get_cron_expr() {
                println!("  cron:     {}", cron);
            }
            println!("  targets:");
            for t in &r.targets {
                println!("    - path={} 通配符={} older_than_days={} min_size_kb={}",
                    t.path, t.glob, t.older_than_days, t.min_size_kb);
                if !t.exclude.is_empty() {
                    println!("      exclude: {:?}", t.exclude);
                }
            }
        }
        None => {
            println!("[FAIL] 规则不存在: {}", rule_id);
        }
    }
    Ok(())
}

fn run_stats(config_dir: PathBuf) -> Result<()> {
    let state_path = config_dir.join("state.json");
    let state = StateManager::new(state_path);
    let s = state.snapshot();
    println!("[Tarn] 累计统计");
    println!("   总运行次数: {}", s.totals.total_runs);
    println!("   总释放空间: {}", format_bytes(s.totals.total_freed_bytes));
    println!("   总删除文件: {}", s.totals.total_files_deleted);
    if let Some(last) = &s.last_run {
        println!();
        println!("   最近一次运行:");
        println!("     run_id: {}", last.run_id);
        println!("     时间:   {} → {}", last.ts_start, last.ts_end);
        println!("     触发:   {}", last.trigger);
        println!("     释放:   {}", format_bytes(last.freed_bytes));
        println!("     删除:   {} 文件", last.files_deleted);
        println!("     状态:   {} (exit={})", last.status, last.exit_code);
    }
    if !s.rules.is_empty() {
        println!();
        println!("   各规则统计:");
        for (id, rs) in &s.rules {
            println!("     {}: 跑 {} 次, 最近释放 {} (状态 {})",
                id, rs.run_count, format_bytes(rs.last_freed_bytes), rs.last_status);
        }
    }
    Ok(())
}

fn run_reload(config_dir: PathBuf) -> Result<()> {
    // 优先发 SIGHUP 给 daemon
    let pidfile = config_dir.join("run/tarn.pid");
    if let Some(pid) = sysutil::read_pidfile(&pidfile) {
        if sysutil::pid_alive(pid) && sysutil::pid_cmdline_contains(pid, "tarn") {
            println!("[Tarn] 发送 SIGHUP 到 daemon (pid={})", pid);
            daemon::signal_daemon(&pidfile, libc::SIGHUP)?;
            println!("[OK] SIGHUP 已发送");
            return Ok(());
        }
    }

    // 没有 daemon 运行, 直接验证配置
    println!("[Tarn] daemon 未运行, 仅校验配置语法");
    let mut ok = true;
    match Settings::load(&config_dir.join("config/settings.toml")) {
        Ok(_) => println!("[OK] settings.toml 解析成功"),
        Err(e) => { println!("[FAIL] settings.toml 解析失败: {}", e); ok = false; }
    }
    match Blacklist::load(&config_dir.join("config/blacklist.toml")) {
        Ok(b) => println!("[OK] blacklist.toml 解析成功 ({} 条规则)", b.rule.len()),
        Err(e) => { println!("[FAIL] blacklist.toml 解析失败: {}", e); ok = false; }
    }
    match Whitelist::load(&config_dir.join("config/whitelist.toml")) {
        Ok(w) => {
            let total = w.protect.len() + w.protect_package.len() + w.protect_ext.len() + w.protect_mtime.len();
            println!("[OK] whitelist.toml 解析成功 ({} 项保护)", total);
        }
        Err(e) => { println!("[FAIL] whitelist.toml 解析失败: {}", e); ok = false; }
    }
    if !ok {
        std::process::exit(1);
    }
    Ok(())
}

fn run_webui(config_dir: PathBuf, bind: String, port: Option<u16>) -> Result<()> {
    let handle = reload::init_config(config_dir.clone())?;
    let (port, bind) = {
        let cfg = handle.read();
        let port = port.unwrap_or(cfg.settings.webui.port);
        let bind = if bind.is_empty() { cfg.settings.webui.bind.clone() } else { bind };
        (port, bind)
    };
    println!("[Tarn] WebUI 启动中... http://{}:{}", bind, port);
    tarn_webui::serve(config_dir, handle, bind, port)
}

fn run_daemon_cmd(config_dir: PathBuf) -> Result<()> {
    // 在 spawn logger/webui 线程之前阻塞 daemon 信号,
    // 确保所有后续线程继承此掩码, 信号只被 run_daemon 内的 sigwait 线程捕获。
    daemon::block_daemon_signals()?;

    // 在 spawn 任何线程之前忽略 SIGPIPE
    // (写日志/状态文件/WebUI socket 时若对端关闭, 默认 SIGPIPE 会终止 daemon)
    // 必须在 spawn WebUI/logger 线程之前调用, 信号处置是进程级属性, 新线程继承。
    sysutil::ignore_sigpipe();

    let handle = reload::init_config(config_dir.clone())?;
    let logger = {
        let cfg = handle.read();
        make_logger(&config_dir, &cfg.settings)?
    };
    logger.info("main", &format!("Tarn daemon 启动, config_dir={}", config_dir.display()));
    logger.info("main", "SIGPIPE 处置已设为 SIG_IGN");

    // ============ 内嵌 WebUI HTTP 服务 ============
    // daemon 启动时在独立线程内拉起 axum (自身 tokio runtime),
    // 与 cron 主循环并发跑, 进程退出时线程随之结束。
    // 确保 service.sh 拉起 daemon 后端口 8080 立即监听, 避免浏览器访问被拒。
    {
        let cfg = handle.read();
        let webui_enabled = cfg.settings.webui.enabled;
        let bind = cfg.settings.webui.bind.clone();
        let port = cfg.settings.webui.port;
        drop(cfg);

        if webui_enabled {
            let config_dir_clone = config_dir.clone();
            let handle_clone = handle.clone();
            let logger_clone = logger.clone();
            std::thread::Builder::new()
                .name("tarn-webui".to_string())
                .spawn(move || {
                    logger_clone.info("webui", &format!("内嵌 WebUI 启动: http://{}:{}", bind, port));
                    // tarn_webui::serve 内部自建 tokio runtime 并 block_on, 阻塞此线程
                    if let Err(e) = tarn_webui::serve(config_dir_clone, handle_clone, bind, port) {
                        logger_clone.error("webui", &format!("WebUI 服务退出 (错误): {}", e));
                    } else {
                        logger_clone.info("webui", "WebUI 服务退出");
                    }
                })?;
            logger.info("main", "WebUI 线程已 spawn");
        } else {
            logger.info("main", "webui.enabled=false, 跳过内嵌 WebUI");
        }
    }

    let ctx = DaemonContext::new(config_dir, handle, logger)?;
    daemon::run_daemon(ctx)
}

fn run_enable(config_dir: PathBuf, rule_id: String, enable: bool) -> Result<()> {
    // 读 blacklist.toml, 修改对应规则的 enabled, 写回
    let path = config_dir.join("config/blacklist.toml");
    let content = std::fs::read_to_string(&path)?;
    let mut blacklist: Blacklist = toml::from_str(&content)
        .map_err(|e| anyhow::anyhow!("解析 blacklist.toml 失败: {}", e))?;

    let mut found = false;
    for rule in &mut blacklist.rule {
        if rule.id == rule_id {
            rule.enabled = enable;
            found = true;
            break;
        }
    }
    if !found {
        return Err(anyhow::anyhow!("规则不存在: {}", rule_id));
    }

    // 原子写回
    let new_content = toml::to_string_pretty(&blacklist)
        .map_err(|e| anyhow::anyhow!("序列化失败: {}", e))?;
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, &new_content)?;
    std::fs::rename(&tmp, &path)?;

    println!("{} 规则: {}", if enable { "[OK] 启用" } else { "[OFF] 禁用" }, rule_id);

    // 若 daemon 在运行, 发 SIGHUP 热重载
    let pidfile = config_dir.join("run/tarn.pid");
    if let Some(pid) = sysutil::read_pidfile(&pidfile) {
        if sysutil::pid_alive(pid) && sysutil::pid_cmdline_contains(pid, "tarn") {
            let _ = daemon::signal_daemon(&pidfile, libc::SIGHUP);
            println!("[Tarn] 已通知 daemon 热重载 (pid={})", pid);
        }
    }
    Ok(())
}

fn run_config(config_dir: PathBuf, action: ConfigAction) -> Result<()> {
    let path = config_dir.join("config/settings.toml");
    match action {
        ConfigAction::List => {
            let content = std::fs::read_to_string(&path)?;
            let settings: Settings = toml::from_str(&content)
                .map_err(|e| anyhow::anyhow!("解析失败: {}", e))?;
            let toml_out = toml::to_string_pretty(&settings)
                .map_err(|e| anyhow::anyhow!("序列化失败: {}", e))?;
            println!("{}", toml_out);
        }
        ConfigAction::Get { key } => {
            let content = std::fs::read_to_string(&path)?;
            let settings: Settings = toml::from_str(&content)
                .map_err(|e| anyhow::anyhow!("解析失败: {}", e))?;
            // 简单实现: 按点号路径取值
            let json = serde_json::to_value(&settings)?;
            let v = key.split('.').fold(json, |acc, k| acc.get(k).cloned().unwrap_or(serde_json::Value::Null));
            if v.is_null() {
                println!("(未找到: {})", key);
            } else {
                println!("{}", v);
            }
        }
        ConfigAction::Set { key, value } => {
            // 读 → 改 (JSON 路径) → 写
            let content = std::fs::read_to_string(&path)?;
            let settings: Settings = toml::from_str(&content)
                .map_err(|e| anyhow::anyhow!("解析失败: {}", e))?;
            let mut json = serde_json::to_value(&settings)?;

            // 简单实现: 仅支持一级 key (如 engine.parallel_workers)
            let parts: Vec<&str> = key.split('.').collect();
            if parts.len() == 2 {
                if let Some(section) = json.get_mut(parts[0]) {
                    if let Some(v) = section.get_mut(parts[1]) {
                        // 尝试解析为不同类型
                        if let Ok(n) = value.parse::<i64>() {
                            *v = serde_json::Value::from(n);
                        } else if let Ok(b) = value.parse::<bool>() {
                            *v = serde_json::Value::from(b);
                        } else {
                            *v = serde_json::Value::String(value.clone());
                        }
                        println!("[OK] 设置 {} = {}", key, value);
                    } else {
                        return Err(anyhow::anyhow!("字段不存在: {}", parts[1]));
                    }
                } else {
                    return Err(anyhow::anyhow!("段不存在: {}", parts[0]));
                }
            } else {
                return Err(anyhow::anyhow!("仅支持 section.field 格式"));
            }

            // 转回 Settings 再写回 TOML
            let new_settings: Settings = serde_json::from_value(json)
                .map_err(|e| anyhow::anyhow!("反序列化失败: {}", e))?;
            let toml_out = toml::to_string_pretty(&new_settings)
                .map_err(|e| anyhow::anyhow!("序列化失败: {}", e))?;
            let tmp = path.with_extension("tmp");
            std::fs::write(&tmp, &toml_out)?;
            std::fs::rename(&tmp, &path)?;
            println!("[OK] 已保存到 {}", path.display());

            // 通知 daemon
            let pidfile = config_dir.join("run/tarn.pid");
            if let Some(pid) = sysutil::read_pidfile(&pidfile) {
                if sysutil::pid_alive(pid) && sysutil::pid_cmdline_contains(pid, "tarn") {
                    let _ = daemon::signal_daemon(&pidfile, libc::SIGHUP);
                    println!("[Tarn] 已通知 daemon 热重载");
                }
            }
        }
    }
    Ok(())
}

fn run_log(config_dir: PathBuf, tail: usize) -> Result<()> {
    let log_path = config_dir.join("logs/tarn.log");
    if !log_path.exists() {
        println!("(无日志文件: {})", log_path.display());
        return Ok(());
    }
    let content = std::fs::read_to_string(&log_path)?;
    let lines: Vec<&str> = content.lines().collect();
    let start = if lines.len() > tail { lines.len() - tail } else { 0 };
    for line in &lines[start..] {
        println!("{}", line);
    }
    Ok(())
}

fn format_bytes(bytes: u64) -> String {
    const KB: u64 = 1024;
    const MB: u64 = KB * 1024;
    const GB: u64 = MB * 1024;
    const TB: u64 = GB * 1024;
    if bytes >= TB {
        format!("{:.2} TB", bytes as f64 / TB as f64)
    } else if bytes >= GB {
        format!("{:.2} GB", bytes as f64 / GB as f64)
    } else if bytes >= MB {
        format!("{:.2} MB", bytes as f64 / MB as f64)
    } else if bytes >= KB {
        format!("{:.2} KB", bytes as f64 / KB as f64)
    } else {
        format!("{} B", bytes)
    }
}

fn run_notify_error(config_dir: PathBuf, title: String, msg: String, force: bool) -> Result<()> {
    if force {
        notify::reset_rate_limit(&config_dir);
    }
    println!("[Tarn] 发送错误通知: {} - {}", title, msg);
    notify::send_notification_force(&title, &msg)?;
    println!("[OK] 通知已发送");
    Ok(())
}

fn run_debug_cmd(config_dir: PathBuf) -> Result<()> {
    println!("[Tarn] 运行 debug.sh 收集诊断快照...");
    match notify::run_debug_sh() {
        Ok(()) => {
            println!("[OK] debug.sh 已在后台启动");
            println!("     诊断包: {}/logs/debug-<时间戳>.tar.gz", config_dir.display());
            println!("     解压: tar xzf debug-<时间戳>.tar.gz");
            Ok(())
        }
        Err(e) => {
            println!("[FAIL] debug.sh 启动失败: {}", e);
            println!("       请确认模块已正确安装: /data/adb/modules/tarn/debug.sh");
            Err(e)
        }
    }
}
