//! 保护层: 路径白名单校验 + 用户自定义白名单匹配
//!
//! 保护判断顺序:
//! 1. 路径白名单 ([`is_target_allowed`]): target.path 必须落在 [`ALLOWED_ROOTS`] 下,
//!    且不能命中 [`HARDCODED_PROTECT`] (即便在 ALLOWED_ROOTS 下也拒)。
//!    例外: [`HARDCODED_ALLOW`] 下的路径放行 (如 /data/adb/tarn/rules)。
//! 2. [`ProtectSet::check`] (用户自定义保护, 在 whitelist.toml 配置):
//!    - protect_path (prefix/glob)
//!    - protect_package
//!    - protect_ext
//!    - protect_mtime
//! 3. 都没命中 → 允许删除
//!
//! 路径白名单是强安全栅栏 (创建规则时 + 执行时双重校验), 防止误删系统目录。

use crate::config::Whitelist;
use std::collections::HashSet;
use std::path::Path;
use std::time::SystemTime;

/// 允许清理的根目录前缀 (路径白名单)。
/// target.path 必须落在这些根之下才允许执行, 否则拒绝 (防误删系统/关键目录)。
pub const ALLOWED_ROOTS: &[&str] = &[
    "/data/data",           // App 数据 (缓存/崩溃/临时)
    "/data/user",           // App 数据 (多用户 /data/user/0/<pkg>)
    "/data/anr",            // 应用无响应 (ANR) 崩溃记录
    "/data/local/tmp",      // 本地临时文件
    "/data/system/dropbox", // 系统崩溃 dropbox
    "/data/tombstones",     // 原生崩溃 tombstone
    "/sdcard",              // 外置存储 (用户文件)
    "/storage/emulated",    // 外置存储 (另一种路径)
    "/data/adb/tarn/rules", // Tarn 规则包目录 (清理规则产生的临时文件)
];

/// 硬编码保护目录 (即便落在 ALLOWED_ROOTS 下也绝不删)。
/// 这些是系统/引导/Tarn 自身的关键目录, 删除会导致变砖或模块失效。
const HARDCODED_PROTECT: &[&str] = &[
    "/system",
    "/vendor",
    "/product",
    "/apex",
    "/data/adb", // Magisk/KernelSU 模块根
    "/data/adb/magisk",
    "/data/adb/modules",
    "/data/adb/tarn", // Tarn 自身 (配置/状态/日志)
    "/data/adb/tarn/config",
    "/data/adb/tarn/state.json",
    "/data/adb/tarn/logs",
];

/// Tarn 自身放行子目录 (规则包临时文件可清, 但不删 Tarn 主目录)。
const HARDCODED_ALLOW: &[&str] = &[
    "/data/adb/tarn/rules", // 规则包解压临时文件
];

/// 规范化路径: 折叠多余 / , 解析 . 和 .., 去掉末尾 / (根除外)。
/// 用于路径校验前的一致化, 防止 `/data/data//../adb` 之类绕过白名单。
fn normalize_path(p: &str) -> String {
    if p.is_empty() {
        return String::new();
    }
    let mut parts: Vec<&str> = Vec::new();
    let is_abs = p.starts_with('/');
    for seg in p.split('/') {
        match seg {
            "" | "." => {}
            ".." => {
                if !parts.is_empty() {
                    parts.pop();
                }
            }
            other => parts.push(other),
        }
    }
    let joined = parts.join("/");
    if is_abs {
        if joined.is_empty() {
            "/".to_string()
        } else {
            format!("/{}", joined)
        }
    } else {
        joined
    }
}

/// 检查 target 路径是否允许清理 (路径白名单 + 硬编码保护)。
///
/// 返回 `Ok(())` 表示允许, `Err(reason)` 表示拒绝 (reason 是给用户看的中文说明)。
///
/// 校验逻辑:
/// 1. 规范化路径 (折叠 `//` / `.` / `..`)
/// 2. 必须以 `/` 开头 (绝对路径)
/// 3. 不能落在 [`HARDCODED_PROTECT`] 下 (即便在 [`ALLOWED_ROOTS`] 下也拒)
///    - 例外: [`HARDCODED_ALLOW`] 下的路径放行 (如 `/data/adb/tarn/rules`)
/// 4. 必须落在 [`ALLOWED_ROOTS`] 某个根之下
pub fn is_target_allowed(path: &str) -> Result<(), String> {
    let norm = normalize_path(path);
    if !norm.starts_with('/') {
        return Err(format!("路径必须以 / 开头: {}", path));
    }
    // 硬编码保护检查 (优先级最高)
    for hp in HARDCODED_PROTECT {
        if path_in_prefix(&norm, hp) {
            // 检查是否在 HARDCODED_ALLOW 放行子目录
            let allowed = HARDCODED_ALLOW.iter().any(|ha| path_in_prefix(&norm, ha));
            if !allowed {
                return Err(format!("路径在系统保护目录内, 不允许清理: {}", norm));
            }
        }
    }
    // 白名单根检查
    let in_allowed = ALLOWED_ROOTS.iter().any(|root| path_in_prefix(&norm, root));
    if !in_allowed {
        return Err(format!(
            "路径不在允许清理的范围内: {}\n允许的目录: {}",
            norm,
            ALLOWED_ROOTS.join(", ")
        ));
    }
    Ok(())
}

/// 路径前缀匹配: 严格路径组件匹配, 避免字符串前缀旁路
///
/// 问题: `"/data/adb/tarn/rules_evil".starts_with("/data/adb/tarn/rules")` 返回 true,
/// 导致 `/data/adb/tarn/rules_evil` 被误判为放行路径。
///
/// 修复: 必须是完整路径相等, 或后面紧贴路径分隔符 `/`。
fn path_in_prefix(path: &str, prefix: &str) -> bool {
    if path == prefix {
        return true;
    }
    // 必须以 `prefix + "/"` 开头, 避免子字符串误匹配
    let prefix_with_slash = if prefix.ends_with('/') {
        prefix.to_string()
    } else {
        format!("{}/", prefix)
    };
    path.starts_with(&prefix_with_slash)
}

/// 编译后的保护集合
#[derive(Debug, Clone)]
pub struct ProtectSet {
    /// prefix 匹配 (含硬编码 + protect_path match=prefix)
    prefix: HashSet<String>,
    /// glob 匹配 (DFA)
    glob: globset::GlobSet,
    /// 包名保护 (包名 → 仅子目录列表, None=全保护)
    packages: std::collections::HashMap<String, Option<HashSet<String>>>,
    /// 扩展名保护 (小写, 无点) → scope (global=空串 或 路径前缀)
    exts: Vec<(HashSet<String>, String)>,
    /// mtime 保护 (within_days, scope)
    mtime: Vec<(u32, String)>,
}

impl ProtectSet {
    /// 从 whitelist.conf 编译用户自定义保护集
    pub fn compile(wl: &Whitelist) -> Result<Self, String> {
        let mut prefix: HashSet<String> = HashSet::new();
        let mut glob_patterns: Vec<globset::Glob> = Vec::new();

        // 1. protect_path (path 自动判断 glob/prefix)
        //    - path 含通配符 (* ? [) → glob 匹配 (用 globset DFA)
        //    - 否则 → prefix 匹配 (最常用, 保护该目录及其所有子内容)
        for pp in &wl.protect {
            if pp.is_glob() {
                let g = globset::Glob::new(&pp.path)
                    .map_err(|e| format!("glob 编译失败 {}: {}", pp.path, e))?;
                glob_patterns.push(g);
            } else {
                prefix.insert(pp.path.clone());
            }
        }

        let mut glob_builder = globset::GlobSetBuilder::new();
        for g in &glob_patterns {
            glob_builder.add(g.clone());
        }
        let glob = glob_builder
            .build()
            .map_err(|e| format!("GlobSet 构建失败: {}", e))?;

        // 3. protect_package
        let mut packages: std::collections::HashMap<String, Option<HashSet<String>>> =
            std::collections::HashMap::new();
        for pk in &wl.protect_package {
            let only = if pk.only.is_empty() {
                None
            } else {
                Some(pk.only.iter().cloned().collect())
            };
            packages.insert(pk.package.clone(), only);
        }

        // 4. protect_ext
        let mut exts: Vec<(HashSet<String>, String)> = Vec::new();
        for pe in &wl.protect_ext {
            let set: HashSet<String> = pe
                .extensions
                .iter()
                .map(|e| e.trim_start_matches('.').to_lowercase())
                .collect();
            let scope = if pe.scope == "global" {
                String::new()
            } else {
                pe.scope.clone()
            };
            exts.push((set, scope));
        }

        // 5. protect_mtime
        let mut mtime: Vec<(u32, String)> = Vec::new();
        for pm in &wl.protect_mtime {
            let scope = if pm.scope == "global" {
                String::new()
            } else {
                pm.scope.clone()
            };
            mtime.push((pm.within_days, scope));
        }

        Ok(Self {
            prefix,
            glob,
            packages,
            exts,
            mtime,
        })
    }

    /// 检查给定路径是否被保护
    ///
    /// 返回 Some(reason) 表示被保护, None 表示可删
    pub fn check(&self, path: &Path, mtime: Option<SystemTime>) -> Option<&'static str> {
        let path_str = path.to_string_lossy();

        // 1. prefix 匹配 (protect_path prefix)
        for p in &self.prefix {
            if path_in_prefix(&path_str, p) {
                return Some("blocked_prefix");
            }
        }

        // 2. glob 匹配
        if self.glob.is_match(path) {
            return Some("blocked_glob");
        }

        // 3. protect_package: 匹配 /data/data/<pkg>/ 或 /data/user/0/<pkg>/
        if let Some(pkg) = extract_package_from_path(&path_str) {
            if let Some(only) = self.packages.get(&pkg) {
                match only {
                    None => return Some("blocked_package"),
                    Some(subs) => {
                        // 检查子目录是否在 only 列表
                        if let Some(subdir) = extract_subdir_from_path(&path_str, &pkg) {
                            if subs.contains(&subdir) {
                                return Some("blocked_package");
                            }
                        }
                    }
                }
            }
        }

        // 4. protect_ext
        // 修复 R6: scope 用 path_in_prefix 严格路径组件匹配, 避免
        // scope="/data/data/com.foo" 误匹配 "/data/data/com.foobar/..."
        if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
            let ext_lower = ext.to_lowercase();
            for (set, scope) in &self.exts {
                if set.contains(&ext_lower) {
                    if scope.is_empty() || path_in_prefix(&path_str, scope) {
                        return Some("blocked_ext");
                    }
                }
            }
        }

        // 5. protect_mtime (同样修复 R6: scope 用 path_in_prefix)
        if let Some(mtime_val) = mtime {
            if let Ok(now) = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH) {
                if let Ok(file_age) = mtime_val.duration_since(SystemTime::UNIX_EPOCH) {
                    for (within_days, scope) in &self.mtime {
                        let age_sec = now.as_secs().saturating_sub(file_age.as_secs());
                        let within_sec = (*within_days as u64) * 86400;
                        if age_sec < within_sec {
                            if scope.is_empty() || path_in_prefix(&path_str, scope) {
                                return Some("blocked_mtime");
                            }
                        }
                    }
                }
            }
        }

        None
    }
}

/// 从路径提取包名 (支持 /data/data/<pkg>/... 和 /data/user/0/<pkg>/...)
fn extract_package_from_path(path: &str) -> Option<String> {
    if let Some(rest) = path.strip_prefix("/data/data/") {
        let pkg = rest.split('/').next()?;
        return Some(pkg.to_string());
    }
    if let Some(rest) = path.strip_prefix("/data/user/") {
        // /data/user/0/<pkg>/...
        let parts: Vec<&str> = rest.splitn(3, '/').collect();
        if parts.len() >= 2 {
            return Some(parts[1].to_string());
        }
    }
    None
}

/// 从 /data/data/<pkg>/<subdir>/... 或 /data/user/<id>/<pkg>/<subdir>/... 提取 subdir
/// (修复 M4: 支持任意 user_id, 不再硬编码 0)
fn extract_subdir_from_path(path: &str, pkg: &str) -> Option<String> {
    let prefix = format!("/data/data/{}/", pkg);
    if let Some(rest) = path.strip_prefix(&prefix) {
        let subdir = rest.split('/').next()?;
        return Some(subdir.to_string());
    }
    // /data/user/<任意 id>/<pkg>/...
    if let Some(rest) = path.strip_prefix("/data/user/") {
        let parts: Vec<&str> = rest.splitn(3, '/').collect();
        // parts[0] = user_id, parts[1] = pkg, parts[2] = rest
        if parts.len() >= 3 && parts[1] == pkg {
            let subdir = parts[2].split('/').next()?;
            return Some(subdir.to_string());
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_path_in_prefix_strict() {
        // 完全相等
        assert!(path_in_prefix("/data/adb/tarn/rules", "/data/adb/tarn/rules"));
        // 正常子路径
        assert!(path_in_prefix("/data/adb/tarn/rules/x.toml", "/data/adb/tarn/rules"));
        assert!(path_in_prefix("/data/adb/tarn/rules/sub/y.toml", "/data/adb/tarn/rules"));
        // 关键: 字符串前缀但非路径组件必须返回 false (C3 修复回归)
        assert!(!path_in_prefix("/data/adb/tarn/rules_evil", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("/data/adb/tarn/rulessecret", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("/data/adb/tarn/logs_evil/x", "/data/adb/tarn/logs"));
        // 空路径
        assert!(!path_in_prefix("/", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("", "/data/adb/tarn/rules"));
    }

    #[test]
    fn test_extract_subdir_multi_user() {
        // /data/data/<pkg>/<sub>/...
        assert_eq!(
            extract_subdir_from_path("/data/data/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        // /data/user/0/<pkg>/<sub>/... (M4: 任意 user_id)
        assert_eq!(
            extract_subdir_from_path("/data/user/0/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        // M4 修复: user_id=10 也能匹配
        assert_eq!(
            extract_subdir_from_path("/data/user/10/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        assert_eq!(
            extract_subdir_from_path("/data/user/11/com.foo/files/y.db", "com.foo"),
            Some("files".to_string())
        );
        // 包名不匹配
        assert_eq!(
            extract_subdir_from_path("/data/user/0/com.bar/cache/x.tmp", "com.foo"),
            None
        );
    }

    // ===== normalize_path 单元测试 =====

    #[test]
    fn test_normalize_path_basic() {
        // 基本路径不变
        assert_eq!(normalize_path("/data/data/com.foo"), "/data/data/com.foo");
        assert_eq!(normalize_path("/sdcard/Download/x"), "/sdcard/Download/x");
    }

    #[test]
    fn test_normalize_path_dotdot() {
        // .. 折叠到上一级
        assert_eq!(normalize_path("/data/data/../adb"), "/data/adb");
        assert_eq!(normalize_path("/a/b/c/../../d"), "/a/d");
        // .. 超过根目录边界, 不再向上 (根的 .. = 根)
        assert_eq!(normalize_path("/../etc"), "/etc");
        assert_eq!(normalize_path("/../../etc"), "/etc");
    }

    #[test]
    fn test_normalize_path_trailing_slash_and_collapsed() {
        // 末尾 / 去掉 (根除外)
        assert_eq!(normalize_path("/data/data/"), "/data/data");
        assert_eq!(normalize_path("/data/data//"), "/data/data");
        // 多余 / 折叠
        assert_eq!(normalize_path("/data//data///com.foo"), "/data/data/com.foo");
        // 根保留
        assert_eq!(normalize_path("/"), "/");
        assert_eq!(normalize_path("///"), "/");
        // . 折叠
        assert_eq!(normalize_path("/data/./data/./com.foo"), "/data/data/com.foo");
    }

    #[test]
    fn test_normalize_path_empty_and_relative() {
        // 空字符串
        assert_eq!(normalize_path(""), "");
        // 相对路径保持相对
        assert_eq!(normalize_path("foo/bar"), "foo/bar");
        assert_eq!(normalize_path("foo/../bar"), "bar");
        assert_eq!(normalize_path("./foo"), "foo");
    }

    // ===== is_target_allowed 单元测试 =====

    #[test]
    fn test_is_target_allowed_app_data() {
        // /data/data/<pkg>/cache 在白名单内
        assert!(is_target_allowed("/data/data/com.foo/cache").is_ok());
        // 深层子路径也允许
        assert!(is_target_allowed("/data/data/com.foo/cache/sub/deep").is_ok());
        // /data/user/0/<pkg>/... 允许
        assert!(is_target_allowed("/data/user/0/com.foo/cache").is_ok());
        assert!(is_target_allowed("/data/user/10/com.foo/files/x").is_ok());
    }

    #[test]
    fn test_is_target_allowed_tarn_rules() {
        // /data/adb/tarn/rules 是 HARDCODED_ALLOW 例外, 允许清理
        assert!(is_target_allowed("/data/adb/tarn/rules/x").is_ok());
        assert!(is_target_allowed("/data/adb/tarn/rules/sub/y.toml").is_ok());
        // 但 /data/adb/tarn 自身被 HARDCODED_PROTECT 拒绝
        assert!(is_target_allowed("/data/adb/tarn").is_err());
        assert!(is_target_allowed("/data/adb/tarn/config").is_err());
        assert!(is_target_allowed("/data/adb/tarn/state.json").is_err());
        assert!(is_target_allowed("/data/adb/tarn/logs").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_system() {
        // /system 被硬编码保护拒绝
        assert!(is_target_allowed("/system").is_err());
        assert!(is_target_allowed("/system/bin/x").is_err());
        // /vendor /product /apex 同理
        assert!(is_target_allowed("/vendor").is_err());
        assert!(is_target_allowed("/product").is_err());
        assert!(is_target_allowed("/apex").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_data_adb() {
        // /data/adb 整个根被 HARDCODED_PROTECT 拒绝 (除 /data/adb/tarn/rules 例外)
        assert!(is_target_allowed("/data/adb").is_err());
        assert!(is_target_allowed("/data/adb/magisk").is_err());
        assert!(is_target_allowed("/data/adb/modules/x").is_err());
        assert!(is_target_allowed("/data/adb/tarn/config").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_relative() {
        // 相对路径必须拒绝
        assert!(is_target_allowed("relative/path").is_err());
        assert!(is_target_allowed("foo").is_err());
        assert!(is_target_allowed("").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_etc() {
        // /etc 不在白名单也不在硬编码保护, 走白名单根检查拒绝
        assert!(is_target_allowed("/etc").is_err());
        assert!(is_target_allowed("/etc/passwd").is_err());
        // /proc /sys 同理
        assert!(is_target_allowed("/proc").is_err());
        assert!(is_target_allowed("/sys").is_err());
        // /data 自身不在白名单 (只有 /data/data /data/user 等子目录在)
        assert!(is_target_allowed("/data").is_err());
        assert!(is_target_allowed("/data/misc").is_err());
    }

    #[test]
    fn test_is_target_allowed_bypass_dotdot() {
        // 穿越尝试: /data/data/../adb → 规范化为 /data/adb → 命中 HARDCODED_PROTECT
        assert!(is_target_allowed("/data/data/../adb").is_err());
        // /data/user/0/com.foo/../../../adb → /data/adb
        assert!(is_target_allowed("/data/user/0/com.foo/../../../adb").is_err());
        // /sdcard/../adb → /adb (不在白名单)
        assert!(is_target_allowed("/sdcard/../adb").is_err());
        // /data/data/com.foo/../../system → /data/system (不在白名单)
        assert!(is_target_allowed("/data/data/com.foo/../../system").is_err());
    }

    #[test]
    fn test_is_target_allowed_sdcard() {
        // /sdcard 用户文件目录允许
        assert!(is_target_allowed("/sdcard/Download").is_ok());
        assert!(is_target_allowed("/sdcard/DCIM/Camera").is_ok());
        // /storage/emulated/0/... 同理
        assert!(is_target_allowed("/storage/emulated/0/Download").is_ok());
        // 其他允许根
        assert!(is_target_allowed("/data/anr").is_ok());
        assert!(is_target_allowed("/data/local/tmp/x.tmp").is_ok());
        assert!(is_target_allowed("/data/tombstones").is_ok());
        assert!(is_target_allowed("/data/system/dropbox/x").is_ok());
    }

    #[test]
    fn test_is_target_allowed_trailing_slash_and_collapse() {
        // 末尾 / 被规范化掉, 不影响判断
        assert!(is_target_allowed("/data/data/com.foo/cache/").is_ok());
        // 多余 / 被折叠
        assert!(is_target_allowed("/data//data//com.foo/cache").is_ok());
        // 末尾 / 后接被拒绝路径仍要拒
        assert!(is_target_allowed("/system/").is_err());
    }

    #[test]
    fn test_allowed_roots_no_substring_bypass() {
        // 关键回归: /data/datacom.foo 不是 /data/data 子路径 (字符串前缀但非路径组件)
        // path_in_prefix 严格路径组件匹配, 不应被误放行
        assert!(is_target_allowed("/data/datacom.foo").is_err());
        // /data/databar 同理
        assert!(is_target_allowed("/data/databar/x").is_err());
        // /data/adb/tarn/rules_evil 不是 /data/adb/tarn/rules 子路径
        // 它命中 HARDCODED_PROTECT 的 /data/adb/tarn 但不在 HARDCODED_ALLOW → 拒绝
        assert!(is_target_allowed("/data/adb/tarn/rules_evil").is_err());
    }
}
