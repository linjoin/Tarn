//! 系统调用工具: 低功耗 + 高性能调优
//!
//! 基于 RESEARCH-4 调研结论 + v0.2.1 理论验证 (搜索 Baidu/CSDN/Zhihu/GitHub/Juejin/Google):
//! - `nice(19)` 把进程优先级降到最低, 不与前台争 CPU
//!   理论依据: Linux CFS 调度器用 nice 值计算时间片权重 (weight = 1024 * 1.25^(-nice)),
//!   nice 19 → weight ~15, 占 CPU 约 1.5%。Android Bionic libc 完整支持 setpriority(2),
//!   内核一定遵守。✓ 在所有 Android 设备上有效 (kernel.org/scheduler/sched-design-CFS)。
//! - `ioprio_set(IOPRIO_CLASS_IDLE)` — **v0.2.1 已移除**
//!   理论依据: ionice IDLE 类仅在 CFQ/BFQ 调度器下生效 (kernel/block/ioprio.c)。
//!   CFQ 调度器在内核 5.x 已被移除; Android 的 UFS/eMMC 闪存默认用 mq-deadline /
//!   none / kyber 调度器, 这些调度器**完全忽略 ioprio**, IDLE 类调用是空操作。
//!   绝大多数 Android 设备上无效, 保留只会增加代码复杂度并误导用户, 故直接删除。
//! - `sched_setaffinity` 绑定到小核 (big.LITTLE 的 LITTLE cluster), 避免占大核
//!   理论依据: big.LITTLE 架构下小核频率低、性能弱, 绑核后 daemon 只在小核运行,
//!   不抢占大核导致前台 jank。Google NDK 工程师确认 cpuinfo_max_freq 可用于探测小核
//!   (cpu_capacity 更优但部分设备损坏, 故用 cpuinfo_max_freq + 兜底)。
//! - `oom_score_adj` 调低, 防 OOM killer 误杀 daemon
//!
//! [v0.1.11 CPU 亲和性遗漏问题修复]
//!   v0.1.10 曾因"per-thread 遗漏"移除了 sched_setaffinity, 但正确做法是修复而非删除。
//!   遗漏根因: Linux 上 sched_setaffinity(pid=0) 只设调用线程, 已 spawn 的线程
//!   (logger / webui / tokio worker) 不受影响。
//!
//!   修复方案 ([`set_cpu_affinity_all_threads`]):
//!   1. 先设当前线程 (pid=0), 后续 spawn 的线程继承此 affinity
//!   2. 遍历 /proc/self/task/<tid> 对每个已存在的线程单独调 sched_setaffinity(tid)
//!   这样既覆盖已 spawn 的线程 (logger/webui/tokio), 又覆盖未来 spawn 的线程, 无遗漏。
//!   ESRCH (线程刚退出) 静默跳过, 其他错误记录但不中断。
//!
//!   小核探测 ([`detect_little_cores`]): 读 /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq,
//!   取频率最低的那组, 容忍 ±5% 同频误差。失败回退 [0,1,2,3]。
//!
//! 空闲时 CPU 占用: daemon 主循环 timerfd poll(-1) 阻塞, logger 线程 rx.recv() 阻塞,
//! 信号线程 sigwait 阻塞, WebUI tokio epoll park — 全部 0 CPU, 不与前台争资源。
//! v0.2.0: 移除 tail_log_to_broadcast 后台轮询 (原 300ms/5s 轮询日志文件), 日志改为
//! 用户手动刷新 (/api/logs/recent), 彻底消除 WebUI 空闲时的周期性 CPU 唤醒。
//!
//! 这些都是 root 进程特权操作, 普通用户调用会失败但不会 panic (优雅降级)。

use std::io;

// ============================================================
// 常量定义
// ============================================================

/// nice 最高优先级降到 19 (最低)
pub const NICE_LOWEST: i32 = 19;

/// oom_score_adj 最低 (-1000 = 禁止被 OOM kill)
pub const OOM_SCORE_ADJ_MIN: i32 = -1000;
/// daemon 推荐值: -1000 (完全禁止被 OOM killer 杀死)
///
/// v0.4.4: 从 -900 改为 -1000。用户反馈定时任务清理完后 daemon 进程会消失,
/// 排查发现清理大批文件后系统内存压力上升, OOM killer 在 -900 仍有概率选中
/// daemon (尤其清理 SD Maid 系统级规则包涉及数千文件时)。改为 -1000 完全
/// 豁免, daemon 永远不会被 OOM kill, 保证 cron 调度连续性。
/// (daemon 自身内存占用稳定在 ~3MB, 不会成为内存大户; 让位系统已无必要)
pub const OOM_SCORE_ADJ_DAEMON: i32 = -1000;

// ============================================================
// 低功耗调优诊断报告 (v0.2.1)
// ============================================================

/// 低功耗调优诊断报告
///
/// 让用户清楚知道每项调优是否真正生效, 而不是 "调用了就当生效"。
/// nice 总是有效 (内核 CFS 保证); affinity 取决于权限。
///
/// (v0.2.1: ionice IDLE 已移除 — 在绝大多数 Android 设备的 mq-deadline / none /
/// kyber 调度器下是空操作, CFQ 调度器也已在内核 5.x 移除, 保留无意义。)
#[derive(Debug, Clone)]
pub struct LowPowerReport {
    /// nice 是否调用成功
    pub nice_applied: bool,
    /// nice 值 (19 = 最低优先级)
    pub nice_value: i32,
    /// CPU 亲和性是否调用成功
    pub affinity_applied: bool,
    /// 绑定的 CPU 核心列表
    pub affinity_cores: Vec<usize>,
    /// 各项操作的错误信息 (空 = 无错误)
    pub errors: Vec<String>,
}

impl LowPowerReport {
    /// 生成面向用户的单行摘要 (用于 module.prop description / 日志)
    pub fn summary_line(&self) -> String {
        let nice_str = if self.nice_applied {
            format!("nice={} ✓", self.nice_value)
        } else {
            "nice ✗".to_string()
        };
        let aff_str = if !self.affinity_cores.is_empty() && self.affinity_applied {
            format!("绑核 {:?} ✓", self.affinity_cores)
        } else if !self.affinity_cores.is_empty() {
            format!("绑核 {:?} ✗", self.affinity_cores)
        } else {
            "无绑核".to_string()
        };
        format!("{} | {}", nice_str, aff_str)
    }
}

// ============================================================
// 公开 API
// ============================================================

/// 应用低功耗调优: nice + (可选) CPU 亲和性
///
/// - `cpu_affinity` 为空: 跳过亲和性 (仅 nice)
/// - `cpu_affinity` 非空: 绑定到指定核心, 且通过 /proc/self/task 遍历覆盖所有线程
///
/// 组合: nice 19 让 CFS 调度器不优先调度 tarn (所有 Android 设备有效),
/// affinity 绑小核避免占大核导致前台 jank。空闲时 daemon 全程阻塞等待, 0 CPU。
///
/// (v0.2.1: 移除 ionice IDLE — 在绝大多数 Android 设备的 mq-deadline / none / kyber
/// 调度器下是空操作, CFQ 调度器也已在内核 5.x 移除, 保留无意义。)
///
/// 全部失败容错, 单项失败不影响其他。返回 [`LowPowerReport`] 诊断报告,
/// 调用方可据报告向用户展示每项调优是否真正生效。
pub fn apply_low_power(cpu_affinity: &[usize]) -> LowPowerReport {
    let mut report = LowPowerReport {
        nice_applied: false,
        nice_value: NICE_LOWEST,
        affinity_applied: false,
        affinity_cores: cpu_affinity.to_vec(),
        errors: Vec::new(),
    };

    // 1. nice — 内核 CFS 一定遵守, 所有 Android 设备有效
    if let Err(e) = set_nice(NICE_LOWEST) {
        report.errors.push(format!("nice({}): {}", NICE_LOWEST, e));
    } else {
        report.nice_applied = true;
    }

    // 2. CPU 亲和性 — 遍历 /proc/self/task 覆盖所有线程
    if !cpu_affinity.is_empty() {
        let aff_errs = set_cpu_affinity_all_threads(cpu_affinity);
        if aff_errs.is_empty() {
            report.affinity_applied = true;
        } else {
            report.errors.extend(aff_errs);
        }
    }

    report
}

/// 设置进程 nice 值 (优先级)
///
/// 用 `setpriority(PRIO_PROCESS, 0, value)` 替代 `nice()`,
/// 因为 nice() 的 -1 返回值歧义 (可能是合法值也可能是错误),
/// 而 setpriority 返回 0/-1 语义清晰, 且跨平台兼容 (Android Bionic 也支持)。
///
/// `value`: 19 = 最低优先级, -20 = 最高。root 可任意调。
pub fn set_nice(value: i32) -> io::Result<()> {
    let r = unsafe { libc::setpriority(libc::PRIO_PROCESS, 0, value) };
    if r < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

/// 设置 CPU 亲和性 (绑定到指定 CPU 核心) — 仅设当前线程
///
/// `sched_setaffinity(2)`: 把当前线程限制在这些 CPU 上跑。
/// big.LITTLE 上绑小核 (通常是 0-3) 避免占大核导致前台 jank。
///
/// 注意: Linux 上 sched_setaffinity 是 per-thread 的, 只影响调用线程。
/// 要覆盖进程内所有线程 (含已 spawn 的 logger/webui/tokio worker), 请用
/// [`set_cpu_affinity_all_threads`]。
pub fn set_cpu_affinity(cpus: &[usize]) -> io::Result<()> {
    if cpus.is_empty() {
        return Ok(());
    }
    let mut set: libc::cpu_set_t = unsafe { std::mem::zeroed() };
    for &cpu in cpus {
        // v0.5.1 修复 H5: 边界检查, 防 CPU_SET 越界写 (UB)。
        // CPU_SETSIZE = 1024, cpu >= 1024 会越界 __bits 数组 → 栈溢出/crash。
        if cpu >= 1024 {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("cpu_affinity 越界 (0-1023): {}", cpu),
            ));
        }
        // CPU_SET 宏: 设第 cpu 位
        unsafe { libc::CPU_SET(cpu, &mut set); }
    }
    let r = unsafe { libc::sched_setaffinity(0, std::mem::size_of::<libc::cpu_set_t>(), &set) };
    if r < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

/// 设置 CPU 亲和性到进程内所有线程 (修复 per-thread 遗漏问题)
///
/// [v0.1.11] 修复 v0.1.10 的遗漏问题:
/// Linux 上 sched_setaffinity(pid=0) 只设调用线程, 已 spawn 的线程不受影响。
/// daemon 启动顺序: logger 线程 + webui 线程 (含 tokio worker) 在 run_daemon 之前
/// 就已 spawn, 单纯在 run_daemon 里调 sched_setaffinity(0) 无法覆盖它们。
///
/// 修复策略:
/// 1. 先设当前线程 (pid=0) — 后续 spawn 的线程 (signal 等) 继承此 affinity
/// 2. 遍历 /proc/self/task/<tid>, 对每个已存在的线程单独调 sched_setaffinity(tid)
///    覆盖 logger / webui / tokio worker 等先于本函数 spawn 的线程
///
/// ESRCH (线程刚退出) 静默跳过, 其他错误收集返回但不中断。
/// 返回所有失败原因 (空 = 全成功)。
pub fn set_cpu_affinity_all_threads(cpus: &[usize]) -> Vec<String> {
    let mut errs = Vec::new();
    if cpus.is_empty() {
        return errs;
    }
    // 构造 cpu_set_t
    let mut set: libc::cpu_set_t = unsafe { std::mem::zeroed() };
    for &cpu in cpus {
        unsafe { libc::CPU_SET(cpu, &mut set); }
    }
    let set_size = std::mem::size_of::<libc::cpu_set_t>();

    // 1. 设当前线程 (pid=0), 后续新线程继承
    let r = unsafe { libc::sched_setaffinity(0, set_size, &set) };
    if r < 0 {
        errs.push(format!("sched_setaffinity(self): {}", io::Error::last_os_error()));
    }

    // 2. 遍历 /proc/self/task/<tid> 设所有已存在的线程
    //    覆盖 logger / webui / tokio worker 等先于本函数 spawn 的线程
    if let Ok(entries) = std::fs::read_dir("/proc/self/task") {
        for entry in entries.flatten() {
            let name = entry.file_name();
            let name_str = match name.to_str() {
                Some(s) => s,
                None => continue,
            };
            let tid: i32 = match name_str.parse() {
                Ok(t) => t,
                Err(_) => continue,
            };
            // 跳过 0 (实际 /proc/self/task 不会有 0, 防御)
            if tid == 0 {
                continue;
            }
            let r = unsafe { libc::sched_setaffinity(tid, set_size, &set) };
            if r < 0 {
                let e = io::Error::last_os_error();
                // ESRCH = 线程刚退出, 静默跳过 (遍历期间线程可能已退出)
                if e.raw_os_error() != Some(libc::ESRCH) {
                    errs.push(format!("sched_setaffinity(tid={}): {}", tid, e));
                }
            }
        }
    }

    errs
}

/// 探测小核 CPU 编号 (big.LITTLE)
///
/// 策略: 读 /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq,
/// 取频率最低的那组作为小核。失败则默认 0-3。
pub fn detect_little_cores() -> Vec<usize> {
    let mut freqs: Vec<(usize, u64)> = Vec::new();
    for i in 0..16 {
        let path = format!("/sys/devices/system/cpu/cpu{}/cpufreq/cpuinfo_max_freq", i);
        if let Ok(s) = std::fs::read_to_string(&path) {
            if let Ok(khz) = s.trim().parse::<u64>() {
                freqs.push((i, khz));
            }
        }
    }
    if freqs.is_empty() {
        return vec![0, 1, 2, 3];
    }
    // 取频率最低的 (小核), 多于 4 个时取前 4
    let mut sorted = freqs.clone();
    sorted.sort_by_key(|(_, f)| *f);
    let min_freq = sorted.first().map(|(_, f)| *f).unwrap_or(0);
    // 同频的都算小核 (容忍 ±5%)
    let threshold = min_freq + min_freq / 20;
    let little: Vec<usize> = sorted
        .iter()
        .filter(|(_, f)| *f <= threshold)
        .map(|(c, _)| *c)
        .take(4)
        .collect();
    if little.is_empty() {
        vec![0, 1, 2, 3]
    } else {
        little
    }
}

/// 设置 oom_score_adj (防 OOM kill)
///
/// 写 /proc/self/oom_score_adj, 范围 -1000 到 1000。
pub fn set_oom_score_adj(value: i32) -> io::Result<()> {
    std::fs::write("/proc/self/oom_score_adj", value.to_string())
}

/// v0.4.4: 忽略 SIGPIPE (防止管道写断终止 daemon)
///
/// 默认 SIGPIPE 处置 = Term (终止进程)。Android root daemon 写日志/状态/socket 时,
/// 若对端关闭, 内核投递 SIGPIPE, daemon 被杀。改用 SIG_IGN 后, write() 返回 EPIPE。
///
/// 信号处置是进程级属性, 任何线程调用后对所有线程生效。
/// 建议在 spawn 任何线程之前调用 (新线程继承信号处置)。
pub fn ignore_sigpipe() {
    unsafe {
        let _ = libc::signal(libc::SIGPIPE, libc::SIG_IGN);
    }
}

/// 读取指定 PID 进程的实际 nice 值 (从 /proc/<pid>/stat 第 19 字段)
///
/// 用于 WebUI 向用户展示 "daemon 的 nice 值确实是 19" 的铁证。
/// 失败返回 None。
pub fn read_proc_nice(pid: i32) -> Option<i32> {
    let stat = std::fs::read_to_string(format!("/proc/{}/stat", pid)).ok()?;
    // /proc/<pid>/stat 格式 (1-indexed, 见 man proc):
    //   1 pid 2 comm 3 state 4 ppid 5 pgrp 6 session 7 tty_nr 8 tpgid 9 flags
    //   10 minflt 11 cminflt 12 majflt 13 cmajflt 14 utime 15 stime
    //   16 cutime 17 cstime 18 priority 19 nice 20 num_threads ...
    // comm 可能含空格和括号, 从最后一个 ')' 之后开始解析字段。
    // rfind(')') 后 split_whitespace 的第一个字段是 field 3 (state),
    // 因此 fields 索引 = stat 字段号 - 3:
    //   fields[0]=state(3) fields[1]=ppid(4) ... fields[15]=priority(18)
    //   fields[16]=nice(19) fields[17]=num_threads(20)
    let after_comm = stat.rfind(')')?;
    let rest = &stat[after_comm + 1..];
    let fields: Vec<&str> = rest.split_whitespace().collect();
    // nice 是 stat 第 19 字段 = fields[16]
    fields.get(16).and_then(|s| s.parse::<i32>().ok())
}

/// 读取指定 PID 进程的 CPU 亲和性 (从 /proc/<pid>/status 的 Cpus_allowed_list)
///
/// 返回人类可读的格式如 "0-3" 或 "0,2-3"。用于 WebUI 展示 "daemon 确实绑在小核"。
/// 失败返回 None。
pub fn read_proc_cpus_allowed_list(pid: i32) -> Option<String> {
    let status = std::fs::read_to_string(format!("/proc/{}/status", pid)).ok()?;
    for line in status.lines() {
        if let Some(rest) = line.strip_prefix("Cpus_allowed_list:") {
            return Some(rest.trim().to_string());
        }
    }
    None
}

/// 获取当前进程 PID
pub fn current_pid() -> i32 {
    unsafe { libc::getpid() }
}

/// 获取当前进程 UID
pub fn current_uid() -> u32 {
    unsafe { libc::getuid() }
}

/// 检查是否 root
pub fn is_root() -> bool {
    current_uid() == 0
}

/// 检查指定 PID 是否存活
pub fn pid_alive(pid: i32) -> bool {
    // kill(pid, 0) 返回 0 表示存活
    unsafe { libc::kill(pid, 0) == 0 }
}

/// 检查指定 PID 的 cmdline 是否包含某关键字 (防 PID 复用)
pub fn pid_cmdline_contains(pid: i32, keyword: &str) -> bool {
    let path = format!("/proc/{}/cmdline", pid);
    if let Ok(bytes) = std::fs::read(&path) {
        // cmdline 用 NUL 分隔参数
        let cmdline = String::from_utf8_lossy(&bytes).replace('\0', " ");
        return cmdline.contains(keyword);
    }
    false
}

/// 对 pidfile 加排它锁并写入 PID (flock + truncate + write, 不用 rename)
///
/// 返回 fd (保持打开 = 持锁, 关闭 = 释放)。崩溃自动释放。
/// 这是比 kill -0 更严谨的防多开方案。
///
/// 修复 v0.5.1 CRITICAL: 旧实现 lock_pidfile + write_pidfile 分两步,
/// write_pidfile 用 tmp+rename 替换了 inode, 导致 _lock_file 持有的 flock
/// 仍锁在旧 inode 上, 磁盘上的新 pidfile (新 inode) 完全无锁 →
/// 第二个实例能再次 lock 成功 → 防多开失效, 双开导致 state.json 并发写坏。
/// 修复: 合并为单一函数, 对同一个 fd 先 flock 后 truncate+write, 不 rename。
///
/// 权限 0o600 (仅 root 可读), 避免 PID 信息泄漏
pub fn lock_and_write_pidfile(path: &std::path::Path, pid: i32) -> io::Result<std::fs::File> {
    use std::io::Write;
    use std::os::unix::io::AsRawFd;
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let f = std::fs::OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false) // 不 truncate, 先拿锁再 truncate 防竞态
        .mode(0o600) // 0o600, 防止其他用户读取 PID
        .open(path)?;
    // 1. 先拿 flock (非阻塞), 失败说明已有实例运行
    let r = unsafe { libc::flock(f.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) };
    if r < 0 {
        let e = io::Error::last_os_error();
        return Err(io::Error::new(
            e.kind(),
            format!("pidfile 已被其他实例锁定: {}", e),
        ));
    }
    // 2. 拿到锁后 truncate + write PID (同一 inode, 锁不丢失)
    let content = format!("{}\n", pid);
    f.set_len(0)?;
    {
        let mut f = &f; // 借用, 不消耗
        f.write_all(content.as_bytes())?;
        f.flush()?;
    }
    f.sync_all()?;
    // fsync 父目录 (防掉电后 metadata 未持久化)
    if let Some(parent) = path.parent() {
        if let Ok(pf) = std::fs::File::open(parent) {
            let _ = pf.sync_all();
        }
    }
    Ok(f)
}

/// 读 pidfile 中的 PID
pub fn read_pidfile(path: &std::path::Path) -> Option<i32> {
    std::fs::read_to_string(path)
        .ok()
        .and_then(|s| s.trim().parse::<i32>().ok())
}

/// 删除 pidfile
pub fn remove_pidfile(path: &std::path::Path) {
    let _ = std::fs::remove_file(path);
}

use std::os::unix::fs::OpenOptionsExt;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_pid_cmdline_self() {
        let self_cmd = pid_cmdline_contains(current_pid(), "");
        assert!(self_cmd); // 空串恒匹配
    }

    #[test]
    fn test_read_proc_nice_uses_correct_field() {
        // 构造 fake /proc/<pid>/stat 字符串, 模拟 daemon (priority=39, nice=19, num_threads=8)
        // 字段布局: pid (comm) state ppid pgrp session tty_nr tpgid flags
        //          minflt cminflt majflt cmajflt utime stime cutime cstime priority nice num_threads
        // priority(18)=39, nice(19)=19, num_threads(20)=8
        let fake_stat = "26195 (tarn daemon) S 1 26191 26191 0 -1 4194304 123 0 0 0 1 0 0 0 39 19 8";
        // 手动解析验证字段索引
        let after_comm = fake_stat.rfind(')').unwrap();
        let rest = &fake_stat[after_comm + 1..];
        let fields: Vec<&str> = rest.split_whitespace().collect();
        // fields[15] = priority (field 18) = 39
        assert_eq!(fields.get(15).and_then(|s| s.parse::<i32>().ok()), Some(39),
            "fields[15] 应为 priority=39, 实际: {:?}", fields.get(15));
        // fields[16] = nice (field 19) = 19
        assert_eq!(fields.get(16).and_then(|s| s.parse::<i32>().ok()), Some(19),
            "fields[16] 应为 nice=19, 实际: {:?}", fields.get(16));
        // fields[17] = num_threads (field 20) = 8 (不是 nice!)
        assert_eq!(fields.get(17).and_then(|s| s.parse::<i32>().ok()), Some(8),
            "fields[17] 应为 num_threads=8, 实际: {:?}", fields.get(17));
        // 确保 nice(19) 和 num_threads(8) 不相等 (防止误读 num_threads 当 nice)
        assert_ne!(fields.get(16), fields.get(17),
            "nice 和 num_threads 不应相等 (否则 bug 不会被发现)");
    }

    #[test]
    fn test_read_proc_nice_self() {
        // 读自己进程的 nice, 应返回 Some 且在合法范围 [-20, 19]
        let nice = read_proc_nice(current_pid());
        assert!(nice.is_some(), "read_proc_nice(self) 应返回 Some");
        let n = nice.unwrap();
        assert!(n >= -20 && n <= 19, "nice 值应在 [-20, 19] 范围内, 实际: {}", n);
    }
}
