//! WebUI 入口文件动态生成 (KernelSU webroot/index.html)
//!
//! ## 背景
//! KernelSU 管理器点击模块"Open WebUI"时, 会打开 `$MODPATH/webroot/index.html`。
//! 此文件的作用是重定向到 daemon 内嵌 WebUI 的实际监听地址 (http://bind:port/)。
//!
//! ## 动态生成时机
//! 1. **daemon 启动时** (run_daemon 入口): 读 settings.toml 的 [webui] bind/port, 写入 index.html
//! 2. **热重载时** (收到 SIGHUP): 用户改了 bind/port 后, daemon 重新生成 index.html
//! 3. **customize.sh 安装时** (兜底): 防止 daemon 还没启动时 KSU 用户点击模块没反应
//!
//! ## 路径策略
//! MODPATH 固定为 `/data/adb/modules/tarn` (Magisk/KernelSU 约定, module id = tarn)。
//! 不读环境变量 (daemon 启动时环境已被 init 重置, MODPATH 不可用)。
//!
//! ## 失败处理
//! 写入失败 (SELinux 拒绝 / 模块目录不存在) 不影响 daemon 主流程, 仅记 WARN 日志。
//! 因为:
//! - Magisk 用户用不上 webroot/ (Magisk 无此机制)
//! - KernelSU 用户即使 index.html 失效, 也可手动浏览器访问 http://127.0.0.1:8080/

use anyhow::{Context, Result};
use std::path::PathBuf;

/// MODPATH 固定路径 (Magisk/KernelSU 模块安装目录 + module id)
///
/// 不从环境变量读, 因为 daemon 由 service.sh setsid 启动, 环境里没有 MODPATH。
/// 模块 id = "tarn" 在 module.prop 硬编码, 此路径也硬编码对应。
const MODPATH: &str = "/data/adb/modules/tarn";

/// webroot 目录 (相对 MODPATH)
const WEBROOT_DIR: &str = "webroot";

/// index.html 文件名
const INDEX_HTML: &str = "index.html";

/// 获取 webroot 目录绝对路径
pub fn webroot_dir() -> PathBuf {
    PathBuf::from(MODPATH).join(WEBROOT_DIR)
}

/// 获取 index.html 绝对路径
pub fn index_html_path() -> PathBuf {
    webroot_dir().join(INDEX_HTML)
}

/// 生成 index.html 内容
///
/// 内容: `<!DOCTYPE html><script>document.location='http://BIND:PORT/'</script>`
///
/// 注意: bind 为 "0.0.0.0" 时浏览器仍用 127.0.0.1 访问 (本机回环),
/// 所以 bind=0.0.0.0 时 URL 里替换为 127.0.0.1, 避免浏览器拒绝打开 0.0.0.0。
pub fn build_index_html_content(bind: &str, port: u16) -> String {
    let host = if bind == "0.0.0.0" || bind == "::" {
        "127.0.0.1"
    } else {
        bind
    };
    // v0.5.1 修复 M8: 防 HTML/JS 注入。
    // 旧实现把 bind (来自 settings.toml) 直接插入 <script> 字符串字面量,
    // 若 bind 含 '</script>' 等可断链 HTML, 可执行恶意 JS (窃取 localStorage token)。
    // 修复: 严格校验 host 仅含合法字符 (IP/hostname/[a-zA-Z0-9.\-:]), 拒绝非法输入。
    let valid = host.chars().all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == ':' || c == '[' || c == ']');
    let safe_host = if valid { host } else { "127.0.0.1" };
    format!(
        "<!DOCTYPE html><script>document.location='http://{host}:{port}/'</script>\n",
        host = safe_host,
        port = port,
    )
}

/// 生成 (或更新) webroot/index.html
///
/// 调用时机: daemon 启动 / 热重载 / 手动触发
///
/// 行为:
/// 1. 创建 $MODPATH/webroot/ 目录 (若不存在)
/// 2. 写入 index.html (覆盖)
/// 3. chmod 0644 (KSU 管理器需可读)
///
/// 失败不退出调用方, 仅返回 Err 由调用方记日志
pub fn generate_index_html(bind: &str, port: u16) -> Result<PathBuf> {
    let dir = webroot_dir();
    let path = index_html_path();
    let content = build_index_html_content(bind, port);

    // 1. 创建目录 (幂等)
    std::fs::create_dir_all(&dir)
        .with_context(|| format!("创建 webroot 目录失败: {}", dir.display()))?;

    // 2. 写入 index.html
    std::fs::write(&path, &content)
        .with_context(|| format!("写入 index.html 失败: {}", path.display()))?;

    // 3. chmod 0644 (KSU 管理器需可读, 不限制其他用户读)
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o644))
            .with_context(|| format!("chmod 0644 失败: {}", path.display()))?;
    }

    Ok(path)
}

/// 从配置读取 bind/port 并生成 index.html
///
/// 便捷封装: 直接传 Settings 引用, 内部提取 webui.bind / webui.port
pub fn generate_from_settings(settings: &crate::config::Settings) -> Result<PathBuf> {
    generate_index_html(&settings.webui.bind, settings.webui.port)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_content_localhost() {
        let s = build_index_html_content("127.0.0.1", 8080);
        assert!(s.contains("http://127.0.0.1:8080/"));
        assert!(s.starts_with("<!DOCTYPE html>"));
    }

    #[test]
    fn test_content_wildcard_bind() {
        // bind=0.0.0.0 时, URL 里应用 127.0.0.1 (浏览器拒绝打开 0.0.0.0)
        let s = build_index_html_content("0.0.0.0", 9090);
        assert!(s.contains("http://127.0.0.1:9090/"));
        assert!(!s.contains("0.0.0.0"));
    }

    #[test]
    fn test_content_ipv6_wildcard() {
        let s = build_index_html_content("::", 8080);
        assert!(s.contains("http://127.0.0.1:8080/"));
    }

    #[test]
    fn test_content_lan_ip() {
        let s = build_index_html_content("192.168.1.100", 8080);
        assert!(s.contains("http://192.168.1.100:8080/"));
    }
}
