# Tarn 社区清理规则库

> 全网深度搜集整理的 Android 缓存清理规则, 按 Tarn 真实 schema (config.rs) 编写,
> 即导即用, 覆盖 **150+ App** (含主流 + 小众长尾) + 系统深层垃圾.
>
> **规则独立于模块包发布**: Tarn 模块 zip 不含任何规则, 用户从本目录 (GitHub `rules/`)
> 自行下载需要的规则文件, 导入到设备 `/data/adb/tarn/config/` 或通过 WebUI 导入.
>
> **已放弃 risk 等级制度**: 规则文件不写 risk 字段, 后端 API 不返回 risk,
> WebUI 不展示 risk 标签. 用 `enabled = true/false` 作为唯一安全栅栏, `dry_run` 作为预览栅栏.

---

## 规则包清单

共 **17 个文件 / 394 条规则 / 734 个 target**, 覆盖 150+ App (主流大厂 + 小众长尾) + 系统深层垃圾.

### 系统级

| 文件 | 覆盖范围 | 规则数 | 默认启用 |
|------|----------|--------|----------|
| `system-junk.txt` | 系统日志 / ANR / dropbox / 临时文件 | 4 | 全部 |
| `system-deep.txt` | 系统深层垃圾 (tombstones / logcat 转储 / dalvik-cache 临时) | 12 | 5 启用 |
| `app-cache.txt` | 所有 App 通用缓存 (通配符, 激进) | 5 | 2 启用 |

### 主流大厂 App

| 文件 | 覆盖范围 | 规则数 | 默认启用 |
|------|----------|--------|----------|
| `tencent-apps.txt` | 微信 / QQ / 腾讯视频 / 王者荣耀 / 和平精英 等 | 9 | 8 启用 |
| `social-apps.txt` | 抖音 / 快手 / 小红书 / 知乎 / 头条 / 微博 / 贴吧 | 11 | 全部 |
| `ecommerce-apps.txt` | 淘宝 / 京东 / 拼多多 / 美团 / 饿了么 / 携程 / 唯品会 | 9 | 全部 |
| `media-apps.txt` | B站 / 网易云 / 爱奇艺 / 优酷 / 芒果TV / 喜马拉雅 / YouTube / Spotify | 12 | 11 启用 |
| `browsers.txt` | Chrome / Edge / Firefox / 夸克 / UC / QQ / 百度 / Via | 10 | 全部 |
| `utility-apps.txt` | 支付宝 / 高德 / 百度地图 / 滴滴 / 12306 / 点评 / WPS / 钉钉 / 企微 / 飞书 | 11 | 全部 |

### 垂直领域 (中频 App)

| 文件 | 覆盖范围 | 规则数 | 默认启用 |
|------|----------|--------|----------|
| `games.txt` | 原神 / 星穹铁道 / 绝区零 / 王者 / 和平精英 / LOL / 金铲铲 / 明日方舟 等 21 款 | 45 | 40 启用 |
| `cloud-input-reading.txt` | 网盘 10 + 输入法 6 + 阅读 9 (百度网盘/阿里云盘/搜狗/微信读书/起点/番茄…) | 70 | 50 启用 |
| `ai-im-overseas.txt` | AI 助手 11 + 海外 IM 14 (ChatGPT/Claude/Gemini/豆包/通义/Kimi/Telegram/Discord…) | 26 | 25 启用 |
| `finance-news-fitness.txt` | 金融 13 + 新闻 9 + 运动 6 (工行/招行/同花顺/腾讯新闻/Keep/咕咚…) | 29 | 28 启用 |
| `lifestyle-stream-email.txt` | 生活出行 11 + 直播 4 + 邮箱 5 (哈啰/闲鱼/贝壳/斗鱼/虎牙/QQ邮箱/Gmail…) | 21 | 20 启用 |

### 小众长尾 App (全网深度挖掘, 非阿里/腾讯系)

| 文件 | 覆盖范围 | 规则数 | 默认启用 |
|------|----------|--------|----------|
| `niche-apps-a.txt` | 摄影修图 8 + 工具效率 8 + 学习教育 8 (美图/黄油/泼辣/Snapseed/VSCO/一个木函/Nova/TickTick/百词斩/扇贝/网易公开课…) | 24 | 全部 |
| `niche-apps-b.txt` | 海外工具 6 + 开发工具 5 + 剪辑 7 + 旅行 6 + 网络代理 8 + 阅读 6 (Notion/Termux/剪映/缤客/Clash/v2rayNG/七猫…) | 44 | 38 启用 |
| `niche-apps-c.txt` | 医疗 6 + 母婴 5 + IoT 6 + 汽车 6 + 政务 5 + 教育 13 (微医/丁香/宝宝树/米家/涂鸦/蔚来/反诈中心/交管12123/粉笔…) | 52 | 45 启用 |

**统计**: 394 条规则, 其中 `enabled=true` 341 条 (纯 cache/日志, 安全), `enabled=false` 53 条 (离线下载/资源包/用户数据, 用户自评后开启).

---

## 快速使用

### 方式 1: WebUI 导入 (推荐)

1. 打开 WebUI (`http://127.0.0.1:8080`, token 在 `/data/adb/tarn/run/token`)
2. 顶部菜单 → **规则** → **导入**
3. 选择需要的 `.txt` 文件 (可多选, 内容为 TOML 格式)
4. 导入后可逐条启用/禁用/编辑

### 方式 2: 手动复制到设备

```sh
# 把规则文件推到设备 (adb 或 root 文件管理器)
adb push rules/tencent-apps.txt /data/local/tmp/
adb shell su -c "cp /data/local/tmp/tencent-apps.txt /data/adb/tarn/config/"

# 合并到 blacklist.toml (Tarn 引擎只读 blacklist.toml)
adb shell su -c "cat /data/adb/tarn/config/tencent-apps.txt >> /data/adb/tarn/config/blacklist.toml"

# 热重载
adb shell su -c "/data/adb/modules/tarn/tarn reload"
```

### 方式 3: 只用某个规则包

只想清微信? 只导入 `tencent-apps.txt` 即可. 只想清游戏? 只导入 `games.txt`.
每个文件独立, 不互相依赖.

---

## 规则设计原则

### 1. 安全第一: 只清 cache, 不碰核心数据

- 所有规则默认只清理 `cache` / `code_cache` 目录 (Android 设计为可被系统回收, App 自动重建)
- **不删** `databases` / `files` / `shared_prefs` (App 核心数据, 含账号/聊天记录/设置)
- **不删** 离线下载 / 资源包 (除非规则明确标 `enabled = false`, 用户自评后开)

### 2. enabled 状态: 激进规则默认关

| 类型 | 含义 | 默认状态 |
|------|------|----------|
| 纯 cache / 日志 | App 自动重建, 删了无副作用 | 启用 |
| 通配符全局清理 (如 `/data/data/*/cache`) | 万一某 App cache 里有重要东西, 默认关 | **关闭**, 用户自评 |
| 离线下载 / 资源包 / Shader 缓存 | 删了要重新下载或编译 | **关闭**, 用户自评 |

### 3. 定时策略: 高频 App 每日, 低频 App 每周

- 每日清理 (`0 3 * * *`): 微信/QQ/抖音/淘宝 等高频使用 App
- 每周清理 (`0 3 * * 0`): 系统日志/聊天图片缩略图/地图瓦片 等低频增长项
- 离线缓存: 默认关, 用户开了后按 30~90 天清理

### 4. older_than_days 防误删热数据

- 视频/音频播放缓存: `older_than_days = 3` (只清 3 天前的, 避免删正在看的)
- 图片缩略图: `older_than_days = 14~30`
- 系统日志: `older_than_days = 3~7` (留最近几天的排查用)
- 离线下载: `older_than_days = 30~90` (用户的主动下载, 给足时间)

### 5. 不使用 risk 等级制度

Tarn 已放弃 risk 等级制度 (risk 字段在 schema 里仅作展示标签, 不影响是否执行).
规则文件**不写 risk 字段**, 用 `enabled = true/false` 作为唯一的安全栅栏,
`dry_run` 作为预览栅栏. 用户写完规则就能执行, 不再有"high risk 规则被拦截"的困惑.

---

## 各 App 包名速查表

### 腾讯系
| App | 包名 |
|-----|------|
| 微信 | `com.tencent.mm` |
| QQ | `com.tencent.mobileqq` |
| 腾讯视频 | `com.tencent.qqlive` |
| 王者荣耀 | `com.tencent.tmgp.sgame` |
| 和平精英 | `com.tencent.tmgp.pubgmhd` |
| 英雄联盟手游 | `com.tencent.lolm` |
| 金铲铲之战 | `com.tencent.jkchess` |
| 全民K歌 | `com.tencent.karaoke` |
| 企业微信 | `com.tencent.wework` |
| QQ浏览器 | `com.tencent.mtt` |
| QQ邮箱 | `com.tencent.android.mail` |
| 腾讯新闻 | `com.tencent.news` |

### 米哈游 / 鹰角
| App | 包名 |
|-----|------|
| 原神 | `com.miHoYo.GenshinImpact` |
| 崩坏:星穹铁道 | `com.miHoYo.hkrpg` (国服) / `com.HoYoverse.hkrpgoversea` (国际服) |
| 绝区零 | `com.miHoYo.ZZZ` |
| 明日方舟 | `com.hypergryph.arknights` (国服) / `com.YoStarEN.Arknights` (国际服) |

### 网易游戏
| App | 包名 |
|-----|------|
| 阴阳师 | `com.netease.onmyoji` |
| 永劫无间手游 | `com.netease.l22` |
| 蛋仔派对 | `com.netease.party` |
| 第五人格 | `com.netease.dwrg` |
| 光遇 | `com.netease.sky` |
| 我的世界 (中国版) | `com.netease.x19` |

### 社交短视频
| App | 包名 |
|-----|------|
| 抖音 | `com.ss.android.ugc.aweme` |
| 抖音极速版 | `com.ss.android.ugc.aweme.lite` |
| 快手 | `com.smile.gifmaker` |
| 快手极速版 | `com.kuaishou.nebula` |
| 小红书 | `com.xingin.xhs` |
| 知乎 | `com.zhihu.android` |
| 今日头条 | `com.ss.android.article.news` |
| 微博 | `com.sina.weibo` |
| 百度贴吧 | `com.baidu.tieba` |

### 电商
| App | 包名 |
|-----|------|
| 淘宝 | `com.taobao.taobao` |
| 天猫 | `com.tmall.wireless` |
| 京东 | `com.jingdong.app.mall` |
| 拼多多 | `com.xunmeng.pinduoduo` |
| 美团 | `com.sankuai.meituan` |
| 美团外卖 | `com.sankuai.meituan.takeoutnew` |
| 饿了么 | `me.ele` |
| 携程 | `ctrip.android.view` |
| 飞猪 | `com.taobao.trip` |
| 唯品会 | `com.achievo.vipshop` |
| 闲鱼 | `com.taobao.idlefish` |
| 转转 | `com.wuba.zhuanzhuan` |
| 58同城 | `com.wuba` |
| 贝壳找房 | `com.lianjia.beike` |

### 长视频音频
| App | 包名 |
|-----|------|
| 哔哩哔哩 | `tv.danmaku.bili` |
| 网易云音乐 | `com.netease.cloudmusic` |
| 爱奇艺 | `com.qiyi.video` |
| 优酷 | `com.youku.phone` |
| 芒果TV | `com.hunantv.imgo.activity` |
| 喜马拉雅 | `com.ximalaya.ting.android` |
| YouTube | `com.google.android.youtube` |
| Spotify | `com.spotify.music` |

### 浏览器
| App | 包名 |
|-----|------|
| Chrome | `com.android.chrome` |
| Edge | `com.microsoft.emmx` |
| Firefox | `org.mozilla.firefox` |
| 夸克 | `com.quark.browser` |
| UC浏览器 | `com.UCMobile` |
| QQ浏览器 | `com.tencent.mtt` |
| 百度浏览器 | `com.baidu.browser.apps` |
| Via | `mark.via` |

### 工具生活
| App | 包名 |
|-----|------|
| 支付宝 | `com.eg.android.alipaygphone` |
| 高德地图 | `com.autonavi.minimap` |
| 百度地图 | `com.baidu.BaiduMap` |
| 滴滴出行 | `com.sdu.didi.psnger` |
| 12306 | `com.MobileTicket` |
| 大众点评 | `com.dianping.v1` |
| WPS Office | `cn.wps.moffice_eng` |
| 钉钉 | `com.alibaba.android.rimet` |
| 飞书 | `com.ss.android.lark` |
| 哈啰出行 | `com.jingyao.easybike` |
| 青桔单车 | `com.didi.bike` |
| 曹操出行 | `com.caocao` |
| 飞常准 | `com.flightmanager.view` |
| 航旅纵横 | `com.umetrip.android.app` |

### 网盘
| App | 包名 |
|-----|------|
| 百度网盘 | `com.baidu.netdisk` |
| 阿里云盘 | `com.alicloud.databox` |
| 夸克网盘 | `com.quark.clouddrive` |
| 天翼云盘 | `com.cn21.ecloud` |
| 微云 | `com.qq.qcloud` |
| OneDrive | `com.microsoft.skydrive` |
| Google Drive | `com.google.android.apps.docs` |
| 坚果云 | `nutstore.android` |
| 123云盘 | `com.mfcloudcalculate.networkdisk` |
| 迅雷 | `com.xunlei.downloadprovider` |

### 输入法
| App | 包名 |
|-----|------|
| 搜狗输入法 | `com.sohu.inputmethod.sogou` |
| 百度输入法 | `com.baidu.input` |
| 讯飞输入法 | `com.iflytek.inputmethod` |
| 微信输入法 | `com.tencent.wetype` |
| Gboard | `com.google.android.inputmethod.latin` |

### 阅读
| App | 包名 |
|-----|------|
| 微信读书 | `com.tencent.weread` |
| 起点读书 | `com.qidian.QDReader` |
| 番茄小说 | `com.dragon.read` |
| QQ阅读 | `com.qq.reader` |
| 多看阅读 | `com.duokan.reader` |
| 京东读书 | `com.jd.read` |
| 网易蜗牛读书 | `com.netease.snailread` |
| 得到 | `com.luojilab.player` |

### AI 助手
| App | 包名 |
|-----|------|
| ChatGPT | `com.openai.chatgpt` |
| Claude | `com.anthropic.claude` |
| Google Gemini | `com.google.android.apps.bard` |
| Microsoft Copilot | `com.microsoft.copilot` |
| 豆包 | `com.larus.nova` |
| 通义千问 | `com.aliyun.tongyi` |
| Kimi | `com.moonshot.kimichat` |
| 文心一言 | `com.baidu.newapp` |
| 智谱清言 | `com.zhipuai.qingyan` |
| 讯飞星火 | `com.iflytek.spark` |

### 海外 IM
| App | 包名 |
|-----|------|
| Telegram | `org.telegram.messenger` |
| Discord | `com.discord` |
| Signal | `org.thoughtcrime.securesms` |
| WhatsApp | `com.whatsapp` |
| Messenger | `com.facebook.orca` |
| Instagram | `com.instagram.android` |
| Twitter/X | `com.twitter.android` |
| Reddit | `com.reddit.frontpage` |
| Slack | `com.Slack` |
| Zoom | `us.zoom.videomeetings` |
| Microsoft Teams | `com.microsoft.teams` |
| Line | `jp.naver.line.android` |

### 金融银行证券
| App | 包名 |
|-----|------|
| 工商银行 | `com.icbc.android.ims` |
| 建设银行 | `com.chinamworld.main` |
| 招商银行 | `com.cmbchina.pb` |
| 农业银行 | `com.android.bankabc` |
| 中国银行 | `com.chinamworld.bocmbci` |
| 交通银行 | `com.bankcomm.Bankcomm` |
| 京东金融 | `com.jd.jrapp` |
| 度小满 | `com.baidu.xiaoduwallet` |
| 蚂蚁财富 | `com.antfortune.wealth` |
| 同花顺 | `com.hexin.plat.android` |
| 东方财富 | `com.eastmoney.android.finance` |
| 雪球 | `com.xueqiu.android` |
| 大智慧 | `com.gtd.lbwmobile` |

### 新闻资讯
| App | 包名 |
|-----|------|
| 腾讯新闻 | `com.tencent.news` |
| 网易新闻 | `com.netease.newsreader.activity` |
| 澎湃新闻 | `com.wondertek.paper` |
| 新浪新闻 | `com.sina.news` |
| 凤凰新闻 | `com.ifeng.news2` |
| 界面新闻 | `com.jiemian.news` |
| 央视新闻 | `cn.cntvnews.app` |
| 虎嗅 | `com.huxiu` |
| 36氪 | `com.lazyaudio.duokan` |

### 运动健康
| App | 包名 |
|-----|------|
| Keep | `com.gotokeep.keep` |
| 悦跑圈 | `com.caitongyun.joyrun` |
| 咕咚 | `com.codoon.gps` |
| FitTime | `com.fittime.riley` |
| 薄荷健康 | `com.boohee.one` |
| 美柚 | `com.lingan.meiriyi` |

### 直播
| App | 包名 |
|-----|------|
| 斗鱼 | `com.douyu.group.everest` |
| 虎牙 | `com.duowan.kiwi` |
| YY | `com.yy.yymobile` |
| 映客 | `com.inke.android` |

### 邮箱
| App | 包名 |
|-----|------|
| QQ邮箱 | `com.tencent.android.mail` |
| 网易邮箱大师 | `com.netease.mail` |
| Gmail | `com.google.android.gm` |
| Outlook | `com.microsoft.office.outlook` |
| 139邮箱 | `cn.cmos.mm3gclient` |

---

## 自定义指南

### 加一个本规则库没覆盖的 App

以"酷安" (`com.coolapk.market`) 为例, 复制下面的模板到 `blacklist.toml`:

```toml
[[rule]]
id = "coolapk-cache"
name = "酷安缓存"
enabled = true
priority = 60

[rule.trigger]
on = ["manual", "cron"]
cron_expr = "0 3 * * *"   # 每天凌晨 3 点

[[rule.targets]]
path = "/data/data/com.coolapk.market"
glob = "{cache,code_cache}"
mode = "clear_dirs"

[[rule.targets]]
path = "/storage/emulated/0/Android/data/com.coolapk.market"
glob = "cache"
mode = "clear_dirs"
```

改 3 处: `id` / `name` / `path` 里的包名.

### 调整清理频率

改 `cron_expr`:
- `0 3 * * *` = 每天凌晨 3 点
- `0 3 * * 0` = 每周日凌晨 3 点
- `0 3 * * 1,4` = 每周一、周四凌晨 3 点
- `0 */6 * * *` = 每 6 小时一次
- `0 0 1 * *` = 每月 1 号

### 只手动触发, 不定时

```toml
[rule.trigger]
on = ["manual"]   # 去掉 cron 和 boot
```

### 清理更深层的目录 (如 App 的 files/logs)

```toml
[[rule.targets]]
path = "/data/data/com.example.app"
glob = "files/{log,crash,reports}/**/*"
mode = "delete_files"
older_than_days = 7   # 只删 7 天前的日志
```

---

## 验证规则

导入规则后, **先 dry-run 预览** 再真删:

```sh
# 预览所有规则会删什么 (不真删)
/data/adb/modules/tarn/tarn run --dry-run --json

# 只跑某条规则
/data/adb/modules/tarn/tarn run --rule wechat-internal-cache --dry-run

# 确认无误后真删
/data/adb/modules/tarn/tarn run
```

WebUI 也有 "预览" 按钮, 点一下看会删哪些文件.

---

## 常见问题

### Q: 为什么有的规则默认 enabled = false?

A: 两种情况:
1. **激进规则** (如"所有 App 内部缓存" `app-cache.txt` 的通配符规则): 通配符匹配所有 App, 万一某个 App 的 cache 里有重要东西会误删, 默认关让你评估后开
2. **离线下载 / 资源包** (如"B站离线缓存"、"原神 shader 缓存"、"Keep 离线课程"): 会删用户主动下载的内容, 默认关

### Q: 清完 cache 后 App 会变慢吗?

A: 会有短暂的冷启动慢 (App 要重建缓存), 但运行一会就恢复. 对微信/QQ 这类高频 App, 建议夜里定时清, 早上用正好是冷启动, 用一会就热了.

### Q: 清理会删聊天记录吗?

A: **不会**. 聊天记录在 `databases/` 目录, 规则只清 `cache/` 目录. 但聊天图片缩略图 (如微信的 `image2` 缩略图) 规则会删 N 天前的缩略图, 原图不动.

### Q: 金融银行 App 清完会掉账号吗?

A: **不会**. 账号/证书/交易记录在 `databases/` 和 `shared_prefs/` 里, 规则只清 `cache/`/`code_cache/`. 清完只是重新加载行情/K线/UI 资源, 需要重新登录的情况极少 (个别 App 把 token 存 cache 里的会要求重新登录, 但不丢数据).

### Q: 规则没生效?

检查:
1. `enabled = true` 了吗?
2. 规则的 `path` 在 Tarn 允许的根目录内吗? (见 `protect.rs` 的 `ALLOWED_ROOTS`)
3. 改完 toml 后 `tarn reload` 了吗?
4. `tarn run --dry-run` 看有匹配到文件吗? 没有可能是 glob 写错或文件不存在

### Q: 想贡献新规则?

欢迎补充! 提 issue 或 PR 到 Tarn 仓库的 `rules/` 目录, 标注:
- App 名称和包名 (请在应用宝/小米应用商店/GitHub ApkMirror 交叉验证)
- 缓存目录路径 (从 `adb shell ls` 或 root 文件管理器确认)
- 默认 enabled 状态 (纯 cache = true, 离线数据 = false)
- 来源 (哪里看到的路径)

---

## 规则来源 (全网搜集, 交叉验证)

- [d4rken-org/sdmaid-se](https://github.com/d4rken-org/sdmaid-se) — SD Maid SE, 最专业的 Android 清理工具, AppCleaner 设计原则
- [WeirdMidas/BasicCleaner](https://github.com/WeirdMidas/BasicCleaner) — Magisk 清理模块, 系统级路径清单
- [DEMONNICA/Clear-Optimization](https://github.com/DEMONNICA/Clear-Optimization) — Magisk 优化模块
- [Cai-Ming-Yu/CMY-CacheCleaner](https://github.com/Cai-Ming-Yu/CMY-CacheCleaner) — KernelSU 缓存清理
- [Petit-Abba/black_and_white_list](https://github.com/Petit-Abba/black_and_white_list) — 黑白名单模块, 通用清理模式
- [S123123sd/SmartClear](https://github.com/S123123sd/SmartClear) — AutoPurge Pro, logs/.tmp 清理思路
- Android 官方文档 (`getCacheDir()` / `getExternalCacheDir()` / `getCodeCacheDir()` 规范)
- 应用宝 / 小米应用商店 / Google Play / APKMirror / APKPure (包名校验)
- Reddit / XDA 论坛 / 知乎 / 百度经验 / CSDN (社区缓存路径汇总)
