//! [v0.7.6] io_uring 批量 unlinkat — 5.11+ 内核加速批量删除
//!
//! ## 背景
//! v0.7.5 的 executor.execute_batch 逐个 sync unlinkat(dirfd, name, 0),
//! N 个文件 N 次 syscall (N 次 user/kernel 切换)。io_uring 批量 unlinkat 把 N 次
//! unlinkat 合并为少量 io_uring_enter, 显著降低切换开销。
//!
//! ## 全网调研依据
//! - man7 io_uring_prep_unlinkat.3: IORING_OP_UNLINKAT opcode, 等价 unlinkat(2)
//! - kernelnewbies/Linux_5.11: IORING_OP_UNLINKAT 在 Linux 5.11 合入
//! - 5.10 GKI 不支持, 必须 io_uring_register_probe 运行时探测 (见 sysutil)
//! - io-uring crate 0.7: 纯 Rust, opcode::UnlinkAt 可用
//!
//! ## 运行时检测
//! - io_uring_unlinkat_available() 判断内核 5.11+ 且 opcode 可用
//! - 5.11+ → 批量 unlinkat; 5.10 → 回退 sync unlinkat 循环
//!
//! ## 正确性
//! - AT_REMOVEDIR 不设 (flags=0, 只删文件, 不删目录; 目录由 clean_empty_dirs 处理)
//! - 路径字符串生命周期: CString 存活到 reap (与 iouring_stat 同策略)
//! - 失败 (ENOENT/EACCES 等) 返回 false, 调用方决定是否回退
//! - ext4+discard 场景禁用 (TRIM 风暴, 见 executor fs_aware_throttle)
//!
//! ## 收益 (理论)
//! 命中 N 个文件:
//! - sync unlinkat: N 次 syscall (N 次切换, 每次 ~1μs)
//! - io_uring 批量: ceil(N/SQ_DEPTH) 次 io_uring_enter, 切换次数降 ~SQ_DEPTH 倍
//! - 命中 100: 100→1 (省 99%); 命中 1000: 1000→4 (省 99.6%)

use std::path::Path;

/// 批量删除多个文件, 返回每项是否成功。
///
/// 内核 5.11+ 用 io_uring 批量 unlinkat; 否则回退 sync unlinkat 循环。
/// 返回 Vec<bool> 与输入 paths 等长, true=删除成功, false=失败 (不存在/权限/其他)。
///
/// 注意: 本函数只删文件 (flags=0, 不含 AT_REMOVEDIR), 目录会返回 false。
pub fn batch_unlink(paths: &[std::path::PathBuf]) -> Vec<bool> {
    if paths.is_empty() {
        return Vec::new();
    }
    // ext4+discard 场景由调用方判断, 这里只看 io_uring 是否可用
    if !crate::sysutil::io_uring_unlinkat_available() {
        return fallback_sync_unlink(paths);
    }
    match batch_unlinkat_io_uring(paths) {
        Ok(v) => v,
        // io_uring 任何失败 (setup/submit/reap) 都回退 sync, 保证正确性优先
        Err(_) => fallback_sync_unlink(paths),
    }
}

/// sync unlinkat 循环回退 (内核 < 5.11 或 io_uring 失败时用)
fn fallback_sync_unlink(paths: &[std::path::PathBuf]) -> Vec<bool> {
    paths.iter().map(|p| sync_unlinkat(p)).collect()
}

/// 单文件 sync unlinkat (与 executor::unlinkat_file 同实现, 此处独立保留供回退用)
fn sync_unlinkat(path: &Path) -> bool {
    use std::os::unix::ffi::OsStrExt;
    use std::os::unix::fs::OpenOptionsExt;
    use std::os::unix::io::AsRawFd;

    let parent = match path.parent() {
        Some(p) => p,
        None => return std::fs::remove_file(path).is_ok(),
    };
    let file_name = match path.file_name() {
        Some(n) => n,
        None => return std::fs::remove_file(path).is_ok(),
    };

    let dir = match std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_DIRECTORY | libc::O_CLOEXEC)
        .open(parent)
    {
        Ok(d) => d,
        Err(_) => return std::fs::remove_file(path).is_ok(),
    };
    let dirfd = dir.as_raw_fd();

    let cstr = match std::ffi::CString::new(file_name.as_bytes()) {
        Ok(c) => c,
        Err(_) => return false,
    };

    // unlinkat(dirfd, name, 0) — 0 = 删文件 (AT_REMOVEDIR 才删目录)
    let r = unsafe { libc::unlinkat(dirfd, cstr.as_ptr(), 0) };
    r == 0
}

/// io_uring 批量 unlinkat 实现。
///
/// 策略: SQ 容量有限 (默认 256 entries), 路径数 > SQ 容量时分批。
/// 每批: 填 SQE (pathname 用 CString, 必须存活到 reap) → submit+wait → 读 CQE 填结果。
/// user_data = 路径在 paths 中的全局索引, CQE reap 时按 user_data 定位。
fn batch_unlinkat_io_uring(paths: &[std::path::PathBuf]) -> std::io::Result<Vec<bool>> {
    use io_uring::{IoUring, opcode, types};
    use std::os::unix::ffi::OsStrExt;

    const SQ_ENTRIES: u32 = 256;
    let mut ring = IoUring::new(SQ_ENTRIES)?;

    let mut results: Vec<bool> = vec![false; paths.len()];

    let mut idx = 0usize;
    while idx < paths.len() {
        let batch_end = (idx + SQ_ENTRIES as usize).min(paths.len());
        let batch_size = batch_end - idx;

        // 1. 准备本批 CString (pathname 指针依赖 CString 存活到 reap)
        let cstrings: Vec<std::ffi::CString> = paths[idx..batch_end]
            .iter()
            .map(|p| {
                std::ffi::CString::new(p.as_os_str().as_bytes())
                    .unwrap_or_else(|_| std::ffi::CString::new("").unwrap())
            })
            .collect();

        // 2. 提交 SQE (user_data = 全局路径索引)
        //    opcode::UnlinkAt::new(Fd, path, flags)
        //    flags=0: 删文件 (不设 AT_REMOVEDIR)
        {
            let mut sq = ring.submission();
            for (i, cs) in cstrings.iter().enumerate() {
                let global_idx = idx + i;
                let unlink_op = opcode::UnlinkAt::new(
                    types::Fd(libc::AT_FDCWD),
                    cs.as_ptr(),
                )
                .flags(0) // 0 = 删文件, 不删目录
                .build()
                .user_data(global_idx as u64);

                if sq.is_full() {
                    drop(sq);
                    ring.submit_and_wait(batch_size)?;
                    sq = ring.submission();
                }
                unsafe {
                    sq.push(&unlink_op).map_err(|_| std::io::Error::other("sqe push"))?;
                }
            }
        }

        // 3. submit + wait 本批全部完成
        ring.submit_and_wait(batch_size)?;

        // 4. reap CQE, 按 user_data 定位填结果
        let cq = ring.completion();
        for cqe in cq {
            let global_idx = cqe.user_data() as usize;
            let res = cqe.result();
            // res == 0 → 成功; res < 0 → 失败 (ENOENT/EACCES/EISDIR 等)
            if global_idx < results.len() && res == 0 {
                results[global_idx] = true;
            }
            // res < 0: results[global_idx] 保持 false
        }

        idx = batch_end;
    }

    Ok(results)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_batch_unlink_basic() {
        let tmp = std::env::temp_dir().join(format!("tarn_iouring_unlink_test_{}", std::process::id()));
        let _ = std::fs::create_dir_all(&tmp);
        let p1 = tmp.join("f1.txt");
        let p2 = tmp.join("f2.txt");
        let p3 = tmp.join("f3.txt");
        std::fs::write(&p1, b"a").unwrap();
        std::fs::write(&p2, b"b").unwrap();
        std::fs::write(&p3, b"c").unwrap();

        let paths = vec![p1.clone(), p2.clone(), p3.clone()];
        let results = batch_unlink(&paths);
        assert_eq!(results.len(), 3);
        // 全部应成功 (io_uring 或 sync 回退都能删)
        assert!(results.iter().all(|&r| r), "所有文件应删除成功");
        assert!(!p1.exists());
        assert!(!p2.exists());
        assert!(!p3.exists());

        let _ = std::fs::remove_dir_all(&tmp);
    }

    #[test]
    fn test_batch_unlink_nonexistent() {
        // 不存在的文件应返回 false (不 panic)
        let paths = vec![std::path::PathBuf::from("/nonexistent/tarn_unlink_test_12345")];
        let results = batch_unlink(&paths);
        assert_eq!(results.len(), 1);
        assert!(!results[0]);
    }

    #[test]
    fn test_batch_unlink_empty() {
        let results = batch_unlink(&[]);
        assert!(results.is_empty());
    }

    #[test]
    fn test_batch_unlink_directory_returns_false() {
        // unlinkat flags=0 不删目录, 应返回 false
        let tmp = std::env::temp_dir().join(format!("tarn_iouring_unlink_dir_test_{}", std::process::id()));
        let _ = std::fs::create_dir_all(&tmp);
        let paths = vec![tmp.clone()];
        let results = batch_unlink(&paths);
        assert_eq!(results.len(), 1);
        assert!(!results[0], "删除目录应失败 (flags=0 不含 AT_REMOVEDIR)");
        assert!(tmp.exists(), "目录应保留");
        let _ = std::fs::remove_dir_all(&tmp);
    }

    #[test]
    fn test_batch_unlink_mixed() {
        // 混合: 存在的文件 + 不存在的 + 目录
        let tmp = std::env::temp_dir().join(format!("tarn_iouring_unlink_mixed_test_{}", std::process::id()));
        let _ = std::fs::create_dir_all(&tmp);
        let f1 = tmp.join("exists.txt");
        std::fs::write(&f1, b"x").unwrap();
        let subdir = tmp.join("subdir");
        std::fs::create_dir_all(&subdir).unwrap();
        let nonexistent = tmp.join("nope.txt");

        let paths = vec![f1.clone(), nonexistent.clone(), subdir.clone()];
        let results = batch_unlink(&paths);
        assert_eq!(results.len(), 3);
        assert!(results[0], "存在文件应删除成功");
        assert!(!results[1], "不存在文件应失败");
        assert!(!results[2], "目录应失败 (flags=0)");
        assert!(!f1.exists());
        assert!(subdir.exists(), "目录应保留");

        let _ = std::fs::remove_dir_all(&tmp);
    }
}
