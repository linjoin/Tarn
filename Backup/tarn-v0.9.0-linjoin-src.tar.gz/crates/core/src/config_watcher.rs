//! 配置文件 inotify 监控 (自动热重载)
//!
//! 监控 `config/` 和 `rules/` 目录下的 `.toml` / `.txt` 文件, 文件变化时 `raise(SIGHUP)`
//! 触发主循环热重载, 复用现有 SIGHUP 机制 (打断 sleep + 设置 reload_requested)。
//!
//! ## 设计
//! - **IN_CLOSE_WRITE**: 文件写入完成(关闭)才触发, 不读半成品 (用户要求)
//! - **IN_MOVED_TO**: 覆盖原子保存 (write temp + rename) 的 rename 落地事件
//! - **IN_CREATE / IN_DELETE**: rules/ 下增删 .toml / .txt 文件
//! - **独立线程 + poll(-1) 阻塞**: 空闲 CPU = 0 (内核无事件时不唤醒)
//! - **raise(SIGHUP)**: 标准信号合并, 多次事件最多触发一次 reload
//!
//! ## 事件流
//! ```text
//! 用户编辑 settings.toml 并保存
//!   → 编辑器 write temp + rename (或直接 write+close)
//!   → 内核产生 inotify 事件 (IN_CLOSE_WRITE 或 IN_MOVED_TO)
//!   → watcher 线程 poll 返回
//!   → 解析事件, 过滤 .toml
//!   → raise(SIGHUP)
//!   → sigwait 线程取走信号, reload.store(true)
//!   → 主循环 sleep/timer.wait 被 EINTR 打断
//!   → 下次迭代 swap(false) 拿到 true
//!   → 执行 reload()
//! ```
//!
//! ## 理论依据
//! - inotify(7): IN_CLOSE_WRITE "File opened for writing was closed."
//!   https://man7.org/linux/man-pages/man7/inotify.7.html
//! - IN_MODIFY 每次 write 触发(可能多次), IN_CLOSE_WRITE 只在 close 时触发 1 次,
//!   适合配置 reload 场景 (避免读到写一半的文件, 避免一次保存多次 reload)。
//! - 原子保存 (write temp + rename) 时文件级 watch 会失效 (inode 替换),
//!   必须 watch 父目录 + IN_MOVED_TO 才能捕获。
//! - poll(2) 阻塞等待 fd 可读, 无事件时线程 park, CPU 占用 0。

use crate::logger::AsyncLogger;
use anyhow::{anyhow, Context, Result};
use std::collections::HashMap;
use std::ffi::CString;
use std::os::unix::io::RawFd;
use std::path::Path;
use std::sync::Arc;
use std::thread;

/// 监控的事件掩码
/// - IN_CLOSE_WRITE: 文件写入关闭 (主要事件, 用户要求的)
/// - IN_MOVED_TO: 原子保存 rename 落地 (编辑器常用)
/// - IN_CREATE: 新建文件 (rules/ 下新加规则)
/// - IN_DELETE: 删除文件 (rules/ 下删除规则)
const WATCH_MASK: u32 = libc::IN_CLOSE_WRITE
    | libc::IN_MOVED_TO
    | libc::IN_CREATE
    | libc::IN_DELETE;

/// 启动配置文件监控线程
///
/// 监控 `config_dir/config/` 和 `config_dir/rules/` 目录下的 `.toml` / `.txt` 文件变化。
/// 文件变化时 `raise(SIGHUP)` 触发主循环热重载 (复用现有 SIGHUP 机制)。
///
/// **空闲 CPU 占用 = 0** (poll 阻塞等待内核事件, 无事件不唤醒)。
///
/// 失败返回 Err, 调用方应记录日志但不退出 daemon (退化到手动 `tarn reload`)。
///
/// # 安全
/// 必须在 `install_signal_handlers` 之后调用, 确保 SIGHUP 已被捕获
/// (否则 raise(SIGHUP) 会终止进程)。
pub fn start_config_watcher(
    config_dir: &Path,
    logger: Arc<AsyncLogger>,
) -> Result<thread::JoinHandle<()>> {
    // 1. 创建 inotify 实例 (nonblock + cloexec)
    let fd: RawFd = unsafe { libc::inotify_init1(libc::IN_NONBLOCK | libc::IN_CLOEXEC) };
    if fd < 0 {
        return Err(anyhow!(
            "inotify_init1 失败: {}",
            std::io::Error::last_os_error()
        ));
    }

    // 2. 对 config/ 和 rules/ 目录加 watch
    let watch_dirs: Vec<(&str, std::path::PathBuf)> = vec![
        ("config", config_dir.join("config")),
        ("rules", config_dir.join("rules")),
    ];
    let mut wd2name: HashMap<i32, String> = HashMap::new();
    for (name, dir) in &watch_dirs {
        // 目录不存在则跳过 (首次安装 rules/ 可能为空, 但应已创建)
        if !dir.is_dir() {
            logger.warn(
                "watcher",
                &format!("目录不存在, 跳过监控: {}", dir.display()),
            );
            continue;
        }
        let s = dir.to_str().context("配置目录路径含非 UTF-8 字符")?;
        let c = match CString::new(s) {
            Ok(c) => c,
            Err(_) => continue,
        };
        let wd = unsafe { libc::inotify_add_watch(fd, c.as_ptr(), WATCH_MASK) };
        if wd < 0 {
            logger.warn(
                "watcher",
                &format!(
                    "inotify_add_watch 失败 ({}): {}",
                    dir.display(),
                    std::io::Error::last_os_error()
                ),
            );
            continue;
        }
        wd2name.insert(wd, name.to_string());
        logger.info(
            "watcher",
            &format!("监控目录: {} (wd={})", dir.display(), wd),
        );
    }

    if wd2name.is_empty() {
        unsafe { libc::close(fd) };
        return Err(anyhow!(
            "无目录可监控, 配置热重载退化为手动 (tarn reload)"
        ));
    }

    // 3. 起监控线程
    let logger_clone = logger.clone();
    let handle = thread::Builder::new()
        .name("tarn-config-watcher".to_string())
        .spawn(move || {
            watcher_loop(fd, wd2name, logger_clone);
        })
        .context("创建配置监控线程失败")?;
    Ok(handle)
}

/// 监控线程主循环
///
/// `poll(-1)` 阻塞等待 inotify fd 可读, 读事件, 过滤 .toml / .txt, `raise(SIGHUP)`。
fn watcher_loop(fd: RawFd, wd2name: HashMap<i32, String>, logger: Arc<AsyncLogger>) {
    logger.info(
        "watcher",
        "配置文件监控线程已启动 (mask=CLOSE_WRITE|MOVED_TO|CREATE|DELETE, 过滤 .toml / .txt)",
    );
    let mut buf = [0u8; 4096];

    loop {
        // poll 阻塞等待 inotify fd 可读 (timeout=-1 = 无限等待, 零 CPU 空闲)
        let mut pfd = libc::pollfd {
            fd,
            events: libc::POLLIN,
            revents: 0,
        };
        let r = unsafe { libc::poll(&mut pfd, 1, -1) };
        if r < 0 {
            let e = std::io::Error::last_os_error();
            if e.raw_os_error() == Some(libc::EINTR) {
                continue; // 被信号打断, 正常, 继续 poll
            }
            logger.error(
                "watcher",
                &format!("poll 失败, 配置监控线程停止: {}", e),
            );
            return;
        }
        if r == 0 {
            continue; // 超时 (不应该发生, timeout=-1)
        }

        // fd 可读, 循环读尽所有事件 (nonblock, 读到 EAGAIN 为止)
        let mut triggered: Vec<String> = Vec::new();
        loop {
            let n = unsafe { libc::read(fd, buf.as_mut_ptr() as *mut _, buf.len()) };
            if n < 0 {
                let e = std::io::Error::last_os_error();
                if e.raw_os_error() == Some(libc::EAGAIN) {
                    break; // 读干了 (nonblock)
                }
                if e.raw_os_error() == Some(libc::EINTR) {
                    continue; // 被信号打断, 重试 read
                }
                logger.error("watcher", &format!("read 失败: {}", e));
                break;
            }
            if n == 0 {
                break;
            }
            parse_events(&buf[..n as usize], &wd2name, &mut triggered);
        }

        if !triggered.is_empty() {
            for f in &triggered {
                logger.info("watcher", &format!("配置文件变化: {}", f));
            }
            logger.info(
                "watcher",
                &format!(
                    "触发热重载 (raise SIGHUP), 共 {} 个事件",
                    triggered.len()
                ),
            );
            // raise SIGHUP 给自己进程:
            //   - sigwait 线程取走信号, reload.store(true)
            //   - 主循环的 timer.wait/sleep 被 EINTR 打断, 尽快进入 reload 分支
            //   - 标准信号合并, 短时间多次事件只触发一次 reload
            //   - SIGHUP 已被 install_signal_handlers 捕获, 不会终止进程
            unsafe { libc::raise(libc::SIGHUP) };
        }
    }
}

/// 解析一次 read 返回的 inotify_event 数组, 提取关心的 .toml / .txt 文件变化
///
/// 用 read_unaligned 逐事件读取: [u8; N] 对齐=1 而 inotify_event 对齐=4,
/// 若 buf 起始地址非 4 字节对齐, 直接 `&*(... as *const inotify_event)` 转引用为 UB。
/// read_unaligned 安全处理任意对齐 (返回值是 copy, 非 reference;
/// 内核保证事件在 buffer 内对齐)。
fn parse_events(buf: &[u8], wd2name: &HashMap<i32, String>, out: &mut Vec<String>) {
    let ev_size = std::mem::size_of::<libc::inotify_event>();
    let mut off = 0usize;
    while off + ev_size <= buf.len() {
        // read_unaligned 避免对齐 UB (返回值的 copy, 非 reference)
        let ev: libc::inotify_event = unsafe {
            std::ptr::read_unaligned(buf.as_ptr().add(off) as *const libc::inotify_event)
        };

        // 提取文件名 (ev.len > 0 表示是目录内文件事件, = 0 是 watch 目录本身)
        if ev.len > 0 {
            let name_start = off + ev_size;
            let name_end = name_start + ev.len as usize;
            if name_end <= buf.len() {
                let name_bytes = &buf[name_start..name_end];
                let end = name_bytes.iter().position(|&b| b == 0).unwrap_or(name_bytes.len());
                let name = String::from_utf8_lossy(&name_bytes[..end]).to_string();
                // 只关心 .toml / .txt 文件 (rules/ 下规则包用 .txt 后缀, 因安卓系统对 .toml 陌生后缀限制)
                // config/ 下三文件仍是 .toml, rules/ 下规则包改用 .txt (内容仍为 TOML 格式)
                if name.ends_with(".toml") || name.ends_with(".txt") {
                    let dir = wd2name.get(&ev.wd).cloned().unwrap_or_else(|| "?".to_string());
                    let mask = mask_to_str(ev.mask);
                    out.push(format!("{}/{} ({})", dir, name, mask));
                }
            }
        } else {
            // watch 目录本身的事件 (罕见, 如目录被删除), 也触发 reload
            let dir = wd2name.get(&ev.wd).cloned().unwrap_or_else(|| "?".to_string());
            out.push(format!("{}/ (目录本身, mask=0x{:x})", dir, ev.mask));
        }

        off += ev_size + ev.len as usize;
    }
}

/// 事件掩码转可读字符串
fn mask_to_str(mask: u32) -> String {
    let mut parts = Vec::new();
    if mask & libc::IN_CLOSE_WRITE != 0 {
        parts.push("CLOSE_WRITE");
    }
    if mask & libc::IN_MOVED_TO != 0 {
        parts.push("MOVED_TO");
    }
    if mask & libc::IN_CREATE != 0 {
        parts.push("CREATE");
    }
    if mask & libc::IN_DELETE != 0 {
        parts.push("DELETE");
    }
    if mask & libc::IN_ISDIR != 0 {
        parts.push("ISDIR");
    }
    parts.join("|")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mask_to_str() {
        assert_eq!(mask_to_str(libc::IN_CLOSE_WRITE), "CLOSE_WRITE");
        assert_eq!(
            mask_to_str(libc::IN_CLOSE_WRITE | libc::IN_MOVED_TO),
            "CLOSE_WRITE|MOVED_TO"
        );
        assert_eq!(mask_to_str(0), "");
    }

    #[test]
    fn test_parse_events_empty() {
        let wd2name: HashMap<i32, String> = HashMap::new();
        let mut out = Vec::new();
        parse_events(&[], &wd2name, &mut out);
        assert!(out.is_empty());
    }
}
