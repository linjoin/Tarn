//! Tarn Core Engine
//!
//! 系统级、高并发、低功耗的文件治理引擎核心。
//!
//! 模块结构:
//! - [`config`]: 三文件配置 (blacklist/whitelist/settings) 的 schema 与加载
//! - [`protect`]: 路径白名单校验 + 用户自定义保护匹配 (6 种白名单)
//! - [`matcher`]: DFA 通配符匹配引擎
//! - [`walker`]: Rayon 并行目录遍历 (getdents64 直读)
//! - [`executor`]: 先标记后删执行器 (批量 unlinkat)
//! - [`logger`]: crossbeam-channel 异步日志
//! - [`state`]: JSON 状态持久化
//! - [`reload`]: 热重载 (Arc<RwLock<Config>>)
//! - [`scheduler`]: timerfd + CLOCK_BOOTTIME_ALARM (穿透 Doze)
//! - [`sysutil`]: 低功耗工具 (nice/CPU 亲和性/pidfile/flock)
//! - [`daemon`]: 完整 daemon 循环 (timerfd + cron + 信号 + wake_lock)
//! - [`timeutil`]: 时区工具 (跟随系统时区, 日志/状态/调度统一)

pub mod config;
pub mod protect;
pub mod matcher;
pub mod walker;
pub mod executor;
pub mod logger;
pub mod state;
pub mod reload;
pub mod scheduler;
pub mod sysutil;
pub mod iouring_stat;
pub mod iouring_unlink;
pub mod daemon;
pub mod timeutil;
pub mod webroot;
pub mod module_prop;
pub mod config_watcher;
pub mod notify;

pub use config::{Settings, Whitelist, Blacklist, Rule, Target};
pub use protect::{ProtectSet, ALLOWED_ROOTS, is_target_allowed};
pub use matcher::Matcher;
pub use executor::{Executor, RunResult, RunOptions, Trigger};
pub use logger::{AsyncLogger, LogLevel, LogEntry};
pub use scheduler::{DozeTimer, WakeLock, CronSchedule};

/// 引擎版本
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// 配置 schema 版本
pub const CONFIG_SCHEMA_VERSION: u32 = 1;
