//! [v0.7.5] io_uring 批量 statx — 5.10+ 内核加速命中文件的元数据获取
//!
//! ## 背景
//! v0.7.4 延迟 stat 后, walker 不再 stat 每个文件, 改为 matcher 命中后 executor 才 stat。
//! 但命中量较大时 (宽 glob 规则, 如 **/*.log 命中几千上万), 逐个 lstat 仍有 N 次 syscall
//! (N 次 user/kernel 切换)。io_uring 批量 statx 把 N 次 lstat 合并为少量 io_uring_enter,
//! 显著降低切换开销。
//!
//! ## 全网调研依据
//! - io_uring_prep_statx(3) man page: IORING_OP_STATX opcode, 等价 statx(2) syscall
//! - Reddit r/rust + Rust Users Forum: batch statx via io_uring 实战讨论
//! - io-uring crate 0.7: 纯 Rust, 不依赖 liburing C 库, 直接 libc::syscall 调
//!   io_uring_setup/enter, 可交叉编译到 aarch64-linux-android (已验证)
//! - Linux 5.1 引入 io_uring, 5.1+ 支持 STATX opcode; Android GKI 5.10 (Android 12)
//!   是稳定基线, 用户已全面面向 5.10+ 机型
//!
//! ## 运行时检测 (v0.7.7 Android-aware)
//! - io_uring_setup_available() 真调 io_uring_setup 探测, 不只看内核版本
//! - 很多 Android 5.10/5.15 GKI 内核因 2023-2024 io_uring 漏洞被 OEM CONFIG_IO_URING=n
//!   编译掉或 SELinux/seccomp 禁用 → 真探测返回 false → 直接走 lstat, 不白做失败 setup
//! - 旧版 (v0.7.5-7.6) 只看 kernel_version_ge(5,10), 在 io_uring 被编译掉的 5.10+ 内核上
//!   每批清理都触发一次失败的 IoUring::new, 纯浪费. v0.7.7 改用真探测修复.
//! - io_uring 真可用 → 批量 statx; 否则回退 lstat 循环 (见 fallback_batch_lstat)
//!
//! ## 正确性
//! - STATX_SIZE | STATX_MTIME mask 只取需要的字段 (kernel 仍需 inode lookup, 但省 user/kernel 切换)
//! - AT_SYMLINK_NOFOLLOW flags 不跟随 symlink, 与 lstat 语义一致 (walker 原语义)
//! - 失败 (ENOENT 等) 返回 None, 调用方 entry 保持 0 (与 lstat_meta 失败行为一致)
//! - user_data 存路径索引, CQE reap 时按 user_data 定位结果填回
//!
//! ## 收益 (理论)
//! 命中 N 个文件:
//! - lstat 循环: N 次 syscall (N 次 user/kernel 切换, 每次 ~1μs)
//! - io_uring 批量: ceil(N/SQ_DEPTH) 次 io_uring_enter (submit+wait), 切换次数降 ~SQ_DEPTH 倍
//! - 命中 100: lstat 100 次切换 → io_uring ~1 次 (省 99%)
//! - 命中 1000: lstat 1000 次 → io_uring ~4 次 (省 99.6%)

use std::path::Path;

use once_cell::sync::OnceCell;

use crate::sysutil::io_uring_setup_available;

/// 是否启用 io_uring 批量 stat (Android-aware 真探测)。
///
/// 不只看内核版本, 而是真调 io_uring_setup:
/// - 5.10+ 但 CONFIG_IO_URING=n (很多 Android OEM 关闭) → false
/// - SELinux/seccomp 禁用 io_uring_setup → false
/// - 真正可用 → true
/// 结果 OnceCell 缓存, 全进程只探一次.
pub fn io_uring_available() -> bool {
    static AVAIL: OnceCell<bool> = OnceCell::new();
    *AVAIL.get_or_init(|| io_uring_setup_available())
}

/// 批量取多个文件的 (size, mtime)。
///
/// io_uring 真可用时用批量 statx; 否则回退 lstat 循环。
/// 返回 Vec 与输入 paths 等长, 每项 Option: None = stat 失败 (文件不存在/权限), Some = (size, mtime)。
///
/// 用 AT_SYMLINK_NOFOLLOW 不跟随 symlink, 与 lstat 语义一致。
pub fn batch_meta(paths: &[std::path::PathBuf]) -> Vec<Option<(u64, i64)>> {
    if !io_uring_available() || paths.is_empty() {
        return fallback_batch_lstat(paths);
    }
    match batch_statx_io_uring(paths) {
        Ok(v) => v,
        // io_uring 任何失败 (setup/submit/reap) 都回退 lstat, 保证正确性优先
        Err(_) => fallback_batch_lstat(paths),
    }
}

/// lstat 循环回退 (内核 < 5.10 或 io_uring 失败时用)
fn fallback_batch_lstat(paths: &[std::path::PathBuf]) -> Vec<Option<(u64, i64)>> {
    paths.iter().map(|p| lstat_meta(p)).collect()
}

/// 单文件 lstat (与 executor::lstat_meta 同实现, 此处独立保留供回退用)
fn lstat_meta(path: &Path) -> Option<(u64, i64)> {
    use std::os::unix::ffi::OsStrExt;
    let cstr = std::ffi::CString::new(path.as_os_str().as_bytes()).ok()?;
    let mut st: libc::stat = unsafe { std::mem::zeroed() };
    if unsafe { libc::lstat(cstr.as_ptr(), &mut st) } < 0 {
        return None;
    }
    Some((st.st_size as u64, st.st_mtime))
}

/// io_uring 批量 statx 实现。
///
/// 策略: SQ 容量有限 (默认 256 entries), 路径数 > SQ 容量时分批。
/// 每批: 填 SQE (pathname 用 CString, 必须存活到 reap) → submit+wait → 读 CQE 填结果。
/// user_data = 路径在 paths 中的全局索引, CQE reap 时按 user_data 定位。
fn batch_statx_io_uring(paths: &[std::path::PathBuf]) -> std::io::Result<Vec<Option<(u64, i64)>>> {
    use io_uring::{IoUring, opcode, types};

    // SQ entries 数 (同时是每批上限)。256 是平衡点: 够大覆盖常见命中量, 内存可控。
    // 实际 ring 会分配 2^ceil_pow2(256)=256 SQE + 256 CQE。
    const SQ_ENTRIES: u32 = 256;

    let mut ring = IoUring::new(SQ_ENTRIES)?;

    let mut results: Vec<Option<(u64, i64)>> = vec![None; paths.len()];

    // 预分配 CString 池 (pathname 必须存活到 reap, 不能在 build() 后立即 drop)
    // 每批复用: 批内 CString 存活, 批结束 drop
    let mut idx = 0usize;
    while idx < paths.len() {
        let batch_end = (idx + SQ_ENTRIES as usize).min(paths.len());
        let batch_size = batch_end - idx;

        // 1. 准备本批 CString (pathname 指针依赖 CString 存活)
        let cstrings: Vec<std::ffi::CString> = paths[idx..batch_end]
            .iter()
            .map(|p| {
                use std::os::unix::ffi::OsStrExt;
                std::ffi::CString::new(p.as_os_str().as_bytes())
                    .unwrap_or_else(|_| std::ffi::CString::new("").unwrap())
            })
            .collect();

        // 2. 准备 statx 缓冲区 (每路径一个 statx 结构体)
        let mut statx_bufs: Vec<libc::statx> = (0..batch_size)
            .map(|_| unsafe { std::mem::zeroed() })
            .collect();

        // STATX_SIZE | STATX_MTIME: 只取需要的字段 (kernel 仍需 inode lookup, 但明确告诉
        // kernel 我们不关心其他字段, 部分文件系统可省无关字段的 IO)
        const MASK: u32 = libc::STATX_SIZE | libc::STATX_MTIME;

        // 3. 提交 SQE (user_data = 全局路径索引)
        //    SQE 是 Borrowed SQE, 必须在 submit 前 push 完所有 SQE
        {
            let mut sq = ring.submission();
            for (i, cs) in cstrings.iter().enumerate() {
                let global_idx = idx + i;
                let statx_ptr = &mut statx_bufs[i] as *mut libc::statx as *mut types::statx;
                let statx_op = opcode::Statx::new(
                    types::Fd(libc::AT_FDCWD),
                    cs.as_ptr(),
                    statx_ptr,
                )
                .flags(libc::AT_SYMLINK_NOFOLLOW)
                .mask(MASK)
                .build()
                .user_data(global_idx as u64);

                // SQ 满时先 submit 一批 (理论上 batch_size <= SQ_ENTRIES 不会满, 防御性处理)
                if sq.is_full() {
                    drop(sq);
                    ring.submit_and_wait(batch_size)?;
                    sq = ring.submission();
                }
                // push 是 unsafe (操作共享队列内存), 但本线程独占 ring 且无并发 push, 安全
                unsafe { sq.push(&statx_op).map_err(|_| std::io::Error::other("sqe push"))?; }
            }
        }

        // 4. submit + wait 本批全部完成
        ring.submit_and_wait(batch_size)?;

        // 5. reap CQE, 按 user_data 定位填结果
        let cq = ring.completion();
        for cqe in cq {
            let global_idx = cqe.user_data() as usize;
            let res = cqe.result();
            if global_idx < results.len() && res >= 0 {
                let st = &statx_bufs[global_idx - idx];
                // stx_mask 检查字段是否真填充 (kernel 可能不支持某字段)
                let size = if (st.stx_mask & libc::STATX_SIZE) != 0 {
                    st.stx_size as u64
                } else {
                    0
                };
                let mtime = if (st.stx_mask & libc::STATX_MTIME) != 0 {
                    st.stx_mtime.tv_sec as i64
                } else {
                    0
                };
                results[global_idx] = Some((size, mtime));
            }
            // res < 0 (ENOENT 等): results[global_idx] 保持 None, 与 lstat 失败行为一致
        }

        idx = batch_end;
    }

    Ok(results)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    #[test]
    fn test_batch_meta_matches_lstat() {
        // 创建临时文件, 对比 io_uring 批量 vs lstat 单个, 结果应一致
        let tmp = std::env::temp_dir().join(format!("tarn_iouring_test_{}", std::process::id()));
        let _ = fs::create_dir_all(&tmp);
        let p1 = tmp.join("f1.txt");
        let p2 = tmp.join("f2.txt");
        fs::write(&p1, b"hello world").unwrap();
        fs::write(&p2, b"another file content here").unwrap();

        let paths = vec![p1.clone(), p2.clone()];
        let batch = batch_meta(&paths);
        assert_eq!(batch.len(), 2);

        // 对比 lstat 单个
        let s1 = lstat_meta(&p1).unwrap();
        let s2 = lstat_meta(&p2).unwrap();
        assert_eq!(batch[0], Some(s1), "p1 io_uring vs lstat 不一致");
        assert_eq!(batch[1], Some(s2), "p2 io_uring vs lstat 不一致");

        // size 应正确
        assert_eq!(s1.0, 11, "p1 size 应为 11");
        assert_eq!(s2.0, 25, "p2 size 应为 25");

        let _ = fs::remove_dir_all(&tmp);
    }

    #[test]
    fn test_batch_meta_nonexistent() {
        // 不存在的文件应返回 None (不 panic)
        let paths = vec![std::path::PathBuf::from("/nonexistent/tarn_test_12345")];
        let batch = batch_meta(&paths);
        assert_eq!(batch.len(), 1);
        assert_eq!(batch[0], None);
    }

    #[test]
    fn test_batch_meta_empty() {
        let batch = batch_meta(&[]);
        assert!(batch.is_empty());
    }

    #[test]
    fn test_io_uring_available_consistent() {
        // 多次调用应返回一致结果 (OnceCell 缓存)
        let a = io_uring_available();
        let b = io_uring_available();
        assert_eq!(a, b);
    }
}
