//! 状态持久化: JSON 文件 + 原子写 (tmp + fsync + rename)

use crate::executor::RunResult;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use parking_lot::RwLock;

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct State {
    pub schema_version: u32,
    pub last_updated: String,
    pub totals: Totals,
    pub last_run: Option<LastRun>,
    pub rules: HashMap<String, RuleState>,
    /// 最近运行历史 (最多 50 条, 先进先出)
    #[serde(default)]
    pub history: Vec<HistoryEntry>,
    /// 统计轮转归档历史 (FIFO, 最多 keep_rotation_history 份)
    ///
    /// 每次 totals 达到阈值被清零时, 旧 totals 快照存到这里。
    /// 让用户能查看每个"周期"的清理量, 而不是只看累计。
    #[serde(default)]
    pub rotation_history: Vec<RotationEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Totals {
    pub total_runs: u64,
    pub total_freed_bytes: u64,
    pub total_files_deleted: u64,
    /// 累计清理的空目录数
    #[serde(default)]
    pub total_dirs_removed: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct LastRun {
    pub run_id: String,
    pub ts_start: String,
    pub ts_end: String,
    pub trigger: String,
    pub freed_bytes: u64,
    pub files_deleted: u64,
    pub status: String,
    pub exit_code: i32,
    /// 本次是否为预览模式 (dry_run)
    ///
    /// true = 未实际删除, freed_bytes/files_deleted 仅表示"将要"清理的量。
    /// 前端据此显示"预览"标签和"将删除/将释放"措辞。
    #[serde(default)]
    pub dry_run: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RuleState {
    pub last_run: String,
    pub last_freed_bytes: u64,
    pub last_status: String,
    pub run_count: u64,
    /// 累计释放字节 (所有运行总和)
    #[serde(default)]
    pub total_freed_bytes: u64,
    /// 累计删除文件数
    #[serde(default)]
    pub total_files_deleted: u64,
    /// 成功次数 (last_status == "ok")
    #[serde(default)]
    pub success_count: u64,
    /// 失败次数 (last_status == "failed")
    #[serde(default)]
    pub fail_count: u64,
    /// 累计扫描文件数
    #[serde(default)]
    pub total_files_scanned: u64,
    /// 累计拦截文件数 (白名单保护)
    #[serde(default)]
    pub total_files_blocked: u64,
    /// 累计清理的空目录数
    #[serde(default)]
    pub total_dirs_removed: u64,
    /// 最近一次运行的 run_id
    #[serde(default)]
    pub last_run_id: String,
}

/// 历史记录单条 (轻量, 用于 WebUI 概览页趋势/时间线)
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct HistoryEntry {
    pub run_id: String,
    pub ts_start: String,
    pub ts_end: String,
    pub trigger: String,
    pub freed_bytes: u64,
    pub files_deleted: u64,
    pub files_scanned: u64,
    /// 本次清理的空目录数
    #[serde(default)]
    pub dirs_removed: u64,
    pub duration_ms: u64,
    pub dry_run: bool,
    pub exit_code: i32,
    /// Top 规则简表 (rule_id → freed_bytes, 最多 5 条)
    #[serde(default)]
    pub top_rules: Vec<(String, u64)>,
    /// 本次运行包含的所有规则 ID (用于规则详情历史过滤)
    #[serde(default)]
    pub rule_ids: Vec<String>,
    /// 每规则的状态简表 (rule_id → "ok"/"failed"/"skipped"/"blocked")
    #[serde(default)]
    pub rule_statuses: Vec<(String, String)>,
}

const MAX_HISTORY: usize = 50;

/// 统计轮转归档条目
///
/// 当 totals 达到阈值时, 把当前 totals 快照存为一条 RotationEntry,
/// 然后把 totals 清零开始新一轮统计。
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RotationEntry {
    /// 轮转发生时间 (RFC3339 CST)
    pub rotated_at: String,
    /// 触发轮转的原因: "files" (文件数达阈) / "bytes" (字节数达阈)
    pub reason: String,
    /// 本轮累计运行次数
    pub total_runs: u64,
    /// 本轮累计释放字节
    pub total_freed_bytes: u64,
    /// 本轮累计删除文件数
    pub total_files_deleted: u64,
    /// 本轮累计清理空目录数
    pub total_dirs_removed: u64,
}

/// 状态管理器 (线程安全)
pub struct StateManager {
    path: PathBuf,
    inner: Arc<RwLock<State>>,
}

impl StateManager {
    pub fn new(path: PathBuf) -> Self {
        let state = if path.exists() {
            std::fs::read_to_string(&path)
                .ok()
                .and_then(|s| serde_json::from_str(&s).ok())
                .unwrap_or_default()
        } else {
            State::default()
        };

        Self {
            path,
            inner: Arc::new(RwLock::new(state)),
        }
    }

    /// 记录一次运行结果
    ///
    /// 预览模式 (dry_run) 处理:
    /// - 仍记录 `last_run` 和 `history` (前端需展示"上次运行"和"运行时间线",
    ///   已通过 `dry_run` 字段区分预览/真删)
    /// - **不累加** `totals` / per-rule 累计 / `run_count`, 避免预览数据
    ///   污染"累计清理 X GB / Y 个文件"等真实统计
    pub fn record_run(&self, result: &RunResult) {
        let mut s = self.inner.write();
        Self::record_run_into(&mut s, result);
        drop(s);
        let _ = self.save();
    }

    /// [v0.7.8] 提取 record_run 核心逻辑 (不持锁/不 save), 供 record_run 和
    /// record_run_with_rotation 复用。record_run_with_rotation 改一次锁 + 一次 save,
    /// 消除旧版两次写锁 + 两次 save (每次 save 含 atomic_write + fsync) 的开销。
    fn record_run_into(s: &mut State, result: &RunResult) {
        if !result.dry_run {
            s.totals.total_runs += 1;
            s.totals.total_freed_bytes += result.freed_bytes;
            s.totals.total_files_deleted += result.files_deleted;
            // 累计空目录清理数
            s.totals.total_dirs_removed += result.dirs_removed;
        }

        s.last_run = Some(LastRun {
            run_id: result.run_id.clone(),
            ts_start: result.ts_start.clone(),
            ts_end: result.ts_end.clone(),
            trigger: result.trigger.clone(),
            freed_bytes: result.freed_bytes,
            files_deleted: result.files_deleted,
            status: if result.exit_code == 0 { "completed".to_string() } else { "failed".to_string() },
            exit_code: result.exit_code,
            dry_run: result.dry_run,
        });

        if !result.dry_run {
            for rr in &result.rules {
                let entry = s.rules.entry(rr.rule_id.clone()).or_default();
                entry.last_run = result.ts_start.clone();
                entry.last_freed_bytes = rr.freed_bytes;
                entry.last_status = format!("{:?}", rr.status).to_lowercase();
                entry.last_run_id = result.run_id.clone();
                entry.run_count += 1;
                entry.total_freed_bytes += rr.freed_bytes;
                entry.total_files_deleted += rr.files_deleted;
                entry.total_files_scanned += rr.files_scanned;
                entry.total_files_blocked += rr.files_blocked;
                // 累计空目录清理数
                entry.total_dirs_removed += rr.dirs_removed;
                // 成功/失败计数 (ok = 成功, failed = 失败, skipped/blocked 不计)
                match rr.status {
                    crate::executor::RuleStatus::Ok => entry.success_count += 1,
                    crate::executor::RuleStatus::Failed => entry.fail_count += 1,
                    _ => {}
                }
            }
        }

        // 历史记录 (FIFO, 最多 MAX_HISTORY 条)
        let mut top_rules: Vec<(String, u64)> = result.rules.iter()
            .map(|rr| (rr.rule_id.clone(), rr.freed_bytes))
            .filter(|(_, b)| *b > 0)
            .collect();
        top_rules.sort_by(|a, b| b.1.cmp(&a.1));
        top_rules.truncate(5);
        // 所有规则 ID + 每规则状态 (用于规则详情历史过滤)
        let rule_ids: Vec<String> = result.rules.iter().map(|rr| rr.rule_id.clone()).collect();
        let rule_statuses: Vec<(String, String)> = result.rules.iter()
            .map(|rr| (rr.rule_id.clone(), format!("{:?}", rr.status).to_lowercase()))
            .collect();
        s.history.push(HistoryEntry {
            run_id: result.run_id.clone(),
            ts_start: result.ts_start.clone(),
            ts_end: result.ts_end.clone(),
            trigger: result.trigger.clone(),
            freed_bytes: result.freed_bytes,
            files_deleted: result.files_deleted,
            files_scanned: result.files_scanned,
            dirs_removed: result.dirs_removed,
            duration_ms: result.duration_ms,
            dry_run: result.dry_run,
            exit_code: result.exit_code,
            top_rules,
            rule_ids,
            rule_statuses,
        });
        if s.history.len() > MAX_HISTORY {
            let drop_n = s.history.len() - MAX_HISTORY;
            s.history.drain(0..drop_n);
        }

        s.last_updated = now_iso();
    }

    /// 带轮转检查的运行记录
    ///
    /// 与 `record_run` 相同, 但在累加 totals 后检查是否达到轮转阈值。
    /// 达到则归档当前 totals 到 rotation_history 并清零 (history 数组保留)。
    /// 返回 Some(rotation_entry) 表示发生了轮转, 调用方可记日志/更新 module.prop。
    pub fn record_run_with_rotation(
        &self,
        result: &RunResult,
        rotate_after_files: u64,
        rotate_after_bytes: u64,
        keep_rotation_history: u32,
    ) -> Option<RotationEntry> {
        // [v0.7.8] 一次锁完成累加 + 轮转检查, 消除旧版两次写锁 + 两次 save
        // (旧版 record_run 内部一次锁+save, 外层再一次锁+save, 共 4 次 syscall)
        let mut s = self.inner.write();
        Self::record_run_into(&mut s, result);
        let files = s.totals.total_files_deleted;
        let bytes = s.totals.total_freed_bytes;
        let need_rotate = (rotate_after_files > 0 && files >= rotate_after_files)
            || (rotate_after_bytes > 0 && bytes >= rotate_after_bytes);
        if !need_rotate {
            // [v0.7.8 fix] 必须先 save 再返回! 旧版 record_run 内部总 save 一次,
            // 新版一次锁后如果直接 return None 会漏 save → 进程重启数据丢失。
            drop(s);
            let _ = self.save();
            return None;
        }

        let reason = if rotate_after_files > 0 && files >= rotate_after_files {
            "files".to_string()
        } else {
            "bytes".to_string()
        };
        let entry = RotationEntry {
            rotated_at: now_iso(),
            reason: reason.clone(),
            total_runs: s.totals.total_runs,
            total_freed_bytes: s.totals.total_freed_bytes,
            total_files_deleted: s.totals.total_files_deleted,
            total_dirs_removed: s.totals.total_dirs_removed,
        };

        // 归档 (FIFO, 保留 keep_rotation_history 份; 0 = 不保留仅清零)
        if keep_rotation_history > 0 {
            s.rotation_history.push(entry.clone());
            let max = keep_rotation_history as usize;
            if s.rotation_history.len() > max {
                let drop_n = s.rotation_history.len() - max;
                s.rotation_history.drain(0..drop_n);
            }
        }

        // 清零 totals (history + rules 保留, 仅累计 totals 清零)
        s.totals = Totals::default();
        s.last_updated = now_iso();
        drop(s);
        let _ = self.save();
        Some(entry)
    }

    /// 原子写入磁盘
    pub fn save(&self) -> std::io::Result<()> {
        let s = self.inner.read().clone();
        let json = serde_json::to_string_pretty(&s).map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))?;
        atomic_write(&self.path, &json)
    }

    /// 获取快照
    pub fn snapshot(&self) -> State {
        self.inner.read().clone()
    }
}

/// 原子写: tmp + fsync 文件 + fsync 父目录 + rename
///
/// fsync 父目录确保 rename 的 dirent 落盘, 防止掉电后 state.json 变空或旧。
pub fn atomic_write(path: &Path, content: &str) -> std::io::Result<()> {
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, content)?;
    let f = std::fs::File::open(&tmp)?;
    f.sync_all()?;
    drop(f);
    std::fs::rename(&tmp, path)?;
    // fsync 父目录确保 rename 的 dirent 落盘
    if let Some(parent) = path.parent() {
        if let Ok(pf) = std::fs::File::open(parent) {
            let _ = pf.sync_all();
        }
    }
    Ok(())
}

fn now_iso() -> String {
    crate::timeutil::now_cst_rfc3339()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::executor::{RuleResult, RuleStatus, RunResult, Trigger};

    fn test_state_path(name: &str) -> PathBuf {
        let p = std::env::temp_dir().join("tarn-test").join("state").join(name);
        let _ = std::fs::remove_dir_all(&p);
        std::fs::create_dir_all(&p).unwrap();
        p.join("state.json")
    }

    fn fake_run(dry_run: bool, freed: u64, files: u64, rule_id: &str) -> RunResult {
        let mut result = RunResult {
            run_id: format!("run-{}", if dry_run { "dry" } else { "real" }),
            trigger: "manual".to_string(),
            ts_start: now_iso(),
            ts_end: now_iso(),
            dry_run,
            freed_bytes: freed,
            files_deleted: files,
            dirs_removed: 0,
            rules: vec![RuleResult {
                rule_id: rule_id.to_string(),
                rule_name: rule_id.to_string(),
                status: RuleStatus::Ok,
                freed_bytes: freed,
                files_deleted: files,
                ..Default::default()
            }],
            ..Default::default()
        };
        result.rules_executed = 1;
        result.rules_planned = 1;
        result
    }

    /// 预览模式 (dry_run) 不应累加 totals / per-rule 累计 / run_count,
    /// 但应记录 last_run (带 dry_run 标记) 和 history。
    #[test]
    fn test_dry_run_does_not_pollute_totals() {
        let sm = StateManager::new(test_state_path("dry_pollute"));

        // 1. 记录一次预览运行: 将释放 1GB, 将删 100 文件
        sm.record_run(&fake_run(true, 1024 * 1024 * 1024, 100, "rule_a"));

        let snap = sm.snapshot();
        // totals 不应被预览污染
        assert_eq!(snap.totals.total_runs, 0, "预览不计入 total_runs");
        assert_eq!(snap.totals.total_freed_bytes, 0, "预览不计入 total_freed_bytes");
        assert_eq!(snap.totals.total_files_deleted, 0, "预览不计入 total_files_deleted");

        // last_run 应记录 (带 dry_run=true)
        let lr = snap.last_run.expect("last_run 应被记录");
        assert!(lr.dry_run, "last_run.dry_run 应为 true");
        assert_eq!(lr.freed_bytes, 1024 * 1024 * 1024);

        // history 应记录 (带 dry_run=true)
        assert_eq!(snap.history.len(), 1, "history 应保留预览记录");
        assert!(snap.history[0].dry_run);

        // per-rule 累计不应被预览污染
        let rs = snap.rules.get("rule_a");
        assert!(rs.is_none(), "预览不应创建 per-rule 累计条目");
    }

    /// 预览后再跑真删, totals 只反映真删那次。
    #[test]
    fn test_dry_run_then_real_run_totals() {
        let sm = StateManager::new(test_state_path("dry_then_real"));

        // 先预览 (将删 100 文件, 将释放 1GB)
        sm.record_run(&fake_run(true, 1024 * 1024 * 1024, 100, "rule_a"));
        // 再真删 (删 5 文件, 释放 50MB)
        sm.record_run(&fake_run(false, 50 * 1024 * 1024, 5, "rule_a"));

        let snap = sm.snapshot();
        // totals 只反映真删
        assert_eq!(snap.totals.total_runs, 1, "只计 1 次真删");
        assert_eq!(snap.totals.total_files_deleted, 5, "只计 5 个真删文件");
        assert_eq!(snap.totals.total_freed_bytes, 50 * 1024 * 1024, "只计 50MB 真释放");

        // per-rule 累计也只反映真删
        let rs = snap.rules.get("rule_a").expect("真删后应有 per-rule 条目");
        assert_eq!(rs.run_count, 1, "per-rule run_count 只计真删");
        assert_eq!(rs.total_files_deleted, 5);
        assert_eq!(rs.total_freed_bytes, 50 * 1024 * 1024);

        // last_run 反映最后一次 (真删)
        let lr = snap.last_run.expect("last_run 应存在");
        assert!(!lr.dry_run, "最后一次是真删");

        // history 保留两次 (预览 + 真删)
        assert_eq!(snap.history.len(), 2);
        assert!(snap.history[0].dry_run, "第一次是预览");
        assert!(!snap.history[1].dry_run, "第二次是真删");
    }

    /// 预览模式不应触发统计轮转 (即使预览量超过轮转阈值)。
    #[test]
    fn test_dry_run_does_not_trigger_rotation() {
        let sm = StateManager::new(test_state_path("dry_rotation"));

        // 预览一个超大清理量 (超过 100 文件阈值)
        let big_dry = fake_run(true, 0, 200, "rule_a");
        let rotated = sm.record_run_with_rotation(&big_dry, 100, 0, 3);
        assert!(rotated.is_none(), "预览不应触发轮转");

        let snap = sm.snapshot();
        assert!(snap.rotation_history.is_empty(), "预览不应产生轮转归档");
        assert_eq!(snap.totals.total_files_deleted, 0, "预览后 totals 仍为 0");

        // 真删超过阈值才触发轮转
        let big_real = fake_run(false, 0, 150, "rule_a");
        let rotated = sm.record_run_with_rotation(&big_real, 100, 0, 3);
        assert!(rotated.is_some(), "真删超过阈值应触发轮转");
    }

    /// [v0.7.8] !need_rotate 分支必须 save 到磁盘 (回归保护)
    /// 主审查发现: record_run_with_rotation 一次锁后, !need_rotate 直接 return None 漏 save,
    /// 进程重启后 state.json 丢失本次 run。本测试模拟进程重启验证磁盘持久化。
    #[test]
    fn test_record_run_with_rotation_no_rotate_persists_to_disk() {
        let path = test_state_path("no_rotate_persist");
        let freed = 50 * 1024 * 1024; // 50MB
        let files = 50; // < 100 阈值, 不触发轮转

        // 第一次进程: record_run_with_rotation 不触发轮转
        {
            let sm = StateManager::new(path.clone());
            let rotated = sm.record_run_with_rotation(&fake_run(false, freed, files, "rule_a"), 100, 0, 3);
            assert!(rotated.is_none(), "50 < 100 阈值, 不应轮转");
            // sm drop 时也不 save (save 在 record_run_with_rotation 内)
        }

        // 第二次进程: 重新加载同一 state.json, 验证数据持久化
        let sm2 = StateManager::new(path.clone());
        let snap = sm2.snapshot();
        assert_eq!(snap.totals.total_runs, 1, "total_runs 应已持久化");
        assert_eq!(snap.totals.total_freed_bytes, freed, "total_freed_bytes 应已持久化");
        assert_eq!(snap.totals.total_files_deleted, files, "total_files_deleted 应已持久化");
        assert_eq!(snap.history.len(), 1, "history 应有 1 条记录");
        assert!(snap.last_run.is_some(), "last_run 应存在");
        assert!(snap.rotation_history.is_empty(), "不应有轮转归档");
    }

    /// [v0.7.8] need_rotate 分支的磁盘持久化 (轮转后 totals 清零, rotation_history 归档)
    #[test]
    fn test_record_run_with_rotation_rotate_persists_to_disk() {
        let path = test_state_path("rotate_persist");
        let freed = 200 * 1024 * 1024; // 200MB
        let files = 150; // > 100 阈值, 触发轮转

        {
            let sm = StateManager::new(path.clone());
            let rotated = sm.record_run_with_rotation(&fake_run(false, freed, files, "rule_a"), 100, 0, 3);
            assert!(rotated.is_some(), "150 > 100 阈值, 应轮转");
        }

        let sm2 = StateManager::new(path.clone());
        let snap = sm2.snapshot();
        // 轮转后 totals 清零
        assert_eq!(snap.totals.total_runs, 0, "轮转后 totals 清零");
        assert_eq!(snap.totals.total_files_deleted, 0, "轮转后 totals 清零");
        // 但 rotation_history 有归档
        assert_eq!(snap.rotation_history.len(), 1, "应有 1 条轮转归档");
        assert_eq!(snap.rotation_history[0].total_files_deleted, files, "归档记录原值");
        assert_eq!(snap.rotation_history[0].total_freed_bytes, freed, "归档记录原值");
        // history 保留
        assert_eq!(snap.history.len(), 1, "history 保留");
    }

    // 确认 Trigger 等枚举在测试中被引用 (避免未使用 import 警告)
    #[test]
    fn _ensure_trigger_used() {
        let _ = Trigger::Manual;
    }
}
