//! 系统调用工具: 低功耗 + 高性能调优
//!
//! 基于 RESEARCH-4 调研结论 + 理论验证 (搜索 Baidu/CSDN/Zhihu/GitHub/Juejin/Google):
//! - `nice(19)` 把进程优先级降到最低, 不与前台争 CPU
//!   理论依据: Linux CFS 调度器用 nice 值计算时间片权重 (weight = 1024 * 1.25^(-nice)),
//!   nice 19 → weight ~15, 占 CPU 约 1.5%。Android Bionic libc 完整支持 setpriority(2),
//!   内核一定遵守。✓ 在所有 Android 设备上有效 (kernel.org/scheduler/sched-design-CFS)。
//! - `ioprio_set(IOPRIO_CLASS_IDLE)` 不使用
//!   理论依据: ionice IDLE 类仅在 CFQ/BFQ 调度器下生效 (kernel/block/ioprio.c)。
//!   CFQ 调度器在内核 5.x 已被移除; Android 的 UFS/eMMC 闪存默认用 mq-deadline /
//!   none / kyber 调度器, 这些调度器**完全忽略 ioprio**, IDLE 类调用是空操作,
//!   绝大多数 Android 设备上无效, 故不调用。
//! - `sched_setaffinity` 绑定到小核 (big.LITTLE 的 LITTLE cluster), 避免占大核
//!   理论依据: big.LITTLE 架构下小核频率低、性能弱, 绑核后 daemon 只在小核运行,
//!   不抢占大核导致前台 jank。Google NDK 工程师确认 cpuinfo_max_freq 可用于探测小核
//!   (cpu_capacity 更优但部分设备损坏, 故用 cpuinfo_max_freq + 兜底)。
//! - `oom_score_adj` 调低, 防 OOM killer 误杀 daemon
//!
//! CPU 亲和性 per-thread 遗漏问题:
//!   Linux 上 sched_setaffinity(pid=0) 只设调用线程, 已 spawn 的线程
//!   (logger / webui / tokio worker) 不受影响。
//!
//!   解决方案 ([`set_cpu_affinity_all_threads`]):
//!   1. 先设当前线程 (pid=0), 后续 spawn 的线程继承此 affinity
//!   2. 遍历 /proc/self/task/<tid> 对每个已存在的线程单独调 sched_setaffinity(tid)
//!   这样既覆盖已 spawn 的线程 (logger/webui/tokio), 又覆盖未来 spawn 的线程, 无遗漏。
//!   ESRCH (线程刚退出) 静默跳过, 其他错误记录但不中断。
//!
//!   小核探测 ([`detect_little_cores`]): 读 /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq,
//!   取频率最低的那组, 容忍 ±5% 同频误差。失败回退 [0,1,2,3]。
//!
//! 空闲时 CPU 占用: daemon 主循环 timerfd poll(-1) 阻塞, logger 线程 rx.recv() 阻塞,
//! 信号线程 sigwait 阻塞, WebUI tokio epoll park — 全部 0 CPU, 不与前台争资源。
//! 日志采用手动刷新 (/api/logs/recent), 不做后台轮询, 避免 WebUI 空闲时的周期性 CPU 唤醒。
//!
//! 这些都是 root 进程特权操作, 普通用户调用会失败但不会 panic (优雅降级)。

use std::io;

// ============================================================
// 常量定义
// ============================================================

/// nice 最高优先级降到 19 (最低)
pub const NICE_LOWEST: i32 = 19;

/// oom_score_adj 最低 (-1000 = 禁止被 OOM kill)
pub const OOM_SCORE_ADJ_MIN: i32 = -1000;
/// daemon 推荐值: -1000 (完全禁止被 OOM killer 杀死)
///
/// 值为 -1000 (完全豁免被 OOM kill)。清理大批文件后系统内存压力上升,
/// OOM killer 在更高阈值 (如 -900) 仍有概率选中 daemon (尤其清理涉及数千文件的
/// 系统级规则包时), -1000 完全豁免, daemon 永远不会被 OOM kill, 保证 cron 调度
/// 连续性。daemon 自身内存占用稳定在 ~3MB, 不会成为内存大户。
pub const OOM_SCORE_ADJ_DAEMON: i32 = -1000;

// ============================================================
// 低功耗调优诊断报告
// ============================================================

/// 低功耗调优诊断报告
///
/// 让用户清楚知道每项调优是否真正生效, 而不是 "调用了就当生效"。
/// nice 总是有效 (内核 CFS 保证); affinity 取决于权限。
///
/// 不使用 ionice IDLE — 在绝大多数 Android 设备的 mq-deadline / none /
/// kyber 调度器下是空操作, CFQ 调度器也已在内核 5.x 移除, 保留无意义。
#[derive(Debug, Clone)]
pub struct LowPowerReport {
    /// nice 是否调用成功
    pub nice_applied: bool,
    /// nice 值 (19 = 最低优先级)
    pub nice_value: i32,
    /// CPU 亲和性是否调用成功
    pub affinity_applied: bool,
    /// 绑定的 CPU 核心列表
    pub affinity_cores: Vec<usize>,
    /// 各项操作的错误信息 (空 = 无错误)
    pub errors: Vec<String>,
}

impl LowPowerReport {
    /// 生成面向用户的单行摘要 (用于 module.prop description / 日志)
    pub fn summary_line(&self) -> String {
        let nice_str = if self.nice_applied {
            format!("nice={} ✓", self.nice_value)
        } else {
            "nice ✗".to_string()
        };
        let aff_str = if !self.affinity_cores.is_empty() && self.affinity_applied {
            format!("绑核 {:?} ✓", self.affinity_cores)
        } else if !self.affinity_cores.is_empty() {
            format!("绑核 {:?} ✗", self.affinity_cores)
        } else {
            "无绑核".to_string()
        };
        format!("{} | {}", nice_str, aff_str)
    }
}

// ============================================================
// 公开 API
// ============================================================

/// 应用低功耗调优: nice + (可选) CPU 亲和性
///
/// - `cpu_affinity` 为空: 跳过亲和性 (仅 nice)
/// - `cpu_affinity` 非空: 绑定到指定核心, 且通过 /proc/self/task 遍历覆盖所有线程
///
/// 组合: nice 19 让 CFS 调度器不优先调度 tarn (所有 Android 设备有效),
/// affinity 绑小核避免占大核导致前台 jank。空闲时 daemon 全程阻塞等待, 0 CPU。
///
/// 不使用 ionice IDLE — 在绝大多数 Android 设备的 mq-deadline / none / kyber
/// 调度器下是空操作, CFQ 调度器也已在内核 5.x 移除, 保留无意义。
///
/// 全部失败容错, 单项失败不影响其他。返回 [`LowPowerReport`] 诊断报告,
/// 调用方可据报告向用户展示每项调优是否真正生效。
pub fn apply_low_power(cpu_affinity: &[usize]) -> LowPowerReport {
    let mut report = LowPowerReport {
        nice_applied: false,
        nice_value: NICE_LOWEST,
        affinity_applied: false,
        affinity_cores: cpu_affinity.to_vec(),
        errors: Vec::new(),
    };

    // 1. nice — 内核 CFS 一定遵守, 所有 Android 设备有效
    if let Err(e) = set_nice(NICE_LOWEST) {
        report.errors.push(format!("nice({}): {}", NICE_LOWEST, e));
    } else {
        report.nice_applied = true;
    }

    // 2. CPU 亲和性 — 遍历 /proc/self/task 覆盖所有线程
    if !cpu_affinity.is_empty() {
        let aff_errs = set_cpu_affinity_all_threads(cpu_affinity);
        if aff_errs.is_empty() {
            report.affinity_applied = true;
        } else {
            report.errors.extend(aff_errs);
        }
    }

    report
}

/// 设置进程 nice 值 (优先级)
///
/// 用 `setpriority(PRIO_PROCESS, 0, value)` 替代 `nice()`,
/// 因为 nice() 的 -1 返回值歧义 (可能是合法值也可能是错误),
/// 而 setpriority 返回 0/-1 语义清晰, 且跨平台兼容 (Android Bionic 也支持)。
///
/// `value`: 19 = 最低优先级, -20 = 最高。root 可任意调。
pub fn set_nice(value: i32) -> io::Result<()> {
    let r = unsafe { libc::setpriority(libc::PRIO_PROCESS, 0, value) };
    if r < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

/// 设置 CPU 亲和性 (绑定到指定 CPU 核心) — 仅设当前线程
///
/// `sched_setaffinity(2)`: 把当前线程限制在这些 CPU 上跑。
/// big.LITTLE 上绑小核 (通常是 0-3) 避免占大核导致前台 jank。
///
/// 注意: Linux 上 sched_setaffinity 是 per-thread 的, 只影响调用线程。
/// 要覆盖进程内所有线程 (含已 spawn 的 logger/webui/tokio worker), 请用
/// [`set_cpu_affinity_all_threads`]。
pub fn set_cpu_affinity(cpus: &[usize]) -> io::Result<()> {
    if cpus.is_empty() {
        return Ok(());
    }
    let mut set: libc::cpu_set_t = unsafe { std::mem::zeroed() };
    for &cpu in cpus {
        // 边界检查, 防 CPU_SET 越界写 (UB)。
        // CPU_SETSIZE = 1024, cpu >= 1024 会越界 __bits 数组 → 栈溢出/crash。
        if cpu >= 1024 {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("cpu_affinity 越界 (0-1023): {}", cpu),
            ));
        }
        // CPU_SET 宏: 设第 cpu 位
        unsafe { libc::CPU_SET(cpu, &mut set); }
    }
    let r = unsafe { libc::sched_setaffinity(0, std::mem::size_of::<libc::cpu_set_t>(), &set) };
    if r < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

/// 设置 CPU 亲和性到进程内所有线程 (覆盖 per-thread 遗漏问题)
///
/// Linux 上 sched_setaffinity(pid=0) 只设调用线程, 已 spawn 的线程不受影响。
/// daemon 启动顺序: logger 线程 + webui 线程 (含 tokio worker) 在 run_daemon 之前
/// 就已 spawn, 单纯在 run_daemon 里调 sched_setaffinity(0) 无法覆盖它们。
///
/// 策略:
/// 1. 先设当前线程 (pid=0) — 后续 spawn 的线程 (signal 等) 继承此 affinity
/// 2. 遍历 /proc/self/task/<tid>, 对每个已存在的线程单独调 sched_setaffinity(tid)
///    覆盖 logger / webui / tokio worker 等先于本函数 spawn 的线程
///
/// ESRCH (线程刚退出) 静默跳过, 其他错误收集返回但不中断。
/// 返回所有失败原因 (空 = 全成功)。
pub fn set_cpu_affinity_all_threads(cpus: &[usize]) -> Vec<String> {
    let mut errs = Vec::new();
    if cpus.is_empty() {
        return errs;
    }
    // 构造 cpu_set_t
    // [v0.7.8 fix] 边界检查, 防 CPU_SET 越界写 (UB)。
    // 与 set_cpu_affinity 一致: cpu >= 1024 会越界 __bits 数组 → 栈溢出/crash。
    // config validate 已校验, 这里是防御性兜底 (防直接调用此函数的路径绕过 validate)。
    let mut set: libc::cpu_set_t = unsafe { std::mem::zeroed() };
    for &cpu in cpus {
        if cpu >= 1024 {
            errs.push(format!("cpu_affinity 越界 (0-1023), 跳过: {}", cpu));
            continue;
        }
        unsafe { libc::CPU_SET(cpu, &mut set); }
    }
    let set_size = std::mem::size_of::<libc::cpu_set_t>();

    // 1. 设当前线程 (pid=0), 后续新线程继承
    let r = unsafe { libc::sched_setaffinity(0, set_size, &set) };
    if r < 0 {
        errs.push(format!("sched_setaffinity(self): {}", io::Error::last_os_error()));
    }

    // 2. 遍历 /proc/self/task/<tid> 设所有已存在的线程
    //    覆盖 logger / webui / tokio worker 等先于本函数 spawn 的线程
    if let Ok(entries) = std::fs::read_dir("/proc/self/task") {
        for entry in entries.flatten() {
            let name = entry.file_name();
            let name_str = match name.to_str() {
                Some(s) => s,
                None => continue,
            };
            let tid: i32 = match name_str.parse() {
                Ok(t) => t,
                Err(_) => continue,
            };
            // 跳过 0 (实际 /proc/self/task 不会有 0, 防御)
            if tid == 0 {
                continue;
            }
            let r = unsafe { libc::sched_setaffinity(tid, set_size, &set) };
            if r < 0 {
                let e = io::Error::last_os_error();
                // ESRCH = 线程刚退出, 静默跳过 (遍历期间线程可能已退出)
                if e.raw_os_error() != Some(libc::ESRCH) {
                    errs.push(format!("sched_setaffinity(tid={}): {}", tid, e));
                }
            }
        }
    }

    errs
}

/// 探测小核 CPU 编号 (big.LITTLE)
///
/// 策略: 读 /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq,
/// 取频率最低的那组作为小核。失败则默认 0-3。
pub fn detect_little_cores() -> Vec<usize> {
    let mut freqs: Vec<(usize, u64)> = Vec::new();
    for i in 0..16 {
        let path = format!("/sys/devices/system/cpu/cpu{}/cpufreq/cpuinfo_max_freq", i);
        if let Ok(s) = std::fs::read_to_string(&path) {
            if let Ok(khz) = s.trim().parse::<u64>() {
                freqs.push((i, khz));
            }
        }
    }
    if freqs.is_empty() {
        return vec![0, 1, 2, 3];
    }
    // 取频率最低的 (小核), 多于 4 个时取前 4
    let mut sorted = freqs.clone();
    sorted.sort_by_key(|(_, f)| *f);
    let min_freq = sorted.first().map(|(_, f)| *f).unwrap_or(0);
    // 同频的都算小核 (容忍 ±5%)
    let threshold = min_freq + min_freq / 20;
    let little: Vec<usize> = sorted
        .iter()
        .filter(|(_, f)| *f <= threshold)
        .map(|(c, _)| *c)
        .take(4)
        .collect();
    if little.is_empty() {
        vec![0, 1, 2, 3]
    } else {
        little
    }
}

/// 设置 oom_score_adj (防 OOM kill)
///
/// 写 /proc/self/oom_score_adj, 范围 -1000 到 1000。
pub fn set_oom_score_adj(value: i32) -> io::Result<()> {
    std::fs::write("/proc/self/oom_score_adj", value.to_string())
}

/// 忽略 SIGPIPE (防止管道写断终止 daemon)
///
/// 默认 SIGPIPE 处置 = Term (终止进程)。Android root daemon 写日志/状态/socket 时,
/// 若对端关闭, 内核投递 SIGPIPE, daemon 被杀。改用 SIG_IGN 后, write() 返回 EPIPE。
///
/// 信号处置是进程级属性, 任何线程调用后对所有线程生效。
/// 建议在 spawn 任何线程之前调用 (新线程继承信号处置)。
pub fn ignore_sigpipe() {
    unsafe {
        let _ = libc::signal(libc::SIGPIPE, libc::SIG_IGN);
    }
}

/// 读取指定 PID 进程的实际 nice 值 (从 /proc/<pid>/stat 第 19 字段)
///
/// 用于 WebUI 向用户展示 "daemon 的 nice 值确实是 19" 的铁证。
/// 失败返回 None。
pub fn read_proc_nice(pid: i32) -> Option<i32> {
    let stat = std::fs::read_to_string(format!("/proc/{}/stat", pid)).ok()?;
    // /proc/<pid>/stat 格式 (1-indexed, 见 man proc):
    //   1 pid 2 comm 3 state 4 ppid 5 pgrp 6 session 7 tty_nr 8 tpgid 9 flags
    //   10 minflt 11 cminflt 12 majflt 13 cmajflt 14 utime 15 stime
    //   16 cutime 17 cstime 18 priority 19 nice 20 num_threads ...
    // comm 可能含空格和括号, 从最后一个 ')' 之后开始解析字段。
    // rfind(')') 后 split_whitespace 的第一个字段是 field 3 (state),
    // 因此 fields 索引 = stat 字段号 - 3:
    //   fields[0]=state(3) fields[1]=ppid(4) ... fields[15]=priority(18)
    //   fields[16]=nice(19) fields[17]=num_threads(20)
    let after_comm = stat.rfind(')')?;
    let rest = &stat[after_comm + 1..];
    let fields: Vec<&str> = rest.split_whitespace().collect();
    // nice 是 stat 第 19 字段 = fields[16]
    fields.get(16).and_then(|s| s.parse::<i32>().ok())
}

/// 读取指定 PID 进程的 CPU 亲和性 (从 /proc/<pid>/status 的 Cpus_allowed_list)
///
/// 返回人类可读的格式如 "0-3" 或 "0,2-3"。用于 WebUI 展示 "daemon 确实绑在小核"。
/// 失败返回 None。
pub fn read_proc_cpus_allowed_list(pid: i32) -> Option<String> {
    let status = std::fs::read_to_string(format!("/proc/{}/status", pid)).ok()?;
    for line in status.lines() {
        if let Some(rest) = line.strip_prefix("Cpus_allowed_list:") {
            return Some(rest.trim().to_string());
        }
    }
    None
}

/// 获取当前进程 PID
pub fn current_pid() -> i32 {
    unsafe { libc::getpid() }
}

/// 获取当前进程 UID
pub fn current_uid() -> u32 {
    unsafe { libc::getuid() }
}

/// 检查是否 root
pub fn is_root() -> bool {
    current_uid() == 0
}

/// 检查指定 PID 是否存活
pub fn pid_alive(pid: i32) -> bool {
    // kill(pid, 0) 返回 0 表示存活
    unsafe { libc::kill(pid, 0) == 0 }
}

/// 检查指定 PID 的 cmdline 是否包含某关键字 (防 PID 复用)
pub fn pid_cmdline_contains(pid: i32, keyword: &str) -> bool {
    let path = format!("/proc/{}/cmdline", pid);
    if let Ok(bytes) = std::fs::read(&path) {
        // cmdline 用 NUL 分隔参数
        let cmdline = String::from_utf8_lossy(&bytes).replace('\0', " ");
        return cmdline.contains(keyword);
    }
    false
}

/// 对 pidfile 加排它锁并写入 PID (flock + truncate + write, 不用 rename)
///
/// 返回 fd (保持打开 = 持锁, 关闭 = 释放)。崩溃自动释放。
/// 这是比 kill -0 更严谨的防多开方案。
///
/// 单一函数同时持锁和写 pid: 对同一个 fd 先 flock 后 truncate+write, 不 rename。
/// 若分两步 (lock_pidfile + write_pidfile), write_pidfile 用 tmp+rename 会替换 inode,
/// 导致 _lock_file 持有的 flock 仍锁在旧 inode 上, 磁盘上的新 pidfile (新 inode) 完全无锁,
/// 第二个实例能再次 lock 成功 → 防多开失效, 双开导致 state.json 并发写坏。
///
/// 权限 0o600 (仅 root 可读), 避免 PID 信息泄漏
pub fn lock_and_write_pidfile(path: &std::path::Path, pid: i32) -> io::Result<std::fs::File> {
    use std::io::Write;
    use std::os::unix::io::AsRawFd;
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let f = std::fs::OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false) // 不 truncate, 先拿锁再 truncate 防竞态
        .mode(0o600) // 0o600, 防止其他用户读取 PID
        .open(path)?;
    // 1. 先拿 flock (非阻塞), 失败说明已有实例运行
    let r = unsafe { libc::flock(f.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) };
    if r < 0 {
        let e = io::Error::last_os_error();
        return Err(io::Error::new(
            e.kind(),
            format!("pidfile 已被其他实例锁定: {}", e),
        ));
    }
    // 2. 拿到锁后 truncate + write PID (同一 inode, 锁不丢失)
    let content = format!("{}\n", pid);
    f.set_len(0)?;
    {
        let mut f = &f; // 借用, 不消耗
        f.write_all(content.as_bytes())?;
        f.flush()?;
    }
    f.sync_all()?;
    // fsync 父目录 (防掉电后 metadata 未持久化)
    if let Some(parent) = path.parent() {
        if let Ok(pf) = std::fs::File::open(parent) {
            let _ = pf.sync_all();
        }
    }
    Ok(f)
}

/// 尝试获取清理互斥锁 (跨进程 flock)。
///
/// daemon cron 和 WebUI api_clean 执行清理前调用, 防止两路并发清理同一路径
/// 产生 race (删除操作本身幂等, 但并发会导致: 审计重复计数 / state.json 并发写坏 /
/// 用户在 WebUI 点清理时 daemon 正好 cron 触发, 两路同时扫同一目录)。
///
/// 实现: 对 `<config_dir>/run/cleaning.lock` 加 flock LOCK_EX | LOCK_NB。
/// - 返回 Ok(File): 持锁成功, File drop 时自动释放锁 (RAII)
/// - 返回 Err: 已有清理在跑 (另一进程或线程持有锁)
///
/// 跨进程有效 (flock 是系统级锁), 同进程内不同线程也有效。
/// 崩溃自动释放 (fd 关闭即解锁)。
pub fn try_lock_cleaning(lock_path: &std::path::Path) -> io::Result<std::fs::File> {
    use std::os::unix::io::AsRawFd;
    if let Some(parent) = lock_path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let f = std::fs::OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false)
        .mode(0o600)
        .open(lock_path)?;
    let r = unsafe { libc::flock(f.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) };
    if r < 0 {
        let e = io::Error::last_os_error();
        return Err(io::Error::new(
            e.kind(),
            format!("cleaning.lock 已被持有 (另一清理正在进行): {}", e),
        ));
    }
    Ok(f)
}

/// 读 pidfile 中的 PID
pub fn read_pidfile(path: &std::path::Path) -> Option<i32> {
    std::fs::read_to_string(path)
        .ok()
        .and_then(|s| s.trim().parse::<i32>().ok())
}

/// 删除 pidfile
pub fn remove_pidfile(path: &std::path::Path) {
    let _ = std::fs::remove_file(path);
}

// ============================================================
// [v0.7.5] 内核版本检测 — io_uring 批量 stat 前置判断
// ============================================================
// io_uring 在 Linux 5.1 引入, statx opcode 在 5.1+ 支持, 但 Android 设备
// GKI 5.10 是稳定基线 (Android 12), 用户已全面面向 5.10+ 机型。
// 运行时 uname() 读 release 字段, 解析 "5.10.x" 形式, 与 (major, minor) 比较。
// 用 once_cell 缓存 (uname 是 syscall, 但调用频率低, 缓存主要为简洁)。

/// 判断当前内核版本 >= (major, minor)。
///
/// 解析 uname().release 的主.次版本号。失败 (解析不出数字) 时保守返回 false,
/// 确保不支持时回退到安全路径 (lstat 循环)。
///
/// 例: kernel_version_ge(5, 10) → 内核 5.10+ 返回 true, 5.9/4.x 返回 false。
pub fn kernel_version_ge(major: u32, minor: u32) -> bool {
    use once_cell::sync::OnceCell;
    static CACHED: OnceCell<(u32, u32)> = OnceCell::new();
    let (kmaj, kmin) = *CACHED.get_or_init(|| {
        // uname() syscall, 失败返回 (0, 0) → 后续比较恒 false → 保守回退
        let mut buf: libc::utsname = unsafe { std::mem::zeroed() };
        let r = unsafe { libc::uname(&mut buf) };
        if r != 0 {
            return (0, 0);
        }
        // release 字段是 [c_char; 65], NUL 结尾。取到 NUL 前的字节。
        let release: Vec<u8> = buf
            .release
            .iter()
            .take_while(|&&c| c != 0)
            .map(|&c| c as u8)
            .collect();
        let s = String::from_utf8_lossy(&release);
        parse_kernel_version(&s).unwrap_or((0, 0))
    });
    // 比较: major 更大 → true; major 相等 minor 更大或相等 → true
    (kmaj, kmin) >= (major, minor)
}

/// 返回 uname release 完整字符串 (如 "5.10.66-android13-8-00100-g...")。
///
/// 用于日志打印"检测到内核版本为 xxx"。失败返回 "unknown"。
/// 与 kernel_version_ge 共用 OnceCell 缓存, 不重复 syscall。
pub fn kernel_version_string() -> String {
    use once_cell::sync::OnceCell;
    static CACHED: OnceCell<String> = OnceCell::new();
    CACHED.get_or_init(|| {
        let mut buf: libc::utsname = unsafe { std::mem::zeroed() };
        let r = unsafe { libc::uname(&mut buf) };
        if r != 0 {
            return "unknown".to_string();
        }
        let release: Vec<u8> = buf
            .release
            .iter()
            .take_while(|&&c| c != 0)
            .map(|&c| c as u8)
            .collect();
        String::from_utf8_lossy(&release).into_owned()
    })
    .clone()
}

/// 解析 uname release 字符串的主.次版本号。
/// 例: "5.10.66-android13-8-00100-g..." → Some((5, 10))
///     "4.14.190" → Some((4, 14))
///     "garbage" → None
fn parse_kernel_version(s: &str) -> Option<(u32, u32)> {
    let bytes = s.as_bytes();
    let mut i = 0;
    // 跳过前导非数字 (有些发行版有前缀, 虽然 Android 一般没有)
    while i < bytes.len() && !bytes[i].is_ascii_digit() {
        i += 1;
    }
    let major_start = i;
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    let major: u32 = s[major_start..i].parse().ok()?;
    // 跳过分隔符 (. 或 -)
    if i < bytes.len() && (bytes[i] == b'.' || bytes[i] == b'-') {
        i += 1;
    }
    let minor_start = i;
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    let minor: u32 = s[minor_start..i].parse().ok()?;
    Some((major, minor))
}

// ============================================================
// [v0.7.6] 文件系统类型探测 — ext4+discard 是删除性能头号杀手
// ============================================================
// 全网调研依据 (patrick-nagel.net/blog/archives/337, lwn.net/Articles/787272):
// ext4 + discard mount option 删一批小文件比无 discard 慢 64 倍 (同步 TRIM 阻塞每次 unlink)。
// f2fs 默认 async discard 影响小。运行时 statfs 读 f_type + 解析 /proc/mounts 看 discard。

/// 文件系统类型
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsType {
    Ext4,
    F2fs,
    Other,
}

/// 探测指定路径所在分区的文件系统类型。
///
/// 用 statfs() 读 f_type:
/// - ext4 = 0xef53
/// - f2fs = 0xf2f52010
/// 失败返回 Other。
pub fn detect_fs_type(path: &std::path::Path) -> FsType {
    let p = path.to_str().unwrap_or("/");
    let cstr = match std::ffi::CString::new(p) {
        Ok(c) => c,
        Err(_) => return FsType::Other,
    };
    let mut buf: libc::statfs = unsafe { std::mem::zeroed() };
    let r = unsafe { libc::statfs(cstr.as_ptr(), &mut buf) };
    if r != 0 {
        return FsType::Other;
    }
    // f_type 常量见 linux/magic.h
    const EXT4_SUPER_MAGIC: i64 = 0xEF53;
    const F2FS_SUPER_MAGIC: i64 = 0xF2F52010;
    match buf.f_type as i64 {
        EXT4_SUPER_MAGIC => FsType::Ext4,
        F2FS_SUPER_MAGIC => FsType::F2fs,
        _ => FsType::Other,
    }
}

/// 探测指定路径所在分区是否挂载了 discard 选项。
///
/// 解析 /proc/mounts, 找到覆盖 path 的最长前缀挂载点, 检查其 mount options 是否含 "discard"。
/// 失败 (读不了 /proc/mounts 或找不到挂载点) 返回 false (保守不限速)。
pub fn is_mount_discard(path: &std::path::Path) -> bool {
    let mounts = match std::fs::read_to_string("/proc/mounts") {
        Ok(s) => s,
        Err(_) => return false,
    };
    let path_str = path.to_str().unwrap_or("/");
    match_mountpoint_discard(&mounts, path_str)
}

/// [v0.7.8] 提取为纯函数, 便于单元测试 (无需 mock /proc/mounts)。
///
/// 解析 mounts 文本 (/proc/mounts 格式), 找覆盖 path 的最长前缀挂载点,
/// 检查其 mount options 是否含 "discard"。
fn match_mountpoint_discard(mounts: &str, path_str: &str) -> bool {
    // 找覆盖 path 的最长前缀挂载点
    let mut best_mount: Option<&str> = None;
    let mut best_len = 0usize;
    for line in mounts.lines() {
        // /proc/mounts 格式: device mountpoint fstype options dump pass
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 4 {
            continue;
        }
        let mountpoint = parts[1];
        // path 必须等于 mountpoint 或以 mountpoint/ 开头
        // [v0.7.8 fix] mountpoint == "/" 特殊处理: 根挂载点覆盖所有绝对路径,
        // 但原逻辑要求 path[1] == '/', 即 path 必须是 "//..." 才匹配, 导致
        // /etc /system 等只落在根挂载点的路径漏匹配 (保守判为非 discard, 不限速)。
        // mountpoint == "/" 时放行所有绝对路径 (path_str 已保证以 / 开头)。
        if path_str == mountpoint
            || mountpoint == "/"
            || (path_str.starts_with(mountpoint)
                && path_str.as_bytes().get(mountpoint.len()) == Some(&b'/'))
        {
            if mountpoint.len() > best_len {
                best_len = mountpoint.len();
                best_mount = Some(parts[3]); // options
            }
        }
    }
    // 检查最佳挂载点的 options 是否含 discard
    // options 是逗号分隔, 如 "rw,seclabel,relatime,discard"
    if let Some(opts) = best_mount {
        for opt in opts.split(',') {
            if opt == "discard" {
                return true;
            }
        }
    }
    false
}

/// 探测结果: 文件系统类型 + 是否 discard, 缓存避免重复 statfs + 解析 /proc/mounts。
/// key = 规范化路径前缀 (取 path 所在分区的挂载点)。
/// 实际只对 /data 和 /sdcard 这两个主要清理目标探测, 缓存命中率高。
pub struct FsProbe {
    pub fs_type: FsType,
    pub is_discard: bool,
    /// ext4 + discard = 删除性能杀手, 调用方据此降并发
    pub is_ext4_discard: bool,
}

impl FsProbe {
    /// 探测指定路径的文件系统情况
    pub fn probe(path: &std::path::Path) -> Self {
        let fs_type = detect_fs_type(path);
        let is_discard = is_mount_discard(path);
        let is_ext4_discard = fs_type == FsType::Ext4 && is_discard;
        Self {
            fs_type,
            is_discard,
            is_ext4_discard,
        }
    }
}

// ============================================================
// [v0.7.6] openat2 可用性检测 — Linux 5.6+ 支持
// ============================================================
// openat2 + RESOLVE_NO_SYMLINKS 内核级杜绝 symlink TOCTOU (man7 openat2.2,
// lwn.net/Articles/1050887)。5.10 满足。运行时检测: 调一次 openat2,
// ENOSYS 则回退 openat。

/// 判断 openat2 syscall 是否可用 (Linux 5.6+)。
///
/// 用 once_cell 缓存: 调一次 openat2(open("/proc/self", O_PATH|O_DIRECTORY), ".", ...),
/// 成功或返回 EEXIST/EINVAL(参数合法但路径问题) → 可用; ENOSYS → 不可用。
pub fn openat2_available() -> bool {
    use once_cell::sync::OnceCell;
    static AVAIL: OnceCell<bool> = OnceCell::new();
    *AVAIL.get_or_init(|| probe_openat2())
}

fn probe_openat2() -> bool {
    // openat2 syscall: SYS_openat2 = 437 (aarch64/arm64 通用)
    // struct open_how { u64 flags; u64 mode; u64 resolve; }
    // 用最安全的方式: 对 /proc/self 调 openat2(dirfd, ".", O_PATH|O_CLOEXEC, RESOLVE_NO_SYMLINKS)
    use std::os::unix::io::AsRawFd;
    let dir = match std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_DIRECTORY | libc::O_CLOEXEC)
        .open("/proc/self")
    {
        Ok(d) => d,
        Err(_) => return false,
    };
    // open_how 结构体: flags, mode, resolve (3 个 u64 = 24 字节)
    #[repr(C)]
    struct OpenHow {
        flags: u64,
        mode: u64,
        resolve: u64,
    }
    // RESOLVE_NO_SYMLINKS = 0x02
    const RESOLVE_NO_SYMLINKS: u64 = 0x02;
    let how = OpenHow {
        flags: (libc::O_PATH | libc::O_CLOEXEC) as u64,
        mode: 0,
        resolve: RESOLVE_NO_SYMLINKS,
    };
    let cstr = match std::ffi::CString::new(".") {
        Ok(c) => c,
        Err(_) => return false,
    };
    let r = unsafe {
        libc::syscall(
            libc::SYS_openat2,
            dir.as_raw_fd(),
            cstr.as_ptr(),
            &how as *const OpenHow,
            std::mem::size_of::<OpenHow>(),
        )
    };
    if r >= 0 {
        // 成功, 关闭返回的 fd
        unsafe { libc::close(r as i32) };
        return true;
    }
    // 错误码判断: 用 std::io::Error::last_os_error() 跨平台取 errno
    // (Android bionic 用 __errno, glibc 用 __errno_location, 不能硬编码)
    let err = std::io::Error::last_os_error();
    let errno = err.raw_os_error().unwrap_or(0);
    // ENOSYS = 38 (内核不支持 openat2)
    // EINVAL = 22 可能是参数问题 (不该发生), 也视为不可用
    // 其他错误 (EEXIST 等) 说明 openat2 本身可用只是路径问题 → 可用
    errno != libc::ENOSYS && errno != libc::EINVAL
}

// ============================================================
// [v0.7.7] io_uring 真正可用性探测 (Android-aware) — 不只看内核版本
// ============================================================
// 全网调研依据 (Android 安全公告 2023-2024, Google 推荐 CONFIG_IO_URING=n):
// io_uring 在 2023-2024 爆出一系列高危漏洞 (CVE-2023-... 等), Google 与各 OEM
// 在很多 Android 内核 (含 5.10/5.15 GKI) 编译时直接 CONFIG_IO_URING=n 关闭,
// 或通过 SELinux/seccomp 对非特权进程禁用 io_uring_setup。仅看 uname 版本
// (>=5.10) 判 io_uring 可用是错误的 —— 5.10+ 内核也可能 io_uring 不可用。
//
// 正确做法: 真正调一次 io_uring_setup(entries=1), 看 fd 是否 >= 0:
// - 成功 → 关闭 fd, 返回 true (io_uring 真正可用)
// - ENOSYS (38) → 内核无 io_uring 系统调用 (CONFIG_IO_URING=n 编译掉)
// - EPERM (1) / EACCES (13) → SELinux/seccomp 策略禁用
// - 其他负值 → 不可用
// 结果 OnceCell 缓存, 全进程只探一次, 避免每批清理重复失败 setup。

/// io_uring_setup 参数结构体 (与内核 struct io_uring_params 二进制兼容)
///
/// 模块级共享: [`io_uring_setup_available`] 与 [`probe_io_uring_unlinkat`] 复用,
/// 避免在两处重复定义同一布局。
#[repr(C)]
struct IoUringParams {
    sq_entries: u32,
    cq_entries: u32,
    flags: u32,
    sq_thread_cpu: u32,
    sq_thread_idle: u32,
    features: u32,
    wq_fd: u32,
    resv: [u32; 3],
    sq_off: SqRingOffsets,
    cq_off: CqRingOffsets,
}

#[repr(C)]
struct SqRingOffsets {
    head: u32,
    tail: u32,
    ring_mask: u32,
    ring_entries: u32,
    flags: u32,
    dropped: u32,
    array: u32,
    resv1: u32,
    resv2: u64,
}

#[repr(C)]
struct CqRingOffsets {
    head: u32,
    tail: u32,
    ring_mask: u32,
    ring_entries: u32,
    overflow: u32,
    cqes: u32,
    flags: u32,
    resv1: u32,
    resv2: u64,
}

/// 判断 io_uring 在当前内核是否真正可用 (Android-aware capability probe)。
///
/// **不只看内核版本**, 而是真正调 `io_uring_setup(1, params)`:
/// - 5.10+ 但 `CONFIG_IO_URING=n` (很多 Android OEM 关闭) → ENOSYS → false
/// - SELinux/seccomp 禁用 → EPERM/EACCES → false
/// - 真正可用 → fd >= 0 → 关闭 fd → true
///
/// 结果 OnceCell 缓存, 全进程只探一次。iouring_stat 与 iouring_unlink 都应
/// 以此为前置判断, 避免在 io_uring 不可用的设备上每批都白做一次失败 setup
/// (旧版 iouring_stat 只看 kernel_version_ge(5,10), 在 io_uring 被编译掉的
/// 5.10+ Android 内核上会每批清理都触发一次失败的 IoUring::new, 纯浪费)。
pub fn io_uring_setup_available() -> bool {
    use once_cell::sync::OnceCell;
    static AVAIL: OnceCell<bool> = OnceCell::new();
    *AVAIL.get_or_init(|| probe_io_uring_setup())
}

fn probe_io_uring_setup() -> bool {
    // io_uring_setup(entries=1, params) — 最小 ring 探测
    // entries=1 是合法最小值 (内核会上取整到 2^ceil_pow2(1)=1)。
    // 用裸 libc::syscall 而非 io-uring crate, 保证探测本身零依赖、可独立缓存。
    let mut params: IoUringParams = unsafe { std::mem::zeroed() };
    let fd = unsafe {
        libc::syscall(
            libc::SYS_io_uring_setup,
            1u32, // entries
            &mut params as *mut IoUringParams,
        )
    };
    if fd < 0 {
        // ENOSYS (内核无 io_uring) / EPERM/EACCES (SELinux/seccomp) / 其他 → 不可用
        return false;
    }
    // 成功: 关闭探测用 fd, 避免泄漏
    unsafe { libc::close(fd as i32) };
    true
}

// ============================================================
// [v0.7.6] io_uring unlinkat 可用性检测 — IORING_OP_UNLINKAT 在 5.11+
// ============================================================
// 全网调研依据 (man7 io_uring_prep_unlinkat.3, kernelnewbies/Linux_5.11):
// IORING_OP_UNLINKAT 在 Linux 5.11 合入。5.10 GKI 不支持。
// 用 io_uring_register_probe 探测 opcode 37 (IORING_OP_UNLINKAT) 是否可用。
// 5.11+ → 批量 unlinkat; 5.10 → 回退 sync unlinkat 循环。
// (注: 本探测内部也会 io_uring_setup, setup 失败即返回 false, 天然 Android-aware)

/// 判断 io_uring 是否支持 IORING_OP_UNLINKAT (Linux 5.11+)。
///
/// 用 io_uring_register_probe 探测 opcode 37。
/// 5.11+ 返回 true; 5.10 或 io_uring 不可用返回 false。
pub fn io_uring_unlinkat_available() -> bool {
    use once_cell::sync::OnceCell;
    static AVAIL: OnceCell<bool> = OnceCell::new();
    *AVAIL.get_or_init(|| probe_io_uring_unlinkat())
}

fn probe_io_uring_unlinkat() -> bool {
    // io_uring_probe 结构体在 libc crate 中可能没有完整导出,
    // 用裸 syscall + 手动构造 probe 结构体。
    // io_uring_setup(1, params) 创建 ring, 然后 io_uring_register(ring_fd, IORING_REGISTER_PROBE, probe, len)
    // IORING_REGISTER_PROBE = 7
    // IORING_OP_UNLINKAT = 37

    // 复用模块级 IoUringParams (与 io_uring_setup_available 共享, 避免重复定义)
    // 先用 io_uring_setup 创建一个最小 ring (entries=1)
    // io_uring_probe 结构体: 最后一个字段是变长数组
    // struct io_uring_probe {
    //     u8 last_op;   // 最后支持的 opcode
    //     u8 ops_len;   // ops 数组长度
    //     u16 resv;
    //     u32 resv2[3];
    //     struct io_uring_probe_op ops[0]; // 每个 8 字节: u8 op, u8 resv, u16 flags, u32 resv2
    // };
    // 为了简单, 分配一个足够大的 buffer (256 个 opcode × 8 字节 + 头部 16 字节)

    let mut params: IoUringParams = unsafe { std::mem::zeroed() };
    let ring_fd = unsafe {
        libc::syscall(
            libc::SYS_io_uring_setup,
            1u32, // entries
            &mut params as *mut IoUringParams,
        )
    };
    if ring_fd < 0 {
        return false;
    }

    // 分配 probe buffer: 头部 16 字节 + 256 ops × 8 字节 = 2064 字节
    const NUM_OPS: usize = 256;
    const PROBE_SIZE: usize = 16 + NUM_OPS * 8;
    let mut probe_buf: Vec<u8> = vec![0u8; PROBE_SIZE];

    // io_uring_register(fd, IORING_REGISTER_PROBE=7, arg, nr_args=NUM_OPS)
    let r = unsafe {
        libc::syscall(
            libc::SYS_io_uring_register,
            ring_fd as i32,
            7u32, // IORING_REGISTER_PROBE
            probe_buf.as_mut_ptr() as *mut libc::c_void,
            NUM_OPS as u32,
        )
    };
    // 关闭 ring fd
    unsafe { libc::close(ring_fd as i32) };

    if r < 0 {
        return false;
    }

    // 解析 probe: last_op 在 offset 0, ops_len 在 offset 1
    let last_op = probe_buf[0];
    let ops_len = probe_buf[1];

    // IORING_OP_UNLINKAT = 37
    const IORING_OP_UNLINKAT: u8 = 37;

    // 如果 last_op < 37, 内核根本不知道这个 opcode
    if last_op < IORING_OP_UNLINKAT {
        return false;
    }

    // 检查 ops 数组中 opcode 37 的 flags 是否含 IO_URING_OP_SUPPORTED (0x0001)
    // 每个 probe_op: u8 op, u8 resv, u16 flags, u32 resv2 = 8 字节
    // ops 从 offset 16 开始, 第 i 个 op 在 offset 16 + i*8
    let actual_len = (ops_len as usize).min(NUM_OPS);
    for i in 0..actual_len {
        let offset = 16 + i * 8;
        if offset + 4 > probe_buf.len() {
            break;
        }
        let op = probe_buf[offset];
        let flags = u16::from_le_bytes([probe_buf[offset + 2], probe_buf[offset + 3]]);
        if op == IORING_OP_UNLINKAT {
            // IO_URING_OP_SUPPORTED = 0x0001
            return (flags & 0x0001) != 0;
        }
    }
    false
}

use std::os::unix::fs::OpenOptionsExt;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_pid_cmdline_self() {
        let self_cmd = pid_cmdline_contains(current_pid(), "");
        assert!(self_cmd); // 空串恒匹配
    }

    #[test]
    fn test_read_proc_nice_uses_correct_field() {
        // 构造 fake /proc/<pid>/stat 字符串, 模拟 daemon (priority=39, nice=19, num_threads=8)
        // 字段布局: pid (comm) state ppid pgrp session tty_nr tpgid flags
        //          minflt cminflt majflt cmajflt utime stime cutime cstime priority nice num_threads
        // priority(18)=39, nice(19)=19, num_threads(20)=8
        let fake_stat = "26195 (tarn daemon) S 1 26191 26191 0 -1 4194304 123 0 0 0 1 0 0 0 39 19 8";
        // 手动解析验证字段索引
        let after_comm = fake_stat.rfind(')').unwrap();
        let rest = &fake_stat[after_comm + 1..];
        let fields: Vec<&str> = rest.split_whitespace().collect();
        // fields[15] = priority (field 18) = 39
        assert_eq!(fields.get(15).and_then(|s| s.parse::<i32>().ok()), Some(39),
            "fields[15] 应为 priority=39, 实际: {:?}", fields.get(15));
        // fields[16] = nice (field 19) = 19
        assert_eq!(fields.get(16).and_then(|s| s.parse::<i32>().ok()), Some(19),
            "fields[16] 应为 nice=19, 实际: {:?}", fields.get(16));
        // fields[17] = num_threads (field 20) = 8 (不是 nice!)
        assert_eq!(fields.get(17).and_then(|s| s.parse::<i32>().ok()), Some(8),
            "fields[17] 应为 num_threads=8, 实际: {:?}", fields.get(17));
        // 确保 nice(19) 和 num_threads(8) 不相等 (防止误读 num_threads 当 nice)
        assert_ne!(fields.get(16), fields.get(17),
            "nice 和 num_threads 不应相等 (否则 bug 不会被发现)");
    }

    #[test]
    fn test_read_proc_nice_self() {
        // 读自己进程的 nice, 应返回 Some 且在合法范围 [-20, 19]
        let nice = read_proc_nice(current_pid());
        assert!(nice.is_some(), "read_proc_nice(self) 应返回 Some");
        let n = nice.unwrap();
        assert!(n >= -20 && n <= 19, "nice 值应在 [-20, 19] 范围内, 实际: {}", n);
    }

    #[test]
    fn test_parse_kernel_version_android_gki() {
        // Android 12 GKI 5.10 典型 release
        assert_eq!(parse_kernel_version("5.10.66-android13-8-00100-gabc"), Some((5, 10)));
        // Android 14 GKI 5.15
        assert_eq!(parse_kernel_version("5.15.123-android14-6-00100-gdef"), Some((5, 15)));
        // Android 15 GKI 6.1
        assert_eq!(parse_kernel_version("6.1.50-android15-6-00100-ghi"), Some((6, 1)));
        // 老内核 4.14
        assert_eq!(parse_kernel_version("4.14.190"), Some((4, 14)));
        // 纯主次版本
        assert_eq!(parse_kernel_version("5.10"), Some((5, 10)));
        // 无效输入
        assert_eq!(parse_kernel_version("garbage"), None);
        assert_eq!(parse_kernel_version(""), None);
    }

    #[test]
    fn test_kernel_version_ge_self() {
        // 宿主机 (Linux 沙箱) 内核必然 >= 3.0, 测一个一定成立的下界
        assert!(kernel_version_ge(3, 0), "宿主机内核应 >= 3.0");
        // 测一个一定不成立的上界 (100.0 不存在)
        assert!(!kernel_version_ge(100, 0), "内核版本不应 >= 100.0");
    }

    // === [v0.7.6] 文件系统探测测试 ===

    #[test]
    fn test_detect_fs_type_root() {
        // / 肯定存在, 探测不应 panic (具体类型取决于宿主, 不硬断言)
        let ft = detect_fs_type(std::path::Path::new("/"));
        // 沙箱通常是 ext4 或其他, 只验证不 panic + 返回合法值
        let _ = ft;
    }

    #[test]
    fn test_detect_fs_type_nonexistent() {
        // 不存在的路径, statfs 失败 → Other
        let ft = detect_fs_type(std::path::Path::new("/nonexistent_tarn_test_12345"));
        assert_eq!(ft, FsType::Other);
    }

    #[test]
    fn test_is_mount_discard_root() {
        // /proc/mounts 在 Linux 上一定可读, 探测不应 panic
        // 不硬断言返回值 (取决于宿主 mount 配置)
        let _ = is_mount_discard(std::path::Path::new("/"));
    }

    #[test]
    fn test_fs_probe_root() {
        let probe = FsProbe::probe(std::path::Path::new("/"));
        // is_ext4_discard 只有 fs_type==Ext4 且 is_discard==true 才为 true
        if probe.fs_type != FsType::Ext4 {
            assert!(!probe.is_ext4_discard);
        }
        // 一致性: is_ext4_discard ⟹ fs_type==Ext4 && is_discard
        if probe.is_ext4_discard {
            assert_eq!(probe.fs_type, FsType::Ext4);
            assert!(probe.is_discard);
        }
    }

    // === [v0.7.6] openat2 可用性测试 ===

    #[test]
    fn test_openat2_available_consistent() {
        // 多次调用应一致 (OnceCell 缓存)
        let a = openat2_available();
        let b = openat2_available();
        assert_eq!(a, b);
    }

    // === [v0.7.6] io_uring unlinkat 可用性测试 ===

    #[test]
    fn test_io_uring_unlinkat_available_consistent() {
        // 多次调用应一致 (OnceCell 缓存)
        let a = io_uring_unlinkat_available();
        let b = io_uring_unlinkat_available();
        assert_eq!(a, b);
        // 沙箱内核若 < 5.11 会返回 false, 若 >= 5.11 返回 true, 不硬断言
    }

    // === [v0.7.7] io_uring setup 真探测测试 ===

    #[test]
    fn test_io_uring_setup_available_consistent() {
        // 多次调用应一致 (OnceCell 缓存)
        let a = io_uring_setup_available();
        let b = io_uring_setup_available();
        assert_eq!(a, b);
        // 不硬断言 true/false: 沙箱内核可能编译掉 io_uring (ENOSYS→false) 或支持 (true)
    }

    #[test]
    fn test_io_uring_setup_implies_unlinkat_logic() {
        // 逻辑一致性: 若 io_uring_setup 不可用, 则 io_uring_unlinkat 必也不可用
        // (unlinkat 探测内部也调 io_uring_setup, setup 失败则 unlinkat 返回 false)
        if !io_uring_setup_available() {
            assert!(
                !io_uring_unlinkat_available(),
                "io_uring_setup 不可用时, io_uring_unlinkat 不应可用"
            );
        }
    }

    // === [v0.7.8] is_mount_discard 根挂载点匹配回归测试 ===

    /// [v0.7.8 fix] 旧版 is_mount_discard 对 mountpoint="/" 的匹配逻辑有 bug:
    /// 要求 path[mountpoint.len()] == '/', 即 path[1] == '/', 只有 "//etc" 才匹配。
    /// 导致 /etc /system 等只落在根挂载点的路径漏匹配 (返回 false, 保守不限速)。
    /// 修复后 mountpoint == "/" 时放行所有绝对路径。
    #[test]
    fn test_match_mountpoint_discard_root_mountpoint() {
        // 构造 mock /proc/mounts: 根挂载点 / 是 ext4+discard, /data 是 ext4 无 discard
        // (真实 /proc/mounts 根 / 只有一行, 不重复)
        let mounts = "/dev/block/dm-0 / ext4 rw,seclabel,relatime,discard 0 0\n\
                      /dev/block/dm-1 /data ext4 rw,seclabel,relatime 0 0\n";

        // /etc 只落在根挂载点 /, 根有 discard → 应返回 true (旧版返回 false, bug!)
        assert!(match_mountpoint_discard(mounts, "/etc"),
            "/etc 落在根挂载点 / (discard), 应返回 true");
        assert!(match_mountpoint_discard(mounts, "/system/bin"),
            "/system/bin 落在根挂载点 / (discard), 应返回 true");

        // /data 有单独挂载点 (无 discard), 应优先匹配 /data 而非根 /
        // /data 的 options 不含 discard → false (即使根 / 有 discard)
        assert!(!match_mountpoint_discard(mounts, "/data/data/com.foo"),
            "/data 匹配 /data 挂载点 (无 discard), 应返回 false");

        // /data 本身
        assert!(!match_mountpoint_discard(mounts, "/data"),
            "/data 匹配 /data 挂载点 (无 discard), 应返回 false");

        // 根 / 本身
        assert!(match_mountpoint_discard(mounts, "/"),
            "/ 匹配根挂载点 (discard), 应返回 true");

        // 更长前缀优先: /data/app 落在 /data (无 discard), 不落根 /
        assert!(!match_mountpoint_discard(mounts, "/data/app/com.foo"),
            "/data/app 匹配 /data (更长前缀, 无 discard), 应返回 false");
    }

    /// [v0.7.8 fix] set_cpu_affinity_all_threads 对 cpu >= 1024 应跳过不 panic。
    /// 旧版直接 CPU_SET(cpu, &set) 无边界检查, cpu >= 1024 越界写栈 (UB)。
    #[test]
    fn test_set_cpu_affinity_all_threads_bounds_check() {
        // 传 cpu >= 1024, 应返回错误列表而非 panic
        let errs = set_cpu_affinity_all_threads(&[1024, 1025, 2048]);
        assert!(!errs.is_empty(), "cpu >= 1024 应被拒绝并记录错误");
        // 用 ends_with 精确匹配 (避免 "跳过: 1024" 包含 "跳过: 1" 子串的误判)
        assert!(errs.iter().any(|e| e.ends_with("跳过: 1024")), "错误应含 1024");
        assert!(errs.iter().any(|e| e.ends_with("跳过: 1025")), "错误应含 1025");
        assert!(errs.iter().any(|e| e.ends_with("跳过: 2048")), "错误应含 2048");

        // 混合合法 + 非法: 合法的应被设上, 非法的记错误
        let errs = set_cpu_affinity_all_threads(&[0, 1024, 1]);
        assert!(errs.iter().any(|e| e.ends_with("跳过: 1024")), "1024 应记错误");
        // cpu 0 和 1 合法, 不应出现 ends_with "跳过: 0" 或 "跳过: 1" 的越界错误
        // (ends_with 精确匹配, "跳过: 1024" 不 ends_with "跳过: 1")
        assert!(!errs.iter().any(|e| e.ends_with("跳过: 0")),
            "cpu 0 合法, 不应记越界错误");
        assert!(!errs.iter().any(|e| e.ends_with("跳过: 1")),
            "cpu 1 合法, 不应记越界错误");

        // 空列表不 panic
        let errs = set_cpu_affinity_all_threads(&[]);
        assert!(errs.is_empty(), "空 cpu 列表应返回空错误");
    }
}