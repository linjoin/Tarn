//! 并行目录遍历器: getdents64 直读 + Rayon 工作窃取 + crossbeam 流式
//!
//! 基于 RESEARCH-4 调研结论:
//! - libc crate 没导出 getdents64 函数, 但有 SYS_getdents64 常量 + dirent64 结构体
//! - 用 libc::syscall(SYS_getdents64, fd, buf, count) 直接调用
//! - 32KB 缓冲区是事实标准 (glibc readdir 内部即 32K)
//! - d_type 字段免 stat 调用 (DT_REG=8 / DT_DIR=4 / DT_LNK=10)
//! - DT_UNKNOWN 才回退 fstatat(AT_SYMLINK_NOFOLLOW)
//! - 遍历必须用 d_reclen 推进指针, 不能用 size_of::<dirent64>()
//! - d_name 必须 owned 拷贝 (跨多轮 syscall 复用 buf 时, 早期 slice 会悬垂)
//! - Rayon 工作窃取线程池做并行, crossbeam::bounded 做背压
//! - 工作队列空 + 活跃 worker 数为 0 时才退出 (Condvar 同步), 防止退化串行
//!
//! 目标性能: 10 万文件 < 200ms, 百万文件 < 2s, 内存 < 15MB

use crossbeam_channel::Sender;
use smallvec::SmallVec;
use ahash::AHashSet;
use std::ffi::OsStr;
use std::os::unix::ffi::OsStrExt;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Condvar, Mutex};
use crate::protect::ProtectSet;

// ============================================================
// 数据结构
// ============================================================

/// 目录条目 (流式产出)
#[derive(Debug, Clone)]
pub struct DirEntry {
    pub path: PathBuf,
    pub file_type: FileType,
    pub size: u64,
    pub mtime: i64,
    pub ino: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FileType {
    File,
    Dir,
    Symlink,
    Other,
}

impl FileType {
    /// 从 d_type 字节转换
    pub fn from_d_type(d_type: u8) -> Self {
        match d_type {
            libc::DT_REG => FileType::File,
            libc::DT_DIR => FileType::Dir,
            libc::DT_LNK => FileType::Symlink,
            _ => FileType::Other,
        }
    }
}

/// 遍历选项
#[derive(Debug, Clone)]
pub struct WalkOptions {
    /// 最大深度 (0=不限)
    pub max_depth: usize,
    /// 是否跟随 symlink (默认 false, 安全)
    pub follow_symlink: bool,
    /// 是否跳过隐藏文件 (. 开头)
    pub skip_hidden: bool,
    /// 并行 worker 数 (0=自动, =CPU 核数)
    pub parallel_workers: usize,
    /// 通道容量 (背压)
    pub channel_capacity: usize,
    /// 跳过这些目录 (绝对路径前缀)
    pub skip_dirs: AHashSet<PathBuf>,
    /// 用 getdents64 直读 (false 时回退 std::fs::read_dir)
    pub use_getdents: bool,
    /// 缓冲区大小 (默认 256KB, 运行时按 st_blksize 自适应取大)
    pub buf_size: usize,
    /// 保护集合 (follow_symlink=true 时, symlink 目标若受保护则不递归)
    /// None = 不查保护 (单测/独立使用 walker 时用)
    pub protect: Option<Arc<ProtectSet>>,
    /// [v0.7.6] 用 openat2 + RESOLVE_NO_SYMLINKS 打开目录 (内核级防 symlink TOCTOU)
    /// true: 优先 openat2 (5.6+), 不可用自动回退 openat
    /// false: 直接用 openat (与 v0.7.5 一致)
    pub use_openat2: bool,
}

impl Default for WalkOptions {
    fn default() -> Self {
        Self {
            max_depth: 0,
            follow_symlink: false,
            skip_hidden: false,
            parallel_workers: 0,
            channel_capacity: 1024,
            skip_dirs: AHashSet::new(),
            use_getdents: true,
            // [v0.7.4] getdents64 buffer 32KB → 256KB。
            // 依据 (全网调研): glibc readdir 内部按 fstat(dirfd).st_blksize 动态调 buffer,
            // 最大到 1MB; walkdir issue #108 指出 32KB 一次只 ~400 条, 大目录需多次 syscall。
            // 256KB 一次 ~3000 条, 大目录 syscall 次数降 ~8 倍。
            // 内存影响: 每 worker 多占 224KB, 8 worker ≈ 1.8MB (远低于 15MB 预算)。
            buf_size: 256 * 1024,
            protect: None,
            use_openat2: true,
        }
    }
}

/// 遍历结果统计
#[derive(Debug, Clone, Default)]
pub struct WalkStats {
    pub total_entries: u64,
    pub files: u64,
    pub dirs: u64,
    pub symlinks: u64,
    pub other: u64,
    pub errors: u64,
    pub duration_ms: u64,
    pub bytes_read: u64,
}

// ============================================================
// getdents64 直读 syscall
// ============================================================

/// 单条原始目录项 (owned name, 避免跨 syscall 复用 buf 时的悬垂引用)
struct RawEntry {
    /// owned name bytes (从 buf 中拷贝出来, buf 复用安全)
    name: Vec<u8>,
    d_type: u8,
    ino: u64,
}

/// 读取一个目录的全部条目 (getdents64 直读)
///
/// 复用传入的 buf 避免重分配。返回的条目持有 owned name (Vec<u8>),
/// 因此 buf 在下一轮 syscall 被覆写时不会影响已返回的条目。
/// d_type = DT_UNKNOWN 的条目也返回, 由调用方决定是否 stat。
///
/// [v0.7.6] 返回 SmallVec<[RawEntry; 64]>: 常见目录 <64 项零堆分配,
/// 大目录自动 spillover 到堆 (nnethercote perf-book: arrayvec/smallvec 在热路径避免分配)。
fn getdents64_read(
    fd: std::os::unix::io::RawFd,
    buf: &mut Vec<u8>,
    buf_size: usize,
) -> std::io::Result<SmallVec<[RawEntry; 64]>> {
    if buf.len() < buf_size {
        buf.resize(buf_size, 0);
    }

    let mut entries: SmallVec<[RawEntry; 64]> = SmallVec::new();

    loop {
        let nread = unsafe {
            libc::syscall(
                libc::SYS_getdents64,
                fd,
                buf.as_mut_ptr() as *mut libc::c_void,
                buf_size,
            )
        };
        if nread == 0 {
            break; // EOF
        }
        if nread < 0 {
            let err = std::io::Error::last_os_error();
            // getdents64 是慢系统调用, 可被信号中断返回 EINTR, 这里需重试,
            // 否则会丢失整个目录剩余条目 (files_deleted 偏少)。
            // daemon 用 pthread_sigmask 屏蔽了 SIGTERM/SIGINT, 但 SIGCHLD/SIGIO 等
            // 未屏蔽信号仍可能中断 worker 线程的 getdents64。
            if err.raw_os_error() == Some(libc::EINTR) {
                continue;
            }
            return Err(err);
        }
        let nread = nread as usize;

        // 按 d_reclen 推进指针解析
        let mut offset = 0usize;
        while offset < nread {
            // 强转 dirent64 头部 (不拷贝, 仅引用)
            let p = buf.as_ptr().wrapping_add(offset) as *const libc::dirent64;
            let entry_ref = unsafe { &*p };
            let reclen = entry_ref.d_reclen as usize;
            if reclen == 0 || offset + reclen > nread {
                break; // 防御
            }

            // d_name 是 [c_char; 256], NUL 结尾
            let name_ptr = &entry_ref.d_name as *const _ as *const u8;
            let name_len = unsafe {
                let mut len = 0;
                while *name_ptr.add(len) != 0 {
                    len += 1;
                    if len > 255 {
                        break;
                    }
                }
                len
            };
            // owned 拷贝: 必须复制, 否则下一轮 syscall 会覆写这些字节
            let name_bytes: Vec<u8> =
                unsafe { std::slice::from_raw_parts(name_ptr, name_len) }.to_vec();

            // 跳过 "." 和 ".."
            if !(name_bytes == b"." || name_bytes == b"..") {
                entries.push(RawEntry {
                    name: name_bytes,
                    d_type: entry_ref.d_type,
                    ino: entry_ref.d_ino,
                });
            }

            offset += reclen;
        }
    }

    Ok(entries)
}

/// 用 fstatat 取文件类型 (DT_UNKNOWN 时回退)
///
/// 用 AT_SYMLINK_NOFOLLOW 不跟随符号链接。
fn fstatat_type(dirfd: std::os::unix::io::RawFd, name: &OsStr) -> Option<FileType> {
    let cstr = std::ffi::CString::new(name.as_bytes()).ok()?;
    let mut st: libc::stat = unsafe { std::mem::zeroed() };
    let r = unsafe {
        libc::fstatat(
            dirfd,
            cstr.as_ptr(),
            &mut st,
            libc::AT_SYMLINK_NOFOLLOW,
        )
    };
    if r < 0 {
        return None;
    }
    let mode = st.st_mode;
    if mode & libc::S_IFMT == libc::S_IFREG {
        Some(FileType::File)
    } else if mode & libc::S_IFMT == libc::S_IFDIR {
        Some(FileType::Dir)
    } else if mode & libc::S_IFMT == libc::S_IFLNK {
        Some(FileType::Symlink)
    } else {
        Some(FileType::Other)
    }
}

/// [v0.7.6] 用 openat2 + RESOLVE_NO_SYMLINKS 打开目录
///
/// 内核级杜绝 symlink TOCTOU: RESOLVE_NO_SYMLINKS 让内核在路径解析阶段
/// 拒绝任何符号链接组件, 比 follow_symlink=false 的用户态检查更强。
/// (man7 openat2.2, lwn.net/Articles/1050887)
///
/// 成功返回 File, ENOSYS/失败返回 None (调用方回退 openat)。
fn open_dir_openat2(dir: &Path) -> Option<std::fs::File> {
    use std::os::unix::ffi::OsStrExt;
    use std::os::unix::io::FromRawFd;

    let cstr = std::ffi::CString::new(dir.as_os_str().as_bytes()).ok()?;

    // open_how 结构体: flags, mode, resolve (3 个 u64 = 24 字节)
    #[repr(C)]
    struct OpenHow {
        flags: u64,
        mode: u64,
        resolve: u64,
    }
    // RESOLVE_NO_SYMLINKS = 0x02 (linux/openat2.h)
    const RESOLVE_NO_SYMLINKS: u64 = 0x02;
    let how = OpenHow {
        flags: (libc::O_RDONLY | libc::O_DIRECTORY | libc::O_CLOEXEC) as u64,
        mode: 0,
        resolve: RESOLVE_NO_SYMLINKS,
    };

    let r = unsafe {
        libc::syscall(
            libc::SYS_openat2,
            libc::AT_FDCWD,
            cstr.as_ptr(),
            &how as *const OpenHow,
            std::mem::size_of::<OpenHow>(),
        )
    };
    if r >= 0 {
        // 成功, 把裸 fd 包成 File (File drop 时自动 close)
        return Some(unsafe { std::fs::File::from_raw_fd(r as i32) });
    }
    // 失败: ENOSYS (内核不支持 openat2) / EINVAL / EACCES / ENOENT 等 → None, 调用方回退
    None
}

// ============================================================
// 并行遍历主入口
// ============================================================

/// 并行遍历根目录, 通过 channel 流式产出 DirEntry
///
/// 用法:
/// ```ignore
/// let (tx, rx) = crossbeam_channel::bounded(1024);
/// std::thread::spawn(move || walker::walk_parallel(root, opts, tx));
/// while let Ok(entry) = rx.recv() {
///     // 处理 entry
/// }
/// ```
pub fn walk_parallel(root: &Path, opts: &WalkOptions, tx: Sender<DirEntry>) -> WalkStats {
    let start = std::time::Instant::now();
    let stats = std::sync::Arc::new(parking_lot::Mutex::new(WalkStats::default()));

    // 配置 Rayon 线程池 (隔离 Tokio / Rayon, 避免线程爆炸)
    // 关键: 始终构建 LOCAL pool (.build()), 绝不用 rayon::scope (会初始化全局 pool,
    //   全局 pool 线程常驻永不退出, 导致清理后线程数不回落)。
    //   parallel_workers=0 → num_cpus(); >0 → 用户指定。
    let num_threads = if opts.parallel_workers > 0 {
        opts.parallel_workers
    } else {
        num_cpus()
    };
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(num_threads)
        .stack_size(256 * 1024)
        .thread_name(|i| format!("tarn-walk-{}", i))
        .build()
        .ok();

    // 工作窃取队列 + 活跃 worker 计数 + Condvar 同步
    //
    // 关键不变量:
    // - active_count > 0 ⟺ 至少有一个 worker 正在处理目录 (可能产出新子目录)
    // - worker 取到目录时 active_count += 1; 完成时 active_count -= 1
    // - 队列空时 worker 不立即退出, 而是等待 Condvar
    // - 只有当 (queue empty AND active_count == 0) 时才退出
    // 这样保证子目录在 worker 处理父目录过程中才被 push 回队列的场景下, 其他 worker 不会提前退出
    let work_queue = Arc::new(Mutex::new(vec![(root.to_path_buf(), 0usize)]));
    let active_count = Arc::new(AtomicUsize::new(0));
    let cvar = Arc::new(Condvar::new());

    let buf_size = opts.buf_size;
    let opts_clone = opts.clone();
    let stats_clone = stats.clone();
    let tx_clone = tx.clone();
    let queue_clone = work_queue.clone();
    let active_clone = active_count.clone();
    let cvar_clone = cvar.clone();

    let worker = move || {
        // 每个线程一个复用 buffer (避免重分配)
        let mut buf: Vec<u8> = Vec::with_capacity(buf_size);

        loop {
            // 原子地从队列取一个目录, 同时维护 active_count
            // 关键: active_count 的增减必须在持有 queue 锁的情况下完成
            // 避免其他 worker 在 pop 后 + increment 前看到 (空队列 + active=0) 而误退出
            let next = {
                let mut q = queue_clone.lock().unwrap();
                loop {
                    if let Some(item) = q.pop() {
                        // 取到目录, 标记本 worker 活跃 (在锁内, 其他 worker 一定能看到)
                        active_clone.fetch_add(1, Ordering::SeqCst);
                        break Some(item);
                    }
                    // 队列空: 检查是否所有 worker 都空闲
                    if active_clone.load(Ordering::SeqCst) == 0 {
                        // 没有活跃 worker, 也没有待处理目录: 整体结束
                        break None;
                    }
                    // 等待其他 worker push 子目录 (释放锁, 让 push 的 worker 能拿到)
                    q = cvar_clone.wait(q).unwrap();
                }
            };
            let (dir, depth) = match next {
                Some(x) => x,
                None => break, // 全部完成
            };

            walk_one_dir(
                &dir,
                depth,
                &opts_clone,
                &tx_clone,
                &queue_clone,
                &stats_clone,
                &mut buf,
            );

            // 本 worker 完成当前目录
            active_clone.fetch_sub(1, Ordering::SeqCst);
            // 通知所有等待的 worker 重新检查队列
            cvar_clone.notify_all();
        }
    };

    match pool {
        Some(p) => {
            // 用 rayon scope 让多个 worker 并行
            p.scope(|s| {
                // [v0.7.8] 去掉 .min(8) 静默截断: worker 数应 = pool 线程数 = parallel_workers 配置。
                // 旧版 .min(8) 在用户配 parallel_workers=16 时仍只 spawn 8 个 worker,
                // 导致 16 线程的 pool 里 8 线程空闲, 与 config.rs 校验 (1-16) 语义不一致。
                // parallel_workers 已在 config 校验上限 16, 无需 walker 再截断。
                for _ in 0..p.current_num_threads() {
                    s.spawn(|_| {
                        worker();
                    });
                }
            });
        }
        None => {
            // pool build 失败 (极罕见, 如资源耗尽): 单线程兜底。
            // 绝不用 rayon::scope (全局 pool 线程常驻, 清理后不退出)。
            worker();
        }
    }

    let mut s = stats.lock().clone();
    s.duration_ms = start.elapsed().as_millis() as u64;
    s
}

/// 遍历单个目录 (getdents64 或回退 read_dir)
fn walk_one_dir(
    dir: &Path,
    depth: usize,
    opts: &WalkOptions,
    tx: &Sender<DirEntry>,
    queue: &Arc<Mutex<Vec<(PathBuf, usize)>>>,
    stats: &std::sync::Arc<parking_lot::Mutex<WalkStats>>,
    buf: &mut Vec<u8>,
) {
    // 跳过 skip_dirs
    if opts.skip_dirs.iter().any(|d| dir.starts_with(d)) {
        return;
    }

    if opts.use_getdents {
        walk_one_dir_getdents(dir, depth, opts, tx, queue, stats, buf);
    } else {
        walk_one_dir_std(dir, depth, opts, tx, queue, stats);
    }
}

/// getdents64 直读版
fn walk_one_dir_getdents(
    dir: &Path,
    depth: usize,
    opts: &WalkOptions,
    tx: &Sender<DirEntry>,
    queue: &Arc<Mutex<Vec<(PathBuf, usize)>>>,
    stats: &std::sync::Arc<parking_lot::Mutex<WalkStats>>,
    buf: &mut Vec<u8>,
) {
    use std::os::unix::fs::OpenOptionsExt;
    use std::os::unix::io::AsRawFd;

    // [v0.7.6] 打开目录: 优先 openat2 + RESOLVE_NO_SYMLINKS (内核级防 symlink TOCTOU),
    // 不可用或配置关闭时回退 openat + O_DIRECTORY (与 v0.7.5 一致)。
    // 全网调研依据: man7 openat2.2, lwn.net/Articles/1050887 — RESOLVE_NO_SYMLINKS
    // 让内核在路径解析阶段拒绝任何符号链接, 比 follow_symlink=false 的用户态检查更强。
    let f = if opts.use_openat2 && crate::sysutil::openat2_available() {
        match open_dir_openat2(dir) {
            Some(f) => f,
            None => {
                // openat2 失败 (非 ENOSYS, 如权限), 回退 openat
                match std::fs::OpenOptions::new()
                    .read(true)
                    .custom_flags(libc::O_DIRECTORY | libc::O_CLOEXEC)
                    .open(dir)
                {
                    Ok(f) => f,
                    Err(_) => {
                        stats.lock().errors += 1;
                        return;
                    }
                }
            }
        }
    } else {
        match std::fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_CLOEXEC)
            .open(dir)
        {
            Ok(f) => f,
            Err(_) => {
                stats.lock().errors += 1;
                return;
            }
        }
    };
    let dirfd = f.as_raw_fd();

    // [v0.7.6] getdents64 buffer 按 st_blksize 自适应 (glibc readdir 内部策略):
    // fstat(dirfd) 读 st_blksize, 与 opts.buf_size 取大。
    // 对超大目录 (百万项) 有微小收益; 对普通目录 256KB 已够。
    // 全网调研依据: stackoverflow getdents64 buffer size, glibc readdir 动态调 buffer。
    let effective_buf_size = {
        let mut st: libc::stat = unsafe { std::mem::zeroed() };
        let r = unsafe { libc::fstat(dirfd, &mut st) };
        if r == 0 && st.st_blksize > 0 {
            // st_blksize 通常 4096, 取与 opts.buf_size 的最大值
            // 上限 1MB 防极端值 (glibc 也是 1MB 上限)
            let blksize = (st.st_blksize as usize).min(1024 * 1024);
            blksize.max(opts.buf_size)
        } else {
            opts.buf_size
        }
    };

    // getdents64 直读 (复用 buf)
    let entries = match getdents64_read(dirfd, buf, effective_buf_size) {
        Ok(e) => e,
        Err(_) => {
            stats.lock().errors += 1;
            return;
        }
    };

    // drop f 关闭 fd (在发送前关闭避免 fd 泄漏)
    // 但 fstatat 需要 dirfd, 所以延迟关闭
    for entry in entries {
        // 跳过隐藏文件
        if opts.skip_hidden && entry.name.first() == Some(&b'.') {
            continue;
        }

        let os_name = OsStr::from_bytes(&entry.name);
        let path = dir.join(os_name);

        // 解析文件类型 (DT_UNKNOWN 回退 fstatat)
        let ft = if entry.d_type == libc::DT_UNKNOWN {
            fstatat_type(dirfd, os_name).unwrap_or(FileType::Other)
        } else {
            FileType::from_d_type(entry.d_type)
        };

        // [v0.7.4] 延迟 stat: walker 不再对每个文件 fstatat 取 size+mtime。
        // matcher 只用 path glob 做匹配 (不需 size/mtime), 而 older_than_days /
        // min_size_kb / protect.check(mtime) 都在 matcher.matches() 命中后才执行。
        // 所以 size/mtime 改由 executor 在命中后对命中的文件 stat 取 (见 lstat_meta)。
        // 收益: 1.4w 文件从 1.4w 次 fstatat (~420ms) → 命中的 N 次 (通常几百, ~10ms)。
        // DirEntry.size/mtime 这里填 0 占位, executor 命中后会用真实值覆盖。
        let size = 0u64;
        let mtime = 0i64;

        let dir_entry = DirEntry {
            path: path.clone(),
            file_type: ft,
            size,
            mtime,
            ino: entry.ino,
        };

        // 发送到 channel
        if tx.send(dir_entry).is_err() {
            return; // 消费端关闭
        }

        {
            let mut s = stats.lock();
            s.total_entries += 1;
            match ft {
                FileType::File => s.files += 1,
                FileType::Dir => s.dirs += 1,
                FileType::Symlink => s.symlinks += 1,
                FileType::Other => s.other += 1,
            }
        }

        // 递归目录: push 到工作队列让其他线程 steal
        // - Dir: 无条件递归
        // - Symlink: 仅 follow_symlink=true 且目标确实是目录时递归 (避免 symlink 环, max_depth 强制兜底)
        let should_recurse = if ft == FileType::Dir {
            true
        } else if ft == FileType::Symlink && opts.follow_symlink {
            // follow_symlink 时检查 symlink 目标是否受保护, 防绕过 ProtectSet
            // (canonicalize 解析真实路径再 check; 默认 follow_symlink=false 不受影响)
            if let Some(p) = &opts.protect {
                match std::fs::canonicalize(&path) {
                    Ok(canon) if p.check(&canon, None).is_some() => false, // 受保护, 不递归
                    Ok(_) => std::fs::metadata(&path).map(|m| m.is_dir()).unwrap_or(false),
                    Err(_) => false, // canonicalize 失败, 保守不递归
                }
            } else {
                std::fs::metadata(&path).map(|m| m.is_dir()).unwrap_or(false)
            }
        } else {
            false
        };
        if should_recurse && (opts.max_depth == 0 || depth + 1 < opts.max_depth) {
            queue.lock().unwrap().push((path, depth + 1));
        }
    }
    // f 在这里 drop, 关闭 dirfd
}

/// std::fs::read_dir 回退版 (兼容性, 不用 getdents64)
fn walk_one_dir_std(
    dir: &Path,
    depth: usize,
    opts: &WalkOptions,
    tx: &Sender<DirEntry>,
    queue: &Arc<Mutex<Vec<(PathBuf, usize)>>>,
    stats: &std::sync::Arc<parking_lot::Mutex<WalkStats>>,
) {
    let read_dir = match std::fs::read_dir(dir) {
        Ok(rd) => rd,
        Err(_) => {
            stats.lock().errors += 1;
            return;
        }
    };

    for entry in read_dir.flatten() {
        let path = entry.path();
        let file_name = entry.file_name();
        let name_bytes = file_name.as_encoded_bytes();

        if name_bytes == b"." || name_bytes == b".." {
            continue;
        }
        if opts.skip_hidden && name_bytes.first() == Some(&b'.') {
            continue;
        }

        let ft = match entry.file_type() {
            Ok(ft) => {
                if ft.is_dir() {
                    FileType::Dir
                } else if ft.is_symlink() {
                    FileType::Symlink
                } else if ft.is_file() {
                    FileType::File
                } else {
                    FileType::Other
                }
            }
            Err(_) => {
                stats.lock().errors += 1;
                continue;
            }
        };

        // [v0.7.4] 延迟 stat: 同 getdents64 版, std 回退版也不取 size/mtime,
        // 由 executor 在 matcher 命中后 stat (见 executor::lstat_meta)。
        let size = 0u64;
        let mtime = 0i64;

        let dir_entry = DirEntry {
            path: path.clone(),
            file_type: ft,
            size,
            mtime,
            ino: 0,
        };

        if tx.send(dir_entry).is_err() {
            return;
        }

        {
            let mut s = stats.lock();
            s.total_entries += 1;
            match ft {
                FileType::File => s.files += 1,
                FileType::Dir => s.dirs += 1,
                FileType::Symlink => s.symlinks += 1,
                FileType::Other => s.other += 1,
            }
        }

        if ft == FileType::Dir && (opts.max_depth == 0 || depth + 1 < opts.max_depth) {
            queue.lock().unwrap().push((path, depth + 1));
        } else if ft == FileType::Symlink && opts.follow_symlink
            && (opts.max_depth == 0 || depth + 1 < opts.max_depth)
        {
            // follow_symlink 时检查 symlink 目标是否受保护, 防绕过 ProtectSet
            let protected = if let Some(p) = &opts.protect {
                match std::fs::canonicalize(&path) {
                    Ok(canon) => p.check(&canon, None).is_some(),
                    Err(_) => true, // canonicalize 失败, 保守视为受保护 (不递归)
                }
            } else {
                false
            };
            if !protected && std::fs::metadata(&path).map(|m| m.is_dir()).unwrap_or(false) {
                queue.lock().unwrap().push((path, depth + 1));
            }
        }
    }
}

/// 获取 CPU 核数
fn num_cpus() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(4)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crossbeam_channel::bounded;

    #[test]
    fn test_walk_root() {
        // 遍历 /tmp (宿主环境一定有)
        let tmp = std::env::temp_dir();
        std::fs::create_dir_all(&tmp).unwrap();
        // 创建测试文件
        let test_dir = tmp.join("tarn_walk_test");
        std::fs::create_dir_all(&test_dir).unwrap();
        std::fs::write(test_dir.join("a.txt"), "hello").unwrap();
        std::fs::write(test_dir.join("b.log"), "world").unwrap();

        let (tx, rx) = bounded::<DirEntry>(1024);
        let opts = WalkOptions {
            use_getdents: true,
            ..Default::default()
        };
        let walk_dir = test_dir.clone();
        let handle = std::thread::spawn(move || {
            walk_parallel(&walk_dir, &opts, tx);
        });

        let mut files = 0;
        for entry in rx.iter() {
            if entry.file_type == FileType::File {
                files += 1;
            }
        }
        handle.join().unwrap();
        assert!(files >= 2, "应至少扫到 2 个文件");

        // 清理
        let _ = std::fs::remove_dir_all(&test_dir);
    }

    #[test]
    fn test_file_type_from_d_type() {
        assert_eq!(FileType::from_d_type(libc::DT_REG), FileType::File);
        assert_eq!(FileType::from_d_type(libc::DT_DIR), FileType::Dir);
        assert_eq!(FileType::from_d_type(libc::DT_LNK), FileType::Symlink);
        assert_eq!(FileType::from_d_type(libc::DT_UNKNOWN), FileType::Other);
        assert_eq!(FileType::from_d_type(99), FileType::Other);
    }

    #[test]
    fn test_getdents_read_tmp() {
        use std::os::unix::fs::OpenOptionsExt;
        use std::os::unix::io::AsRawFd;
        let tmp = std::env::temp_dir();
        let f = std::fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_CLOEXEC)
            .open(&tmp)
            .unwrap();
        let mut buf = Vec::with_capacity(32 * 1024);
        let entries = getdents64_read(f.as_raw_fd(), &mut buf, 32 * 1024).unwrap();
        // /tmp 至少有几个条目
        assert!(!entries.is_empty(), "应读到目录条目");
    }

    /// 多轮 syscall 复用 buf 时, 早期条目的 name 不应被覆写 (回归测试)
    #[test]
    fn test_getdents_multibatch_no_dangling() {
        use std::os::unix::fs::OpenOptionsExt;
        use std::os::unix::io::AsRawFd;
        let tmp = std::env::temp_dir();
        let test_dir = tmp.join("tarn_walk_multibatch_test");
        let _ = std::fs::remove_dir_all(&test_dir);
        std::fs::create_dir_all(&test_dir).unwrap();
        // 创建 >117 个文件 (32KB 缓冲区装不下, 触发多轮 syscall)
        let mut expected_names: Vec<String> = (0..300)
            .map(|i| format!("file_{:03}_name_padding_here_to_make_long_XXXXXX_{}", i, i))
            .collect();
        for name in &expected_names {
            std::fs::write(test_dir.join(name), "x").unwrap();
        }

        let f = std::fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_CLOEXEC)
            .open(&test_dir)
            .unwrap();
        let mut buf = Vec::with_capacity(32 * 1024);
        let entries = getdents64_read(f.as_raw_fd(), &mut buf, 32 * 1024).unwrap();

        // 校验: 每个条目的 name 必须与磁盘上真实文件名匹配
        let mut got_names: Vec<String> = entries
            .iter()
            .map(|e| String::from_utf8_lossy(&e.name).to_string())
            .collect();
        got_names.sort();
        expected_names.sort();
        assert_eq!(
            got_names, expected_names,
            "多轮 syscall 后条目名必须与磁盘一致, 不应被覆写"
        );

        let _ = std::fs::remove_dir_all(&test_dir);
    }

    /// 多 worker 并行遍历深层目录树, 不应退化串行 (回归测试)
    #[test]
    fn test_walk_parallel_deep_tree() {
        let tmp = std::env::temp_dir();
        let test_dir = tmp.join("tarn_walk_deep_test");
        let _ = std::fs::remove_dir_all(&test_dir);
        std::fs::create_dir_all(&test_dir).unwrap();
        // 创建 3 层目录树, 每层 5 个子目录, 每个叶子目录 5 个文件
        // 总: 5*5*5 = 125 个叶子目录, 625 文件
        for i in 0..5u32 {
            let d1 = test_dir.join(format!("L1_{}", i));
            std::fs::create_dir_all(&d1).unwrap();
            for j in 0..5u32 {
                let d2 = d1.join(format!("L2_{}", j));
                std::fs::create_dir_all(&d2).unwrap();
                for k in 0..5u32 {
                    let d3 = d2.join(format!("L3_{}", k));
                    std::fs::create_dir_all(&d3).unwrap();
                    for f in 0..5u32 {
                        std::fs::write(d3.join(format!("file_{}.txt", f)), "x").unwrap();
                    }
                }
            }
        }

        let (tx, rx) = bounded::<DirEntry>(1024);
        let opts = WalkOptions {
            parallel_workers: 4,
            use_getdents: true,
            ..Default::default()
        };
        let walk_dir = test_dir.clone();
        let handle = std::thread::spawn(move || {
            walk_parallel(&walk_dir, &opts, tx);
        });

        let mut files = 0u64;
        let mut dirs = 0u64;
        for entry in rx.iter() {
            match entry.file_type {
                FileType::File => files += 1,
                FileType::Dir => dirs += 1,
                _ => {}
            }
        }
        handle.join().unwrap();
        // 625 文件 + 5 (L1) + 25 (L2) + 125 (L3) = 155 子目录 (root 本身不计入 DirEntry 流)
        assert_eq!(files, 625, "应扫到所有 625 个文件");
        assert_eq!(dirs, 5 + 25 + 125, "应扫到所有 155 个子目录");
        let _ = std::fs::remove_dir_all(&test_dir);
    }

    /// [v0.7.8] parallel_workers=16 (去掉 .min(8) 截断后) 验证:
    /// 16 worker 并发不死锁/不栈溢出/结果完整。
    /// 旧版 .min(8) 会截断到 8, 新版用满 16 线程 (config 上限 16)。
    #[test]
    fn test_walk_parallel_16_workers() {
        let tmp = std::env::temp_dir();
        let test_dir = tmp.join("tarn_walk_16w_test");
        let _ = std::fs::remove_dir_all(&test_dir);
        std::fs::create_dir_all(&test_dir).unwrap();
        // 创建 4 层目录树, 每层 4 个子目录, 每个叶子目录 4 个文件
        // 总: 4^3 = 64 个叶子目录, 256 文件, 足够 16 worker 工作窃取
        for i in 0..4u32 {
            let d1 = test_dir.join(format!("L1_{}", i));
            std::fs::create_dir_all(&d1).unwrap();
            for j in 0..4u32 {
                let d2 = d1.join(format!("L2_{}", j));
                std::fs::create_dir_all(&d2).unwrap();
                for k in 0..4u32 {
                    let d3 = d2.join(format!("L3_{}", k));
                    std::fs::create_dir_all(&d3).unwrap();
                    for f in 0..4u32 {
                        std::fs::write(d3.join(format!("file_{}.txt", f)), "x").unwrap();
                    }
                }
            }
        }

        let (tx, rx) = bounded::<DirEntry>(1024);
        let opts = WalkOptions {
            parallel_workers: 16, // [v0.7.8] 去掉 .min(8) 后真正用满 16 线程
            use_getdents: true,
            ..Default::default()
        };
        let walk_dir = test_dir.clone();
        let handle = std::thread::spawn(move || {
            walk_parallel(&walk_dir, &opts, tx);
        });

        let mut files = 0u64;
        let mut dirs = 0u64;
        for entry in rx.iter() {
            match entry.file_type {
                FileType::File => files += 1,
                FileType::Dir => dirs += 1,
                _ => {}
            }
        }
        handle.join().expect("16 worker 不应 panic/死锁");
        // 256 文件 + 4 (L1) + 16 (L2) + 64 (L3) = 84 子目录
        assert_eq!(files, 256, "16 worker 应扫到所有 256 个文件");
        assert_eq!(dirs, 4 + 16 + 64, "应扫到所有 84 个子目录");
        let _ = std::fs::remove_dir_all(&test_dir);
    }
}
