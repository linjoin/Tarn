#!/system/bin/sh
# Tarn - 开机自启脚本
# 创建目录结构 + 启动后台服务 + 防止多开。
# 管理器在 late_start service 阶段调用本脚本。

#=========== busybox 检测 ===========
detect_bb() {
  for cand in \
    /data/adb/ksu/bin/busybox \
    /data/adb/ap/bin/busybox \
    /data/adb/magisk/busybox \
    /system/bin/busybox \
    /system/xbin/busybox; do
    [ -x "$cand" ] && { echo "$cand"; return 0; }
  done
  command -v busybox 2>/dev/null && return 0
  echo ""
  return 1
}

BB=$(detect_bb)
bb_wrap() {
  cmd=$1
  shift
  if [ -n "$BB" ]; then
    "$BB" "$cmd" "$@"
  else
    "$cmd" "$@"
  fi
}

#=========== 路径变量 ===========
MODDIR=${0%/*}
DATADIR=/data/adb/tarn
BIN="$MODDIR/tarn"
PIDFILE="$DATADIR/run/tarn.pid"
LOGDIR="$DATADIR/logs"
BOOTLOG="$LOGDIR/boot.log"
RUNLOG="$LOGDIR/tarn.log"
SETTINGS_FILE="$DATADIR/config/settings.toml"

#=========== 日志轮转配置 (读 settings.toml [log] 段) ===========
# 日志策略: 运行时无论多大都不轮转 (只追加), 轮转只发生在开机备份。
# keep_files: 开机备份保留份数 (0 = 不备份继续追加; >=1 时开机把旧 log rename 为 .1)
LOG_KEEP=3
if [ -f "$SETTINGS_FILE" ]; then
  _v=$(bb_wrap grep -E '^[[:space:]]*keep_files[[:space:]]*=' "$SETTINGS_FILE" 2>/dev/null | head -n 1 | bb_wrap sed -E 's/.*=[[:space:]]*([0-9]+).*/\1/' | tr -d '[:space:]')
  [ -n "$_v" ] && LOG_KEEP=$_v
fi
unset _v

# rotate_log_file <path>: log → log.1 → ... → log.<keep> (删超 keep 的)
# keep=0 时不轮转 (避免误清当前日志)
rotate_log_file() {
  _p=$1
  [ -n "$_p" ] || return 0
  [ "$LOG_KEEP" -gt 0 ] 2>/dev/null || return 0
  # 删除超过 keep 的旧备份
  _i=$((LOG_KEEP + 1))
  while [ $_i -ge 1 ]; do
    rm -f "${_p}.${_i}" 2>/dev/null
    _i=$((_i - 1))
  done
  # .keep-1 → .keep, .keep-2 → .keep-1, ... .1 → .2, log → .1
  _i=$((LOG_KEEP - 1))
  while [ $_i -ge 1 ]; do
    [ -f "${_p}.${_i}" ] && mv -f "${_p}.${_i}" "${_p}.$((_i + 1))" 2>/dev/null
    _i=$((_i - 1))
  done
  [ -f "$_p" ] && mv -f "$_p" "${_p}.1" 2>/dev/null
}

#=========== 工具函数 ===========
# log_boot: 写 boot.log (只追加, 运行时不轮转; 轮转只发生在开机备份)
log_boot() {
  ts=$(date '+%Y-%m-%d %H:%M:%S')
  echo "[$ts] $1" >> "$BOOTLOG" 2>/dev/null
}

#=========== 0. 前置检查 ===========
if [ ! -x "$BIN" ]; then
  log_boot "错误: 程序文件不存在或不可执行: $BIN"
  exit 1
fi

#=========== 0.1 目录结构 ===========
mkdir -p "$DATADIR/config" "$DATADIR/logs" "$DATADIR/run" "$DATADIR/rules" "$DATADIR/trash" 2>/dev/null
chmod 700 "$DATADIR" "$DATADIR/config" "$DATADIR/logs" "$DATADIR/run" "$DATADIR/rules" "$DATADIR/trash" 2>/dev/null
chown root:root "$DATADIR" 2>/dev/null

#=========== 0.2 开机备份旧日志 ==========
# [v0.2.7] 每次开机先把 boot.log / tarn.log 备份 (rename .1 → .2, log → .1),
# 再开始写新日志。让用户每次开机能看到上一轮启动的完整日志, 不被新日志覆盖。
# keep_files = 0 时不备份 (与大小轮转一致, 0 = 不轮转继续追加)。
# daemon 此时尚未启动, tarn.log 可安全 rename; daemon 启动后 >> 会自动新建空文件。
# 放在 0.1 之后确保 logs 目录已建, 放在 0.3 之前让本轮所有 log_boot 写新文件。
if [ "$LOG_KEEP" -gt 0 ] 2>/dev/null; then
  for _lf in "$BOOTLOG" "$RUNLOG"; do
    [ -f "$_lf" ] || continue
    # 空文件不备份 (无意义, 避免产生空 .1)
    _sz=$(wc -c < "$_lf" 2>/dev/null | tr -d '[:space:]')
    [ -n "$_sz" ] && [ "$_sz" -gt 0 ] 2>/dev/null || continue
    rotate_log_file "$_lf"
  done
  unset _lf _sz
fi
# 备份完成后再写第一条日志 (此时写入的是全新 boot.log)
[ "$LOG_KEEP" -gt 0 ] 2>/dev/null && log_boot "已备份上一轮日志 (保留 ${LOG_KEEP} 份, 下次开机再轮转)"

#=========== 0.3 清理旧版残留 ===========
for stale in "$DATADIR/token" "$DATADIR/tarn.sock"; do
  if [ -e "$stale" ]; then
    rm -f "$stale" 2>/dev/null
    log_boot "清理旧版残留: $(basename "$stale")"
  fi
done

log_boot "================================================"
log_boot "Tarn 启动中"
log_boot "模块目录: $MODDIR"
log_boot "数据目录: $DATADIR"
log_boot "================================================"

#=========== 1. 旧实例检测 (防多开) ===========
if [ -f "$PIDFILE" ]; then
  OLD_PID=$(cat "$PIDFILE" 2>/dev/null | tr -d '[:space:]')
  if [ -n "$OLD_PID" ] && [ "$OLD_PID" -gt 0 ] 2>/dev/null; then
    if kill -0 "$OLD_PID" 2>/dev/null; then
      OLD_CMDLINE=""
      if [ -r "/proc/$OLD_PID/cmdline" ]; then
        OLD_CMDLINE=$(tr '\0' ' ' < "/proc/$OLD_PID/cmdline" 2>/dev/null)
      fi
      case "$OLD_CMDLINE" in
        *tarn*)
          log_boot "检测到旧实例 (pid=$OLD_PID), 正在停止..."
          kill -TERM "$OLD_PID" 2>/dev/null
          i=0
          while [ $i -lt 12 ]; do
            if ! kill -0 "$OLD_PID" 2>/dev/null; then
              log_boot "旧实例已退出"
              break
            fi
            sleep 1
            i=$((i + 1))
          done
          if kill -0 "$OLD_PID" 2>/dev/null; then
            log_boot "旧实例未响应, 强制结束"
            kill -KILL "$OLD_PID" 2>/dev/null
            sleep 1
          fi
          ;;
        *)
          log_boot "进程 pid=$OLD_PID 不匹配, 清理记录文件"
          rm -f "$PIDFILE"
          ;;
      esac
    else
      log_boot "旧进程已不存在, 清理记录文件"
      rm -f "$PIDFILE"
    fi
  else
    rm -f "$PIDFILE"
  fi
fi

#=========== 1.5 恢复累计清理统计 ==========
# 每次开机从 state.json 恢复累计清理量到 module.prop,
# 确保管理器列表持续显示历史数据 (异常关机也不丢失)。
# [v0.2.5] description 新格式: 已停止 | 删除 N 个文件 | 已清理 X GB
# [v0.2.6] 修复: 与 customize.sh 5.3 段格式对齐 (此前开机路径缺文件数)
MODULE_PROP="$MODDIR/module.prop"
STATE_FILE="$DATADIR/state.json"
if [ -f "$STATE_FILE" ] && [ -f "$MODULE_PROP" ]; then
  TOTAL_FREED=$(bb_wrap grep -E '"total_freed_bytes"[[:space:]]*:' "$STATE_FILE" 2>/dev/null | head -n 1 | bb_wrap sed -E 's/.*:[[:space:]]*([0-9]+).*/\1/' | tr -d '[:space:]')
  TOTAL_FILES=$(bb_wrap grep -E '"total_files_deleted"[[:space:]]*:' "$STATE_FILE" 2>/dev/null | head -n 1 | bb_wrap sed -E 's/.*:[[:space:]]*([0-9]+).*/\1/' | tr -d '[:space:]')
  [ -z "$TOTAL_FILES" ] && TOTAL_FILES=0
  if [ -n "$TOTAL_FREED" ]; then
    case "$TOTAL_FREED" in
      *[!0-9]*)
        log_boot "统计数据异常, 跳过恢复"
        ;;
      *)
        CLEANED_STR=""
        GB=$((1024 * 1024 * 1024))
        MB=$((1024 * 1024))
        KB=1024
        if [ "$TOTAL_FREED" -ge "$GB" ] 2>/dev/null; then
          if command -v awk >/dev/null 2>&1; then
            CLEANED_STR=$(awk -v b="$TOTAL_FREED" -v g="$GB" 'BEGIN{printf "%.2f GB", b/g}')
          else
            CLEANED_STR="$((TOTAL_FREED / GB)) GB"
          fi
        elif [ "$TOTAL_FREED" -ge "$MB" ] 2>/dev/null; then
          if command -v awk >/dev/null 2>&1; then
            CLEANED_STR=$(awk -v b="$TOTAL_FREED" -v m="$MB" 'BEGIN{printf "%.2f MB", b/m}')
          else
            CLEANED_STR="$((TOTAL_FREED / MB)) MB"
          fi
        elif [ "$TOTAL_FREED" -ge "$KB" ] 2>/dev/null; then
          if command -v awk >/dev/null 2>&1; then
            CLEANED_STR=$(awk -v b="$TOTAL_FREED" -v k="$KB" 'BEGIN{printf "%.2f KB", b/k}')
          else
            CLEANED_STR="$((TOTAL_FREED / KB)) KB"
          fi
        else
          CLEANED_STR="${TOTAL_FREED} B"
        fi
        bb_wrap sed -i -E "s|^description=.*|description=已停止 \| 删除 ${TOTAL_FILES} 个文件 \| 已清理 ${CLEANED_STR}|" "$MODULE_PROP" 2>/dev/null
        log_boot "已恢复累计统计: 删除 ${TOTAL_FILES} 文件 / 已清理 ${CLEANED_STR}"
        ;;
    esac
  fi
fi

#=========== 2. 启动后台服务 ===========
# setsid + nohup 双重脱离控制终端, 确保服务稳定后台运行。
SETS_PID=""
if command -v setsid >/dev/null 2>&1; then
  SETSID_CMD="setsid"
elif [ -n "$BB" ] && "$BB" --list 2>/dev/null | grep -q '^setsid$'; then
  SETSID_CMD="$BB setsid"
else
  SETSID_CMD=""
fi

if [ -n "$SETSID_CMD" ]; then
  log_boot "启动后台服务..."
  $SETSID_CMD nohup "$BIN" daemon </dev/null >>"$RUNLOG" 2>&1 &
else
  log_boot "警告: setsid 不可用, 降级启动"
  nohup "$BIN" daemon </dev/null >>"$RUNLOG" 2>&1 &
fi
DAEMON_BG_PID=$!

#=========== 3. 等待服务就绪 (最多 5s) ===========
i=0
while [ $i -lt 5 ]; do
  if [ -f "$PIDFILE" ]; then
    DAEMON_PID=$(cat "$PIDFILE" 2>/dev/null | tr -d '[:space:]')
    if [ -n "$DAEMON_PID" ] && [ "$DAEMON_PID" -gt 0 ] 2>/dev/null; then
      if kill -0 "$DAEMON_PID" 2>/dev/null; then
        log_boot "✓ 服务已启动 (pid=$DAEMON_PID)"
        log_boot "运行日志: $RUNLOG"
        log_boot "================================================"
        exit 0
      else
        log_boot "警告: 服务启动后立即退出"
        break
      fi
    fi
  fi
  sleep 1
  i=$((i + 1))
done

log_boot "错误: 服务启动失败"
log_boot "请查看运行日志: $RUNLOG"
log_boot "诊断命令: $BIN doctor"
log_boot "================================================"

exit 1
