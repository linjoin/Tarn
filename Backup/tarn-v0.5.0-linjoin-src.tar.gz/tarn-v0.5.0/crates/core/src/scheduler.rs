//! 定时调度器: timerfd + CLOCK_BOOTTIME_ALARM (穿透 Doze)
//!
//! 基于 RESEARCH-1 (timerfd_report) 调研结论:
//! - CLOCK_BOOTTIME_ALARM (Linux 3.11+) 自 Android 6 起全设备支持
//! - root 天然具备 CAP_WAKE_ALARM, 无需额外配置
//! - timerfd 触发会唤醒 CPU suspend (内核级)
//! - 干活期间持 wake_lock (/sys/power/wake_lock) 防系统再睡
//! - root 守护进程不受 Cached Apps Freezer 影响
//! - TFD_TIMER_ABSTIME 用绝对时间避免累积漂移 (周期任务)
//! - TFD_NONBLOCK + TFD_CLOEXEC 必加 (tokio epoll 要求 + 防 fd 泄漏)
//! - read 语义: 到期后 read(fd, &buf, 8) 返回 u64 (累计到期次数)
//!
//! 提供:
//! - DozeTimer: 同步版 timerfd 封装 (用于独立线程)
//! - AsyncDozeTimer: tokio AsyncFd 异步封装 (用于 tokio runtime)
//! - WakeLock: RAII wake_lock 持有者
//! - CronSchedule: cron 表达式解析 + 下次触发计算

use std::io;
use std::os::unix::io::{AsRawFd, RawFd};
use std::path::Path;
use std::time::Duration;

// ============================================================
// 同步版 DozeTimer (用于独立线程)
// ============================================================

/// Doze 穿透定时器 (同步版)
pub struct DozeTimer {
    fd: RawFd,
}

impl DozeTimer {
    /// 创建定时器 (CLOCK_BOOTTIME_ALARM, NONBLOCK|CLOEXEC)
    pub fn new() -> io::Result<Self> {
        let fd = unsafe {
            libc::timerfd_create(
                libc::CLOCK_BOOTTIME_ALARM,
                libc::TFD_NONBLOCK | libc::TFD_CLOEXEC,
            )
        };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Self { fd })
    }

    /// 创建定时器, 指定时钟类型 (用于 fallback)
    pub fn with_clock(clock: libc::clockid_t) -> io::Result<Self> {
        let fd = unsafe {
            libc::timerfd_create(clock, libc::TFD_NONBLOCK | libc::TFD_CLOEXEC)
        };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Self { fd })
    }

    /// 设置单次触发 (相对时间, 毫秒)
    pub fn set_oneshot(&self, delay_ms: u64) -> io::Result<()> {
        let spec = libc::itimerspec {
            it_value: libc::timespec {
                tv_sec: (delay_ms / 1000) as i64,
                tv_nsec: ((delay_ms % 1000) * 1_000_000) as i64,
            },
            it_interval: libc::timespec { tv_sec: 0, tv_nsec: 0 },
        };
        let r = unsafe { libc::timerfd_settime(self.fd, 0, &spec, std::ptr::null_mut()) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(())
    }

    /// 设置单次触发 (相对时间, Duration)
    pub fn set_oneshot_duration(&self, delay: Duration) -> io::Result<()> {
        self.set_oneshot(delay.as_millis() as u64)
    }

    /// 设置周期触发 (首次延迟 + 周期, 毫秒)
    pub fn set_periodic(&self, first_ms: u64, period_ms: u64) -> io::Result<()> {
        let spec = libc::itimerspec {
            it_value: libc::timespec {
                tv_sec: (first_ms / 1000) as i64,
                tv_nsec: ((first_ms % 1000) * 1_000_000) as i64,
            },
            it_interval: libc::timespec {
                tv_sec: (period_ms / 1000) as i64,
                tv_nsec: ((period_ms % 1000) * 1_000_000) as i64,
            },
        };
        let r = unsafe { libc::timerfd_settime(self.fd, 0, &spec, std::ptr::null_mut()) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(())
    }

    /// 设置单次绝对时间触发 (用 TFD_TIMER_ABSTIME, 防累积漂移)
    ///
    /// `abs_boottime_sec` = 自 CLOCK_BOOTTIME_ALARM 起点的秒数
    pub fn set_absolute(&self, abs_sec: i64) -> io::Result<()> {
        let spec = libc::itimerspec {
            it_value: libc::timespec {
                tv_sec: abs_sec,
                tv_nsec: 0,
            },
            it_interval: libc::timespec { tv_sec: 0, tv_nsec: 0 },
        };
        let r = unsafe {
            libc::timerfd_settime(self.fd, libc::TFD_TIMER_ABSTIME, &spec, std::ptr::null_mut())
        };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(())
    }

    /// 阻塞等待触发 (读 8 字节, 返回触发次数)
    ///
    /// 注意: fd 是 NONBLOCK, 这里用 poll 等待可读再 read
    pub fn wait(&self) -> io::Result<u64> {
        // 用 poll 等待可读
        let mut pfd = libc::pollfd {
            fd: self.fd,
            events: libc::POLLIN,
            revents: 0,
        };
        let r = unsafe { libc::poll(&mut pfd, 1, -1) }; // -1 = 无限等待
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        if r == 0 {
            return Err(io::Error::new(io::ErrorKind::TimedOut, "poll timeout"));
        }
        self.read_expirations()
    }

    /// 带超时等待触发
    pub fn wait_timeout(&self, timeout_ms: i32) -> io::Result<Option<u64>> {
        let mut pfd = libc::pollfd {
            fd: self.fd,
            events: libc::POLLIN,
            revents: 0,
        };
        let r = unsafe { libc::poll(&mut pfd, 1, timeout_ms) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        if r == 0 {
            return Ok(None); // 超时
        }
        Ok(Some(self.read_expirations()?))
    }

    /// v0.5.0: 同时等待 timerfd + 额外唤醒 fd (修复 SIGTERM 不能立即唤醒 poll 的 bug)
    ///
    /// 同时 poll timerfd 和 `wake_fd`, 任一可读就返回。用于主循环同时等 cron 触发
    /// 和 shutdown 信号, 避免 SIGTERM 到达后 daemon 要等 timerfd 到期 (可能数小时)
    /// 才退出, 期间还可能多跑一次 cron 清理。
    ///
    /// 返回:
    ///   Ok(true)  — timerfd 到期 (cron 触发), 已消费到期计数
    ///   Ok(false) — wake_fd 可读 (shutdown 信号) 或超时, timerfd 未到期
    ///   Err(...)  — poll 错误 (EINTR 等)
    pub fn wait_timeout_with_wake(&self, wake_fd: RawFd, timeout_ms: i32) -> io::Result<bool> {
        let mut pfds = [
            libc::pollfd { fd: self.fd, events: libc::POLLIN, revents: 0 },
            libc::pollfd { fd: wake_fd, events: libc::POLLIN, revents: 0 },
        ];
        let r = unsafe { libc::poll(pfds.as_mut_ptr(), 2, timeout_ms) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        if r == 0 {
            return Ok(false); // 超时, 两个 fd 都没就绪
        }
        // timerfd 可读? 消费到期计数
        if pfds[0].revents & libc::POLLIN != 0 {
            let _ = self.read_expirations();
            return Ok(true);
        }
        // wake_fd 可读? 消费 eventfd 计数 (防水平触发反复唤醒)
        if pfds[1].revents & libc::POLLIN != 0 {
            let mut buf = [0u8; 8];
            let _ = unsafe { libc::read(wake_fd, buf.as_mut_ptr() as *mut _, 8) };
        }
        Ok(false)
    }

    /// 读到期次数 (非阻塞, 无到期返回 0)
    pub fn read_expirations(&self) -> io::Result<u64> {
        let mut buf = [0u8; 8];
        let n = unsafe { libc::read(self.fd, buf.as_mut_ptr() as *mut _, 8) };
        if n != 8 {
            if n < 0 {
                let e = io::Error::last_os_error();
                if e.kind() == io::ErrorKind::WouldBlock {
                    return Ok(0); // 无到期
                }
                return Err(e);
            }
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "short read"));
        }
        Ok(u64::from_ne_bytes(buf))
    }

    /// 取消定时器 (设 it_value 为 0)
    pub fn disarm(&self) -> io::Result<()> {
        let spec = libc::itimerspec {
            it_value: libc::timespec { tv_sec: 0, tv_nsec: 0 },
            it_interval: libc::timespec { tv_sec: 0, tv_nsec: 0 },
        };
        let r = unsafe { libc::timerfd_settime(self.fd, 0, &spec, std::ptr::null_mut()) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(())
    }

    /// 获取当前 boottime (用于算绝对时间)
    pub fn now_boottime() -> io::Result<Duration> {
        let mut ts = libc::timespec { tv_sec: 0, tv_nsec: 0 };
        let r = unsafe { libc::clock_gettime(libc::CLOCK_BOOTTIME, &mut ts) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Duration::new(ts.tv_sec as u64, ts.tv_nsec as u32))
    }

    /// 获取当前 boottime_alarm (与 timerfd 同源)
    pub fn now_boottime_alarm() -> io::Result<Duration> {
        let mut ts = libc::timespec { tv_sec: 0, tv_nsec: 0 };
        let r = unsafe { libc::clock_gettime(libc::CLOCK_BOOTTIME_ALARM, &mut ts) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Duration::new(ts.tv_sec as u64, ts.tv_nsec as u32))
    }

    pub fn raw_fd(&self) -> RawFd {
        self.fd
    }
}

impl Drop for DozeTimer {
    fn drop(&mut self) {
        if self.fd >= 0 {
            unsafe {
                libc::close(self.fd);
            }
        }
    }
}

impl AsRawFd for DozeTimer {
    fn as_raw_fd(&self) -> RawFd {
        self.fd
    }
}

// ============================================================
// 异步版 AsyncDozeTimer (用于 tokio runtime)
// ============================================================

#[cfg(feature = "tokio")]
pub mod async_timer {
    use super::*;
    use std::io;
    use std::os::unix::io::AsRawFd;
    use tokio::io::unix::AsyncFd;
    use tokio::io::Interest;

    /// tokio 异步版 Doze 穿透定时器
    ///
    /// 用 AsyncFd 包装 NONBLOCK timerfd, 配合 tokio epoll。
    /// 到期时 readable().await 返回, read 8 字节取到期次数。
    pub struct AsyncDozeTimer {
        inner: AsyncFd<DozeTimer>,
    }

    impl AsyncDozeTimer {
        /// 创建 (CLOCK_BOOTTIME_ALARM, NONBLOCK, CLOEXEC)
        pub fn new() -> io::Result<Self> {
            let timer = DozeTimer::new()?;
            let inner = AsyncFd::with_interest(timer, Interest::READABLE)?;
            Ok(Self { inner })
        }

        /// 设置单次相对定时
        pub fn arm_oneshot(&self, delay: Duration) -> io::Result<()> {
            self.inner.get_ref().set_oneshot_duration(delay)
        }

        /// 设置绝对时间定时 (用 BOOTTIME_ALARM 时钟)
        pub fn arm_absolute_boottime(&self, abs: Duration) -> io::Result<()> {
            self.inner.get_ref().set_absolute(abs.as_secs() as i64)
        }

        /// 异步等待到期, 返回 overrun 次数
        pub async fn expired(&self) -> io::Result<u64> {
            let mut buf = [0u8; 8];
            loop {
                let mut guard = self.inner.readable().await?;
                match guard.try_io(|inner| {
                    let fd = inner.get_ref().as_raw_fd();
                    let n =
                        unsafe { libc::read(fd, buf.as_mut_ptr() as *mut _, 8) };
                    if n < 0 {
                        Err(io::Error::last_os_error())
                    } else {
                        Ok(n as usize)
                    }
                }) {
                    Ok(Ok(8)) => return Ok(u64::from_ne_bytes(buf)),
                    Ok(Ok(_)) => continue,
                    Ok(Err(e)) if e.kind() == io::ErrorKind::WouldBlock => continue,
                    Ok(Err(e)) => return Err(e),
                    Err(_would_block) => continue,
                }
            }
        }

        /// 取消
        pub fn disarm(&self) -> io::Result<()> {
            self.inner.get_ref().disarm()
        }
    }

    // 让 AsyncDozeTimer 能被 select
    impl AsRawFd for AsyncDozeTimer {
        fn as_raw_fd(&self) -> RawFd {
            self.inner.get_ref().as_raw_fd()
        }
    }
}

// ============================================================
// WakeLock (RAII)
// ============================================================

/// wake_lock 持有者 (RAII, 退出自动释放)
///
/// 基于 RESEARCH-1:
/// - 写 /sys/power/wake_lock, 格式 "name timeout_ns"
/// - timeout 防止忘记释放导致永远不睡
/// - 释放写 /sys/power/wake_unlock "name"
/// - name 不含空白字符, 用稳定名字复用 wakeup source 防泄漏
pub struct WakeLock {
    name: String,
    released: bool,
}

impl WakeLock {
    /// 持有 wake_lock (带 timeout 兜底)
    ///
    /// `timeout_sec`: 超时自动释放 (防忘记 unlock), 0 = 永久锁
    pub fn acquire(name: &str, timeout_sec: u64) -> io::Result<Self> {
        let path = Path::new("/sys/power/wake_lock");
        let content = if timeout_sec > 0 {
            format!("{} {}\n", name, timeout_sec * 1_000_000_000)
        } else {
            format!("{}\n", name)
        };
        std::fs::write(path, content)?;
        Ok(Self {
            name: name.to_string(),
            released: false,
        })
    }

    /// 主动释放
    pub fn release(mut self) {
        if !self.released {
            let path = Path::new("/sys/power/wake_unlock");
            let _ = std::fs::write(path, format!("{}\n", self.name));
            self.released = true;
        }
    }
}

impl Drop for WakeLock {
    fn drop(&mut self) {
        if !self.released {
            let path = Path::new("/sys/power/wake_unlock");
            let _ = std::fs::write(path, format!("{}\n", self.name));
            self.released = true;
        }
    }
}

// ============================================================
// ShutdownEvent (v0.5.0: eventfd 唤醒通道, 修复 SIGTERM 延迟退出 bug)
// ============================================================

/// v0.5.0: shutdown 唤醒通道 (eventfd)
///
/// ## 背景: v0.4.4 之前 daemon 的 SIGTERM 退出有严重延迟 bug
///
/// daemon 主循环用 `timerfd poll()` 等 cron 触发。SIGHUP/SIGTERM/SIGINT 在
/// `install_signal_handlers` 里被 `pthread_sigmask(SIG_BLOCK)` 阻塞, 由专用
/// 线程 `sigwait` 同步捕获。这导致:
///   - 信号线程收到 SIGTERM 后 `shutdown.store(true)`, 但**主线程的 poll()
///     不会被 SIGTERM 打断** (信号被阻塞, 不触发 EINTR)。
///   - 主线程要等 timerfd 到期 (可能是数小时后的 cron) 才从 poll 返回。
///   - 返回后还可能**多跑一次 cron 清理** (timer_fired=true → run_cron_clean),
///     再回到循环顶部检查 shutdown 才退出。
///
/// 用户反馈: "定时任务清理完后进程会退出", "6 点我还在睡觉谁给他命令的"。
/// 根因: 用户在 03:17 发的 SIGTERM, daemon 到 05:59 cron 触发后才退出,
/// 还多跑了一次清理。日志显示 `释放=0B` (清理的全是空目录, 通配符 bug),
/// 用户以为是清理导致退出。
///
/// ## 修复: eventfd 唤醒通道
///
/// 用 eventfd 作为信号线程 → 主线程的唤醒通道:
///   1. daemon 启动时创建 `ShutdownEvent` (eventfd, NONBLOCK|CLOEXEC)
///   2. 信号线程收到 SIGTERM/SIGINT 后, 设置 shutdown=true 并调用 `notify()`
///      (写 1 字节 u64 到 eventfd)
///   3. 主循环 poll 同时等 timerfd + eventfd (`DozeTimer::wait_timeout_with_wake`),
///      eventfd 可读立即返回, daemon 秒退
///   4. 额外防御: `run_cron_clean` 前再检查一次 shutdown, 即使 eventfd 失败
///      也不会多跑清理
///
/// eventfd 比 pipe 轻 (单 fd, 内核维护 u64 计数器), 比 signalfd 简单 (不替换
/// 信号机制)。Linux 2.6.22+ / Android 全版本支持。
pub struct ShutdownEvent {
    fd: RawFd,
}

impl ShutdownEvent {
    /// 创建 eventfd (初始计数 0, NONBLOCK|CLOEXEC)
    pub fn new() -> io::Result<Self> {
        let fd = unsafe { libc::eventfd(0, libc::EFD_NONBLOCK | libc::EFD_CLOEXEC) };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Self { fd })
    }

    /// 获取 raw fd (传给 DozeTimer::wait_timeout_with_wake)
    pub fn raw_fd(&self) -> RawFd {
        self.fd
    }

    /// 信号线程调用: 写 1 触发唤醒 (幂等, 多次写无副作用, 计数器累加)
    pub fn notify(&self) {
        let val: u64 = 1;
        let buf = val.to_ne_bytes();
        let _ = unsafe { libc::write(self.fd, buf.as_ptr() as *const _, 8) };
    }

    /// 无 timerfd 时的退化等待: 只 poll eventfd, 带超时
    ///
    /// 返回 true = 收到唤醒, false = 超时
    pub fn wait_timeout(&self, timeout_ms: i32) -> io::Result<bool> {
        let mut pfd = libc::pollfd {
            fd: self.fd,
            events: libc::POLLIN,
            revents: 0,
        };
        let r = unsafe { libc::poll(&mut pfd, 1, timeout_ms) };
        if r < 0 {
            return Err(io::Error::last_os_error());
        }
        if r == 0 {
            return Ok(false);
        }
        // 消费 eventfd 计数 (防水平触发)
        let mut buf = [0u8; 8];
        let _ = unsafe { libc::read(self.fd, buf.as_mut_ptr() as *mut _, 8) };
        Ok(true)
    }
}

impl Drop for ShutdownEvent {
    fn drop(&mut self) {
        if self.fd >= 0 {
            unsafe { libc::close(self.fd); }
            self.fd = -1;
        }
    }
}

impl AsRawFd for ShutdownEvent {
    fn as_raw_fd(&self) -> RawFd {
        self.fd
    }
}

// ============================================================
// Cron 调度 (简单实现, 5 字段 标准 cron)
// ============================================================

/// 简单 cron 表达式 (5 字段: 分 时 日 月 周)
///
/// 格式: "分 时 日 月 周"
/// - 分: 0-59
/// - 时: 0-23
/// - 日: 1-31
/// - 月: 1-12
/// - 周: 0-6 (0=周日)
/// - *: 任意
/// - */N: 每 N
/// - a,b,c: 列表
/// - a-b: 范围
///
/// 不依赖外部 crate (避免 croner 等依赖体积), 自实现足够 Tarn 用。
#[derive(Debug, Clone)]
pub struct CronSchedule {
    minutes: Vec<u8>,
    hours: Vec<u8>,
    days: Vec<u8>,
    months: Vec<u8>,
    weekdays: Vec<u8>,
}

impl CronSchedule {
    /// 解析 cron 表达式
    pub fn parse(expr: &str) -> Result<Self, String> {
        let parts: Vec<&str> = expr.split_whitespace().collect();
        if parts.len() != 5 {
            return Err(format!(
                "cron 表达式必须 5 字段 (分 时 日 月 周), got {} 字段: {}",
                parts.len(),
                expr
            ));
        }
        let minutes = parse_field(parts[0], 0, 59)?;
        let hours = parse_field(parts[1], 0, 23)?;
        let days = parse_field(parts[2], 1, 31)?;
        let months = parse_field(parts[3], 1, 12)?;
        let weekdays = parse_field(parts[4], 0, 6)?;

        Ok(Self {
            minutes,
            hours,
            days,
            months,
            weekdays,
        })
    }

    /// 计算从 from 之后下一次触发的时间 (相对 from 的秒数偏移)
    ///
    /// 算法: 从 from+1 分钟开始逐分钟检查, 最多检查 366*24*60 分钟 (一年)
    ///
    /// 时区: UTC+8 (CST). cron 表达式按北京时间匹配, 与日志/状态时区一致。
    pub fn next_after(&self, from: chrono::DateTime<chrono::FixedOffset>) -> Option<chrono::DateTime<chrono::FixedOffset>> {
        use chrono::Timelike;
        // 从下一分钟开始, 秒归零
        let mut t = from
            .with_second(0)?
            .with_nanosecond(0)?
            .checked_add_signed(chrono::Duration::minutes(1))?;

        // 最多搜索一年 (防无效表达式死循环)
        let max_iter = 366 * 24 * 60;
        for _ in 0..max_iter {
            if self.matches_datetime(&t) {
                return Some(t);
            }
            t = t.checked_add_signed(chrono::Duration::minutes(1))?;
        }
        None
    }

    /// 计算到下次触发的 Duration (基于 BOOTTIME, 不考虑时区换算)
    pub fn next_duration(&self) -> Option<Duration> {
        let now = crate::timeutil::now_cst();
        let next = self.next_after(now)?;
        let diff = next.signed_duration_since(now);
        if diff.num_seconds() < 0 {
            return None;
        }
        Some(Duration::from_secs(diff.num_seconds().max(0) as u64))
    }

    fn matches_datetime(&self, t: &chrono::DateTime<chrono::FixedOffset>) -> bool {
        use chrono::{Datelike, Timelike};
        self.minutes.contains(&(t.minute() as u8))
            && self.hours.contains(&(t.hour() as u8))
            && self.days.contains(&(t.day() as u8))
            && self.months.contains(&(t.month() as u8))
            && self.weekdays.contains(&(t.weekday().num_days_from_sunday() as u8))
    }
}

fn parse_field(s: &str, min: u8, max: u8) -> Result<Vec<u8>, String> {
    let mut result: Vec<u8> = Vec::new();
    for part in s.split(',') {
        if part == "*" {
            for v in min..=max {
                result.push(v);
            }
        } else if let Some(step_str) = part.strip_prefix("*/") {
            let step: u8 = step_str
                .parse()
                .map_err(|_| format!("cron step 非法: {}", part))?;
            if step == 0 {
                return Err("cron step 不能为 0".to_string());
            }
            let mut v = min;
            while v <= max {
                result.push(v);
                v = v.saturating_add(step);
            }
        } else if let Some((lo_s, hi_s)) = part.split_once('-') {
            let lo: u8 = lo_s
                .parse()
                .map_err(|_| format!("cron range lo 非法: {}", part))?;
            let hi: u8 = hi_s
                .parse()
                .map_err(|_| format!("cron range hi 非法: {}", part))?;
            if lo < min || hi > max || lo > hi {
                return Err(format!("cron range 越界: {}", part));
            }
            for v in lo..=hi {
                result.push(v);
            }
        } else {
            let v: u8 = part
                .parse()
                .map_err(|_| format!("cron value 非法: {}", part))?;
            if v < min || v > max {
                return Err(format!("cron value 越界: {} ({}-{})", v, min, max));
            }
            result.push(v);
        }
    }
    result.sort();
    result.dedup();
    Ok(result)
}

// ============================================================
// 测试
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_timerfd_create() {
        let timer = DozeTimer::new();
        match timer {
            Ok(t) => {
                println!("✅ timerfd 创建成功, fd={}", t.raw_fd());
                let _ = t.disarm();
            }
            Err(e) => {
                println!("⚠️ timerfd 创建失败 (非 root/无 CAP_WAKE_ALARM?): {}", e);
            }
        }
    }

    #[test]
    fn test_now_boottime() {
        match DozeTimer::now_boottime() {
            Ok(d) => println!("✅ boottime = {:?}", d),
            Err(e) => println!("⚠️ clock_gettime 失败: {}", e),
        }
    }

    #[test]
    fn test_wakelock_acquire_release() {
        // 非 root 环境会失败, 只验证不 panic
        match WakeLock::acquire("tarn_test", 5) {
            Ok(wl) => {
                println!("✅ wakelock 持有");
                wl.release();
                println!("✅ wakelock 释放");
            }
            Err(e) => {
                println!("⚠️ wakelock 失败 (非 root?): {}", e);
            }
        }
    }

    #[test]
    fn test_cron_parse_every_5_min() {
        let c = CronSchedule::parse("*/5 * * * *").unwrap();
        assert!(c.minutes.contains(&0));
        assert!(c.minutes.contains(&5));
        assert!(c.minutes.contains(&55));
        assert!(c.hours.len() == 24); // *
    }

    #[test]
    fn test_cron_parse_specific() {
        let c = CronSchedule::parse("30 3 * * *").unwrap();
        assert_eq!(c.minutes, vec![30]);
        assert_eq!(c.hours, vec![3]);
    }

    #[test]
    fn test_cron_parse_range() {
        let c = CronSchedule::parse("0 9-17 * * 1-5").unwrap();
        assert!(c.hours.contains(&9));
        assert!(c.hours.contains(&17));
        assert!(c.weekdays.contains(&1)); // 周一
        assert!(c.weekdays.contains(&5)); // 周五
        assert!(!c.weekdays.contains(&0)); // 周日不在内
    }

    #[test]
    fn test_cron_parse_list() {
        let c = CronSchedule::parse("0,30 * * * *").unwrap();
        assert_eq!(c.minutes, vec![0, 30]);
    }

    #[test]
    fn test_cron_parse_invalid() {
        assert!(CronSchedule::parse("xxx").is_err());
        assert!(CronSchedule::parse("* * * *").is_err()); // 4 字段
        assert!(CronSchedule::parse("60 * * * *").is_err()); // 分越界
        assert!(CronSchedule::parse("*/0 * * * *").is_err()); // step 0
    }

    #[test]
    fn test_cron_next_after() {
        let c = CronSchedule::parse("*/5 * * * *").unwrap();
        let now = crate::timeutil::now_cst();
        let next = c.next_after(now);
        assert!(next.is_some());
        if let Some(n) = next {
            // 下次触发应在未来 5 分钟内
            let diff = n.signed_duration_since(now);
            assert!(diff.num_seconds() > 0);
            assert!(diff.num_seconds() <= 5 * 60);
        }
    }
}
