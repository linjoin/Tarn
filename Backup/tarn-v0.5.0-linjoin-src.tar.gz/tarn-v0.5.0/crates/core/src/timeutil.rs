//! 时间工具: 跟随系统时区, 回退 UTC+8
//!
//! v0.4.3 起: 不再硬编码 UTC+8, 改为跟随系统时区 (/etc/localtime + TZ 环境变量)。
//! 若系统未设时区 (偏移 0 且 TZ 空), 回退到 UTC+8 (中国标准时间)。
//!
//! 设计原因:
//! - Magisk 模块运行环境时区可能不可靠 (recovery/容器/某些 ROM 未设 TZ)
//! - chrono::Local 依赖 /etc/localtime 与 TZ 环境变量, Android 正常开机下可用
//! - 用户要求日志时间跟系统时区, 不再硬编码 UTC+8
//! - FixedOffset 不依赖系统时区数据库, 二进制内嵌, 0 外部依赖
//!
//! 所有对外时间 API (函数名保留 cst 前缀, 避免改 20+ 调用点, 语义改为"当前时区"):
//! - [`now_cst`]: 当前系统时区时刻 (DateTime<FixedOffset>)
//! - [`now_cst_sec`]: "YYYY-MM-DD HH:MM:SS" 字符串 (日志行用)
//! - [`now_cst_rfc3339`]: RFC3339 字符串 (state.json / run_id 时间戳用)

use chrono::{DateTime, Datelike, FixedOffset, Local, SecondsFormat, Timelike};

/// UTC+8 固定偏移 (8 * 3600 秒), 作为回退时区
pub const CST_OFFSET_SECS: i32 = 8 * 3600;

/// UTC+8 FixedOffset (线程安全, 无需初始化), 用于系统未设时区时回退
pub fn cst_offset() -> FixedOffset {
    FixedOffset::east_opt(CST_OFFSET_SECS).expect("8*3600 is valid offset")
}

/// 探测系统时区偏移:
/// - 读 chrono::Local (依赖 /etc/localtime + TZ 环境变量)
/// - 偏移非 0 → 一定有时区, 返回 Some(FixedOffset)
/// - 偏移 0 且 TZ 环境变量为空 → 可能未设时区, 返回 None (回退 UTC+8)
/// - 偏移 0 且 TZ 非空 (如 TZ=UTC) → 尊重显式设置, 返回 Some(+0)
fn system_offset() -> Option<FixedOffset> {
    let now = Local::now();
    let offset = now.offset().local_minus_utc();
    if offset != 0 {
        FixedOffset::east_opt(offset)
    } else {
        // 偏移 0: 可能是 UTC, 也可能未设时区
        let tz = std::env::var("TZ").unwrap_or_default();
        if tz.is_empty() {
            None  // 未设时区, 回退 UTC+8
        } else {
            FixedOffset::east_opt(0)  // 显式 UTC
        }
    }
}

/// 当前系统时区偏移, 若系统未设时区则回退 UTC+8
fn current_offset() -> FixedOffset {
    system_offset().unwrap_or_else(cst_offset)
}

/// 当前系统时区时刻
pub fn now_cst() -> DateTime<FixedOffset> {
    chrono::Utc::now().with_timezone(&current_offset())
}

/// 当前系统时区时间, 精确到秒, 格式 "YYYY-MM-DD HH:MM:SS"
pub fn now_cst_sec() -> String {
    let t = now_cst();
    format!(
        "{:04}-{:02}-{:02} {:02}:{:02}:{:02}",
        t.year(),
        t.month(),
        t.day(),
        t.hour(),
        t.minute(),
        t.second(),
    )
}

/// 当前系统时区时间, RFC3339 格式 (含时区偏移)
pub fn now_cst_rfc3339() -> String {
    now_cst().to_rfc3339_opts(SecondsFormat::Secs, true)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_now_returns_valid_offset() {
        let now = now_cst();
        let offset = now.offset().local_minus_utc();
        // 合法偏移范围: [-43200, 50400] (UTC-12 到 UTC+14)
        assert!(offset >= -43200 && offset <= 50400,
            "时区偏移应在 [-43200, 50400] 范围内, 实际: {}", offset);
    }

    #[test]
    fn test_now_sec_format() {
        let s = now_cst_sec();
        assert_eq!(s.len(), 19, "格式应为 YYYY-MM-DD HH:MM:SS, 实际: {}", s);
        assert_eq!(s.chars().nth(4), Some('-'));
        assert_eq!(s.chars().nth(7), Some('-'));
        assert_eq!(s.chars().nth(10), Some(' '));
        assert_eq!(s.chars().nth(13), Some(':'));
        assert_eq!(s.chars().nth(16), Some(':'));
    }

    #[test]
    fn test_now_rfc3339_has_offset() {
        let s = now_cst_rfc3339();
        // 应以 ±HH:MM 结尾 (跟随系统时区, 不再硬断言 +08:00)
        assert!(s.len() >= 6, "RFC3339 字符串过短: {}", s);
        let tail = &s[s.len()-6..];
        assert!(tail.starts_with('+') || tail.starts_with('-'),
            "RFC3339 应以 ±HH:MM 结尾, 实际尾部: {}", tail);
    }

    #[test]
    fn test_fallback_to_cst_when_no_tz() {
        // 清除 TZ 环境变量, 模拟未设时区
        // 注意: 此测试依赖 /etc/localtime, 在 CI 容器里可能仍有偏移
        // 仅验证 cst_offset() 回退逻辑本身
        let fallback = cst_offset();
        assert_eq!(fallback.local_minus_utc(), 8 * 3600);
    }
}
