//! 保护层: 路径白名单校验 + 用户媒体保护 + 用户自定义白名单匹配
//!
//! 保护判断顺序:
//! 1. 路径白名单 ([`is_target_allowed`]): target.path 必须落在 [`ALLOWED_ROOTS`] 下,
//!    且不能命中 [`HARDCODED_PROTECT`] (即便在 ALLOWED_ROOTS 下也拒)。
//!    例外: [`HARDCODED_ALLOW`] 下的路径放行 (如 /data/adb/tarn/rules)。
//! 2. 用户媒体保护 ([`is_user_media_path`], 跨 /sdcard /storage /data/media 四种路径形式):
//!    DCIM/Pictures/Music/Movies 永不可清理, 防误删照片/截图/视频/音乐。
//!    注: Download 已移出内置保护 (用户可按需在 whitelist.toml 自行保护), 允许规则清理。
//!    防 symlink 绕过: 规则不能经 /storage/emulated/0/DCIM 或 /data/media/0/DCIM
//!    绕过 /sdcard/DCIM 的字面保护。
//! 3. [`ProtectSet::check`] (用户自定义保护, 在 whitelist.toml 配置):
//!    - protect_path (prefix/通配符)
//!    - protect_package
//!    - protect_ext
//!    - protect_mtime
//! 4. 都没命中 → 允许删除
//!
//! 路径白名单是强安全栅栏 (创建规则时 + 执行时双重校验), 防止误删系统目录。

use crate::config::Whitelist;
use std::collections::HashSet;
use std::path::Path;
use std::time::SystemTime;

/// 允许清理的根目录前缀 (路径白名单)。
/// target.path 必须落在这些根之下才允许执行, 否则拒绝 (防误删系统/关键目录)。
///
/// 注意: /sdcard /storage 是 /data/media/<id> 的符号链接 / fuse 挂载入口,
/// OS 在 open() 时透明解析, walker 可直接打开这些路径 (无需引擎解析 symlink)。
///
/// 安全保证: 用户媒体数据 (DCIM/Pictures/Music/Movies) 由 [`is_user_media_path`]
/// 跨 /sdcard /storage/emulated/<id> /storage/self/primary /data/media/<id> 四种形式统一保护,
/// 防止通过 /storage/emulated/0/DCIM 或 /data/media/0/DCIM 绕过 /sdcard/DCIM 的保护。
pub const ALLOWED_ROOTS: &[&str] = &[
    "/data/data",           // App 数据 (缓存/崩溃/临时)
    "/data/user",           // App 数据 (多用户 /data/user/0/<pkg>)
    "/data/anr",            // 应用无响应 (ANR) 崩溃记录
    "/data/local/tmp",      // 本地临时文件
    "/data/system/dropbox", // 系统崩溃 dropbox
    "/data/tombstones",     // 原生崩溃 tombstone
    "/data/log",            // 系统 logcat 转储目录 (规则用通配符限定 *.log/*.txt, 不删目录)
    "/data/dalvik-cache",   // ART 编译缓存目录 (规则用通配符限定 *.tmp, 不删 *.dex)
    "/data/media",          // 外置存储底层路径 (/data/media/0 = 主用户 user 0)
    "/sdcard",              // 外置存储 (/sdcard → /storage/self/primary → /data/media/0)
    "/storage",             // 外置存储 (/storage/emulated/<id> 多用户 + /storage/self/primary)
    "/data/adb/tarn/rules", // Tarn 规则包目录 (清理规则产生的临时文件)
];

/// 用户媒体数据目录名 (永不可清理, 防误删照片/截图/视频/音乐)
const PROTECTED_USER_DIRS: &[&str] = &["DCIM", "Pictures", "Music", "Movies"];
// 注: Download 已于 v0.5.8+ 移出内置保护 (用户要求), 如需保护请在 whitelist.toml 配置 protect_path

/// 检查路径是否落在用户媒体数据目录下。
///
/// /sdcard, /storage/emulated/<id>, /storage/self/primary, /data/media/<id> 在 Android 上
/// 都指向同一份用户存储 (经 symlink / bind / fuse). 由于 [`normalize_path`] 不解析 symlink,
/// 必须对四种字面路径形式统一保护, 否则规则可经 /storage/emulated/0/DCIM 或 /data/media/0/DCIM
/// 绕过 /sdcard/DCIM 的字面保护, 误删用户照片。
///
/// 匹配形式 (按路径组件, 支持任意 user id 0/10/11/...):
/// - /sdcard/<dir>/...
/// - /storage/emulated/<id>/<dir>/...
/// - /storage/self/primary/<dir>/...
/// - /data/media/<id>/<dir>/...
fn is_user_media_path(path: &str) -> bool {
    let parts: Vec<&str> = path.split('/').filter(|s| !s.is_empty()).collect();
    // /sdcard/<dir>/...
    if parts.len() >= 2 && parts[0] == "sdcard" {
        return PROTECTED_USER_DIRS.contains(&parts[1]);
    }
    // /storage/emulated/<id>/<dir>/...  或  /storage/self/primary/<dir>/...
    if parts.len() >= 4 && parts[0] == "storage" {
        if parts[1] == "emulated" {
            // parts[2] = user id, parts[3] = <dir>
            return PROTECTED_USER_DIRS.contains(&parts[3]);
        }
        if parts[1] == "self" && parts[2] == "primary" {
            // parts[3] = <dir>
            return PROTECTED_USER_DIRS.contains(&parts[3]);
        }
    }
    // /data/media/<id>/<dir>/...
    if parts.len() >= 4 && parts[0] == "data" && parts[1] == "media" {
        // parts[2] = user id, parts[3] = <dir>
        return PROTECTED_USER_DIRS.contains(&parts[3]);
    }
    false
}

/// 把 protect_path 展开为 Android 外置存储的全部等价路径形式 (防别名绕过)。
///
/// Android 外置存储有 4 种字面入口形式, 指向同一份物理存储 (/data/media/<id> 是底层真实路径,
/// 其余是它的 symlink / FUSE 挂载入口):
///   1. /sdcard/<剩余>
///   2. /storage/emulated/<id>/<剩余>      (id = user id, 主用户 0, 多用户 10/11/...)
///   3. /storage/self/primary/<剩余>        (仅主用户 id=0 的入口)
///   4. /data/media/<id>/<剩余>
///
/// 用户在 whitelist 配 protect_path 时通常只写一种形式 (如 /sdcard/Download),
/// 但 blacklist target 可能用另一种形式 (如 /storage/emulated/0/Download),
/// 若不归一化, walker 产出的文件路径与 protect_path 字面不匹配 → 保护被绕过。
///
/// 本函数识别输入路径属于哪种形式, 提取 <剩余子路径>, 生成全部 4 种等价路径:
///   /sdcard/Download       → [/sdcard/Download,
///                             /storage/emulated/0/Download, /storage/emulated/10/Download,
///                             /storage/self/primary/Download,
///                             /data/media/0/Download, /data/media/10/Download]
///   (多用户: 默认展开 user 0 + 10, 覆盖主用户 + 常见副用户; 若输入含具体 id, 保留该 id)
///
/// 非 sdcard 路径 (如 /data/data/com.foo/cache) 原样返回 (不展开)。
fn expand_sdcard_aliases(path: &str) -> Vec<String> {
    let parts: Vec<&str> = path.split('/').filter(|s| !s.is_empty()).collect();
    if parts.is_empty() {
        return vec![path.to_string()];
    }

    // 识别输入形式, 提取 (user_id, 剩余子路径组件)
    // 返回 Some((Option<user_id>, 剩余组件)) — user_id=None 表示用默认多用户集合
    let (user_id, rest): (Option<&str>, &[&str]) = {
        // 形式 1: /sdcard/<剩余>
        if parts[0] == "sdcard" {
            (None, &parts[1..])
        }
        // 形式 2: /storage/emulated/<id>/<剩余>
        else if parts.len() >= 3 && parts[0] == "storage" && parts[1] == "emulated" {
            (Some(parts[2]), &parts[3..])
        }
        // 形式 3: /storage/self/primary/<剩余>
        else if parts.len() >= 3 && parts[0] == "storage" && parts[1] == "self" && parts[2] == "primary" {
            // /storage/self/primary 仅主用户, 等价 user 0
            (Some("0"), &parts[3..])
        }
        // 形式 4: /data/media/<id>/<剩余>
        else if parts.len() >= 3 && parts[0] == "data" && parts[1] == "media" {
            (Some(parts[2]), &parts[3..])
        }
        // 非 sdcard 路径: 原样返回
        else {
            return vec![path.to_string()];
        }
    };

    // 剩余子路径重组为字符串 (可能为空, 如 protect_path = "/sdcard" 本身)
    let rest_str = if rest.is_empty() {
        String::new()
    } else {
        format!("/{}", rest.join("/"))
    };

    // 确定要展开的 user id 集合
    // 输入含具体 id → 保留该 id; 输入是 /sdcard (无 id) → 展开 0 + 10 (主用户 + 常见副用户)
    let ids: Vec<&str> = match user_id {
        Some(id) => vec![id],
        None => vec!["0", "10"],
    };

    let mut result: Vec<String> = Vec::new();
    // 形式 1: /sdcard/<剩余> (无 id 概念, 单一)
    result.push(format!("/sdcard{}", rest_str));
    // 形式 2: /storage/emulated/<id>/<剩余>
    for id in &ids {
        result.push(format!("/storage/emulated/{}/{}", id, rest.join("/")));
    }
    // 形式 3: /storage/self/primary/<剩余> (仅主用户)
    result.push(format!("/storage/self/primary{}", rest_str));
    // 形式 4: /data/media/<id>/<剩余>
    for id in &ids {
        result.push(format!("/data/media/{}/{}", id, rest.join("/")));
    }

    // 去重 (rest 为空时 /sdcard 与各形式不会重复, 但保险起见)
    result.sort();
    result.dedup();
    result
}

/// 硬编码保护目录 (即便落在 ALLOWED_ROOTS 下也绝不删)。
/// 这些是系统/引导/Tarn 自身的关键目录, 删除会导致变砖或模块失效。
const HARDCODED_PROTECT: &[&str] = &[
    "/system",
    "/vendor",
    "/product",
    "/apex",
    "/data/adb", // Magisk/KernelSU 模块根
    "/data/adb/magisk",
    "/data/adb/modules",
    "/data/adb/tarn", // Tarn 自身 (配置/状态/日志)
    "/data/adb/tarn/config",
    "/data/adb/tarn/state.json",
    "/data/adb/tarn/logs",
];

/// Tarn 自身放行子目录 (规则包临时文件可清, 但不删 Tarn 主目录)。
const HARDCODED_ALLOW: &[&str] = &[
    "/data/adb/tarn/rules", // 规则包解压临时文件
];

/// 规范化路径: 折叠多余 / , 解析 . 和 .., 去掉末尾 / (根除外)。
/// 用于路径校验前的一致化, 防止 `/data/data//../adb` 之类绕过白名单。
fn normalize_path(p: &str) -> String {
    if p.is_empty() {
        return String::new();
    }
    let mut parts: Vec<&str> = Vec::new();
    let is_abs = p.starts_with('/');
    for seg in p.split('/') {
        match seg {
            "" | "." => {}
            ".." => {
                if !parts.is_empty() {
                    parts.pop();
                }
            }
            other => parts.push(other),
        }
    }
    let joined = parts.join("/");
    if is_abs {
        if joined.is_empty() {
            "/".to_string()
        } else {
            format!("/{}", joined)
        }
    } else {
        joined
    }
}

/// 检查 target 路径是否允许清理 (路径白名单 + 硬编码保护)。
///
/// 返回 `Ok(())` 表示允许, `Err(reason)` 表示拒绝 (reason 是给用户看的中文说明)。
///
/// 校验逻辑:
/// 1. 规范化路径 (折叠 `//` / `.` / `..`)
/// 2. 必须以 `/` 开头 (绝对路径)
/// 3. 不能落在 [`HARDCODED_PROTECT`] 下 (即便在 [`ALLOWED_ROOTS`] 下也拒)
///    - 例外: [`HARDCODED_ALLOW`] 下的路径放行 (如 `/data/adb/tarn/rules`)
/// 4. 必须落在 [`ALLOWED_ROOTS`] 某个根之下
pub fn is_target_allowed(path: &str) -> Result<(), String> {
    let norm = normalize_path(path);
    if !norm.starts_with('/') {
        return Err(format!("路径必须以 / 开头: {}", path));
    }
    // 硬编码保护检查 (优先级最高)
    for hp in HARDCODED_PROTECT {
        if path_in_prefix(&norm, hp) {
            // 检查是否在 HARDCODED_ALLOW 放行子目录
            let allowed = HARDCODED_ALLOW.iter().any(|ha| path_in_prefix(&norm, ha));
            if !allowed {
                return Err(format!("路径在系统保护目录内, 不允许清理: {}", norm));
            }
        }
    }
    // 白名单根检查
    let in_allowed = ALLOWED_ROOTS.iter().any(|root| path_in_prefix(&norm, root));
    if !in_allowed {
        return Err(format!(
            "路径不在允许清理的范围内: {}\n允许的目录: {}",
            norm,
            ALLOWED_ROOTS.join(", ")
        ));
    }
    // 用户媒体数据保护 (加载时门): DCIM/Pictures/Music/Movies 跨四种路径形式统一拒绝,
    // 防止规则经 /storage/emulated/0/DCIM 或 /data/media/0/DCIM 绕过 /sdcard/DCIM 保护
    if is_user_media_path(&norm) {
        return Err(format!(
            "路径在用户媒体数据目录内 (照片/截图/视频/音乐), 不允许清理: {}",
            norm
        ));
    }
    Ok(())
}

/// 路径前缀匹配: 严格路径组件匹配, 避免字符串前缀旁路
///
/// 问题: `"/data/adb/tarn/rules_evil".starts_with("/data/adb/tarn/rules")` 返回 true,
/// 会让 `/data/adb/tarn/rules_evil` 被误判为放行路径。
///
/// 因此必须是完整路径相等, 或后面紧贴路径分隔符 `/`。
fn path_in_prefix(path: &str, prefix: &str) -> bool {
    if path == prefix {
        return true;
    }
    // 必须以 `prefix + "/"` 开头, 避免子字符串误匹配
    let prefix_with_slash = if prefix.ends_with('/') {
        prefix.to_string()
    } else {
        format!("{}/", prefix)
    };
    path.starts_with(&prefix_with_slash)
}

/// 编译后的保护集合
#[derive(Debug, Clone)]
pub struct ProtectSet {
    /// prefix 匹配 (含硬编码 + protect_path match=prefix)
    prefix: HashSet<String>,
    /// 通配符匹配 (DFA)
    glob: globset::GlobSet,
    /// 包名保护 (包名 → 仅子目录列表, None=全保护)
    packages: std::collections::HashMap<String, Option<HashSet<String>>>,
    /// 扩展名保护 (小写, 无点) → scope 集合 (空 Vec=全局, 否则为归一化后的多路径前缀)
    ///
    /// scope 在 compile 时经 expand_sdcard_aliases 归一化为 Vec, 防 sdcard 别名绕过
    /// (用户配 scope="/sdcard/Download", blacklist 用 /storage/emulated/0/Download 形式可绕过)
    exts: Vec<(HashSet<String>, Vec<String>)>,
    /// mtime 保护 (within_days, scope 集合)
    /// 同 exts, scope 归一化为 Vec 防别名绕过
    mtime: Vec<(u32, Vec<String>)>,
}

impl ProtectSet {
    /// 从 whitelist.conf 编译用户自定义保护集
    pub fn compile(wl: &Whitelist) -> Result<Self, String> {
        let mut prefix: HashSet<String> = HashSet::new();
        let mut glob_patterns: Vec<globset::Glob> = Vec::new();

        // 1. protect_path (path 自动判断 通配符/prefix)
        //    - path 含通配符 (* ? [) → 通配符匹配 (用 globset DFA)
        //    - 否则 → prefix 匹配 (最常用, 保护该目录及其所有子内容)
        //
        //    [跨路径形式归一化] (防别名绕过):
        //    若 protect_path 落在 Android 外置存储的 4 种入口形式之一, 自动展开为全部 4 种等价形式,
        //    防止用户保护了 /sdcard/Download 但 blacklist 用 /storage/emulated/0/Download 形式绕过。
        //    (Android 上 /sdcard /storage/emulated/<id> /storage/self/primary /data/media/<id> 指向同一份物理存储)
        for pp in &wl.protect {
            if pp.is_glob() {
                // [跨路径形式归一化] (防别名绕过, 与 prefix 分支一致):
                // glob 类 protect_path 也要展开 sdcard 别名, 否则用户保护 /sdcard/Download/*.pdf
                // 但 blacklist 用 /storage/emulated/0/Download/secret.pdf 形式可绕过保护。
                // expand_sdcard_aliases 把通配符组件当普通路径组件, 仅展开前缀别名部分,
                // 后缀通配符原样保留, 为每种等价路径形式各编译一个 glob。
                for expanded in expand_sdcard_aliases(&pp.path) {
                    // literal_separator(true): * 不跨 / (与 matcher.rs 清理侧语义一致)
                    // 否则 /sdcard/Download/*.pdf 的 * 会跨 / 误匹配 /sdcard/Download/sub/secret.pdf
                    // 导致保护范围比用户预期更宽 (保护侧宁严不宽, 但语义必须与清理侧统一,
                    // 否则用户在 WebUI 看到 include *cache 不跨 / 却看到 protect *cache 跨 / 会困惑)。
                    let g = globset::GlobBuilder::new(&expanded)
                        .literal_separator(true)
                        .build()
                        .map_err(|e| format!("通配符编译失败 {}: {}", expanded, e))?;
                    glob_patterns.push(g);
                }
            } else {
                // 归一化: 把 protect_path 展开为全部等价路径形式
                for expanded in expand_sdcard_aliases(&pp.path) {
                    prefix.insert(expanded);
                }
            }
        }

        let mut glob_builder = globset::GlobSetBuilder::new();
        for g in &glob_patterns {
            glob_builder.add(g.clone());
        }
        let glob = glob_builder
            .build()
            .map_err(|e| format!("GlobSet 构建失败: {}", e))?;

        // 3. protect_package
        let mut packages: std::collections::HashMap<String, Option<HashSet<String>>> =
            std::collections::HashMap::new();
        for pk in &wl.protect_package {
            let only = if pk.only.is_empty() {
                None
            } else {
                Some(pk.only.iter().cloned().collect())
            };
            packages.insert(pk.package.clone(), only);
        }

        // 4. protect_ext
        // [跨路径形式归一化] scope 也调用 expand_sdcard_aliases, 与 protect_path 一致:
        // 否则用户配 scope="/sdcard/Download", blacklist 用 /storage/emulated/0/Download/x.pdf 形式
        // → path_in_prefix 字面匹配失败 → scope 检查不过 → PDF 被清理 (保护被绕过!)
        let mut exts: Vec<(HashSet<String>, Vec<String>)> = Vec::new();
        for pe in &wl.protect_ext {
            let set: HashSet<String> = pe
                .extensions
                .iter()
                .map(|e| e.trim_start_matches('.').to_lowercase())
                .collect();
            let scope: Vec<String> = if pe.scope.is_empty() || pe.scope == "global" {
                Vec::new() // 全局
            } else {
                expand_sdcard_aliases(&pe.scope)
            };
            exts.push((set, scope));
        }

        // 5. protect_mtime (scope 同样归一化)
        let mut mtime: Vec<(u32, Vec<String>)> = Vec::new();
        for pm in &wl.protect_mtime {
            let scope: Vec<String> = if pm.scope.is_empty() || pm.scope == "global" {
                Vec::new()
            } else {
                expand_sdcard_aliases(&pm.scope)
            };
            mtime.push((pm.within_days, scope));
        }

        Ok(Self {
            prefix,
            glob,
            packages,
            exts,
            mtime,
        })
    }

    /// 检查给定路径是否被保护
    ///
    /// 返回 Some(reason) 表示被保护, None 表示可删
    pub fn check(&self, path: &Path, mtime: Option<SystemTime>) -> Option<&'static str> {
        let path_str = path.to_string_lossy();

        // 0. 用户媒体数据保护 (运行时兜底, 跨 /sdcard /storage /data/media 四种形式)
        //    防 walker 误入 DCIM/Pictures/... 子树删用户照片/视频
        if is_user_media_path(&path_str) {
            return Some("blocked_user_media");
        }

        // 1. prefix 匹配 (protect_path prefix)
        for p in &self.prefix {
            if path_in_prefix(&path_str, p) {
                return Some("blocked_prefix");
            }
        }

        // 2. 通配符匹配
        if self.glob.is_match(path) {
            return Some("blocked_glob");
        }

        // 3. protect_package: 匹配 /data/data/<pkg>/ 或 /data/user/0/<pkg>/
        if let Some(pkg) = extract_package_from_path(&path_str) {
            if let Some(only) = self.packages.get(&pkg) {
                match only {
                    None => return Some("blocked_package"),
                    Some(subs) => {
                        // 检查子目录是否在 only 列表
                        if let Some(subdir) = extract_subdir_from_path(&path_str, &pkg) {
                            if subs.contains(&subdir) {
                                return Some("blocked_package");
                            }
                        }
                    }
                }
            }
        }

        // 4. protect_ext
        // scope 是归一化后的 Vec (compile 时已展开 4 种 sdcard 形式), 任一形式命中即保护
        // path_in_prefix 严格路径组件匹配, 避免 scope="/data/data/com.foo" 误匹配 com.foobar
        if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
            let ext_lower = ext.to_lowercase();
            for (set, scopes) in &self.exts {
                if set.contains(&ext_lower) {
                    if scopes.is_empty() || scopes.iter().any(|s| path_in_prefix(&path_str, s)) {
                        return Some("blocked_ext");
                    }
                }
            }
        }

        // 5. protect_mtime (scope 同样是归一化 Vec)
        if let Some(mtime_val) = mtime {
            if let Ok(now) = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH) {
                if let Ok(file_age) = mtime_val.duration_since(SystemTime::UNIX_EPOCH) {
                    for (within_days, scopes) in &self.mtime {
                        let age_sec = now.as_secs().saturating_sub(file_age.as_secs());
                        let within_sec = (*within_days as u64) * 86400;
                        if age_sec < within_sec {
                            if scopes.is_empty() || scopes.iter().any(|s| path_in_prefix(&path_str, s)) {
                                return Some("blocked_mtime");
                            }
                        }
                    }
                }
            }
        }

        None
    }
}

/// 从路径提取包名 (支持 /data/data/<pkg>/... 和 /data/user/0/<pkg>/...)
fn extract_package_from_path(path: &str) -> Option<String> {
    if let Some(rest) = path.strip_prefix("/data/data/") {
        let pkg = rest.split('/').next()?;
        return Some(pkg.to_string());
    }
    if let Some(rest) = path.strip_prefix("/data/user/") {
        // /data/user/0/<pkg>/...
        let parts: Vec<&str> = rest.splitn(3, '/').collect();
        if parts.len() >= 2 {
            return Some(parts[1].to_string());
        }
    }
    None
}

/// 从 /data/data/<pkg>/<subdir>/... 或 /data/user/<id>/<pkg>/<subdir>/... 提取 subdir
/// (支持任意 user_id)
fn extract_subdir_from_path(path: &str, pkg: &str) -> Option<String> {
    let prefix = format!("/data/data/{}/", pkg);
    if let Some(rest) = path.strip_prefix(&prefix) {
        let subdir = rest.split('/').next()?;
        return Some(subdir.to_string());
    }
    // /data/user/<任意 id>/<pkg>/...
    if let Some(rest) = path.strip_prefix("/data/user/") {
        let parts: Vec<&str> = rest.splitn(3, '/').collect();
        // parts[0] = user_id, parts[1] = pkg, parts[2] = rest
        if parts.len() >= 3 && parts[1] == pkg {
            let subdir = parts[2].split('/').next()?;
            return Some(subdir.to_string());
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::ProtectPath;

    #[test]
    fn test_path_in_prefix_strict() {
        // 完全相等
        assert!(path_in_prefix("/data/adb/tarn/rules", "/data/adb/tarn/rules"));
        // 正常子路径
        assert!(path_in_prefix("/data/adb/tarn/rules/x.toml", "/data/adb/tarn/rules"));
        assert!(path_in_prefix("/data/adb/tarn/rules/sub/y.toml", "/data/adb/tarn/rules"));
        // 关键: 字符串前缀但非路径组件必须返回 false (回归测试)
        assert!(!path_in_prefix("/data/adb/tarn/rules_evil", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("/data/adb/tarn/rulessecret", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("/data/adb/tarn/logs_evil/x", "/data/adb/tarn/logs"));
        // 空路径
        assert!(!path_in_prefix("/", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("", "/data/adb/tarn/rules"));
    }

    #[test]
    fn test_extract_subdir_multi_user() {
        // /data/data/<pkg>/<sub>/...
        assert_eq!(
            extract_subdir_from_path("/data/data/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        // /data/user/<id>/<pkg>/<sub>/... 支持任意 user_id
        assert_eq!(
            extract_subdir_from_path("/data/user/0/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        // user_id=10 同样匹配
        assert_eq!(
            extract_subdir_from_path("/data/user/10/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        assert_eq!(
            extract_subdir_from_path("/data/user/11/com.foo/files/y.db", "com.foo"),
            Some("files".to_string())
        );
        // 包名不匹配
        assert_eq!(
            extract_subdir_from_path("/data/user/0/com.bar/cache/x.tmp", "com.foo"),
            None
        );
    }

    // ===== normalize_path 单元测试 =====

    #[test]
    fn test_normalize_path_basic() {
        // 基本路径不变
        assert_eq!(normalize_path("/data/data/com.foo"), "/data/data/com.foo");
        assert_eq!(normalize_path("/sdcard/Download/x"), "/sdcard/Download/x");
    }

    #[test]
    fn test_normalize_path_dotdot() {
        // .. 折叠到上一级
        assert_eq!(normalize_path("/data/data/../adb"), "/data/adb");
        assert_eq!(normalize_path("/a/b/c/../../d"), "/a/d");
        // .. 超过根目录边界后停止向上 (根的 .. = 根)
        assert_eq!(normalize_path("/../etc"), "/etc");
        assert_eq!(normalize_path("/../../etc"), "/etc");
    }

    #[test]
    fn test_normalize_path_trailing_slash_and_collapsed() {
        // 末尾 / 去掉 (根除外)
        assert_eq!(normalize_path("/data/data/"), "/data/data");
        assert_eq!(normalize_path("/data/data//"), "/data/data");
        // 多余 / 折叠
        assert_eq!(normalize_path("/data//data///com.foo"), "/data/data/com.foo");
        // 根保留
        assert_eq!(normalize_path("/"), "/");
        assert_eq!(normalize_path("///"), "/");
        // . 折叠
        assert_eq!(normalize_path("/data/./data/./com.foo"), "/data/data/com.foo");
    }

    #[test]
    fn test_normalize_path_empty_and_relative() {
        // 空字符串
        assert_eq!(normalize_path(""), "");
        // 相对路径保持相对
        assert_eq!(normalize_path("foo/bar"), "foo/bar");
        assert_eq!(normalize_path("foo/../bar"), "bar");
        assert_eq!(normalize_path("./foo"), "foo");
    }

    // ===== is_target_allowed 单元测试 =====

    #[test]
    fn test_is_target_allowed_app_data() {
        // /data/data/<pkg>/cache 在白名单内
        assert!(is_target_allowed("/data/data/com.foo/cache").is_ok());
        // 深层子路径也允许
        assert!(is_target_allowed("/data/data/com.foo/cache/sub/deep").is_ok());
        // /data/user/0/<pkg>/... 允许
        assert!(is_target_allowed("/data/user/0/com.foo/cache").is_ok());
        assert!(is_target_allowed("/data/user/10/com.foo/files/x").is_ok());
    }

    #[test]
    fn test_is_target_allowed_tarn_rules() {
        // /data/adb/tarn/rules 是 HARDCODED_ALLOW 例外, 允许清理
        assert!(is_target_allowed("/data/adb/tarn/rules/x").is_ok());
        assert!(is_target_allowed("/data/adb/tarn/rules/sub/y.toml").is_ok());
        // 但 /data/adb/tarn 自身被 HARDCODED_PROTECT 拒绝
        assert!(is_target_allowed("/data/adb/tarn").is_err());
        assert!(is_target_allowed("/data/adb/tarn/config").is_err());
        assert!(is_target_allowed("/data/adb/tarn/state.json").is_err());
        assert!(is_target_allowed("/data/adb/tarn/logs").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_system() {
        // /system 被硬编码保护拒绝
        assert!(is_target_allowed("/system").is_err());
        assert!(is_target_allowed("/system/bin/x").is_err());
        // /vendor /product /apex 同理
        assert!(is_target_allowed("/vendor").is_err());
        assert!(is_target_allowed("/product").is_err());
        assert!(is_target_allowed("/apex").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_data_adb() {
        // /data/adb 整个根被 HARDCODED_PROTECT 拒绝 (除 /data/adb/tarn/rules 例外)
        assert!(is_target_allowed("/data/adb").is_err());
        assert!(is_target_allowed("/data/adb/magisk").is_err());
        assert!(is_target_allowed("/data/adb/modules/x").is_err());
        assert!(is_target_allowed("/data/adb/tarn/config").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_relative() {
        // 相对路径必须拒绝
        assert!(is_target_allowed("relative/path").is_err());
        assert!(is_target_allowed("foo").is_err());
        assert!(is_target_allowed("").is_err());
    }

    #[test]
    fn test_is_target_allowed_blocked_etc() {
        // /etc 不在白名单也不在硬编码保护, 走白名单根检查拒绝
        assert!(is_target_allowed("/etc").is_err());
        assert!(is_target_allowed("/etc/passwd").is_err());
        // /proc /sys 同理
        assert!(is_target_allowed("/proc").is_err());
        assert!(is_target_allowed("/sys").is_err());
        // /data 自身不在白名单 (只有 /data/data /data/user 等子目录在)
        assert!(is_target_allowed("/data").is_err());
        assert!(is_target_allowed("/data/misc").is_err());
    }

    #[test]
    fn test_is_target_allowed_bypass_dotdot() {
        // 穿越尝试: /data/data/../adb → 规范化为 /data/adb → 命中 HARDCODED_PROTECT
        assert!(is_target_allowed("/data/data/../adb").is_err());
        // /data/user/0/com.foo/../../../adb → /data/adb
        assert!(is_target_allowed("/data/user/0/com.foo/../../../adb").is_err());
        // /sdcard/../adb → /adb (不在白名单)
        assert!(is_target_allowed("/sdcard/../adb").is_err());
        // /data/data/com.foo/../../system → /data/system (不在白名单)
        assert!(is_target_allowed("/data/data/com.foo/../../system").is_err());
    }

    #[test]
    fn test_is_target_allowed_sdcard() {
        // /sdcard 下非媒体目录允许 (应用缓存等)
        assert!(is_target_allowed("/sdcard/Android/data/com.foo/cache").is_ok());
        assert!(is_target_allowed("/sdcard/Android/obb/com.bar/main.obb.cache").is_ok());
        // /storage/emulated/0/... 非媒体目录允许
        assert!(is_target_allowed("/storage/emulated/0/Android/data/com.foo/cache").is_ok());
        // /storage/self/primary/... 非媒体目录允许
        assert!(is_target_allowed("/storage/self/primary/Android/data/com.foo/cache").is_ok());
        // /data/media/0/... 非媒体目录允许
        assert!(is_target_allowed("/data/media/0/Android/data/com.foo/cache").is_ok());
        assert!(is_target_allowed("/data/media/10/Android/data/com.foo/cache").is_ok());
        // 其他允许根
        assert!(is_target_allowed("/data/anr").is_ok());
        assert!(is_target_allowed("/data/local/tmp/x.tmp").is_ok());
        assert!(is_target_allowed("/data/tombstones").is_ok());
        assert!(is_target_allowed("/data/system/dropbox/x").is_ok());
    }

    #[test]
    fn test_is_user_media_path_function() {
        // /sdcard/<dir>/... 形式
        assert!(is_user_media_path("/sdcard/DCIM"));
        assert!(is_user_media_path("/sdcard/DCIM/Camera/IMG.jpg"));
        assert!(is_user_media_path("/sdcard/Pictures/Screenshot/x.png"));
        assert!(is_user_media_path("/sdcard/Music/song.mp3"));
        assert!(is_user_media_path("/sdcard/Movies/clip.mp4"));
        // Download 已移出内置保护, 不再被识别为用户媒体路径
        assert!(!is_user_media_path("/sdcard/Download/doc.pdf"));
        // /sdcard 下非媒体目录不保护
        assert!(!is_user_media_path("/sdcard/Android"));
        assert!(!is_user_media_path("/sdcard/Android/data/com.foo/cache/x.tmp"));
        assert!(!is_user_media_path("/sdcard"));
        // /storage/emulated/<id>/<dir>/... 形式 (支持多用户)
        assert!(is_user_media_path("/storage/emulated/0/DCIM/IMG.jpg"));
        assert!(is_user_media_path("/storage/emulated/10/Pictures/x.png"));
        assert!(!is_user_media_path("/storage/emulated/11/Download/doc.pdf"));
        assert!(!is_user_media_path("/storage/emulated/0/Android/data/com.foo/cache"));
        // /storage/self/primary/<dir>/... 形式
        assert!(is_user_media_path("/storage/self/primary/DCIM/IMG.jpg"));
        assert!(is_user_media_path("/storage/self/primary/Movies/clip.mp4"));
        assert!(!is_user_media_path("/storage/self/primary/Android"));
        // /data/media/<id>/<dir>/... 形式 (支持多用户)
        assert!(is_user_media_path("/data/media/0/DCIM/IMG.jpg"));
        assert!(is_user_media_path("/data/media/10/Music/song.mp3"));
        assert!(is_user_media_path("/data/media/11/Movies/clip.mp4"));
        assert!(!is_user_media_path("/data/media/0/Android/data/com.foo/cache"));
        // 非用户存储路径
        assert!(!is_user_media_path("/data/data/com.foo/cache/x.tmp"));
        assert!(!is_user_media_path("/data/anr/trace.txt"));
        assert!(!is_user_media_path("/system/bin/sh"));
    }

    #[test]
    fn test_user_media_symlink_bypass_protection() {
        // 用户媒体数据 (DCIM/Pictures/Music/Movies) 必须跨四种字面路径形式全部拒绝
        // Download 已移出内置保护, 允许规则清理 (下方断言验证放行)
        // —— 防止规则通过 /storage 或 /data/media 形式绕过 /sdcard/DCIM 的保护

        // /sdcard 形式
        assert!(is_target_allowed("/sdcard/DCIM/Camera/IMG.jpg").is_err());
        assert!(is_target_allowed("/sdcard/Pictures/Screenshot/x.png").is_err());
        assert!(is_target_allowed("/sdcard/Music/song.mp3").is_err());
        assert!(is_target_allowed("/sdcard/Movies/clip.mp4").is_err());
        assert!(is_target_allowed("/sdcard/Download/doc.pdf").is_ok()); // Download 不再保护

        // /storage/emulated/<id> 形式 (关键防绕过)
        assert!(is_target_allowed("/storage/emulated/0/DCIM/Camera/IMG.jpg").is_err());
        assert!(is_target_allowed("/storage/emulated/0/Pictures/Screenshot/x.png").is_err());
        assert!(is_target_allowed("/storage/emulated/10/Music/song.mp3").is_err());
        assert!(is_target_allowed("/storage/emulated/0/Movies/clip.mp4").is_err());
        assert!(is_target_allowed("/storage/emulated/0/Download/doc.pdf").is_ok()); // Download 不再保护

        // /storage/self/primary 形式
        assert!(is_target_allowed("/storage/self/primary/DCIM/Camera/IMG.jpg").is_err());
        assert!(is_target_allowed("/storage/self/primary/Pictures/x.png").is_err());

        // /data/media/<id> 形式
        assert!(is_target_allowed("/data/media/0/DCIM/Camera/IMG.jpg").is_err());
        assert!(is_target_allowed("/data/media/0/Pictures/Screenshot/x.png").is_err());
        assert!(is_target_allowed("/data/media/10/Music/song.mp3").is_err());
        assert!(is_target_allowed("/data/media/0/Movies/clip.mp4").is_err());
        assert!(is_target_allowed("/data/media/0/Download/doc.pdf").is_ok()); // Download 不再保护
    }

    #[test]
    fn test_protectset_runtime_user_media_block() {
        // 运行时兜底: ProtectSet::check 对用户媒体路径返回 blocked_user_media
        let wl = Whitelist::default(); // 空白名单, 仅硬编码保护
        let ps = ProtectSet::compile(&wl).expect("compile");

        // /sdcard 形式
        assert_eq!(
            ps.check(std::path::Path::new("/sdcard/DCIM/IMG.jpg"), None),
            Some("blocked_user_media")
        );
        // /storage/emulated/<id> 形式
        assert_eq!(
            ps.check(std::path::Path::new("/storage/emulated/0/Pictures/x.png"), None),
            Some("blocked_user_media")
        );
        // /data/media/<id> 形式
        assert_eq!(
            ps.check(std::path::Path::new("/data/media/0/Movies/clip.mp4"), None),
            Some("blocked_user_media")
        );
        // 非媒体目录不被此规则拦截 (走后续检查)
        assert_ne!(
            ps.check(std::path::Path::new("/data/anr/trace.txt"), None),
            Some("blocked_user_media")
        );
    }

    #[test]
    fn test_is_target_allowed_trailing_slash_and_collapse() {
        // 末尾 / 被规范化掉, 不影响判断
        assert!(is_target_allowed("/data/data/com.foo/cache/").is_ok());
        // 多余 / 被折叠
        assert!(is_target_allowed("/data//data//com.foo/cache").is_ok());
        // 末尾 / 后接被拒绝路径仍要拒
        assert!(is_target_allowed("/system/").is_err());
    }

    #[test]
    fn test_allowed_roots_no_substring_bypass() {
        // 关键: /data/datacom.foo 不是 /data/data 子路径 (字符串前缀但非路径组件)
        // path_in_prefix 严格路径组件匹配, 不应被误放行
        assert!(is_target_allowed("/data/datacom.foo").is_err());
        // /data/databar 同理
        assert!(is_target_allowed("/data/databar/x").is_err());
        // /data/adb/tarn/rules_evil 不是 /data/adb/tarn/rules 子路径
        // 它命中 HARDCODED_PROTECT 的 /data/adb/tarn 但不在 HARDCODED_ALLOW → 拒绝
        assert!(is_target_allowed("/data/adb/tarn/rules_evil").is_err());
    }

    /// 复现用户实测场景: whitelist protect_path=/sdcard/Download + blacklist target=/storage/emulated/0/Download/
    /// 验证 protect_path 经 expand_sdcard_aliases 归一化后, 能跨 4 种路径形式全方位保护。
    #[test]
    fn test_user_scenario_protect_sdcard_download_vs_blacklist_storage_emulated() {
        // 用户 whitelist: [[protect_path]] path = "/sdcard/Download"
        let mut wl = Whitelist::default();
        wl.protect.push(ProtectPath {
            id: "user_download".to_string(),
            path: "/sdcard/Download".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");

        // walker 产出文件路径 (默认 follow_symlink=false, 路径形式跟随 blacklist target 写法)
        // 4 种路径形式 × 多用户, 全部应被 protect_path 拦截 (归一化后 prefix 集合覆盖全部形式)
        let cases = [
            // (路径形式, 描述)
            ("/sdcard/Download/report.pdf", "/sdcard 形式 (与 protect_path 同形式)"),
            ("/storage/emulated/0/Download/report.pdf", "/storage/emulated/0 形式 (主用户, 关键防绕过)"),
            ("/storage/emulated/10/Download/report.pdf", "/storage/emulated/10 形式 (副用户)"),
            ("/storage/self/primary/Download/report.pdf", "/storage/self/primary 形式"),
            ("/data/media/0/Download/report.pdf", "/data/media/0 形式 (底层真实路径)"),
            ("/data/media/10/Download/report.pdf", "/data/media/10 形式 (副用户底层)"),
        ];

        for (path, desc) in &cases {
            let blocked = ps.check(std::path::Path::new(path), None);
            println!("[运行时门] {:50} → {:?}", path, blocked);
            assert_eq!(
                blocked,
                Some("blocked_prefix"),
                "【{}】应被拦截, 但返回 {:?} (路径别名绕过!)",
                desc,
                blocked
            );
        }

        // 反向验证: 非保护目录 (如 /sdcard/Android/data/...) 不被误伤
        let non_protected = ps.check(std::path::Path::new("/sdcard/Android/data/com.foo/cache/x.tmp"), None);
        println!("[反向验证] /sdcard/Android/data/... → {:?}", non_protected);
        assert_eq!(non_protected, None, "非保护目录不应被误拦");

        // 深层子路径也要保护 (protect_path=/sdcard/Download 应覆盖 /sdcard/Download/sub/deep/...)
        let deep = ps.check(std::path::Path::new("/storage/emulated/0/Download/installer/apk/v1.apk"), None);
        assert_eq!(deep, Some("blocked_prefix"), "深层子路径应被保护");
    }

    /// expand_sdcard_aliases 单元测试: 验证 4 种形式的识别与展开
    #[test]
    fn test_expand_sdcard_aliases() {
        // 形式 1: /sdcard/Download → 展开 6 种 (sdcard + emulated/0 + emulated/10 + self/primary + data/media/0 + data/media/10)
        let r1 = expand_sdcard_aliases("/sdcard/Download");
        assert!(r1.contains(&"/sdcard/Download".to_string()), "含 /sdcard 形式");
        assert!(r1.contains(&"/storage/emulated/0/Download".to_string()), "含 emulated/0");
        assert!(r1.contains(&"/storage/emulated/10/Download".to_string()), "含 emulated/10");
        assert!(r1.contains(&"/storage/self/primary/Download".to_string()), "含 self/primary");
        assert!(r1.contains(&"/data/media/0/Download".to_string()), "含 data/media/0");
        assert!(r1.contains(&"/data/media/10/Download".to_string()), "含 data/media/10");
        println!("/sdcard/Download → {:?}", r1);

        // 形式 2: /storage/emulated/0/Download → 保留 user 0, 展开 4 种 (emulated 形式去重)
        let r2 = expand_sdcard_aliases("/storage/emulated/0/Download");
        assert!(r2.contains(&"/sdcard/Download".to_string()));
        assert!(r2.contains(&"/storage/emulated/0/Download".to_string()));
        assert!(r2.contains(&"/storage/self/primary/Download".to_string()));
        assert!(r2.contains(&"/data/media/0/Download".to_string()));
        // 输入是 user 0, 不应展开 user 10
        assert!(!r2.contains(&"/storage/emulated/10/Download".to_string()), "输入含 user 0, 不展开 10");
        println!("/storage/emulated/0/Download → {:?}", r2);

        // 形式 3: /storage/self/primary/Download → 等价 user 0
        let r3 = expand_sdcard_aliases("/storage/self/primary/Download");
        assert!(r3.contains(&"/sdcard/Download".to_string()));
        assert!(r3.contains(&"/storage/emulated/0/Download".to_string()));
        assert!(r3.contains(&"/data/media/0/Download".to_string()));
        println!("/storage/self/primary/Download → {:?}", r3);

        // 形式 4: /data/media/0/Download → 保留 user 0
        let r4 = expand_sdcard_aliases("/data/media/0/Download");
        assert!(r4.contains(&"/sdcard/Download".to_string()));
        assert!(r4.contains(&"/storage/emulated/0/Download".to_string()));
        assert!(r4.contains(&"/data/media/0/Download".to_string()));
        println!("/data/media/0/Download → {:?}", r4);

        // 深层子路径: /sdcard/Download/sub/deep
        let r5 = expand_sdcard_aliases("/sdcard/Download/sub/deep");
        assert!(r5.contains(&"/sdcard/Download/sub/deep".to_string()));
        assert!(r5.contains(&"/storage/emulated/0/Download/sub/deep".to_string()));
        assert!(r5.contains(&"/data/media/0/Download/sub/deep".to_string()));
        println!("/sdcard/Download/sub/deep → {:?}", r5);

        // 非 sdcard 路径: 原样返回
        let r6 = expand_sdcard_aliases("/data/data/com.foo/cache");
        assert_eq!(r6, vec!["/data/data/com.foo/cache".to_string()], "非 sdcard 路径原样返回");
        println!("/data/data/com.foo/cache → {:?}", r6);

        // 副用户 id (如 11)
        let r7 = expand_sdcard_aliases("/storage/emulated/11/Download");
        assert!(r7.contains(&"/storage/emulated/11/Download".to_string()));
        assert!(r7.contains(&"/data/media/11/Download".to_string()));
        assert!(!r7.contains(&"/storage/emulated/0/Download".to_string()), "user 11 不应展开 0");
        println!("/storage/emulated/11/Download → {:?}", r7);
    }

    /// 反向场景: 用户 protect_path 配 /storage/emulated/0/Download, blacklist 用 /sdcard/Download
    /// 验证反向也能防绕过 (双向保护)
    #[test]
    fn test_protect_path_reverse_form_protection() {
        let mut wl = Whitelist::default();
        wl.protect.push(ProtectPath {
            id: "rev".to_string(),
            path: "/storage/emulated/0/Download".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");

        // blacklist 换 /sdcard 形式 → 应被拦截
        let blocked = ps.check(std::path::Path::new("/sdcard/Download/file.txt"), None);
        assert_eq!(blocked, Some("blocked_prefix"), "反向: protect emulated/0, blacklist /sdcard 应拦截");
        // blacklist 换 /data/media/0 形式 → 应被拦截
        let blocked2 = ps.check(std::path::Path::new("/data/media/0/Download/file.txt"), None);
        assert_eq!(blocked2, Some("blocked_prefix"), "反向: protect emulated/0, blacklist data/media/0 应拦截");
    }

    /// glob 类 protect_path 跨路径形式归一化测试 (v0.5.9 修复的残留 bug)
    ///
    /// 用户配 protect_path = "/sdcard/Download/*.pdf" (通配符), blacklist 用 /storage/emulated/0/Download/secret.pdf
    /// 修复前: glob 分支未调用 expand_sdcard_aliases → /storage/emulated/0 形式绕过保护 (会被清理!)
    /// 修复后: glob 分支也展开 4 种形式, 全部拦截
    #[test]
    fn test_protect_glob_path_sdcard_alias_normalization() {
        let mut wl = Whitelist::default();
        wl.protect.push(ProtectPath {
            id: "pdf_in_download".to_string(),
            path: "/sdcard/Download/*.pdf".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");

        // 4 种路径形式 × 多用户, *.pdf 全部应被拦截 (关键防绕过)
        let cases = [
            "/sdcard/Download/report.pdf",
            "/storage/emulated/0/Download/report.pdf",
            "/storage/emulated/10/Download/report.pdf",
            "/storage/self/primary/Download/report.pdf",
            "/data/media/0/Download/report.pdf",
            "/data/media/10/Download/report.pdf",
        ];
        for path in &cases {
            let blocked = ps.check(std::path::Path::new(path), None);
            assert_eq!(
                blocked,
                Some("blocked_glob"),
                "glob 类 protect_path 应跨形式拦截 {}: 实际 {:?} (残留别名绕过 bug!)",
                path,
                blocked
            );
        }

        // 反向: 非保护后缀 (*.txt) 不应被误拦
        let not_blocked = ps.check(std::path::Path::new("/sdcard/Download/notes.txt"), None);
        assert_eq!(not_blocked, None, "非 *.pdf 文件不应被保护");

        // literal_separator(true): * 不跨 /, /sdcard/Download/sub/secret.pdf 不应被 *.pdf 匹配
        // (用户若想保护子目录, 应写 /sdcard/Download/**/*.pdf)
        let deep = ps.check(std::path::Path::new("/sdcard/Download/sub/secret.pdf"), None);
        assert_eq!(
            deep, None,
            "literal_separator: *.pdf 不跨 /, 深层子目录文件不应被 /sdcard/Download/*.pdf 匹配"
        );

        // ** 跨 / 形式: 用户显式写 **/*.pdf 应保护所有层级
        let mut wl2 = Whitelist::default();
        wl2.protect.push(ProtectPath {
            id: "pdf_recursive".to_string(),
            path: "/sdcard/Download/**/*.pdf".to_string(),
        });
        let ps2 = ProtectSet::compile(&wl2).expect("compile");
        assert_eq!(
            ps2.check(std::path::Path::new("/storage/emulated/0/Download/sub/deep/x.pdf"), None),
            Some("blocked_glob"),
            "** 跨 / 且跨形式: /storage/emulated/0/Download/sub/deep/x.pdf 应被保护"
        );
    }

    /// glob 类 protect_path 反向形式保护 (双向)
    #[test]
    fn test_protect_glob_path_reverse_form() {
        let mut wl = Whitelist::default();
        wl.protect.push(ProtectPath {
            id: "rev_glob".to_string(),
            path: "/storage/emulated/0/Download/*.log".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");

        // blacklist 换 /sdcard 形式 → 应被拦截
        let b1 = ps.check(std::path::Path::new("/sdcard/Download/app.log"), None);
        assert_eq!(b1, Some("blocked_glob"), "反向 glob: protect emulated/0, blacklist /sdcard 应拦截");
        // blacklist 换 /data/media/0 形式 → 应被拦截
        let b2 = ps.check(std::path::Path::new("/data/media/0/Download/app.log"), None);
        assert_eq!(b2, Some("blocked_glob"), "反向 glob: protect emulated/0, blacklist data/media/0 应拦截");
        // /storage/self/primary 形式 → 应被拦截
        let b3 = ps.check(std::path::Path::new("/storage/self/primary/Download/app.log"), None);
        assert_eq!(b3, Some("blocked_glob"), "反向 glob: blacklist self/primary 应拦截");
        // 副用户 emulated/10 → protect 显式写了 user 0, 不展开 10, 但反向 /sdcard 形式已覆盖主用户
        // (protect emulated/0 仅保护 user 0, 这是正确语义 — 用户没说要保护副用户)
        let b4 = ps.check(std::path::Path::new("/storage/emulated/10/Download/app.log"), None);
        assert_eq!(b4, None, "protect 显式 user 0, 不保护 user 10 (正确语义)");
    }

    /// glob 语义一致性: protect 侧 * 不跨 / (与 matcher 清理侧 literal_separator(true) 一致)
    /// 防止用户在 WebUI 看到 include *cache 不跨 / 却看到 protect *cache 跨 / 产生困惑
    #[test]
    fn test_protect_glob_literal_separator_consistency() {
        let mut wl = Whitelist::default();
        // *cache 保护: 只匹配单段名字含 cache 的路径, 不跨 /
        wl.protect.push(ProtectPath {
            id: "cache_glob".to_string(),
            path: "/data/data/*cache".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");

        // *cache 匹配 cache 目录本身 (单段名字)
        assert_eq!(
            ps.check(std::path::Path::new("/data/data/cache"), None),
            Some("blocked_glob")
        );
        assert_eq!(
            ps.check(std::path::Path::new("/data/data/com.foo.cache"), None),
            Some("blocked_glob")
        );
        // *cache 严格不匹配目录里面的文件 (literal_separator)
        assert_eq!(
            ps.check(std::path::Path::new("/data/data/cache/foo.txt"), None),
            None,
            "*cache 不跨 /, 不匹配 cache/foo.txt"
        );
        // 不跨 / (com.foo/cache 不被 *cache 匹配)
        assert_eq!(
            ps.check(std::path::Path::new("/data/data/com.foo/cache"), None),
            None,
            "*cache 不跨 /, 不匹配 com.foo/cache"
        );
    }

    /// ProtectExt scope 跨路径形式归一化测试 (v0.5.9 修复的残留 bug)
    ///
    /// 用户配 protect_ext extensions=["pdf"] scope="/sdcard/Download"
    /// blacklist 用 /storage/emulated/0/Download/secret.pdf 形式
    /// 修复前: scope 未调用 expand_sdcard_aliases → path_in_prefix 字面匹配失败 → PDF 被清理 (保护绕过!)
    /// 修复后: scope 展开为 4 种形式, 任一命中即保护
    #[test]
    fn test_protect_ext_scope_sdcard_alias_normalization() {
        use crate::config::{ProtectExt, Whitelist as Wl};
        let mut wl = Wl::default();
        wl.protect_ext.push(ProtectExt {
            extensions: vec!["pdf".to_string()],
            scope: "/sdcard/Download".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");

        // 4 种路径形式 × 多用户, PDF 全部应被拦截 (关键防绕过)
        let cases = [
            "/sdcard/Download/report.pdf",
            "/storage/emulated/0/Download/report.pdf",
            "/storage/emulated/10/Download/report.pdf",
            "/storage/self/primary/Download/report.pdf",
            "/data/media/0/Download/report.pdf",
            "/data/media/10/Download/report.pdf",
        ];
        for path in &cases {
            let blocked = ps.check(std::path::Path::new(path), None);
            assert_eq!(
                blocked,
                Some("blocked_ext"),
                "ProtectExt scope 应跨形式拦截 {}: 实际 {:?} (scope 别名绕过 bug!)",
                path,
                blocked
            );
        }

        // 反向: scope 外的 PDF 不应被保护
        let outside = ps.check(std::path::Path::new("/sdcard/Android/data/com.foo/x.pdf"), None);
        assert_eq!(outside, None, "scope 外的 PDF 不应被保护");

        // 反向: scope 内的非 PDF 不应被保护 (ext 不匹配)
        let non_pdf = ps.check(std::path::Path::new("/sdcard/Download/notes.txt"), None);
        assert_eq!(non_pdf, None, "scope 内的非 PDF 不应被保护");

        // 反向形式: protect_ext scope 配 /storage/emulated/0/Download, blacklist 用 /sdcard 形式
        let mut wl2 = Wl::default();
        wl2.protect_ext.push(ProtectExt {
            extensions: vec!["log".to_string()],
            scope: "/storage/emulated/0/Download".to_string(),
        });
        let ps2 = ProtectSet::compile(&wl2).expect("compile");
        assert_eq!(
            ps2.check(std::path::Path::new("/sdcard/Download/app.log"), None),
            Some("blocked_ext"),
            "反向: protect scope emulated/0, blacklist /sdcard 应拦截"
        );
        assert_eq!(
            ps2.check(std::path::Path::new("/data/media/0/Download/app.log"), None),
            Some("blocked_ext"),
            "反向: protect scope emulated/0, blacklist data/media/0 应拦截"
        );
    }

    /// ProtectExt scope=global (全局) 不受归一化影响, 仍按扩展名全局保护
    #[test]
    fn test_protect_ext_scope_global_unchanged() {
        use crate::config::{ProtectExt, Whitelist as Wl};
        let mut wl = Wl::default();
        wl.protect_ext.push(ProtectExt {
            extensions: vec!["db".to_string()],
            scope: "global".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");
        // 全局: 任意路径的 .db 都保护
        assert_eq!(
            ps.check(std::path::Path::new("/data/data/com.foo/databases/x.db"), None),
            Some("blocked_ext")
        );
        assert_eq!(
            ps.check(std::path::Path::new("/sdcard/Android/data/com.bar/y.db"), None),
            Some("blocked_ext")
        );
        // 非 .db 不保护
        assert_eq!(
            ps.check(std::path::Path::new("/data/data/com.foo/databases/x.txt"), None),
            None
        );
    }

    /// ProtectMtime scope 跨路径形式归一化测试 (v0.5.9 修复的残留 bug)
    ///
    /// 用户配 protect_mtime within_days=7 scope="/sdcard/Download"
    /// blacklist 用 /storage/emulated/0/Download/recent.pdf 形式 (mtime=现在, 7天内)
    /// 修复前: scope 未归一化 → 7天内文件被清理 (保护绕过!)
    /// 修复后: scope 展开为 4 种形式, 7天内文件跨形式保护
    #[test]
    fn test_protect_mtime_scope_sdcard_alias_normalization() {
        use crate::config::{ProtectMtime, Whitelist as Wl};
        let mut wl = Wl::default();
        wl.protect_mtime.push(ProtectMtime {
            within_days: 7,
            scope: "/sdcard/Download".to_string(),
        });
        let ps = ProtectSet::compile(&wl).expect("compile");

        // 现在 (7天内) 的文件, 4 种路径形式全部应被拦截
        let now = Some(SystemTime::now());
        let cases = [
            "/sdcard/Download/recent.pdf",
            "/storage/emulated/0/Download/recent.pdf",
            "/storage/self/primary/Download/recent.pdf",
            "/data/media/0/Download/recent.pdf",
        ];
        for path in &cases {
            let blocked = ps.check(std::path::Path::new(path), now);
            assert_eq!(
                blocked,
                Some("blocked_mtime"),
                "ProtectMtime scope 应跨形式拦截 7天内文件 {}: 实际 {:?}",
                path,
                blocked
            );
        }

        // scope 外的 7天内文件不应被保护
        let outside = ps.check(std::path::Path::new("/sdcard/Android/data/com.foo/recent.txt"), now);
        assert_eq!(outside, None, "scope 外的 7天内文件不应被保护");

        // 30天前的文件 (超出 7天保护期) 不应被保护, 即便在 scope 内
        let old = SystemTime::now() - std::time::Duration::from_secs(30 * 86400);
        let old_file = ps.check(std::path::Path::new("/sdcard/Download/old.pdf"), Some(old));
        assert_eq!(old_file, None, "30天前文件超出 7天保护期, 不应被保护");
    }
}
