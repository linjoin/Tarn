#!/system/bin/sh
# Tarn 诊断快照脚本 v2
#
# v2 改进 (相对 v1):
#   - 新增 SELinux avc denial 审计 (dmesg + logcat), Android root 故障头号元凶
#   - 新增 fd 上限 / oom_score_adj / inode 使用 检测
#   - 新增 WebUI TCP 端口监听检测 (读 /proc/$PID/net/tcp)
#   - 新增二进制可执行性深度检测 (arch 匹配 + 动态库依赖)
#   - 新增启动链路检测 (模块 disable/remove/update 标志)
#   - 新增 socket 连通性测试 (实际 connect, 非仅 ls)
#   - 新增 Root 框架明确识别 (KSU/APatch/Magisk 给结论)
#   - state.json 瘦身 (只取关键字段 + tail, 不再全文 dump 1776 行)
#   - mount 输出降噪 (只取关键挂载点)
#   - 新增诊断摘要 (末尾汇总各子系统状态)
#   - 每项检测标注 [OK]/[WARN]/[FAIL], 一目了然

MODDIR=${0%/*}
DATADIR=/data/adb/tarn
BIN="$MODDIR/tarn"
LOGDIR="$DATADIR/logs"
TS=$(date '+%Y%m%d_%H%M%S' 2>/dev/null)
OUT="$LOGDIR/debug-${TS}.txt"

# ============================================================
# 工具函数
# ============================================================

detect_bb() {
  for cand in \
    /data/adb/ksu/bin/busybox \
    /data/adb/ap/bin/busybox \
    /data/adb/magisk/busybox \
    /system/bin/busybox \
    /system/xbin/busybox; do
    [ -x "$cand" ] && { echo "$cand"; return 0; }
  done
  command -v busybox 2>/dev/null && return 0
  echo ""
  return 1
}

BB=$(detect_bb)
bb_wrap() {
  cmd=$1
  shift
  if [ -n "$BB" ]; then
    "$BB" "$cmd" "$@"
  else
    "$cmd" "$@"
  fi
}

mkdir -p "$LOGDIR" 2>/dev/null

# 状态标注: $1=OK|WARN|FAIL|INFO, $2=消息
mark() {
  echo "[$1] $2" >> "$OUT" 2>/dev/null
}

section() {
  echo "" >> "$OUT" 2>/dev/null
  echo "========================================================" >> "$OUT" 2>/dev/null
  echo "  $1" >> "$OUT" 2>/dev/null
  echo "========================================================" >> "$OUT" 2>/dev/null
}

run_cmd() {
  echo "$ $*" >> "$OUT" 2>/dev/null
  "$@" >> "$OUT" 2>&1
  echo "" >> "$OUT" 2>/dev/null
}

run_sh() {
  echo "$ $1" >> "$OUT" 2>/dev/null
  sh -c "$1" >> "$OUT" 2>&1
  echo "" >> "$OUT" 2>/dev/null
}

dump_file() {
  _f=$1
  _label=${2:-$_f}
  echo "--- $_label ---" >> "$OUT" 2>/dev/null
  if [ -f "$_f" ]; then
    cat "$_f" >> "$OUT" 2>/dev/null
  else
    echo "(文件不存在: $_f)" >> "$OUT" 2>/dev/null
  fi
  echo "" >> "$OUT" 2>/dev/null
  unset _f _label
}

dump_file_tail() {
  _f=$1
  _n=${2:-200}
  _label=${3:-$_f}
  echo "--- $_label (tail $_n) ---" >> "$OUT" 2>/dev/null
  if [ -f "$_f" ]; then
    bb_wrap tail -n "$_n" "$_f" >> "$OUT" 2>/dev/null
  else
    echo "(文件不存在: $_f)" >> "$OUT" 2>/dev/null
  fi
  echo "" >> "$OUT" 2>/dev/null
  unset _f _n _label
}

# 从 settings.toml 提取字段值 (简单 grep, 不依赖 toml 解析器)
# $1=字段名 $2=默认值
get_setting() {
  _key=$1
  _def=$2
  if [ -f "$DATADIR/config/settings.toml" ]; then
    _v=$(bb_wrap grep -E "^[[:space:]]*${_key}[[:space:]]*=" "$DATADIR/config/settings.toml" 2>/dev/null | head -n 1 | bb_wrap sed -E "s/.*=[[:space:]]*\"?([^\"#[:space:]]+).*/\1/" | tr -d '[:space:]')
    [ -n "$_v" ] && { echo "$_v"; unset _key _def _v; return; }
  fi
  echo "$_def"
  unset _key _def _v
}

# 诊断摘要收集 (末尾输出)
SUMMARY=""
add_summary() {
  SUMMARY="${SUMMARY}$1"$'\n'
}

# ============================================================
# 头部
# ============================================================
{
  echo "========================================================"
  echo "  Tarn 诊断快照 v2"
  echo "  生成时间: $(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
  echo "  模块目录: $MODDIR"
  echo "  数据目录: $DATADIR"
  echo "  busybox:  ${BB:-(未找到, 部分检测将降级)}"
  echo "========================================================"
} > "$OUT" 2>/dev/null

# ============================================================
# 1. 版本与模块信息
# ============================================================
section "1. 版本与模块信息"
if [ -x "$BIN" ]; then
  run_cmd "$BIN" version
  add_summary "[OK] 二进制可执行, version 命令正常"
else
  mark FAIL "二进制不可执行: $BIN (arch 不匹配? 权限? 缺依赖?)"
  add_summary "[FAIL] 二进制不可执行: $BIN"
fi
dump_file "$MODDIR/module.prop" "module.prop"

# 模块状态标志检测 (Magisk/KSU 框架级)
echo "--- 模块状态标志 ---" >> "$OUT" 2>/dev/null
for flag in disable remove skip_mount; do
  if [ -f "$MODDIR/$flag" ]; then
    mark WARN "检测到 $flag 标志 (模块被框架标记: $flag)"
    add_summary "[WARN] 模块带 $flag 标志"
  fi
done
# 待更新检测
if [ -d "/data/adb/modules_update/tarn" ]; then
  mark WARN "检测到 /data/adb/modules_update/tarn (模块待更新, 下次重启替换)"
  add_summary "[WARN] 模块有待更新版本"
fi
if [ ! -f "$MODDIR/disable" ] && [ ! -f "$MODDIR/remove" ]; then
  mark OK "无 disable/remove 标志, 模块处于启用状态"
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 2. 进程信息
# ============================================================
section "2. 进程信息"
PIDFILE="$DATADIR/run/tarn.pid"
DPID=""
if [ -f "$PIDFILE" ]; then
  DPID=$(cat "$PIDFILE" 2>/dev/null | tr -d '[:space:]')
  echo "pidfile 内容: $DPID" >> "$OUT" 2>/dev/null
  if [ -n "$DPID" ] && [ "$DPID" -gt 0 ] 2>/dev/null; then
    if kill -0 "$DPID" 2>/dev/null; then
      mark OK "daemon 进程存活 (pid=$DPID)"
      add_summary "[OK] daemon 运行中 (pid=$DPID)"
      dump_file "/proc/$DPID/status" "/proc/$DPID/status"
      dump_file "/proc/$DPID/cmdline" "/proc/$DPID/cmdline"
      run_sh "ls -la /proc/$DPID/fd/ 2>/dev/null"

      # 进程级资源约束 (v2 新增)
      echo "--- 进程资源约束 ---" >> "$OUT" 2>/dev/null
      echo "$ cat /proc/$DPID/limits" >> "$OUT" 2>/dev/null
      if [ -r "/proc/$DPID/limits" ]; then
        bb_wrap grep -E 'Max open files|Max processes|Max file size' "/proc/$DPID/limits" >> "$OUT" 2>/dev/null
      else
        echo "(不可读: /proc/$DPID/limits)" >> "$OUT" 2>/dev/null
      fi
      echo "" >> "$OUT" 2>/dev/null

      # oom_score_adj (Android lmkd 杀后台进程是高频问题)
      echo "$ cat /proc/$DPID/oom_score_adj" >> "$OUT" 2>/dev/null
      OOM_ADJ=""
      if [ -r "/proc/$DPID/oom_score_adj" ]; then
        OOM_ADJ=$(cat "/proc/$DPID/oom_score_adj" 2>/dev/null | tr -d '[:space:]')
        echo "$OOM_ADJ" >> "$OUT" 2>/dev/null
        if [ -n "$OOM_ADJ" ]; then
          if [ "$OOM_ADJ" -ge 900 ] 2>/dev/null; then
            mark WARN "oom_score_adj=$OOM_ADJ (>=900, 易被 lmkd 在低内存时杀死)"
            add_summary "[WARN] oom_score_adj=$OOM_ADJ 偏高, 易被 lmkd 杀"
          else
            mark OK "oom_score_adj=$OOM_ADJ"
          fi
        fi
      else
        echo "(不可读)" >> "$OUT" 2>/dev/null
      fi
      echo "" >> "$OUT" 2>/dev/null

      # 实际加载的动态库 (从 /proc/maps 提取, 不依赖 ldd)
      echo "--- 已加载动态库 (去重, 从 /proc/$DPID/maps) ---" >> "$OUT" 2>/dev/null
      if [ -r "/proc/$DPID/maps" ]; then
        bb_wrap grep -oE '/system/[^ ]+\.so|/apex/[^ ]+\.so|/data/[^ ]+\.so' "/proc/$DPID/maps" 2>/dev/null | sort -u >> "$OUT" 2>/dev/null
        SO_COUNT=$(bb_wrap grep -coE '\.so' "/proc/$DPID/maps" 2>/dev/null | tr -d '[:space:]')
        mark INFO "已加载 .so 数量(粗略): ${SO_COUNT:-0}"
      else
        mark WARN "/proc/$DPID/maps 不可读"
      fi
      echo "" >> "$OUT" 2>/dev/null
    else
      mark FAIL "pidfile 指向的进程 $DPID 已不存活 (孤儿 pidfile, daemon 可能已崩溃)"
      add_summary "[FAIL] daemon 进程已死 (孤儿 pidfile pid=$DPID)"
    fi
  else
    mark FAIL "pidfile 内容无效: '$DPID'"
    add_summary "[FAIL] pidfile 内容无效"
  fi
else
  mark WARN "pidfile 不存在 (daemon 未运行或未正确初始化)"
  add_summary "[WARN] daemon 未运行 (无 pidfile)"
fi

echo "" >> "$OUT" 2>/dev/null
echo "--- ps (tarn 相关) ---" >> "$OUT" 2>/dev/null
if [ -n "$BB" ]; then
  "$BB" ps 2>/dev/null | bb_wrap grep -E '[t]arn' >> "$OUT" 2>/dev/null
else
  ps -A -o pid,ppid,cmd 2>/dev/null | bb_wrap grep -E '[t]arn' >> "$OUT" 2>/dev/null
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 3. 日志文件
# ============================================================
section "3. 日志文件"
dump_file "$DATADIR/logs/boot.log" "boot.log (完整)"
dump_file_tail "$DATADIR/logs/tarn.log" 300 "tarn.log (tail 300)"

# 日志错误高亮 (v2 新增)
echo "--- 日志中的错误/警告关键词 (tarn.log 最近 500 行) ---" >> "$OUT" 2>/dev/null
if [ -f "$DATADIR/logs/tarn.log" ]; then
  ERR_CNT=$(bb_wrap tail -n 500 "$DATADIR/logs/tarn.log" 2>/dev/null | bb_wrap grep -ciE 'error|panic|fatal|fail|denied' 2>/dev/null | tr -d '[:space:]')
  if [ "${ERR_CNT:-0}" -gt 0 ]; then
    mark WARN "tarn.log 最近 500 行含 ${ERR_CNT} 处错误/警告关键词"
    bb_wrap tail -n 500 "$DATADIR/logs/tarn.log" 2>/dev/null | bb_wrap grep -iE 'error|panic|fatal|fail|denied' 2>/dev/null | bb_wrap tail -n 20 >> "$OUT" 2>/dev/null
    add_summary "[WARN] 日志含 ${ERR_CNT} 处错误关键词"
  else
    mark OK "tarn.log 最近 500 行无错误关键词"
  fi
else
  mark WARN "tarn.log 不存在"
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 4. 配置文件
# ============================================================
section "4. 配置文件"
dump_file "$DATADIR/config/settings.toml" "settings.toml"
dump_file "$DATADIR/config/blacklist.toml" "blacklist.toml"
dump_file "$DATADIR/config/whitelist.toml" "whitelist.toml"

# toml 语法初校验 (v2 新增, 只查明显的括号/引号不匹配)
echo "--- 配置语法初校验 ---" >> "$OUT" 2>/dev/null
for cfg in settings blacklist whitelist; do
  CFGF="$DATADIR/config/${cfg}.toml"
  if [ -f "$CFGF" ]; then
    SECTIONS=$(bb_wrap grep -cE '^\[' "$CFGF" 2>/dev/null | tr -d '[:space:]')
    mark INFO "${cfg}.toml: ${SECTIONS:-0} 个 [section]"
  fi
done
echo "" >> "$OUT" 2>/dev/null

echo "--- rules/ 目录列表 ---" >> "$OUT" 2>/dev/null
if [ -d "$DATADIR/rules" ]; then
  ls -la "$DATADIR/rules/" >> "$OUT" 2>/dev/null
  RULE_CNT=0
  for rf in "$DATADIR/rules"/*.toml; do
    [ -f "$rf" ] || continue
    RULE_CNT=$((RULE_CNT + 1))
    dump_file "$rf" "rules/$(basename "$rf")"
  done
  mark INFO "规则文件数: $RULE_CNT"
  add_summary "[INFO] 加载 $RULE_CNT 个规则文件"
else
  mark WARN "rules/ 目录不存在 (无清理规则, daemon 空跑)"
  add_summary "[WARN] 无 rules 目录"
fi

# ============================================================
# 5. 状态与运行时 (state.json 瘦身)
# ============================================================
section "5. 状态与运行时 (state.json 关键字段)"
STATE="$DATADIR/state.json"
if [ -f "$STATE" ]; then
  STATE_LINES=$(wc -l < "$STATE" 2>/dev/null | tr -d '[:space:]')
  STATE_BYTES=$(wc -c < "$STATE" 2>/dev/null | tr -d '[:space:]')
  mark INFO "state.json: ${STATE_LINES} 行 / ${STATE_BYTES} 字节"

  echo "--- 关键字段提取 ---" >> "$OUT" 2>/dev/null
  # 提取关键字段 (避免全文 dump 淹没诊断)
  for key in '"version"' '"pid"' '"total_files_deleted"' '"total_freed_bytes"' '"last_run_at"' '"last_run_files"' '"last_run_bytes"' '"boot_failures"' '"schedule_enabled"'; do
    bb_wrap grep -E "${key}[[:space:]]*:" "$STATE" 2>/dev/null | head -n 1 >> "$OUT" 2>/dev/null
  done
  echo "" >> "$OUT" 2>/dev/null

  # rotation_history 只看数量, 不 dump 内容
  ROT_CNT=$(bb_wrap grep -cE '"rotation_history"' "$STATE" 2>/dev/null | tr -d '[:space:]')
  if [ "${ROT_CNT:-0}" -gt 0 ]; then
    mark INFO "rotation_history 存在 (累计统计已轮转过)"
  fi

  # 尾部 50 行兜底 (防关键字段名变化)
  dump_file_tail "$STATE" 50 "state.json (tail 50, 兜底)"
else
  mark WARN "state.json 不存在 (daemon 未初始化或首次运行)"
fi

echo "" >> "$OUT" 2>/dev/null
echo "--- run/ 目录列表 ---" >> "$OUT" 2>/dev/null
ls -la "$DATADIR/run/" >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 6. 数据目录结构
# ============================================================
section "6. 数据目录结构"
run_sh "ls -laR $DATADIR/ 2>/dev/null | head -200"

# ============================================================
# 7. 系统信息
# ============================================================
section "7. 系统信息"
run_cmd uname -a
run_sh "uptime 2>/dev/null"
run_sh "cat /proc/loadavg 2>/dev/null"
echo "--- /proc/meminfo ---" >> "$OUT" 2>/dev/null
bb_wrap head -n 15 /proc/meminfo >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null
echo "--- /proc/cpuinfo (前 30 行) ---" >> "$OUT" 2>/dev/null
bb_wrap head -n 30 /proc/cpuinfo >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null

# shell 资源限制 (v2 新增)
echo "--- shell 资源限制 (ulimit) ---" >> "$OUT" 2>/dev/null
echo "$ ulimit -n (open files)" >> "$OUT" 2>/dev/null
ulimit -n 2>/dev/null >> "$OUT" 2>/dev/null
echo "$ ulimit -u (max user processes)" >> "$OUT" 2>/dev/null
ulimit -u 2>/dev/null >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 8. Android 属性
# ============================================================
section "8. Android 属性"
for prop in \
  ro.build.version.release \
  ro.build.version.sdk \
  ro.build.version.incremental \
  ro.product.model \
  ro.product.brand \
  ro.product.manufacturer \
  ro.product.cpu.abi \
  ro.product.cpu.abilist \
  ro.hardware \
  ro.boot.slot_suffix \
  ro.boot.verifiedbootstate \
  ro.boot.flash.locked \
  ro.boot.vbmeta.device_state; do
  run_sh "getprop $prop 2>/dev/null"
done

# ============================================================
# 9. Root 管理器检测 (明确识别, v2 增强)
# ============================================================
section "9. Root 管理器检测 (框架识别)"
ROOT_MGR="未知"
ROOT_VER=""

if [ -d /data/adb/ksu ] || [ -f /data/adb/ksu/.allowlist ] || [ -f /data/adb/ksu_version ]; then
  ROOT_MGR="KernelSU"
  ROOT_VER=$(cat /data/adb/ksu_version 2>/dev/null || cat /data/adb/ksu/version 2>/dev/null | tr -d '[:space:]')
elif [ -d /data/adb/ap ] || [ -f /data/adb/apd/version ]; then
  ROOT_MGR="APatch"
  ROOT_VER=$(cat /data/adb/apd/version 2>/dev/null | tr -d '[:space:]')
elif [ -d /data/adb/magisk ] || [ -n "$(getprop ro.magisk.version 2>/dev/null)" ]; then
  ROOT_MGR="Magisk"
  ROOT_VER=$(getprop ro.magisk.version 2>/dev/null | tr -d '[:space:]')
fi

if [ "$ROOT_MGR" = "未知" ]; then
  mark WARN "未识别到 Root 管理器 (KSU/APatch/Magisk 均未检测到)"
  add_summary "[WARN] 未识别到 Root 框架"
else
  mark OK "Root 管理器: ${ROOT_MGR} ${ROOT_VER}"
  add_summary "[OK] Root 框架: ${ROOT_MGR} ${ROOT_VER}"
fi

echo "" >> "$OUT" 2>/dev/null
echo "--- 各框架目录探测 (详细) ---" >> "$OUT" 2>/dev/null
run_sh "ls -la /data/adb/ksu/ 2>/dev/null | head -10"
run_sh "ls -la /data/adb/ap/ 2>/dev/null | head -10"
run_sh "ls -la /data/adb/magisk/ 2>/dev/null | head -10"
run_sh "getprop ro.magisk.version 2>/dev/null"
run_sh "cat /data/adb/ksu_version 2>/dev/null"
run_sh "cat /data/adb/ksu/version 2>/dev/null"
run_sh "cat /data/adb/apd/version 2>/dev/null"

# ============================================================
# 10. SELinux 与权限 (v2: 新增 avc denial 审计)
# ============================================================
section "10. SELinux 与权限 (含 avc denial 审计)"
SEL_MODE=$(getenforce 2>/dev/null | tr -d '[:space:]')
echo "getenforce: $SEL_MODE" >> "$OUT" 2>/dev/null
if [ "$SEL_MODE" = "Enforcing" ]; then
  mark INFO "SELinux: Enforcing (tarn 需 ksu/magisk 域权限, 出问题先查 avc denial)"
elif [ "$SEL_MODE" = "Permissive" ]; then
  mark WARN "SELinux: Permissive (仅记录不拦截, 生产环境应收紧)"
else
  mark WARN "SELinux: $SEL_MODE (异常状态)"
fi
echo "" >> "$OUT" 2>/dev/null

run_sh "id 2>/dev/null"
run_sh "ls -la /sys/power/wake_lock 2>/dev/null"
run_sh "ls -la /sys/power/wake_unlock 2>/dev/null"

# avc denial 审计 —— Android root 模块故障头号元凶 (v2 核心)
echo "--- SELinux avc denial 审计 (tarn 相关) ---" >> "$OUT" 2>/dev/null
echo "$ dmesg | grep -i 'avc.*denied' | grep -i tarn (尾部 30)" >> "$OUT" 2>/dev/null
AVC_DMESG=""
if command -v dmesg >/dev/null 2>&1 || [ -n "$BB" ]; then
  AVC_DMESG=$(bb_wrap dmesg 2>/dev/null | bb_wrap grep -iE 'avc.*denied' 2>/dev/null | bb_wrap grep -iE 'tarn|u:r:ksu|u:r:magisk' 2>/dev/null | bb_wrap tail -n 30)
fi
if [ -n "$AVC_DMESG" ]; then
  echo "$AVC_DMESG" >> "$OUT" 2>/dev/null
  AVC_CNT=$(echo "$AVC_DMESG" | bb_wrap grep -c '' 2>/dev/null | tr -d '[:space:]')
  mark FAIL "dmesg 发现 ${AVC_CNT} 条 tarn 相关 avc denial (SELinux 拦截了 tarn 的操作!)"
  add_summary "[FAIL] SELinux avc denial: ${AVC_CNT} 条 (dmesg)"
else
  mark OK "dmesg 无 tarn 相关 avc denial"
fi
echo "" >> "$OUT" 2>/dev/null

# logcat 的 avc denial (auditd)
echo "$ logcat -d -b all 2>/dev/null | grep 'avc.*denied' | grep tarn (尾部 30)" >> "$OUT" 2>/dev/null
AVC_LOGCAT=""
if command -v logcat >/dev/null 2>&1; then
  AVC_LOGCAT=$(logcat -d -b all 2>/dev/null | bb_wrap grep -iE 'avc.*denied' 2>/dev/null | bb_wrap grep -iE 'tarn' 2>/dev/null | bb_wrap tail -n 30)
fi
if [ -n "$AVC_LOGCAT" ]; then
  echo "$AVC_LOGCAT" >> "$OUT" 2>/dev/null
  AVC_LC_CNT=$(echo "$AVC_LOGCAT" | bb_wrap grep -c '' 2>/dev/null | tr -d '[:space:]')
  mark WARN "logcat 发现 ${AVC_LC_CNT} 条 tarn 相关 avc denial"
  add_summary "[WARN] SELinux avc denial: ${AVC_LC_CNT} 条 (logcat)"
else
  mark OK "logcat 无 tarn 相关 avc denial (或 logcat 不可用)"
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 11. 存储与挂载 (v2: 新增 inode + 降噪)
# ============================================================
section "11. 存储与挂载 (含 inode)"
echo "--- /data 磁盘空间 ---" >> "$OUT" 2>/dev/null
run_sh "df -h /data 2>/dev/null"
echo "--- /data inode 使用 ---" >> "$OUT" 2>/dev/null
echo "$ df -i /data" >> "$OUT" 2>/dev/null
df -i /data 2>/dev/null >> "$OUT" 2>&1 || mark WARN "df -i 不可用 (busybox 不支持时降级)"
echo "" >> "$OUT" 2>/dev/null

# tarn 数据目录所在分区空间
echo "--- tarn 数据目录空间 ---" >> "$OUT" 2>/dev/null
run_sh "df -h $DATADIR 2>/dev/null"

# mount 降噪: 只取关键挂载点 (v2 改进, 原版 grep 'tarn|/data ' 噪音极大)
echo "--- mount (关键挂载点: /data /sdcard /storage /system) ---" >> "$OUT" 2>/dev/null
bb_wrap mount 2>/dev/null | bb_wrap grep -E ' on /(data|storage|sdcard|system) ' >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null

# /data 只读检测
if bb_wrap mount 2>/dev/null | bb_wrap grep -E ' on /data ' | bb_wrap grep -q 'ro,'; then
  mark FAIL "/data 挂载为只读 (无法写日志/状态/socket!)"
  add_summary "[FAIL] /data 只读"
else
  mark OK "/data 可读写"
fi

# ============================================================
# 12. 二进制与环境能力检测 (v2 新增)
# ============================================================
section "12. 二进制与环境能力检测"

# 二进制存在性 + 权限
if [ -f "$BIN" ]; then
  mark OK "二进制存在: $BIN"
  ls -la "$BIN" >> "$OUT" 2>/dev/null
else
  mark FAIL "二进制不存在: $BIN"
  add_summary "[FAIL] 二进制缺失"
fi

# 架构匹配检测
echo "--- 架构匹配 ---" >> "$OUT" 2>/dev/null
DEV_ABI=$(getprop ro.product.cpu.abi 2>/dev/null | tr -d '[:space:]')
echo "设备 ABI: $DEV_ABI" >> "$OUT" 2>/dev/null
if [ -n "$DEV_ABI" ] && [ -x "$BIN" ]; then
  # 用 readelf 读 ELF header 的 e_machine (aarch64=0xB7, arm=0x28)
  # busybox readelf 不一定有, 用 od 兜底读 magic
  if command -v readelf >/dev/null 2>&1; then
    ELF_MACHINE=$(readelf -h "$BIN" 2>/dev/null | bb_wrap grep -iE 'Machine' | bb_wrap sed -E 's/.*:[[:space:]]*//')
    echo "二进制 Machine: $ELF_MACHINE" >> "$OUT" 2>/dev/null
    case "$DEV_ABI" in
      arm64-v8a)
        echo "$ELF_MACHINE" | bb_wrap grep -qi 'aarch64' && mark OK "arch 匹配 (arm64)" || mark FAIL "arch 不匹配 (设备 arm64, 二进制 $ELF_MACHINE)"
        ;;
      armeabi*)
        echo "$ELF_MACHINE" | bb_wrap grep -qi 'ARM' && mark OK "arch 匹配 (arm)" || mark FAIL "arch 不匹配 (设备 arm, 二进制 $ELF_MACHINE)"
        ;;
    esac
  else
    mark INFO "readelf 不可用, 跳过 arch 严格校验 (依赖 doctor 间接验证)"
  fi
fi
echo "" >> "$OUT" 2>/dev/null

# 动态库依赖 (readelf -d, 进程未运行时用)
echo "--- 动态库依赖 (readelf -d NEEDED) ---" >> "$OUT" 2>/dev/null
if command -v readelf >/dev/null 2>&1 && [ -f "$BIN" ]; then
  echo "$ readelf -d $BIN | grep NEEDED" >> "$OUT" 2>/dev/null
  readelf -d "$BIN" 2>/dev/null | bb_wrap grep -i 'NEEDED' >> "$OUT" 2>/dev/null
  echo "" >> "$OUT" 2>/dev/null
  # 检查依赖的 so 是否存在
  echo "--- 依赖 so 存在性检查 ---" >> "$OUT" 2>/dev/null
  for so in $(readelf -d "$BIN" 2>/dev/null | bb_wrap grep -i 'NEEDED' | bb_wrap sed -E "s/.*\[//; s/\].*//" 2>/dev/null); do
    FOUND=0
    for libdir in /system/lib64 /system/lib /apex/com.android.runtime/lib64 /vendor/lib64 /vendor/lib; do
      if [ -f "$libdir/$so" ]; then
        FOUND=1
        break
      fi
    done
    if [ "$FOUND" = "1" ]; then
      mark OK "依赖 $so: 已找到"
    else
      mark FAIL "依赖 $so: 未找到 (二进制将无法启动!)"
      add_summary "[FAIL] 缺失动态库: $so"
    fi
  done
else
  mark INFO "readelf 不可用, 跳过动态库依赖检查 (进程在跑时见第2章 /proc/maps)"
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 13. WebUI 与通信端点 (v2: 新增端口监听 + socket 连通性)
# ============================================================
section "13. WebUI 与通信端点 (含端口监听 + socket 连通性)"

# 读取 WebUI 配置
WEBUI_ENABLED=$(get_setting "enabled" "true")
WEBUI_BIND=$(get_setting "bind" "127.0.0.1")
WEBUI_PORT=$(get_setting "port" "8080")
echo "WebUI 配置: enabled=$WEBUI_ENABLED bind=$WEBUI_BIND port=$WEBUI_PORT" >> "$OUT" 2>/dev/null

# Unix socket 存在性
SOCK="$DATADIR/run/tarn.sock"
echo "--- Unix socket ---" >> "$OUT" 2>/dev/null
run_sh "ls -la $SOCK 2>/dev/null"

# socket 连通性测试 (v2 核心: 不只 ls, 实际 connect)
echo "--- socket 连通性测试 ---" >> "$OUT" 2>/dev/null
if [ -S "$SOCK" ]; then
  if [ -n "$DPID" ] && kill -0 "$DPID" 2>/dev/null; then
    # 进程存活 + socket 存在 = 大概率可用
    mark OK "socket 存在且 daemon 存活 (pid=$DPID)"
  else
    mark WARN "socket 存在但 daemon 未运行 (可能是孤儿 socket, 需清理)"
    add_summary "[WARN] 孤儿 socket (daemon 未运行但 socket 残留)"
  fi
  # 尝试用 nc 实际连接 (toybox/busybox nc)
  if command -v nc >/dev/null 2>&1 || { [ -n "$BB" ] && "$BB" --list 2>/dev/null | bb_wrap grep -q '^nc$'; }; then
    echo "$ nc -U $SOCK (连通性测试)" >> "$OUT" 2>/dev/null
    echo "" | bb_wrap nc -U "$SOCK" -w 2 2>/dev/null >/dev/null
    NC_RET=$?
    if [ "$NC_RET" = "0" ]; then
      mark OK "nc -U 连接成功 (socket 可达)"
    else
      mark WARN "nc -U 返回 $NC_RET (socket 可能不可达或 daemon 未响应)"
    fi
  else
    mark INFO "nc 不可用, 跳过实际连接测试"
  fi
else
  if [ "$WEBUI_ENABLED" = "true" ]; then
    mark WARN "socket 不存在 (WebUI enabled 但未创建 socket)"
    add_summary "[WARN] WebUI socket 未创建"
  fi
fi
echo "" >> "$OUT" 2>/dev/null

# token 文件
TOKEN="$DATADIR/run/token"
if [ -f "$TOKEN" ]; then
  TOK_SZ=$(wc -c < "$TOKEN" 2>/dev/null | tr -d '[:space:]')
  mark OK "token 文件存在 (${TOK_SZ} 字节, 内容已脱敏)"
else
  mark WARN "token 文件不存在 (WebUI 鉴权将失败)"
  add_summary "[WARN] token 文件缺失"
fi
echo "" >> "$OUT" 2>/dev/null

# TCP 端口监听检测 (v2 核心: 读 /proc/$PID/net/tcp)
echo "--- WebUI TCP 端口监听检测 ---" >> "$OUT" 2>/dev/null
if [ "$WEBUI_ENABLED" = "true" ]; then
  # 端口转 hex (8080 -> 1F90)
  PORT_HEX=$(printf '%04X' "$WEBUI_PORT" 2>/dev/null)
  echo "检测端口: $WEBUI_PORT (0x$PORT_HEX) LISTEN 状态=0A" >> "$OUT" 2>/dev/null

  TCP_FOUND=0
  # 优先从 daemon 进程的 /proc/$PID/net/tcp 查
  if [ -n "$DPID" ] && [ -r "/proc/$DPID/net/tcp" ]; then
    echo "$ cat /proc/$DPID/net/tcp | grep ':$PORT_HEX 00000000:0000 0A'" >> "$OUT" 2>/dev/null
    TCP_LINE=$(bb_wrap grep -E ":${PORT_HEX} 00000000:0000 0A" "/proc/$DPID/net/tcp" 2>/dev/null)
    if [ -n "$TCP_LINE" ]; then
      TCP_FOUND=1
      echo "$TCP_LINE" >> "$OUT" 2>/dev/null
    fi
  fi
  # 兜底: 全局 /proc/net/tcp
  if [ "$TCP_FOUND" = "0" ] && [ -r /proc/net/tcp ]; then
    echo "$ cat /proc/net/tcp | grep ':$PORT_HEX 00000000:0000 0A' (全局兜底)" >> "$OUT" 2>/dev/null
    TCP_LINE=$(bb_wrap grep -E ":${PORT_HEX} 00000000:0000 0A" /proc/net/tcp 2>/dev/null)
    if [ -n "$TCP_LINE" ]; then
      TCP_FOUND=1
      echo "$TCP_LINE" >> "$OUT" 2>/dev/null
    fi
  fi

  if [ "$TCP_FOUND" = "1" ]; then
    mark OK "WebUI 端口 $WEBUI_PORT 正在监听 (LISTEN)"
    add_summary "[OK] WebUI 端口 $WEBUI_PORT 监听中"
  else
    mark FAIL "WebUI 端口 $WEBUI_PORT 未监听 (enabled=true 但无 LISTEN, WebUI 无法访问!)"
    add_summary "[FAIL] WebUI 端口 $WEBUI_PORT 未监听"
  fi
else
  mark INFO "WebUI 未启用 (enabled=false), 跳过端口检测"
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 14. 启动链路检测 (v2 新增)
# ============================================================
section "14. 启动链路检测"

# Magisk/KSU 模块通过 service.sh 在 late_start 阶段拉起
# 检测框架是否正确配置了 tarn 的启动
echo "--- 模块目录完整性 ---" >> "$OUT" 2>/dev/null
for f in module.prop service.sh; do
  if [ -f "$MODDIR/$f" ]; then
    mark OK "$MODDIR/$f 存在"
  else
    mark FAIL "$MODDIR/$f 缺失 (启动链路不完整!)"
    add_summary "[FAIL] 启动链路: $f 缺失"
  fi
done

# service.d 软链检测 (部分用户自定义启动顺序)
echo "--- service.d / post-fs-data.d ---" >> "$OUT" 2>/dev/null
run_sh "ls -la /data/adb/service.d/ 2>/dev/null | grep -i tarn"
run_sh "ls -la /data/adb/post-fs-data.d/ 2>/dev/null | grep -i tarn"

# boot_failures 计数
BOOT_FAIL="$DATADIR/run/boot_failures"
if [ -f "$BOOT_FAIL" ]; then
  BFC=$(cat "$BOOT_FAIL" 2>/dev/null | tr -d '[:space:]')
  case "$BFC" in
    *[!0-9]*|"") BFC=0 ;;
  esac
  if [ "$BFC" -ge 3 ] 2>/dev/null; then
    mark WARN "boot_failures=$BFC (>=3, service.sh 已进入安全模式跳过自启!)"
    add_summary "[WARN] 安全模式: 连续 $BFC 次启动失败"
  elif [ "$BFC" -gt 0 ] 2>/dev/null; then
    mark WARN "boot_failures=$BFC (有启动失败记录, 未达安全模式阈值)"
  else
    mark OK "boot_failures=0 (无启动失败记录)"
  fi
else
  mark OK "无 boot_failures 记录 (首次运行或已清零)"
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 15. doctor 自检
# ============================================================
section "15. doctor 自检"
if [ -x "$BIN" ]; then
  run_cmd "$BIN" doctor
  # doctor 输出含 [OK] 则认为通过
  if "$BIN" doctor 2>/dev/null | bb_wrap grep -q '\[OK\]'; then
    add_summary "[OK] doctor 自检通过"
  else
    add_summary "[WARN] doctor 自检可能有异常"
  fi
else
  mark FAIL "二进制不可执行, 无法运行 doctor"
  add_summary "[FAIL] doctor 无法运行"
fi

# ============================================================
# 16. 内核日志 (dmesg, 尾部)
# ============================================================
section "16. 内核日志 (dmesg, 尾部)"
run_sh "dmesg 2>/dev/null | tail -50"

# ============================================================
# 17. 诊断摘要 (v2 新增)
# ============================================================
section "17. 诊断摘要"
echo "$SUMMARY" >> "$OUT" 2>/dev/null

# 统计问题数
FAIL_CNT=$(echo "$SUMMARY" | bb_wrap grep -c '\[FAIL\]' 2>/dev/null | tr -d '[:space:]')
WARN_CNT=$(echo "$SUMMARY" | bb_wrap grep -c '\[WARN\]' 2>/dev/null | tr -d '[:space:]')
OK_CNT=$(echo "$SUMMARY" | bb_wrap grep -c '\[OK\]' 2>/dev/null | tr -d '[:space:]')
echo "----------------------------------------" >> "$OUT" 2>/dev/null
echo "  OK: ${OK_CNT:-0}  WARN: ${WARN_CNT:-0}  FAIL: ${FAIL_CNT:-0}" >> "$OUT" 2>/dev/null
echo "----------------------------------------" >> "$OUT" 2>/dev/null
if [ "${FAIL_CNT:-0}" -gt 0 ]; then
  echo "  >> 存在 $FAIL_CNT 项严重问题, 请优先排查 [FAIL] 项" >> "$OUT" 2>/dev/null
elif [ "${WARN_CNT:-0}" -gt 0 ]; then
  echo "  >> 存在 $WARN_CNT 项警告, 建议关注 [WARN] 项" >> "$OUT" 2>/dev/null
else
  echo "  >> 各项检测正常" >> "$OUT" 2>/dev/null
fi
echo "" >> "$OUT" 2>/dev/null

# ============================================================
# 完成 + 清理
# ============================================================
section "诊断完成"
echo "诊断快照已写入: $OUT" >> "$OUT" 2>/dev/null
echo "文件大小: $(wc -c < "$OUT" 2>/dev/null | tr -d ' ') 字节" >> "$OUT" 2>/dev/null

KEEP_DAYS=7
find "$LOGDIR" -name 'debug-*.txt' -mtime +${KEEP_DAYS} -delete 2>/dev/null
COUNT=$(ls -1 "$LOGDIR"/debug-*.txt 2>/dev/null | wc -l | tr -d ' ')
echo "当前 debug 快照数: $COUNT (保留 ${KEEP_DAYS} 天)" >> "$OUT" 2>/dev/null

# 崩溃循环节流 (v2 新增): 单次进程生命周期内最多保留 20 份快照, 超出删最旧
if [ "${COUNT:-0}" -gt 20 ] 2>/dev/null; then
  DEL_N=$((COUNT - 20))
  ls -1t "$LOGDIR"/debug-*.txt 2>/dev/null | bb_wrap tail -n "$DEL_N" | while read -r old; do
    rm -f "$old" 2>/dev/null
  done
  echo "崩溃循环节流: 删除 $DEL_N 份最旧快照 (保留最近 20 份)" >> "$OUT" 2>/dev/null
fi

exit 0
