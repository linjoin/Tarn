#!/system/bin/sh
# Tran - 早期启动脚本
# 在 post-fs-data 阶段确保目录结构就绪, 不启动服务 (服务由 service.sh 启动)。

#=========== 路径变量 ===========
MODDIR=${0%/*}
DATADIR=/data/adb/tarn
BOOTLOG="$DATADIR/logs/boot.log"

#=========== 1. 创建目录结构 ===========
mkdir -p "$DATADIR/config" "$DATADIR/logs" "$DATADIR/run" "$DATADIR/rules" "$DATADIR/trash" 2>/dev/null
chmod 700 "$DATADIR" "$DATADIR/config" "$DATADIR/logs" "$DATADIR/run" "$DATADIR/rules" "$DATADIR/trash" 2>/dev/null
chown root:root "$DATADIR" 2>/dev/null

#=========== 2. 写入启动标记 ===========
ts=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
echo "[$ts] [post-fs-data] 目录结构就绪" >> "$BOOTLOG" 2>/dev/null

exit 0
