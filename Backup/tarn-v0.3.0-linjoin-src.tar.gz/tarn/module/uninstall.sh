#!/system/bin/sh
# Tran - 卸载脚本
# 停止后台进程并清理数据目录, 管理器随后自动删除模块目录。
# 注: 卸载脚本的输出不会展示给用户, 本脚本静默执行。

#=========== busybox 检测 ===========
# 优先级: KernelSU > APatch > Magisk > 系统 > PATH
detect_bb() {
  for cand in \
    /data/adb/ksu/bin/busybox \
    /data/adb/ap/bin/busybox \
    /data/adb/magisk/busybox \
    /system/bin/busybox \
    /system/xbin/busybox; do
    [ -x "$cand" ] && { echo "$cand"; return 0; }
  done
  command -v busybox 2>/dev/null && return 0
  echo ""
  return 1
}

BB=$(detect_bb)
# bb_wrap <cmd> [args...]: 优先用 busybox 调用, 否则回退到 PATH
bb_wrap() {
  cmd=$1
  shift
  if [ -n "$BB" ]; then
    "$BB" "$cmd" "$@"
  else
    "$cmd" "$@"
  fi
}

#=========== 路径变量 ===========
DATADIR=/data/adb/tarn
PIDFILE="$DATADIR/run/tarn.pid"

#=========== 1. 停止后台进程 ===========
if [ -f "$PIDFILE" ]; then
  DAEMON_PID=$(cat "$PIDFILE" 2>/dev/null | tr -d '[:space:]')
  if [ -n "$DAEMON_PID" ] && [ "$DAEMON_PID" -gt 0 ] 2>/dev/null; then
    if kill -0 "$DAEMON_PID" 2>/dev/null; then
      OLD_CMDLINE=""
      if [ -r "/proc/$DAEMON_PID/cmdline" ]; then
        OLD_CMDLINE=$(tr '\0' ' ' < "/proc/$DAEMON_PID/cmdline" 2>/dev/null)
      fi
      case "$OLD_CMDLINE" in
        *tarn*)
          # 先优雅退出, 超时后强制结束
          kill -TERM "$DAEMON_PID" 2>/dev/null
          i=0
          while [ $i -lt 10 ]; do
            kill -0 "$DAEMON_PID" 2>/dev/null || break
            sleep 1
            i=$((i + 1))
          done
          kill -0 "$DAEMON_PID" 2>/dev/null && kill -KILL "$DAEMON_PID" 2>/dev/null
          ;;
      esac
    fi
  fi
fi

# 兜底: 清理可能残留的进程 (pidfile 丢失时)
if [ -n "$BB" ]; then
  "$BB" ps 2>/dev/null | bb_wrap grep -E '[t]arn daemon' | while read -r p c; do
    kill -KILL "$p" 2>/dev/null
  done
else
  ps -A -o pid,cmd 2>/dev/null | bb_wrap grep -E '[t]arn daemon' | while read -r p c; do
    kill -KILL "$p" 2>/dev/null
  done
fi

#=========== 2. 删除数据目录 ===========
if [ -d "$DATADIR" ]; then
  rm -rf "$DATADIR" 2>/dev/null
  [ -d "$DATADIR" ] && rm -rf "$DATADIR" 2>/dev/null
fi

#=========== 3. 卸载 WebUI 桌面入口 ===========
# 若安装时部署了 KsuWebUI (Magisk 环境), 一并卸载。
command -v pm >/dev/null 2>&1 && pm uninstall me.weishu.kernelsu.webui >/dev/null 2>&1

exit 0
