//! Tarn CLI 命令定义 (clap derive)

use clap::{Parser, Subcommand};

#[derive(Parser, Debug)]
#[command(name = "tarn", version, about = "Tarn - 系统级文件治理引擎", long_about = None)]
pub struct Cli {
    /// 配置目录 (默认 /data/adb/tarn)
    #[arg(long, global = true, env = "TARN_CONFIG_DIR")]
    pub config_dir: Option<String>,

    /// 详细输出
    #[arg(long, short, global = true)]
    pub verbose: bool,

    /// 禁用颜色
    #[arg(long, global = true)]
    pub no_color: bool,

    #[command(subcommand)]
    pub command: Command,
}

#[derive(Subcommand, Debug)]
pub enum Command {
    /// 执行清理
    Run {
        /// 仅跑指定规则 (可多次)
        #[arg(long)]
        rule: Option<Vec<String>>,

        /// 触发方式
        #[arg(long, default_value = "manual")]
        trigger: String,

        /// 试运行 (不真删) —— 唯一安全栅栏, 默认推荐先预览
        #[arg(long)]
        dry_run: bool,

        /// 输出 JSON
        #[arg(long)]
        json: bool,
    },

    /// 启动 WebUI 服务
    Webui {
        #[arg(long, default_value = "127.0.0.1")]
        bind: String,
        #[arg(long)]
        port: Option<u16>,
    },

    /// 启动定时守护进程 (timerfd + Doze 穿透)
    Daemon,

    /// 列出规则/保护项
    List {
        #[arg(long)]
        pack: Option<String>,
        #[arg(long)]
        enabled_only: bool,
    },

    /// 显示某条规则详情
    Show { rule_id: String },

    /// 启用规则
    Enable { rule_id: String },

    /// 禁用规则
    Disable { rule_id: String },

    /// 读写设置
    Config {
        #[command(subcommand)]
        action: ConfigAction,
    },

    /// 查看日志
    Log {
        #[arg(long, default_value = "50")]
        tail: usize,
    },

    /// 查看累计统计
    Stats,

    /// 自检
    Doctor,

    /// 热重载配置
    Reload,

    /// 版本信息
    Version,
}

#[derive(Subcommand, Debug)]
pub enum ConfigAction {
    Get { key: String },
    Set { key: String, value: String },
    List,
}
