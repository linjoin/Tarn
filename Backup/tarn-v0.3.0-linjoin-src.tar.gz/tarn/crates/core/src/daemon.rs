//! 守护进程: 完整 daemon 循环
//!
//! 基于 RESEARCH-1 / RESEARCH-3 调研结论:
//! - timerfd + CLOCK_BOOTTIME_ALARM 穿透 Doze, 内核级唤醒
//! - 触发后立刻持 wake_lock (短时 + timeout 兜底), 干完释放
//! - SIGHUP 热重载配置 (不打断当前任务)
//! - SIGTERM 优雅退出 (drain in-flight), SIGINT 强制退出
//! - pidfile + flock 防多开
//! - oom_score_adj 调低防 OOM kill
//! - cron 表达式解析 → 算下次触发 → timerfd arm_absolute
//!
//! 重要: 开机只注册服务, 不执行清理任务
//!   - 开机时 Magisk 的 service.sh 启动 daemon
//!   - daemon 启动后直接进入 cron 调度主循环
//!   - 不再开机立即跑 boot 清理 (避免与系统启动 IO 争抢)
//!   - 用户可手动 `tarn run` 或等 cron 到点触发
//!
//! 主循环:
//! ```text
//! loop {
//!   1. 扫描所有 cron 规则, 算最近下次触发时间
//!   2. timerfd set_absolute(最近触发时间)
//!   3. poll(timerfd_fd, SIGTERM/SIGHUP/SIGINT 信号 fd) 多路复用等待
//!   4. 到点:
//!      a. acquire wake_lock
//!      b. 执行所有到期的 cron 规则
//!      c. 保存 state
//!      d. release wake_lock
//!      e. 回到 1
//!   5. SIGHUP: reload 配置, 回到 1
//!   6. SIGTERM: drain + save + exit
//!   7. SIGINT: immediate exit
//! }
//! ```

use crate::executor::{Executor, RunOptions, Trigger};
use crate::logger::AsyncLogger;
use crate::module_prop;
use crate::reload::{reload, ConfigHandle};
use crate::scheduler::{CronSchedule, DozeTimer, WakeLock};
use crate::state::StateManager;
use crate::sysutil;
use crate::webroot;
use crate::config_watcher;
use anyhow::{anyhow, Result};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;

/// daemon 运行所需上下文
pub struct DaemonContext {
    pub config_dir: PathBuf,
    pub config: ConfigHandle,
    pub logger: Arc<AsyncLogger>,
    pub pidfile: PathBuf,
    pub state: Arc<StateManager>,
}

impl DaemonContext {
    pub fn new(
        config_dir: PathBuf,
        config: ConfigHandle,
        logger: Arc<AsyncLogger>,
    ) -> Result<Self> {
        let pidfile = config_dir.join("run/tarn.pid");
        let state_path = config_dir.join("state.json");
        let state = Arc::new(StateManager::new(state_path));
        Ok(Self {
            config_dir,
            config,
            logger,
            pidfile,
            state,
        })
    }
}

/// 启动 daemon 主循环
///
/// 阻塞调用, 直到收到 SIGTERM/SIGINT 或发生不可恢复错误。
///
/// 重要: daemon 启动后只进入 cron 调度循环, **不再执行 boot 清理**。
/// 开机只注册服务 (启动 daemon), 清理任务由 cron 触发或用户手动触发。
pub fn run_daemon(ctx: DaemonContext) -> Result<()> {
    ctx.logger.info("daemon", "Tarn daemon 启动");

    // 1. 防多开: pidfile + flock
    let _lock_file = sysutil::lock_pidfile(&ctx.pidfile).map_err(|e| {
        anyhow!("pidfile 锁定失败, 可能已有实例运行: {}", e)
    })?;
    sysutil::write_pidfile(&ctx.pidfile, sysutil::current_pid())?;
    ctx.logger
        .info("daemon", &format!("pidfile 写入: {}", ctx.pidfile.display()));

    // 2. 低功耗调优 + oom 调低
    // [v0.2.1] apply_low_power 返回 LowPowerReport 诊断报告, 明确告知用户每项
    // 调优是否真正生效。
    //   - nice(19): 内核 CFS 调度器用 nice 值计算时间片权重 (weight=1024*1.25^(-nice)),
    //     nice 19 → weight~15, 占 CPU 约 1.5%, 所有 Android 设备一定生效。
    //   - 绑核: big.LITTLE 上绑小核避免占大核导致前台 jank。
    //   - ionice IDLE: v0.2.1 已移除 (CFQ 调度器内核 5.x 已删, Android 的
    //     mq-deadline/none/kyber 调度器忽略 ioprio, 是空操作, 保留无意义)。
    {
        let cfg = ctx.config.read();
        if cfg.settings.engine.low_power {
            // cpu_affinity 为空 → 自动探测小核; 非空 → 用用户指定的核心
            let affinity = if cfg.settings.engine.cpu_affinity.is_empty() {
                let cores = sysutil::detect_little_cores();
                ctx.logger
                    .info("daemon", &format!("cpu_affinity 为空, 自动探测小核: {:?}", cores));
                cores
            } else {
                cfg.settings.engine.cpu_affinity.clone()
            };
            let report = sysutil::apply_low_power(&affinity);

            // 输出详细诊断日志, 让用户清楚知道每项调优的真实情况
            ctx.logger.info("daemon", "=== 低功耗调优诊断 ===");
            ctx.logger.info(
                "daemon",
                &format!("  nice  : {} (value={}, CFS 调度器一定遵守, 所有设备有效)",
                    if report.nice_applied { "✓ 已应用" } else { "✗ 失败" },
                    report.nice_value),
            );
            if !affinity.is_empty() {
                ctx.logger.info(
                    "daemon",
                    &format!("  绑核  : {} (cores={:?}, 遍历 /proc/self/task 覆盖所有线程)",
                        if report.affinity_applied { "✓ 已应用" } else { "✗ 失败" },
                        affinity),
                );
            }
            ctx.logger.info(
                "daemon",
                &format!("  摘要  : {}", report.summary_line()),
            );
            for e in &report.errors {
                ctx.logger
                    .warn("daemon", &format!("  错误  : {}", e));
            }
            ctx.logger.info("daemon", "=== 低功耗调优诊断结束 ===");
        } else {
            ctx.logger.info("daemon", "low_power=false, 跳过低功耗调优");
        }
    }
    let _ = sysutil::set_oom_score_adj(sysutil::OOM_SCORE_ADJ_DAEMON);
    ctx.logger
        .info("daemon", &format!("oom_score_adj = {}", sysutil::OOM_SCORE_ADJ_DAEMON));

    // 2.5 动态生成 webroot/index.html (KernelSU WebUI 入口)
    // 读 settings.toml 的 [webui] bind/port, 写入 /data/adb/modules/tarn/webroot/index.html
    // 失败不退出 daemon (Magisk 用户用不上 webroot, KSU 用户可手动访问 http://127.0.0.1:port)
    {
        let cfg = ctx.config.read();
        let bind = cfg.settings.webui.bind.clone();
        let port = cfg.settings.webui.port;
        drop(cfg);
        match webroot::generate_index_html(&bind, port) {
            Ok(p) => ctx.logger.info(
                "daemon",
                &format!("webroot/index.html 已生成: {} (重定向到 http://{}:{})", p.display(), bind, port),
            ),
            Err(e) => ctx.logger.warn(
                "daemon",
                &format!("webroot/index.html 生成失败 (不影响主流程): {}", e),
            ),
        }
    }

    // 2.6 更新 module.prop description (Magisk/KSU 管理器模块列表显示)
    // 显示 "运行中 PID=xxx | 删除 xxx 个文件 | 已清理 xxx GB", 累计数据从 state.json 读取
    // 失败不退出 daemon (仅影响管理器显示, 不影响功能)
    {
        let snap = ctx.state.snapshot();
        let freed_bytes = snap.totals.total_freed_bytes;
        let files_deleted = snap.totals.total_files_deleted;
        let pid = sysutil::current_pid() as u32;
        match module_prop::update_from_state(true, Some(pid), files_deleted, freed_bytes) {
            Ok(()) => ctx.logger.info(
                "daemon",
                &format!("module.prop description 已更新: 运行中 PID={} | 删除 {} 个文件 | 已清理 {}",
                    pid, files_deleted, module_prop::format_bytes(freed_bytes)),
            ),
            Err(e) => ctx.logger.warn(
                "daemon",
                &format!("module.prop description 更新失败 (不影响主流程): {}", e),
            ),
        }
    }

    // 3. 安装信号处理器 (用 signalfd 或简单 libc::signal)
    //    这里用独立线程监听 SIGHUP/SIGTERM/SIGINT
    let shutdown_requested = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let reload_requested = Arc::new(std::sync::atomic::AtomicBool::new(false));

    install_signal_handlers(
        shutdown_requested.clone(),
        reload_requested.clone(),
        ctx.logger.clone(),
    )?;
    ctx.logger.info("daemon", "信号处理器已安装 (SIGHUP/SIGTERM/SIGINT)");

    // 3.5 启动配置文件 inotify 监控 (自动热重载)
    //    监控 config/ 和 rules/ 目录下的 .toml 文件, 变化时 raise(SIGHUP)
    //    复用现有 SIGHUP 热重载机制 (打断主循环 sleep + 设置 reload_requested)
    //    必须在 install_signal_handlers 之后启动 (否则 raise(SIGHUP) 会终止进程)
    //    空闲 CPU = 0 (poll 阻塞等待内核事件)
    //    失败不退出 daemon (退化到手动 tarn reload)
    match config_watcher::start_config_watcher(&ctx.config_dir, ctx.logger.clone()) {
        Ok(_handle) => ctx.logger.info(
            "daemon",
            "配置文件 inotify 监控已启动 (文件变化自动热重载, 无需手动 tarn reload)",
        ),
        Err(e) => ctx.logger.warn(
            "daemon",
            &format!(
                "配置文件 inotify 监控启动失败, 退化为手动热重载 (tarn reload): {}",
                e
            ),
        ),
    }

    // 4. (开机不执行清理) 直接进入 cron 调度主循环
    //    daemon 启动后只注册服务, 清理任务由 cron 触发或用户手动触发
    ctx.logger.info("daemon", "开机只注册服务, 跳过 boot 清理");
    ctx.logger.info("daemon", "进入 cron 调度主循环");
    // timerfd 创建失败不退出 daemon, 退化到 sleep 模式 (防某些 ROM SELinux 限制 CLOCK_BOOTTIME_ALARM)
    let timer = match DozeTimer::new() {
        Ok(t) => {
            ctx.logger.info("daemon", "timerfd 创建成功 (CLOCK_BOOTTIME_ALARM)");
            Some(t)
        }
        Err(e) => {
            ctx.logger.warn(
                "daemon",
                &format!("timerfd 创建失败, 退化到 sleep 模式 (Doze 穿透不可用): {}", e),
            );
            None
        }
    };

    while !shutdown_requested.load(std::sync::atomic::Ordering::SeqCst) {
        // 处理 reload 请求
        if reload_requested.swap(false, std::sync::atomic::Ordering::SeqCst) {
            ctx.logger.info("daemon", "收到 SIGHUP, 热重载配置");
            // 记录旧引擎配置, 用于检测热重载后是否有变化
            let (old_low_power, old_cpu_affinity, old_bind, old_port) = {
                let cfg = ctx.config.read();
                (
                    cfg.settings.engine.low_power,
                    cfg.settings.engine.cpu_affinity.clone(),
                    cfg.settings.webui.bind.clone(),
                    cfg.settings.webui.port,
                )
            };
            match reload(&ctx.config, ctx.config_dir.clone()) {
                Ok(()) => {
                    // [v0.2.1] 热重载后打印详细配置摘要, 让用户确认配置已生效
                    let (rules_count, protects_count, cron_count, low_power, cpu_affinity, bind, port, log_level) = {
                        let cfg = ctx.config.read();
                        let cron_count = cfg.blacklist.rule.iter()
                            .filter(|r| r.enabled && r.trigger.on.iter().any(|t| t == "cron"))
                            .count();
                        let protects_count = cfg.whitelist.protect.len()
                            + cfg.whitelist.protect_package.len()
                            + cfg.whitelist.protect_ext.len()
                            + cfg.whitelist.protect_mtime.len();
                        (
                            cfg.blacklist.rule.len(),
                            protects_count,
                            cron_count,
                            cfg.settings.engine.low_power,
                            cfg.settings.engine.cpu_affinity.clone(),
                            cfg.settings.webui.bind.clone(),
                            cfg.settings.webui.port,
                            cfg.settings.log.level.clone(),
                        )
                    };
                    ctx.logger.info("daemon", "=== 配置热重载完成 ===");
                    ctx.logger.info(
                        "daemon",
                        &format!("  清理规则  : {} 条 (其中 cron 定时 {} 条)", rules_count, cron_count),
                    );
                    ctx.logger.info(
                        "daemon",
                        &format!("  保护规则  : {} 条", protects_count),
                    );
                    ctx.logger.info(
                        "daemon",
                        &format!("  low_power : {} (cpu_affinity={:?})", low_power, cpu_affinity),
                    );
                    ctx.logger.info(
                        "daemon",
                        &format!("  WebUI     : {}:{}", bind, port),
                    );
                    ctx.logger.info(
                        "daemon",
                        &format!("  日志级别  : {}", log_level),
                    );

                    // 检测引擎配置是否变化 (low_power / cpu_affinity / webui bind/port)
                    let engine_changed = low_power != old_low_power
                        || cpu_affinity != old_cpu_affinity
                        || bind != old_bind
                        || port != old_port;
                    if engine_changed {
                        ctx.logger.info("daemon", "  检测到引擎配置变化, 重新应用低功耗调优 + 重新生成 webroot");
                        // 重新应用低功耗调优 (cpu_affinity / low_power 可能变了)
                        if low_power {
                            let affinity = if cpu_affinity.is_empty() {
                                let cores = sysutil::detect_little_cores();
                                ctx.logger.info(
                                    "daemon",
                                    &format!("  cpu_affinity 为空, 自动探测小核: {:?}", cores),
                                );
                                cores
                            } else {
                                cpu_affinity.clone()
                            };
                            let report = sysutil::apply_low_power(&affinity);
                            ctx.logger.info(
                                "daemon",
                                &format!(
                                    "  重新应用  : nice={} | 绑核 {:?} ({})",
                                    if report.nice_applied { "✓" } else { "✗" },
                                    affinity,
                                    if report.affinity_applied { "✓" } else { "✗" }
                                ),
                            );
                            for e in &report.errors {
                                ctx.logger.warn("daemon", &format!("  调优错误  : {}", e));
                            }
                        } else {
                            ctx.logger.info("daemon", "  low_power=false, 跳过低功耗调优");
                        }
                        // webui bind/port 变了, 重新生成 index.html
                        match webroot::generate_index_html(&bind, port) {
                            Ok(p) => ctx.logger.info(
                                "daemon",
                                &format!("  webroot  : {} 已更新 (http://{}:{})", p.display(), bind, port),
                            ),
                            Err(e) => ctx.logger.warn(
                                "daemon",
                                &format!("  webroot  : 更新失败 (不影响主流程): {}", e),
                            ),
                        }
                    } else {
                        ctx.logger.info("daemon", "  引擎配置无变化 (仅规则/保护列表更新)");
                    }
                    ctx.logger.info("daemon", "=== 配置热重载结束 ===");
                }
                Err(e) => ctx.logger
                    .error("daemon", &format!("配置热重载失败, 保留旧配置: {}", e)),
            }
        }

        // 计算最近的下次 cron 触发
        let next = match compute_next_cron_trigger(&ctx) {
            Ok(n) => n,
            Err(e) => {
                ctx.logger.error("daemon", &format!("计算 cron 触发失败, 30s 后重试: {}", e));
                std::thread::sleep(std::time::Duration::from_secs(30));
                continue;
            }
        };
        match next {
            Some((trigger_at, rule_ids)) => {
                let now = DozeTimer::now_boottime().unwrap_or(Duration::ZERO);
                let delay = trigger_at.saturating_sub(now);
                let delay_secs = delay.as_secs().max(1); // 至少 1s, 防 0 秒 busy-wait
                ctx.logger.info(
                    "daemon",
                    &format!(
                        "下次 cron 触发: {} 秒后, 待执行规则: {:?}",
                        delay_secs, rule_ids
                    ),
                );

                // 等待: timerfd 到期 / 信号 / sleep 兜底
                let timer_fired = if let Some(ref timer) = timer {
                    // arm timerfd (相对时间), 失败退化到 sleep
                    match timer.set_oneshot_duration(Duration::from_secs(delay_secs)) {
                        Ok(()) => {
                            // 等待 timerfd 到期, 最多等 delay_secs + 30s (防 timerfd 不触发卡死)
                            let wait_ms = (delay_secs * 1000 + 30_000) as i32;
                            match timer.wait_timeout(wait_ms) {
                                Ok(Some(_exp)) => true, // timerfd 到期
                                Ok(None) => false,      // 超时
                                Err(e) => {
                                    ctx.logger.warn(
                                        "daemon",
                                        &format!("timer.wait 错误, sleep 兜底: {}", e),
                                    );
                                    std::thread::sleep(Duration::from_secs(delay_secs));
                                    true
                                }
                            }
                        }
                        Err(e) => {
                            ctx.logger.warn(
                                "daemon",
                                &format!("timerfd 设置失败, sleep 兜底: {}", e),
                            );
                            std::thread::sleep(Duration::from_secs(delay_secs));
                            true
                        }
                    }
                } else {
                    // 无 timerfd (创建失败), 纯 sleep 等待
                    std::thread::sleep(Duration::from_secs(delay_secs));
                    true
                };

                if timer_fired {
                    if let Err(e) = run_cron_clean(&ctx, &rule_ids) {
                        ctx.logger.error("daemon", &format!("cron 清理失败, 继续: {}", e));
                    }
                }
            }
            None => {
                // 没有 cron 规则, 等 60s 再查 (或被信号打断)
                ctx.logger
                    .debug("daemon", "无 cron 规则, 等待 60s");
                if let Some(ref timer) = timer {
                    match timer.set_oneshot(60_000) {
                        Ok(()) => {
                            // wait_timeout 失败也无所谓, poll 会等 60s 超时
                            let _ = timer.wait_timeout(60_000);
                        }
                        Err(e) => {
                            ctx.logger.warn(
                                "daemon",
                                &format!("timerfd 设置失败, sleep 60s 兜底: {}", e),
                            );
                            std::thread::sleep(Duration::from_secs(60));
                        }
                    }
                } else {
                    std::thread::sleep(Duration::from_secs(60));
                }
            }
        }
    }

    // 5. 优雅退出
    ctx.logger.info("daemon", "收到退出信号, 优雅退出");
    let _ = ctx.state.save();
    // 更新 module.prop 为"已停止"状态 (保留累计清理数据)
    let snap = ctx.state.snapshot();
    let freed_bytes = snap.totals.total_freed_bytes;
    let files_deleted = snap.totals.total_files_deleted;
    if let Err(e) = module_prop::update_from_state(false, None, files_deleted, freed_bytes) {
        ctx.logger.warn(
            "daemon",
            &format!("退出时 module.prop 更新失败 (不影响主流程): {}", e),
        );
    }
    sysutil::remove_pidfile(&ctx.pidfile);
    ctx.logger.info("daemon", "Tarn daemon 退出");
    Ok(())
}

/// 在 spawn 任何线程之前阻塞 daemon 信号 (SIGHUP/SIGTERM/SIGINT)
///
/// R1 修复: 之前 install_signal_handlers 在 run_daemon 内才调用 pthread_sigmask,
/// 但 logger/webui 线程在 run_daemon_cmd 阶段已 spawn, 未阻塞信号。
/// 外部信号 (tarn reload 的 SIGHUP / tarn stop 的 SIGTERM / config_watcher 的 raise(SIGHUP))
/// 可能被内核投递给这些未阻塞线程, 触发默认动作 (Term) 终止进程, 而非被 sigwait 捕获。
///
/// POSIX 规定: 新线程继承创建者的信号掩码。因此在本函数之后 spawn 的所有线程
/// (logger / webui / tokio worker / signal) 都会继承阻塞掩码,
/// 信号只被 install_signal_handlers 的 sigwait 线程同步捕获。
///
/// 调用时机: run_daemon_cmd 开头, 在 make_logger / spawn webui 之前。
/// 非 daemon 命令 (run/list/doctor) 不调用, Ctrl+C 等仍按默认行为。
pub fn block_daemon_signals() -> Result<()> {
    use std::io;
    unsafe {
        let mut set: libc::sigset_t = std::mem::zeroed();
        libc::sigemptyset(&mut set);
        libc::sigaddset(&mut set, libc::SIGHUP);
        libc::sigaddset(&mut set, libc::SIGTERM);
        libc::sigaddset(&mut set, libc::SIGINT);
        if libc::pthread_sigmask(libc::SIG_BLOCK, &set, std::ptr::null_mut()) != 0 {
            return Err(anyhow!("pthread_sigmask 失败: {}", io::Error::last_os_error()));
        }
    }
    Ok(())
}

/// 安装信号处理器 (SIGHUP/SIGTERM/SIGINT)
///
/// 用独立线程 + libc::sigwait 同步等待信号 (比 signal-hook 简单, 无依赖)
fn install_signal_handlers(
    shutdown: Arc<std::sync::atomic::AtomicBool>,
    reload: Arc<std::sync::atomic::AtomicBool>,
    logger: Arc<AsyncLogger>,
) -> Result<()> {
    use std::io;

    // 阻塞这些信号, 在专用线程里 sigwait
    unsafe {
        let mut set: libc::sigset_t = std::mem::zeroed();
        libc::sigemptyset(&mut set);
        libc::sigaddset(&mut set, libc::SIGHUP);
        libc::sigaddset(&mut set, libc::SIGTERM);
        libc::sigaddset(&mut set, libc::SIGINT);

        // 阻塞当前线程的这些信号
        if libc::pthread_sigmask(libc::SIG_BLOCK, &set, std::ptr::null_mut()) != 0 {
            return Err(anyhow!("pthread_sigmask 失败: {}", io::Error::last_os_error()));
        }
    }

    std::thread::Builder::new()
        .name("tarn-signal".to_string())
        .spawn(move || {
            loop {
                let mut sig: libc::c_int = 0;
                let r = unsafe { libc::sigwait(&sigset_all(), &mut sig) };
                if r != 0 {
                    logger.error("signal", &format!("sigwait 失败: {}", r));
                    std::thread::sleep(Duration::from_secs(1));
                    continue;
                }
                match sig {
                    libc::SIGHUP => {
                        logger.info("signal", "收到 SIGHUP, 请求热重载");
                        reload.store(true, std::sync::atomic::Ordering::SeqCst);
                    }
                    libc::SIGTERM => {
                        logger.info("signal", "收到 SIGTERM, 请求优雅退出");
                        shutdown.store(true, std::sync::atomic::Ordering::SeqCst);
                        break;
                    }
                    libc::SIGINT => {
                        logger.info("signal", "收到 SIGINT, 立即退出");
                        shutdown.store(true, std::sync::atomic::Ordering::SeqCst);
                        break;
                    }
                    _ => {}
                }
            }
        })?;
    Ok(())
}

/// 构造包含 SIGHUP/SIGTERM/SIGINT 的 sigset
fn sigset_all() -> libc::sigset_t {
    unsafe {
        let mut set: libc::sigset_t = std::mem::zeroed();
        libc::sigemptyset(&mut set);
        libc::sigaddset(&mut set, libc::SIGHUP);
        libc::sigaddset(&mut set, libc::SIGTERM);
        libc::sigaddset(&mut set, libc::SIGINT);
        set
    }
}

/// cron 触发的清理 (执行到期的规则)
///
/// 修复 C4: wake_lock 失败降级运行 (不退出 daemon), executor 错误 log 后继续
fn run_cron_clean(ctx: &DaemonContext, rule_ids: &[String]) -> Result<()> {
    ctx.logger
        .info("daemon", &format!("cron 触发, 执行规则: {:?}", rule_ids));
    // 修复 C4: wake_lock 失败不退出 daemon, 降级运行
    // (某些 Android ROM SELinux 策略不允许写 /sys/power/wake_lock, daemon 仍可干活)
    let _wl = match WakeLock::acquire("tarn_cron", 300) {
        Ok(wl) => wl,
        Err(e) => {
            ctx.logger.warn(
                "daemon",
                &format!("wake_lock 获取失败, 降级运行: {}", e),
            );
            // 用一个占位的 noop WakeLock (None 也可, 只是逻辑上表示 \"不持有\")
            // 这里直接用 Option, 但 WakeLock 是 RAII, 用一个虚假的 NoWakeLock
            return run_cron_clean_inner(ctx, rule_ids);
        }
    };
    run_cron_clean_inner(ctx, rule_ids)
}

fn run_cron_clean_inner(ctx: &DaemonContext, rule_ids: &[String]) -> Result<()> {
    // 修复 H6: 锁内只 clone 必要数据, 立即释放锁
    let (settings, blacklist, protect) = {
        let cfg = ctx.config.read();
        (cfg.settings.clone(), cfg.blacklist.clone(), cfg.protect.clone())
    };

    let executor = Executor::new(settings, blacklist, protect)
        .with_logger(ctx.logger.clone());

    let opts = RunOptions {
        dry_run: false,
        trigger: Trigger::Cron,
        rule_filter: Some(rule_ids.to_vec()),
        ..Default::default()
    };

    let result = executor.run(&opts);

    // [v0.2.5] 带轮转检查的 record_run: 达到阈值时归档 totals 并清零
    let (rotate_files, rotate_bytes, keep_rot) = {
        let cfg = ctx.config.read();
        (
            cfg.settings.state.rotate_after_files,
            cfg.settings.state.rotate_after_bytes,
            cfg.settings.state.keep_rotation_history,
        )
    };
    let rotation = ctx.state.record_run_with_rotation(
        &result, rotate_files, rotate_bytes, keep_rot,
    );
    if let Some(ref r) = rotation {
        ctx.logger.info(
            "daemon",
            &format!(
                "=== 统计轮转触发 (reason={}) === 本轮: 删 {} 文件 / 释放 {} / 跑 {} 次. totals 已清零, 开始新一轮统计",
                r.reason,
                r.total_files_deleted,
                module_prop::format_bytes(r.total_freed_bytes),
                r.total_runs,
            ),
        );
    }

    // 清理后更新 module.prop description (累计数据变了, 管理器列表实时显示)
    let snap = ctx.state.snapshot();
    let freed_bytes = snap.totals.total_freed_bytes;
    let files_deleted = snap.totals.total_files_deleted;
    let pid = sysutil::current_pid() as u32;
    if let Err(e) = module_prop::update_from_state(true, Some(pid), files_deleted, freed_bytes) {
        ctx.logger.warn(
            "daemon",
            &format!("清理后 module.prop 更新失败 (不影响主流程): {}", e),
        );
    }

    ctx.logger.info(
        "daemon",
        &format!(
            "cron 清理完成: 删={} 释放={}B 耗时={}ms (累计已清理 {} / 删 {} 文件)",
            result.files_deleted, result.freed_bytes, result.duration_ms,
            module_prop::format_bytes(freed_bytes), files_deleted
        ),
    );
    Ok(())
}

/// 扫描所有 cron 规则, 计算最近的下次触发时间
///
/// 返回 (触发时刻 boottime Duration, 触发的 rule_ids)
fn compute_next_cron_trigger(ctx: &DaemonContext) -> Result<Option<(Duration, Vec<String>)>> {
    let cfg = ctx.config.read();
    let now = crate::timeutil::now_cst();

    let mut earliest: Option<chrono::DateTime<chrono::FixedOffset>> = None;
    let mut triggered_rules: Vec<String> = Vec::new();

    for rule in &cfg.blacklist.rule {
        if !rule.enabled {
            continue;
        }
        // 只看 trigger.on 包含 "cron" 的规则
        if !rule.trigger.on.iter().any(|t| t == "cron") {
            continue;
        }
        // 修复 H5: 用 RuleTrigger::get_cron_expr 取表达式
        // 优先 cron_expr 字段, 回退解析 on 中的 "cron:<expr>" (向后兼容旧配置)
        let expr = match rule.trigger.get_cron_expr() {
            Some(e) => e,
            None => {
                ctx.logger.debug(
                    "daemon",
                    &format!("规则 {} 标记为 cron 但未提供 cron_expr, 跳过", rule.id),
                );
                continue;
            }
        };

        let schedule = match CronSchedule::parse(expr) {
            Ok(s) => s,
            Err(e) => {
                ctx.logger.warn(
                    "daemon",
                    &format!("规则 {} cron 表达式非法 '{}': {}", rule.id, expr, e),
                );
                continue;
            }
        };

        match schedule.next_after(now) {
            Some(next) => {
                match earliest {
                    Some(e) if e <= next => {} // 保留更早的
                    _ => {
                        earliest = Some(next);
                        triggered_rules = vec![rule.id.clone()];
                    }
                }
                // 同时点触发的规则合并
                if let Some(e) = &earliest {
                    if *e == next && !triggered_rules.contains(&rule.id) {
                        triggered_rules.push(rule.id.clone());
                    }
                }
            }
            None => {
                ctx.logger
                    .warn("daemon", &format!("规则 {} cron 无法算出下次触发", rule.id));
            }
        }
    }

    match earliest {
        Some(t) => {
            let diff = t.signed_duration_since(now);
            let secs = diff.num_seconds().max(0) as u64;
            // 转换为 boottime 域: 当前 boottime + secs
            let now_boottime = DozeTimer::now_boottime().unwrap_or(Duration::ZERO);
            Ok(Some((now_boottime + Duration::from_secs(secs), triggered_rules)))
        }
        None => Ok(None),
    }
}

/// 发送信号到 daemon (CLI tarn reload / stop 用)
pub fn signal_daemon(pidfile: &Path, sig: i32) -> Result<()> {
    let pid = sysutil::read_pidfile(pidfile)
        .ok_or_else(|| anyhow!("pidfile 不存在或为空: {}", pidfile.display()))?;
    if !sysutil::pid_alive(pid) {
        return Err(anyhow!("pid {} 不存活", pid));
    }
    if !sysutil::pid_cmdline_contains(pid, "tarn") {
        return Err(anyhow!("pid {} 不是 tarn 进程 (PID 复用?)", pid));
    }
    let r = unsafe { libc::kill(pid, sig) };
    if r != 0 {
        return Err(anyhow!("kill 失败: {}", std::io::Error::last_os_error()));
    }
    Ok(())
}
