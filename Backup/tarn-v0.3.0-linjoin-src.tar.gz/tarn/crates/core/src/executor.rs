//! 执行器: 两阶段 (先标记后删) + 批量 unlinkat + 审计日志 + 自适应限速
//!
//! 基于 RESEARCH-4 / RESEARCH-3 调研结论:
//! - unlinkat 比 unlink 快: 传父目录 fd + 文件名, 省一次 path 解析
//! - 批量删: 用 unlinkat(dirfd, name, 0) 配合 openat 父目录复用 fd
//! - 审计日志: 每删一个文件记录 (path, size, mtime, rule_id, ts) 到审计 log
//! - 自适应限速: 检测前台 App 是否忙 (读 /proc/loadavg), 忙才限速
//! - dry-run: 不真删, 只统计 + 输出审计
//! - 保护检查: 每个文件删前再查一次 ProtectSet (事中防护)

use crate::config::{Blacklist, Rule, Settings, Target};
use crate::logger::AsyncLogger;
use crate::matcher::Matcher;
use crate::protect::ProtectSet;
use crate::walker::{walk_parallel, DirEntry, FileType, WalkOptions};
use crossbeam_channel::bounded;
use parking_lot::Mutex;
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime};
use uuid::Uuid;

// ============================================================
// 触发方式与运行选项
// ============================================================

/// 触发方式
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Trigger {
    Boot,
    Manual,
    Cron,
    Event,
}

impl Default for Trigger {
    fn default() -> Self {
        Trigger::Manual
    }
}

impl Trigger {
    pub fn as_str(&self) -> &'static str {
        match self {
            Trigger::Boot => "boot",
            Trigger::Manual => "manual",
            Trigger::Cron => "cron",
            Trigger::Event => "event",
        }
    }
}

/// 运行选项
///
/// 设计哲学 (v2):
/// 唯一的安全栅栏是 `dry_run` —— 默认 true 时仅扫描统计不真删, 取消勾选才真删。
/// 所有 `enabled = true` 的规则一律执行, 不再用 risk 字段做拦截
/// (旧 risk 字段保留仅为向后兼容 toml, 不再控制执行)。
#[derive(Debug, Clone, Default)]
pub struct RunOptions {
    /// 唯一安全栅栏: true = 仅预览不真删, false = 真删
    pub dry_run: bool,
    pub trigger: Trigger,
    pub json: bool,
    pub verbose: bool,
    /// 仅跑这些 rule id
    pub rule_filter: Option<Vec<String>>,
    /// 最大执行时长 (秒), 0=不限
    pub timeout_sec: u64,
}

// ============================================================
// 结果结构
// ============================================================

/// 单条规则执行结果
#[derive(Debug, Clone, Default)]
pub struct RuleResult {
    pub rule_id: String,
    pub rule_name: String,
    pub status: RuleStatus,
    pub freed_bytes: u64,
    pub files_deleted: u64,
    pub files_blocked: u64,
    pub files_skipped: u64,
    pub files_scanned: u64,
    /// 清理的空目录数 (clean_empty_dirs 开启时填)
    pub dirs_removed: u64,
    /// 跳过的非空目录数 (统计用, 不算错误)
    pub dirs_skipped: u64,
    pub duration_ms: u64,
    pub targets_count: usize,
    pub error: Option<String>,
    /// 审计: 删除的文件路径 (前 N 条, 防内存爆)
    pub deleted_samples: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum RuleStatus {
    #[default]
    Ok,
    Skipped,
    Failed,
    Blocked,
}

impl RuleStatus {
    pub fn as_str(&self) -> &'static str {
        match self {
            RuleStatus::Ok => "ok",
            RuleStatus::Skipped => "skipped",
            RuleStatus::Failed => "failed",
            RuleStatus::Blocked => "blocked",
        }
    }
}

/// 整体运行结果
#[derive(Debug, Clone, Default)]
pub struct RunResult {
    pub run_id: String,
    pub trigger: String,
    pub ts_start: String,
    pub ts_end: String,
    pub dry_run: bool,
    pub rules_planned: u64,
    pub rules_executed: u64,
    pub rules_failed: u64,
    pub rules_skipped: u64,
    pub freed_bytes: u64,
    pub files_deleted: u64,
    pub files_blocked: u64,
    pub files_scanned: u64,
    /// 全局清理的空目录总数
    pub dirs_removed: u64,
    pub duration_ms: u64,
    pub exit_code: i32,
    pub rules: Vec<RuleResult>,
    /// 完整审计路径列表 (verbose 或 dry-run 时填)
    ///
    /// 修复 C6: 长度上限 MAX_AUDIT_TRAIL (默认 10000), 超过后只增加 audit_dropped_count
    /// 避免扫描百万文件时 OOM
    pub audit_trail: Vec<AuditEntry>,
    /// 因上限被丢弃的审计条目数
    pub audit_dropped: u64,
}

/// 审计条目上限 (修复 C6)
///
/// 10000 条 × ~300 字节 ≈ 3MB, 远低于 daemon 内存预算。
/// 超出的条目计入 audit_dropped, 不留在内存。
pub const MAX_AUDIT_TRAIL: usize = 10000;

/// 审计条目 (每次删除/拦截一条)
#[derive(Debug, Clone, serde::Serialize)]
pub struct AuditEntry {
    pub action: String, // delete | block | skip | rmdir | rmdir_skip
    pub path: String,
    pub size: u64,
    pub rule_id: String,
    pub reason: Option<String>,
    pub ts: String,
}

// ============================================================
// 执行器
// ============================================================

/// 执行器
pub struct Executor {
    settings: Settings,
    blacklist: Blacklist,
    protect: ProtectSet,
    logger: Option<Arc<AsyncLogger>>,
}

impl Executor {
    pub fn new(settings: Settings, blacklist: Blacklist, protect: ProtectSet) -> Self {
        Self {
            settings,
            blacklist,
            protect,
            logger: None,
        }
    }

    /// 注入异步日志器
    pub fn with_logger(mut self, logger: Arc<AsyncLogger>) -> Self {
        self.logger = Some(logger);
        self
    }

    /// 执行清理 (主入口)
    pub fn run(&self, opts: &RunOptions) -> RunResult {
        let run_id = Uuid::new_v4().to_string();
        let ts_start = now_iso();
        let start = Instant::now();

        // 应用低功耗调优 (nice 19 + 绑小核), 在执行线程上
        // [v0.1.11] 恢复 sched_setaffinity (CPU 亲和性), apply_low_power 内部会
        // 遍历 /proc/self/task 对所有线程设亲和性, 修复 per-thread 遗漏问题。
        // cpu_affinity 为空时自动探测小核。
        // [v0.2.1] ionice IDLE 已移除 (CFQ 调度器内核 5.x 已删, Android 的
        // mq-deadline/none/kyber 调度器忽略 ioprio, 是空操作)。
        // apply_low_power 返回 LowPowerReport, 此处仅记录错误项。
        if self.settings.engine.low_power {
            let affinity = if self.settings.engine.cpu_affinity.is_empty() {
                crate::sysutil::detect_little_cores()
            } else {
                self.settings.engine.cpu_affinity.clone()
            };
            let report = crate::sysutil::apply_low_power(&affinity);
            for e in &report.errors {
                if let Some(log) = &self.logger {
                    log.warn("executor", &format!("低功耗调优部分失败: {}", e));
                }
            }
        }

        let mut result = RunResult {
            run_id: run_id.clone(),
            trigger: opts.trigger.as_str().to_string(),
            ts_start: ts_start.clone(),
            dry_run: opts.dry_run,
            ..Default::default()
        };

        if let Some(log) = &self.logger {
            log.info(
                "executor",
                &format!(
                    "run 开始 id={} trigger={} dry_run={}",
                    run_id, opts.trigger.as_str(), opts.dry_run
                ),
            );
        }

        // 1. 过滤规则
        let rules: Vec<&Rule> = self
            .blacklist
            .rule
            .iter()
            .filter(|r| r.enabled)
            .filter(|r| {
                if let Some(filter) = &opts.rule_filter {
                    filter.iter().any(|f| f == &r.id)
                } else {
                    true
                }
            })
            .filter(|r| {
                // 触发方式匹配
                match opts.trigger {
                    Trigger::Boot => r.trigger.on.iter().any(|t| t == "boot"),
                    Trigger::Cron => r.trigger.on.iter().any(|t| t == "cron"),
                    Trigger::Event => r.trigger.on.iter().any(|t| t == "event"),
                    Trigger::Manual => true, // manual 跑所有 enabled
                }
            })
            // v2: 移除 risk 过滤 —— 用户写完规则就必须能执行, dry_run 是唯一兜底
            .collect();

        result.rules_planned = rules.len() as u64;

        // 2. 按 priority 降序 (高优先先删)
        let mut rules_sorted = rules.clone();
        rules_sorted.sort_by(|a, b| b.priority.cmp(&a.priority));

        // 3. 逐条执行
        for rule in rules_sorted {
            // 检查超时
            if opts.timeout_sec > 0 && start.elapsed().as_secs() >= opts.timeout_sec {
                if let Some(log) = &self.logger {
                    log.warn("executor", "全局超时, 中止后续规则");
                }
                break;
            }

            // 检查 min_free_mb (磁盘剩余空间足够才跑)
            if rule.trigger.min_free_mb > 0 {
                if let Some(free) = get_free_bytes(&rule.targets.first().map(|t| t.path.clone()).unwrap_or_default()) {
                    if free / (1024 * 1024) >= rule.trigger.min_free_mb {
                        // 剩余空间充足, 跳过此规则
                        let rr = RuleResult {
                            rule_id: rule.id.clone(),
                            rule_name: rule.name.clone(),
                            status: RuleStatus::Skipped,
                            targets_count: rule.targets.len(),
                            ..Default::default()
                        };
                        result.rules_skipped += 1;
                        result.rules.push(rr);
                        continue;
                    }
                }
            }

            let rule_result = self.run_rule(rule, opts, &mut result.audit_trail);
            result.rules_executed += 1;
            if rule_result.status == RuleStatus::Failed {
                result.rules_failed += 1;
            }
            result.freed_bytes += rule_result.freed_bytes;
            result.files_deleted += rule_result.files_deleted;
            result.files_blocked += rule_result.files_blocked;
            result.files_scanned += rule_result.files_scanned;
            // 累加空目录清理数
            result.dirs_removed += rule_result.dirs_removed;
            result.rules.push(rule_result);
        }

        result.duration_ms = start.elapsed().as_millis() as u64;
        result.ts_end = now_iso();
        result.exit_code = if result.rules_failed > 0 { 1 } else { 0 };

        // 修复 C6: 计算 audit_dropped (超出 MAX_AUDIT_TRAIL 被丢弃的条目数)
        // 期望条目数 = files_deleted + files_blocked + (files_skipped if verbose/dry_run)
        // 实际 = audit_trail.len()
        // rmdir / rmdir_skip 也算入 expected (verbose/dry_run 时审计)
        if opts.verbose || opts.dry_run {
            let skipped: u64 = result.rules.iter().map(|r| r.files_skipped + r.dirs_skipped).sum();
            let expected = result.files_deleted + result.files_blocked + skipped + result.dirs_removed;
            let actual = result.audit_trail.len() as u64;
            result.audit_dropped = expected.saturating_sub(actual);
        }

        if let Some(log) = &self.logger {
            log.info(
                "executor",
                &format!(
                    "run 结束 id={} 删除={} 空目录={} 释放={}B 耗时={}ms",
                    result.run_id,
                    result.files_deleted,
                    result.dirs_removed,
                    result.freed_bytes,
                    result.duration_ms
                ),
            );
        }

        result
    }

    /// 执行单条规则
    fn run_rule(
        &self,
        rule: &Rule,
        opts: &RunOptions,
        audit: &mut Vec<AuditEntry>,
    ) -> RuleResult {
        let start = Instant::now();
        let mut rr = RuleResult {
            rule_id: rule.id.clone(),
            rule_name: rule.name.clone(),
            targets_count: rule.targets.len(),
            ..Default::default()
        };

        if let Some(log) = &self.logger {
            log.info(
                "executor",
                &format!("规则开始: {} ({})", rule.id, rule.name),
            );
        }

        // 修复 H1: 每个 target 独立编译 Matcher (避免 target A 的 exclude 作用于 target B)
        // 预编译所有 target 的 matcher, 后续遍历使用对应 matcher
        let target_matchers: Vec<(usize, Matcher)> = {
            let mut result = Vec::with_capacity(rule.targets.len());
            for (idx, target) in rule.targets.iter().enumerate() {
                let include = vec![format!("{}/{}", target.path.trim_end_matches('/'), target.glob)];
                // exclude 仅作用于本 target
                let exclude: Vec<String> = target.exclude.iter().cloned().collect();
                match Matcher::new(&include, &exclude) {
                    Ok(m) => result.push((idx, m)),
                    Err(e) => {
                        rr.status = RuleStatus::Failed;
                        rr.error = Some(format!("target[{}] matcher 编译失败: {}", idx, e));
                        rr.duration_ms = start.elapsed().as_millis() as u64;
                        if let Some(log) = &self.logger {
                            log.error("executor", &format!("规则 {} target[{}] matcher 失败: {}", rule.id, idx, e));
                        }
                        return rr;
                    }
                }
            }
            result
        };

        // 遍历每个 target, 用其专属 matcher
        for (idx, target) in rule.targets.iter().enumerate() {
            // 找到对应 matcher
            let matcher = target_matchers.iter().find(|(i, _)| *i == idx).map(|(_, m)| m);
            if let Some(m) = matcher {
                self.run_target(rule, target, m, opts, &mut rr, audit);
            }
        }

        rr.duration_ms = start.elapsed().as_millis() as u64;
        rr.status = if rr.error.is_some() {
            RuleStatus::Failed
        } else if rr.files_deleted > 0 || rr.dirs_removed > 0 || opts.dry_run {
            RuleStatus::Ok
        } else {
            RuleStatus::Skipped
        };

        if let Some(log) = &self.logger {
            log.info(
                "executor",
                &format!(
                    "规则结束: {} 删={} 拦={} 跳={} 空目录={} 释放={}B 耗时={}ms",
                    rule.id,
                    rr.files_deleted,
                    rr.files_blocked,
                    rr.files_skipped,
                    rr.dirs_removed,
                    rr.freed_bytes,
                    rr.duration_ms
                ),
            );
        }

        rr
    }

    /// 执行单个 target
    fn run_target(
        &self,
        rule: &Rule,
        target: &Target,
        matcher: &Matcher,
        opts: &RunOptions,
        rr: &mut RuleResult,
        audit: &mut Vec<AuditEntry>,
    ) {
        let path = Path::new(&target.path);
        if !path.exists() {
            // 修复: 路径不存在不再静默返回, 记录到 error + 审计 + 日志, 方便用户排查
            // 之前行为: 静默 return, 规则显示"成功执行"但实际啥也没干, 用户无法排查
            let msg = format!("target 路径不存在: {}", target.path);
            if let Some(log) = &self.logger {
                log.warn("executor", &msg);
            }
            push_audit_capped(audit, AuditEntry {
                action: "skip".to_string(),
                path: target.path.clone(),
                size: 0,
                rule_id: rr.rule_id.clone(),
                reason: Some("path_not_exist".to_string()),
                ts: now_iso(),
            });
            // 不设 error (路径不存在不算规则失败, 可能是 App 卸载后缓存目录消失, 正常情况)
            // 但记到 files_skipped 让用户在统计里看到
            rr.files_skipped += 1;
            return;
        }

        let walk_opts = WalkOptions {
            follow_symlink: self.settings.engine.walk_follow_symlink,
            max_depth: self.settings.engine.walk_max_depth,
            skip_hidden: self.settings.engine.walk_skip_hidden,
            parallel_workers: self.settings.engine.parallel_workers,
            channel_capacity: 1024,
            skip_dirs: HashSet::new(),
            use_getdents: self.settings.engine.use_getdents,
            buf_size: 32 * 1024,
        };

        // 流式遍历 + 匹配 + 删除
        let (tx, rx) = bounded::<DirEntry>(walk_opts.channel_capacity);

        // walker 线程
        let root = path.to_path_buf();
        let walk_opts_clone = walk_opts.clone();
        let walker_handle = std::thread::spawn(move || {
            walk_parallel(&root, &walk_opts_clone, tx);
        });

        // 自适应限速器 (前台忙才限)
        let rate_limiter = AdaptiveRateLimiter::new(
            self.settings.engine.io_throttle_ops_per_sec,
            self.settings.engine.io_throttle_bytes_per_sec,
            self.settings.run.adaptive_rate_limit,
        );

        // 消费线程 (当前线程)
        let batch_size = self.settings.engine.batch_size.max(1);
        let mut batch: Vec<DirEntry> = Vec::with_capacity(batch_size);
        let use_unlinkat = self.settings.engine.use_unlinkat;

        for entry in rx.iter() {
            if entry.file_type != FileType::File {
                continue;
            }
            rr.files_scanned += 1;

            // glob 匹配 (路径相对 target)
            if !matcher.matches(&entry.path) {
                continue;
            }

            // older_than_days 过滤
            if target.older_than_days > 0 {
                let now = SystemTime::now()
                    .duration_since(SystemTime::UNIX_EPOCH)
                    .map(|d| d.as_secs() as i64)
                    .unwrap_or(0);
                let age_days = (now - entry.mtime) / 86400;
                if age_days < target.older_than_days as i64 {
                    rr.files_skipped += 1;
                    if opts.verbose || opts.dry_run {
                        push_audit_capped(audit, AuditEntry {
                            action: "skip".to_string(),
                            path: entry.path.to_string_lossy().to_string(),
                            size: entry.size,
                            rule_id: rr.rule_id.clone(),
                            reason: Some(format!("too_young:{}d", age_days)),
                            ts: now_iso(),
                        });
                    }
                    continue;
                }
            }

            // min_size_kb 过滤
            // R9 修复: 之前不审计, 导致 audit_dropped 计算 (expected = deleted+blocked+skipped)
            // 虚高。改为与 path_not_exist / too_young 一致, 在 verbose/dry_run 时审计。
            if target.min_size_kb > 0 && entry.size < target.min_size_kb * 1024 {
                rr.files_skipped += 1;
                if opts.verbose || opts.dry_run {
                    push_audit_capped(audit, AuditEntry {
                        action: "skip".to_string(),
                        path: entry.path.to_string_lossy().to_string(),
                        size: entry.size,
                        rule_id: rr.rule_id.clone(),
                        reason: Some(format!("too_small:{}KB", target.min_size_kb)),
                        ts: now_iso(),
                    });
                }
                continue;
            }

            // 保护检查 (事中防护, 每文件必查)
            let mtime = SystemTime::UNIX_EPOCH + Duration::from_secs(entry.mtime.max(0) as u64);
            if let Some(reason) = self.protect.check(&entry.path, Some(mtime)) {
                rr.files_blocked += 1;
                if opts.verbose || opts.dry_run {
                    push_audit_capped(audit, AuditEntry {
                        action: "block".to_string(),
                        path: entry.path.to_string_lossy().to_string(),
                        size: entry.size,
                        rule_id: rr.rule_id.clone(),
                        reason: Some(reason.to_string()),
                        ts: now_iso(),
                    });
                }
                continue;
            }

            // 加入待删批次
            batch.push(entry);

            // 攒够 batch_size 就批量删
            if batch.len() >= batch_size {
                self.execute_batch(&batch, opts, use_unlinkat, rr, audit, &rate_limiter);
                batch.clear();
            }
        }

        // 处理剩余
        if !batch.is_empty() {
            self.execute_batch(&batch, opts, use_unlinkat, rr, audit, &rate_limiter);
            batch.clear();
        }

        let _ = walker_handle.join();

        // 空目录清理 (clean_empty_dirs)
        // 三态语义: target.clean_empty_dirs (Some) 覆盖 rule.clean_empty_dirs (默认)
        let do_clean_dirs = target.clean_empty_dirs.unwrap_or(rule.clean_empty_dirs);
        if do_clean_dirs {
            let include_root = target
                .clean_empty_dirs_include_root
                .unwrap_or(rule.clean_empty_dirs_include_root);
            let max_depth = target
                .clean_empty_dirs_max_depth
                .unwrap_or(rule.clean_empty_dirs_max_depth);
            self.clean_empty_dirs(path, include_root, max_depth, opts, rr, audit);
        }
    }

    /// 自底向上递归清理空目录
    ///
    /// 算法:
    /// 1. 后序 DFS: 先递归子目录, 再处理当前目录
    /// 2. 检查当前目录是否为空 (read_dir 返回 0 条)
    /// 3. 空目录: 经 ProtectSet 校验后 rmdir, 计入 dirs_removed + 审计
    /// 4. 非空: 跳过, 计入 dirs_skipped
    ///
    /// 边界:
    /// - `include_root = false` (默认): 不删 target.path 本身 (App 数据根目录可能仍在使用)
    /// - `include_root = true`: 若 target.path 也变空则连它一起删 (慎用, 仅适合临时目录)
    /// - 不向上跨越 target.path (避免误删 /data/data/com.foo 等 App 包目录)
    /// - 不跟随符号链接 (避免删到 /system 等系统目录)
    /// - 受 ProtectSet 约束 (受保护的目录不删)
    /// - `max_depth > 0` 时只清理深度 <= max_depth 的目录 (0 = 不限)
    /// - dry_run 模式下只统计不真删
    /// - IO 错误 (EACCES/ENOTDIR 等) 静默跳过, 不影响主流程
    fn clean_empty_dirs(
        &self,
        root_dir: &Path,
        include_root: bool,
        max_depth: u32,
        opts: &RunOptions,
        rr: &mut RuleResult,
        audit: &mut Vec<AuditEntry>,
    ) {
        // root_dir 不存在 / 不是目录, 直接返回
        if !root_dir.is_dir() {
            return;
        }

        // 后序 DFS 递归清理
        // 收集所有目录 (后序: 先 push 父, 处理时先递归子)
        // 简化实现: 先 BFS 收集所有目录路径, 再按深度倒序处理 (深的先删)
        let mut all_dirs: Vec<(PathBuf, usize)> = Vec::new();
        // 用栈做迭代 DFS 避免递归过深栈溢出 (Android 某些 App 目录树可能很深)
        let mut visit_stack: Vec<(PathBuf, usize)> = vec![(root_dir.to_path_buf(), 0)];
        while let Some((dir, depth)) = visit_stack.pop() {
            // 防御性深度上限 (与 max_depth 解耦, 避免符号链接环导致无限递归)
            if depth > 64 {
                continue;
            }
            all_dirs.push((dir.clone(), depth));
            // 读子目录 (不跟随 symlink)
            match std::fs::read_dir(&dir) {
                Ok(rd) => {
                    for entry in rd.flatten() {
                        // 仅对真实目录 (非 symlink) 递归
                        let ft = match entry.file_type() {
                            Ok(ft) => ft,
                            Err(_) => continue,
                        };
                        if ft.is_dir() {
                            visit_stack.push((entry.path(), depth + 1));
                        }
                    }
                }
                Err(_) => {
                    // 读不了 (权限/EACCES), 跳过此目录的子树
                    continue;
                }
            }
        }

        // 按深度倒序 (深的先处理), 这样删完子目录后父目录可能变空
        all_dirs.sort_by(|a, b| b.1.cmp(&a.1));

        let root_canonical = root_dir.to_path_buf();
        for (dir, depth) in all_dirs {
            // max_depth 限制: 0 = 不限, N = 只清理深度 <= N 的目录
            // (root_dir 自身是深度 0, 其直接子目录是深度 1)
            if max_depth > 0 && depth > max_depth as usize {
                continue;
            }

            // include_root = false (默认): 跳过 target.path 本身 (App 数据根目录, 不删)
            // include_root = true: 若 target.path 也空则连它一起删 (慎用)
            if !include_root && dir == root_canonical {
                continue;
            }

            // 读目录检查是否为空
            let is_empty = match std::fs::read_dir(&dir) {
                Ok(mut rd) => rd.next().is_none(),
                Err(_) => {
                    // 读失败, 跳过 (可能 rmdir 也会失败)
                    continue;
                }
            };

            if !is_empty {
                rr.dirs_skipped += 1;
                if opts.verbose || opts.dry_run {
                    push_audit_capped(audit, AuditEntry {
                        action: "rmdir_skip".to_string(),
                        path: dir.to_string_lossy().to_string(),
                        size: 0,
                        rule_id: rr.rule_id.clone(),
                        reason: Some("not_empty".to_string()),
                        ts: now_iso(),
                    });
                }
                continue;
            }

            // 保护检查: 目录路径受 ProtectSet 约束则不删
            // (protect 主要保护文件, 但保护目录前缀等于保护其下所有内容,
            //  目录本身被保护时也不应删, 否则破坏 App 期望的目录结构)
            if let Some(reason) = self.protect.check(&dir, None) {
                rr.dirs_skipped += 1;
                if opts.verbose || opts.dry_run {
                    push_audit_capped(audit, AuditEntry {
                        action: "rmdir_skip".to_string(),
                        path: dir.to_string_lossy().to_string(),
                        size: 0,
                        rule_id: rr.rule_id.clone(),
                        reason: Some(format!("protected:{}", reason)),
                        ts: now_iso(),
                    });
                }
                continue;
            }

            if opts.dry_run {
                rr.dirs_removed += 1;
                push_audit_capped(audit, AuditEntry {
                    action: "rmdir_dry".to_string(),
                    path: dir.to_string_lossy().to_string(),
                    size: 0,
                    rule_id: rr.rule_id.clone(),
                    reason: None,
                    ts: now_iso(),
                });
            } else {
                // 真删: std::fs::remove_dir (非 remove_dir_all, 仅删空目录)
                match std::fs::remove_dir(&dir) {
                    Ok(()) => {
                        rr.dirs_removed += 1;
                        if opts.verbose {
                            push_audit_capped(audit, AuditEntry {
                                action: "rmdir".to_string(),
                                path: dir.to_string_lossy().to_string(),
                                size: 0,
                                rule_id: rr.rule_id.clone(),
                                reason: None,
                                ts: now_iso(),
                            });
                        }
                    }
                    Err(e) => {
                        // 删失败 (常见: ENOTEMPTY 竞态 — 刚检查完空, 别的进程又写入了;
                        // 或 EACCES 权限; 或 EBUSY mount point)
                        rr.dirs_skipped += 1;
                        if let Some(log) = &self.logger {
                            log.debug(
                                "executor",
                                &format!("rmdir 失败 {}: {}", dir.display(), e),
                            );
                        }
                    }
                }
            }
        }
    }

    /// 批量执行删除 (unlinkat 优先, 失败回退 unlink)
    fn execute_batch(
        &self,
        batch: &[DirEntry],
        opts: &RunOptions,
        use_unlinkat: bool,
        rr: &mut RuleResult,
        audit: &mut Vec<AuditEntry>,
        rate_limiter: &AdaptiveRateLimiter,
    ) {
        for entry in batch {
            // 限速
            rate_limiter.wait(entry.size);

            if opts.dry_run {
                rr.freed_bytes += entry.size;
                rr.files_deleted += 1;
                if rr.deleted_samples.len() < 100 {
                    rr.deleted_samples.push(entry.path.to_string_lossy().to_string());
                }
                push_audit_capped(audit, AuditEntry {
                    action: "delete_dry".to_string(),
                    path: entry.path.to_string_lossy().to_string(),
                    size: entry.size,
                    rule_id: rr.rule_id.clone(),
                    reason: None,
                    ts: now_iso(),
                });
                continue;
            }

            // 真删: 优先 unlinkat, 失败回退 std::fs::remove_file
            let deleted = if use_unlinkat {
                unlinkat_file(&entry.path)
            } else {
                std::fs::remove_file(&entry.path).is_ok()
            };

            if deleted {
                rr.freed_bytes += entry.size;
                rr.files_deleted += 1;
                if rr.deleted_samples.len() < 100 {
                    rr.deleted_samples.push(entry.path.to_string_lossy().to_string());
                }
                if opts.verbose {
                    push_audit_capped(audit, AuditEntry {
                        action: "delete".to_string(),
                        path: entry.path.to_string_lossy().to_string(),
                        size: entry.size,
                        rule_id: rr.rule_id.clone(),
                        reason: None,
                        ts: now_iso(),
                    });
                }
            } else {
                rr.files_skipped += 1;
                if let Some(log) = &self.logger {
                    log.warn(
                        "executor",
                        &format!("删除失败: {}", entry.path.display()),
                    );
                }
            }
        }
    }
}

// ============================================================
// unlinkat 辅助
// ============================================================

/// 用 unlinkat 删文件 (比 unlink 快: 父目录 fd + 文件名)
///
/// 内部: openat 父目录 → unlinkat(dirfd, name, 0)
/// 失败回退 std::fs::remove_file
fn unlinkat_file(path: &Path) -> bool {
    use std::os::unix::fs::OpenOptionsExt;
    use std::os::unix::io::AsRawFd;

    let parent = match path.parent() {
        Some(p) => p,
        None => return std::fs::remove_file(path).is_ok(),
    };
    let file_name = match path.file_name() {
        Some(n) => n,
        None => return std::fs::remove_file(path).is_ok(),
    };

    // openat 父目录 (O_DIRECTORY | O_CLOEXEC | O_PATH 更省权限)
    let dir = match std::fs::OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_DIRECTORY | libc::O_CLOEXEC)
        .open(parent)
    {
        Ok(d) => d,
        Err(_) => return std::fs::remove_file(path).is_ok(),
    };
    let dirfd = dir.as_raw_fd();

    let cstr = match std::ffi::CString::new(file_name.as_encoded_bytes()) {
        Ok(c) => c,
        Err(_) => return std::fs::remove_file(path).is_ok(),
    };

    // unlinkat(dirfd, name, 0) — 0 = 删文件 (AT_REMOVEDIR 才删目录)
    let r = unsafe { libc::unlinkat(dirfd, cstr.as_ptr(), 0) };
    if r == 0 {
        true
    } else {
        // 回退
        std::fs::remove_file(path).is_ok()
    }
}

// ============================================================
// 自适应限速器
// ============================================================

/// 自适应限速器: 前台忙才限速, 空闲时全速
///
/// 策略:
/// - 读 /proc/loadavg, 1 分钟负载 > CPU 核数 * 0.7 视为"忙"
/// - 忙时按 ops_per_sec / bytes_per_sec 限速
/// - 空闲时全速
struct AdaptiveRateLimiter {
    ops_per_sec: u64,
    bytes_per_sec: u64,
    adaptive: bool,
    last_check: Mutex<Instant>,
    ops_this_sec: Mutex<u64>,
    bytes_this_sec: Mutex<u64>,
}

impl AdaptiveRateLimiter {
    fn new(ops_per_sec: u64, bytes_per_sec: u64, adaptive: bool) -> Self {
        Self {
            ops_per_sec,
            bytes_per_sec,
            adaptive,
            last_check: Mutex::new(Instant::now()),
            ops_this_sec: Mutex::new(0),
            bytes_this_sec: Mutex::new(0),
        }
    }

    /// 判断前台是否忙
    fn is_foreground_busy() -> bool {
        if let Ok(s) = std::fs::read_to_string("/proc/loadavg") {
            let parts: Vec<&str> = s.split_whitespace().collect();
            if let Some(load_str) = parts.first() {
                if let Ok(load) = load_str.parse::<f64>() {
                    let cpus = std::thread::available_parallelism()
                        .map(|n| n.get() as f64)
                        .unwrap_or(4.0);
                    return load > cpus * 0.7;
                }
            }
        }
        false
    }

    /// 等待 (如需限速)
    fn wait(&self, bytes: u64) {
        if self.ops_per_sec == 0 && self.bytes_per_sec == 0 {
            return;
        }
        // adaptive 模式: 空闲时全速
        if self.adaptive && !Self::is_foreground_busy() {
            return;
        }

        let now = Instant::now();
        let mut last = self.last_check.lock();
        let elapsed = now.duration_since(*last);

        // 每秒重置计数
        if elapsed >= Duration::from_secs(1) {
            *last = now;
            *self.ops_this_sec.lock() = 0;
            *self.bytes_this_sec.lock() = 0;
        }

        // 检查 ops 限制
        if self.ops_per_sec > 0 {
            let mut ops = self.ops_this_sec.lock();
            if *ops >= self.ops_per_sec {
                // 等到下一秒
                let wait = Duration::from_secs(1).saturating_sub(elapsed);
                std::thread::sleep(wait);
                *last = Instant::now();
                *ops = 0;
                *self.bytes_this_sec.lock() = 0;
            }
            *ops += 1;
        }

        // 检查 bytes 限制
        if self.bytes_per_sec > 0 {
            let mut b = self.bytes_this_sec.lock();
            if *b + bytes > self.bytes_per_sec {
                let wait = Duration::from_secs(1).saturating_sub(elapsed);
                std::thread::sleep(wait);
                *last = Instant::now();
                *b = 0;
                *self.ops_this_sec.lock() = 0;
            }
            *b += bytes;
        }
    }
}

// ============================================================
// 工具函数
// ============================================================

/// 获取指定路径所在分区的剩余空间
fn get_free_bytes(path: &str) -> Option<u64> {
    let p = if path.is_empty() { "/" } else { path };
    let cstr = std::ffi::CString::new(p).ok()?;
    let mut buf: libc::statvfs = unsafe { std::mem::zeroed() };
    let r = unsafe { libc::statvfs(cstr.as_ptr(), &mut buf) };
    if r != 0 {
        return None;
    }
    Some((buf.f_bavail as u64) * (buf.f_frsize as u64))
}

fn now_iso() -> String {
    crate::timeutil::now_cst_rfc3339()
}

/// 受上限保护的审计 push (修复 C6)
///
/// 当 audit.len() >= MAX_AUDIT_TRAIL 时不再 push, 调用方应自增 dropped 计数。
/// 调用方应在循环外用 result.audit_dropped 跟踪超出量。
/// 简化版: 这里只做长度检查, 超出就直接丢弃; 最终统计由调用方完成。
fn push_audit_capped(audit: &mut Vec<AuditEntry>, entry: AuditEntry) {
    if audit.len() < MAX_AUDIT_TRAIL {
        audit.push(entry);
    }
    // 超出上限的丢弃, 调用方在循环结束时根据 files_scanned + files_blocked +
    // files_skipped + files_deleted - audit.len() 算 dropped
}

#[allow(dead_code)]
fn _suppress() {
    let _ = PathBuf::new();
    let _ = Arc::new(());
}

// ============================================================
// 单元测试 — 空目录清理 (clean_empty_dirs) 全语义覆盖
// ============================================================
//
// 测试策略:
// - 在 /tmp/tarn-test/ 下建临时目录树, 跑 executor, 校验 dirs_removed / dirs_skipped
// - 每个 test 独立目录, 互不干扰, 测完清理
// - 覆盖: rule 开/关, target 覆盖, include_root, max_depth, dry_run, 非空跳过, 保护跳过

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::{Blacklist, Rule, Target, Whitelist};
    use std::path::PathBuf;

    /// 测试辅助: 在 /tmp/tarn-test/ 下建唯一测试目录
    fn test_root(name: &str) -> PathBuf {
        let p = std::env::temp_dir().join("tarn-test").join("executor").join(name);
        let _ = std::fs::remove_dir_all(&p);
        std::fs::create_dir_all(&p).unwrap();
        p
    }

    /// 编译空 ProtectSet (无任何保护, 不影响 /tmp/tarn-test/ 路径)
    fn empty_protect() -> ProtectSet {
        ProtectSet::compile(&Whitelist::default()).unwrap()
    }

    /// 构造一条 rule + 单 target, 跑 executor.run(), 返回 RunResult
    fn run_rule(rule: Rule) -> RunResult {
        let mut bl = Blacklist::default();
        bl.rule.push(rule);
        let exec = Executor::new(Settings::default(), bl, empty_protect());
        let opts = RunOptions {
            dry_run: false,
            trigger: Trigger::Manual,
            json: false,
            verbose: false,
            rule_filter: None,
            timeout_sec: 0,
        };
        exec.run(&opts)
    }

    fn make_rule(id: &str, target_path: &str) -> Rule {
        Rule {
            id: id.to_string(),
            name: id.to_string(),
            enabled: true,
            priority: 50,
            risk: "low".to_string(),
            clean_empty_dirs: false,
            clean_empty_dirs_include_root: false,
            clean_empty_dirs_max_depth: 0,
            trigger: Default::default(),
            targets: vec![Target {
                path: target_path.to_string(),
                glob: "**/*".to_string(),
                older_than_days: 0,
                min_size_kb: 0,
                exclude: vec![],
                clean_empty_dirs: None,
                clean_empty_dirs_include_root: None,
                clean_empty_dirs_max_depth: None,
            }],
        }
    }

    // === 基础: rule.clean_empty_dirs = false → 不清空目录 ===
    #[test]
    fn test_clean_empty_dirs_rule_off() {
        let root = test_root("rule_off");
        // 建空子目录
        std::fs::create_dir_all(root.join("sub1/sub2")).unwrap();
        // 写一个文件让 walker 有东西扫
        std::fs::write(root.join("a.txt"), "x").unwrap();

        let mut rule = make_rule("rule_off", root.to_str().unwrap());
        rule.clean_empty_dirs = false;
        let result = run_rule(rule);

        // 文件被删, 空目录保留
        assert_eq!(result.files_deleted, 1);
        assert_eq!(result.dirs_removed, 0);
        assert!(root.join("sub1/sub2").exists(), "rule 关闭时空目录应保留");
    }

    // === rule.clean_empty_dirs = true → 自底向上清空 ===
    #[test]
    fn test_clean_empty_dirs_rule_on() {
        let root = test_root("rule_on");
        std::fs::create_dir_all(root.join("sub1/sub2")).unwrap();
        std::fs::write(root.join("sub1/sub2/old.txt"), "x").unwrap();

        let mut rule = make_rule("rule_on", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        let result = run_rule(rule);

        assert_eq!(result.files_deleted, 1);
        assert_eq!(result.dirs_removed, 2, "sub2 + sub1 都应被清空 (root 不删)");
        assert!(!root.join("sub1").exists());
        assert!(root.exists(), "target.path 本身应保留 (include_root=false)");
    }

    // === target 级覆盖: rule off + target Some(true) → 清空 ===
    #[test]
    fn test_target_override_on() {
        let root = test_root("target_on");
        std::fs::create_dir_all(root.join("d1/d2")).unwrap();
        std::fs::write(root.join("d1/d2/f.txt"), "x").unwrap();

        let mut rule = make_rule("target_on", root.to_str().unwrap());
        rule.clean_empty_dirs = false;
        rule.targets[0].clean_empty_dirs = Some(true);
        let result = run_rule(rule);

        assert_eq!(result.dirs_removed, 2, "target 覆盖为开 → 应清空");
    }

    // === target 级覆盖: rule on + target Some(false) → 不清 ===
    #[test]
    fn test_target_override_off() {
        let root = test_root("target_off");
        std::fs::create_dir_all(root.join("d1/d2")).unwrap();
        std::fs::write(root.join("d1/d2/f.txt"), "x").unwrap();

        let mut rule = make_rule("target_off", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.targets[0].clean_empty_dirs = Some(false);
        let result = run_rule(rule);

        assert_eq!(result.dirs_removed, 0, "target 覆盖为关 → 不清");
        assert!(root.join("d1/d2").exists());
    }

    // === include_root = false (默认): target.path 保留 ===
    #[test]
    fn test_include_root_false() {
        let root = test_root("incl_root_false");
        std::fs::write(root.join("f.txt"), "x").unwrap();

        let mut rule = make_rule("incl_root_false", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.clean_empty_dirs_include_root = false;
        let result = run_rule(rule);

        assert_eq!(result.files_deleted, 1);
        assert_eq!(result.dirs_removed, 0, "无子目录, 且 include_root=false 不删 root");
        assert!(root.exists(), "target.path 应保留");
    }

    // === include_root = true: target.path 变空后也删 ===
    #[test]
    fn test_include_root_true() {
        let root = test_root("incl_root_true");
        std::fs::write(root.join("f.txt"), "x").unwrap();

        let mut rule = make_rule("incl_root_true", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.clean_empty_dirs_include_root = true;
        let result = run_rule(rule);

        assert_eq!(result.files_deleted, 1);
        assert_eq!(result.dirs_removed, 1, "include_root=true → target.path 也删");
        assert!(!root.exists(), "target.path 应被删除");
    }

    // === include_root 通过 target 级覆盖 ===
    #[test]
    fn test_include_root_target_override() {
        let root = test_root("incl_root_t_over");
        std::fs::write(root.join("f.txt"), "x").unwrap();

        let mut rule = make_rule("incl_root_t_over", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.clean_empty_dirs_include_root = false; // rule 级关
        rule.targets[0].clean_empty_dirs_include_root = Some(true); // target 强制开
        let result = run_rule(rule);

        assert_eq!(result.dirs_removed, 1, "target 覆盖 include_root=true → root 删除");
        assert!(!root.exists());
    }

    // === max_depth = 0 (默认): 不限深度, 全清 ===
    #[test]
    fn test_max_depth_unlimited() {
        let root = test_root("max_depth_0");
        // 建 3 层深的空目录树, 文件在最深层
        std::fs::create_dir_all(root.join("a/b/c")).unwrap();
        std::fs::write(root.join("a/b/c/f.txt"), "x").unwrap();

        let mut rule = make_rule("max_depth_0", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.clean_empty_dirs_max_depth = 0;
        let result = run_rule(rule);

        assert_eq!(result.dirs_removed, 3, "深度 0=不限, c + b + a 全清");
        assert!(!root.join("a").exists());
    }

    // === max_depth = 1: 只清深度 <= 1 的 (root 的直接子目录) ===
    #[test]
    fn test_max_depth_1() {
        let root = test_root("max_depth_1");
        std::fs::create_dir_all(root.join("a/b/c")).unwrap();
        std::fs::write(root.join("a/b/c/f.txt"), "x").unwrap();

        let mut rule = make_rule("max_depth_1", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.clean_empty_dirs_max_depth = 1;
        let result = run_rule(rule);

        // 深度: root=0, a=1, b=2, c=3
        // max_depth=1 只清深度<=1: 仅 a (变空后)
        // 但 a 在删 c 后, c 是深度3(超限, 不删, c 非空也不删), b 是深度2(超限, 不删)
        // 所以 a 不会变空 (b 还在), dirs_removed=0
        assert_eq!(result.dirs_removed, 0, "max_depth=1, 深层未清, a 不空 → 0");
        assert!(root.join("a/b/c").exists(), "深层目录保留");
    }

    // === max_depth = 2: 深层文件未删时, b 非空 → 不清 ===
    #[test]
    fn test_max_depth_2() {
        let root = test_root("max_depth_2");
        // 结构: root/a/b/c (dirs) + root/a/b/f.txt (文件)
        // 注意: c 是空目录, f.txt 在 b 下
        std::fs::create_dir_all(root.join("a/b/c")).unwrap();
        std::fs::write(root.join("a/b/f.txt"), "x").unwrap();

        let mut rule = make_rule("max_depth_2", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.clean_empty_dirs_max_depth = 2;
        let result = run_rule(rule);

        // 删 f.txt 后:
        // - c (深度3) 空, 但 3 > max_depth=2 → 不删
        // - b (深度2) 含 c 子目录 → 非空 → 不删
        // - a (深度1) 含 b → 非空 → 不删
        assert_eq!(result.dirs_removed, 0, "c 超深度不删 → b 非空 → a 非空 → 0");
        assert!(root.join("a/b/c").exists(), "深层空目录保留");
    }

    // === max_depth 精确测试: 单层结构 ===
    #[test]
    fn test_max_depth_precise() {
        let root = test_root("max_depth_precise");
        // 结构: root/ (depth 0)
        //        root/sub/ (depth 1)
        //        root/sub/leaf.txt (文件)
        std::fs::create_dir_all(root.join("sub")).unwrap();
        std::fs::write(root.join("sub/leaf.txt"), "x").unwrap();

        let mut rule = make_rule("mdp", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.clean_empty_dirs_max_depth = 1;
        let result = run_rule(rule);

        assert_eq!(result.files_deleted, 1);
        assert_eq!(result.dirs_removed, 1, "sub 深度1 ≤ max_depth=1 → 删");
        assert!(!root.join("sub").exists());
        assert!(root.exists(), "root 深度0, 但 include_root=false → 保留");
    }

    // === 非空目录跳过 ===
    #[test]
    fn test_non_empty_dir_skipped() {
        let root = test_root("non_empty");
        std::fs::create_dir_all(root.join("emptiable")).unwrap();
        std::fs::create_dir_all(root.join("keep")).unwrap();
        std::fs::write(root.join("emptiable/old.txt"), "x").unwrap();
        // keep 下放一个不在 glob 的文件 (用 exclude) — 简化: 直接放一个 .keep 文件但 glob 匹配
        // 实际: glob **/* 会匹配所有文件, 所以 keep/retain.txt 会被删
        // 改为: keep 下放一个目录 (目录不会被 **/* 匹配为文件删)
        std::fs::create_dir_all(root.join("keep/inner")).unwrap();
        std::fs::write(root.join("keep/inner/persist.txt"), "x").unwrap();
        // exclude persist.txt 让它不被删
        let mut rule = make_rule("non_empty", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.targets[0].exclude = vec!["**/persist.txt".to_string()];

        let result = run_rule(rule);

        // old.txt 删 → emptiable 空 → rmdir
        // persist.txt 被 exclude 保留 → keep/inner 非空 → 不删, keep 非空 → 不删
        assert_eq!(result.files_deleted, 1, "仅 old.txt 被删");
        assert_eq!(result.dirs_removed, 1, "仅 emptiable 被清空");
        assert!(root.join("keep/inner/persist.txt").exists());
    }

    // === dry_run: 只统计不真删 ===
    // 注意: dry_run 模式下文件未真删, 目录仍非空, dirs_removed 只统计"本来就已空"的目录
    #[test]
    fn test_dry_run_no_real_delete() {
        let root = test_root("dry_run");
        // sub 本来就空 (无文件), dry_run 应统计为可删
        std::fs::create_dir_all(root.join("sub")).unwrap();
        // 另放一个文件让 walker 有东西扫
        std::fs::write(root.join("f.txt"), "x").unwrap();

        let mut rule = make_rule("dry_run", root.to_str().unwrap());
        rule.clean_empty_dirs = true;

        let mut bl = Blacklist::default();
        bl.rule.push(rule);
        let exec = Executor::new(Settings::default(), bl, empty_protect());
        let opts = RunOptions {
            dry_run: true,
            trigger: Trigger::Manual,
            ..Default::default()
        };
        let result = exec.run(&opts);

        assert_eq!(result.files_deleted, 1, "dry_run 也统计 files_deleted");
        assert_eq!(result.dirs_removed, 1, "sub 本来就空 → dry_run 统计为可删");
        assert!(root.join("f.txt").exists(), "dry_run 不真删文件");
        assert!(root.join("sub").exists(), "dry_run 不真删目录");
    }

    // === 多 target: 不同 target 不同覆盖 ===
    #[test]
    fn test_multi_target_mixed() {
        let root = test_root("multi_target");
        let t1 = root.join("clean_it");
        let t2 = root.join("keep_it");
        // t1 下建子目录 (子目录会变空, 因为 include_root=false 不删 target.path 本身)
        std::fs::create_dir_all(t1.join("sub")).unwrap();
        std::fs::create_dir_all(&t2).unwrap();
        std::fs::write(t1.join("sub/a.txt"), "x").unwrap();
        std::fs::write(t2.join("b.txt"), "x").unwrap();

        let mut rule = make_rule("multi", root.to_str().unwrap());
        rule.clean_empty_dirs = true;
        rule.targets = vec![
            Target {
                path: t1.to_string_lossy().to_string(),
                glob: "**/*".to_string(),
                older_than_days: 0,
                min_size_kb: 0,
                exclude: vec![],
                clean_empty_dirs: None, // 跟随 rule (开)
                clean_empty_dirs_include_root: None,
                clean_empty_dirs_max_depth: None,
            },
            Target {
                path: t2.to_string_lossy().to_string(),
                glob: "**/*".to_string(),
                older_than_days: 0,
                min_size_kb: 0,
                exclude: vec![],
                clean_empty_dirs: Some(false), // 强制关
                clean_empty_dirs_include_root: None,
                clean_empty_dirs_max_depth: None,
            },
        ];
        let result = run_rule(rule);

        assert_eq!(result.files_deleted, 2);
        assert_eq!(result.dirs_removed, 1, "仅 t1/sub 清空, t2 保留");
        assert!(!t1.join("sub").exists(), "t1/sub 被清空");
        assert!(!t2.join("b.txt").exists(), "t2 文件被删 (clean_empty_dirs 只影响目录不影响文件)");
        assert!(t2.exists(), "t2 目录保留 (覆盖关)");
    }
}
