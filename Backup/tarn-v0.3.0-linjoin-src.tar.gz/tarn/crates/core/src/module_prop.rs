//! module.prop 动态 description 更新
//!
//! ## 功能
//! 在 Magisk/KernelSU 管理器的模块列表里, module.prop 的 description 字段会显示给用户。
//! Tarn 把它做成动态的, 实时反映 daemon 状态:
//!   - 运行中: `运行中 PID=12345 | 删除 1234 个文件 | 已清理 1.23 GB`
//!   - 已停止: `已停止 | 删除 1234 个文件 | 已清理 1.23 GB`
//!
//! ## 持久化
//! 累计清理字节数 + 累计删除文件数持久化在 state.json 的 totals,
//! daemon 重启不丢失。
//! module.prop 本身也会被 daemon 改写, 但升级模块时 customize.sh 会解压覆盖 module.prop,
//! 所以 customize.sh 需要从 state.json 读取累计数据, 恢复 description 字段。
//!
//! ## 不允许覆盖 (用户要求)
//! - daemon 运行时: 每次清理后更新 description
//! - customize.sh 升级时: 从 state.json 恢复 description (不丢失累计数据)
//! - uninstall.sh 卸载时: 整个模块目录被删, description 随之消失 (允许)
//! - 其他时机: 不动 module.prop

use anyhow::{Context, Result};
use std::path::PathBuf;

/// MODPATH 固定路径 (与 webroot.rs 一致, daemon 由 setsid 启动环境无 MODPATH)
const MODPATH: &str = "/data/adb/modules/tarn";

/// module.prop 文件路径
pub fn module_prop_path() -> PathBuf {
    PathBuf::from(MODPATH).join("module.prop")
}

/// 字节数格式化为人类可读 (GB / MB / KB / B)
///
/// 规则:
///   - >= 1 GB: 显示 GB, 两位小数 (1.23 GB)
///   - >= 1 MB: 显示 MB, 两位小数 (12.34 MB)
///   - >= 1 KB: 显示 KB, 两位小数 (123.45 KB)
///   - <  1 KB: 显示 B (123 B)
pub fn format_bytes(bytes: u64) -> String {
    const KB: u64 = 1024;
    const MB: u64 = 1024 * 1024;
    const GB: u64 = 1024 * 1024 * 1024;
    if bytes >= GB {
        format!("{:.2} GB", bytes as f64 / GB as f64)
    } else if bytes >= MB {
        format!("{:.2} MB", bytes as f64 / MB as f64)
    } else if bytes >= KB {
        format!("{:.2} KB", bytes as f64 / KB as f64)
    } else {
        format!("{} B", bytes)
    }
}

/// 构造 description 字符串
///
/// [v0.2.5] 新格式: `运行中 PID=xxx | 删除 xxx 个文件 | 已清理 xxx GB`
/// - 运行中: `运行中 PID=12345 | 删除 1234 个文件 | 已清理 1.23 GB`
/// - 已停止: `已停止 | 删除 1234 个文件 | 已清理 1.23 GB`
pub fn build_description(running: bool, pid: Option<u32>, files_deleted: u64, freed_bytes: u64) -> String {
    let cleaned = format_bytes(freed_bytes);
    if running {
        match pid {
            Some(p) => format!("运行中 PID={} | 删除 {} 个文件 | 已清理 {}", p, files_deleted, cleaned),
            None => format!("运行中 | 删除 {} 个文件 | 已清理 {}", files_deleted, cleaned),
        }
    } else {
        format!("已停止 | 删除 {} 个文件 | 已清理 {}", files_deleted, cleaned)
    }
}

/// 更新 module.prop 的 description 字段 (其他字段不动)
///
/// 行为:
/// 1. 读 module.prop 全文
/// 2. 找到 `description=` 行, 替换为新的 description
/// 3. 若没有 description 行, 追加一行
/// 4. 原子写回 (tmp + rename)
///
/// 失败不退出调用方, 仅返回 Err 由调用方记日志
pub fn update_description(description: &str) -> Result<()> {
    let path = module_prop_path();
    let content = std::fs::read_to_string(&path)
        .with_context(|| format!("读取 module.prop 失败: {}", path.display()))?;

    // 逐行处理: 找到 description= 行替换, 其他行保留
    let mut found = false;
    let mut new_lines: Vec<String> = Vec::new();
    for line in content.lines() {
        if line.starts_with("description=") {
            new_lines.push(format!("description={}", description));
            found = true;
        } else {
            new_lines.push(line.to_string());
        }
    }
    if !found {
        // module.prop 没有 description 行, 追加一行
        new_lines.push(format!("description={}", description));
    }

    let new_content = new_lines.join("\n") + "\n";

    // 原子写 (tmp + rename, 与 state.json 一致策略)
    let tmp = path.with_extension("prop.tmp");
    std::fs::write(&tmp, &new_content)
        .with_context(|| format!("写入临时文件失败: {}", tmp.display()))?;
    std::fs::rename(&tmp, &path)
        .with_context(|| format!("rename 失败: {} -> {}", tmp.display(), path.display()))?;

    Ok(())
}

/// 从 state.json 读取累计统计, 生成 description 并更新 module.prop
///
/// 便捷封装: daemon 启动/退出时调用
/// - running=true: 显示 PID
/// - running=false: 显示"已停止"
///
/// [v0.2.5] 新增 files_deleted 参数, description 同时显示删除文件数和清理字节数
pub fn update_from_state(running: bool, pid: Option<u32>, files_deleted: u64, freed_bytes: u64) -> Result<()> {
    let desc = build_description(running, pid, files_deleted, freed_bytes);
    update_description(&desc)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_format_bytes() {
        assert_eq!(format_bytes(0), "0 B");
        assert_eq!(format_bytes(512), "512 B");
        assert_eq!(format_bytes(1024), "1.00 KB");
        assert_eq!(format_bytes(1536), "1.50 KB");
        assert_eq!(format_bytes(1024 * 1024), "1.00 MB");
        assert_eq!(format_bytes(1024 * 1024 * 1024), "1.00 GB");
        assert_eq!(format_bytes(1024 * 1024 * 1024 * 2 + 1024 * 1024 * 100), "2.10 GB");
    }

    #[test]
    fn test_build_description_running() {
        let d = build_description(true, Some(12345), 5678, 1024 * 1024 * 1024 * 2);
        assert_eq!(d, "运行中 PID=12345 | 删除 5678 个文件 | 已清理 2.00 GB");
    }

    #[test]
    fn test_build_description_stopped() {
        let d = build_description(false, None, 100, 1024 * 500);
        assert_eq!(d, "已停止 | 删除 100 个文件 | 已清理 500.00 KB");
    }

    #[test]
    fn test_build_description_running_no_pid() {
        let d = build_description(true, None, 0, 0);
        assert_eq!(d, "运行中 | 删除 0 个文件 | 已清理 0 B");
    }
}
