//! DFA 通配符匹配引擎
//!
//! 使用 globset 将所有 glob 模式编译成单一 DFA,
//! 匹配 O(路径长度), 与模式数无关。

use globset::{Glob, GlobSet, GlobSetBuilder};
use std::path::Path;

/// 编译后的匹配器
#[derive(Debug, Clone)]
pub struct Matcher {
    /// include glob 集合 (命中即纳入待删)
    include: GlobSet,
    /// exclude glob 集合 (命中即排除)
    exclude: GlobSet,
    /// 原始模式 (调试用)
    include_patterns: Vec<String>,
    exclude_patterns: Vec<String>,
}

impl Matcher {
    /// 从 glob 模式列表编译
    pub fn new(include: &[String], exclude: &[String]) -> Result<Self, String> {
        let mut inc_builder = GlobSetBuilder::new();
        let mut inc_patterns = Vec::new();
        for p in include {
            let g = Glob::new(p).map_err(|e| format!("include glob 编译失败 {p}: {e}"))?;
            inc_builder.add(g);
            inc_patterns.push(p.clone());
        }
        let include = inc_builder.build().map_err(|e| format!("include GlobSet 构建失败: {e}"))?;

        let mut exc_builder = GlobSetBuilder::new();
        let mut exc_patterns = Vec::new();
        for p in exclude {
            let g = Glob::new(p).map_err(|e| format!("exclude glob 编译失败 {p}: {e}"))?;
            exc_builder.add(g);
            exc_patterns.push(p.clone());
        }
        let exclude = exc_builder.build().map_err(|e| format!("exclude GlobSet 构建失败: {e}"))?;

        Ok(Self {
            include,
            exclude,
            include_patterns: inc_patterns,
            exclude_patterns: exc_patterns,
        })
    }

    /// 检查路径是否匹配 (命中 include 且不命中 exclude)
    pub fn matches(&self, path: &Path) -> bool {
        if !self.include.is_match(path) {
            return false;
        }
        if self.exclude.is_match(path) {
            return false;
        }
        true
    }

    pub fn include_patterns(&self) -> &[String] {
        &self.include_patterns
    }

    pub fn exclude_patterns(&self) -> &[String] {
        &self.exclude_patterns
    }
}

/// 默认匹配器 (匹配 **/*, 无 exclude)
impl Default for Matcher {
    fn default() -> Self {
        Self::new(&["**/*".to_string()], &[]).expect("默认 matcher 编译失败")
    }
}
