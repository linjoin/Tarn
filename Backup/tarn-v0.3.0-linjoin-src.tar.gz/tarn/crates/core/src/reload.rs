//! 热重载: SIGHUP / tarn reload 命令触发, 重新加载三文件
//!
//! 重载时:
//! 1. 标记 reload_requested
//! 2. 若当前有任务在跑: 不打断, 任务结束后加载
//! 3. 若无任务: 立即加载新配置
//! 4. 加载失败 (语法错): 保留旧配置, 记 ERROR

use crate::config::{Blacklist, Settings, Whitelist};
use crate::protect::ProtectSet;
use anyhow::{anyhow, Result};
use parking_lot::RwLock;
use std::path::PathBuf;
use std::sync::Arc;

/// 全局配置 (热重载替换)
#[derive(Clone)]
pub struct Config {
    pub settings: Settings,
    pub blacklist: Blacklist,
    pub whitelist: Whitelist,
    pub protect: ProtectSet,
}

impl Config {
    pub fn load(config_dir: &PathBuf) -> Result<Self> {
        // 配置文件统一在 config/ 子目录 (与 customize.sh 部署位置一致)
        let settings_path = config_dir.join("config/settings.toml");
        let blacklist_path = config_dir.join("config/blacklist.toml");
        let whitelist_path = config_dir.join("config/whitelist.toml");

        let settings = Settings::load(&settings_path)
            .map_err(|e| anyhow!("settings 加载失败: {e}"))?;
        let blacklist = Blacklist::load(&blacklist_path)
            .map_err(|e| anyhow!("blacklist 加载失败: {e}"))?;
        let whitelist = Whitelist::load(&whitelist_path)
            .map_err(|e| anyhow!("whitelist 加载失败: {e}"))?;

        let protect = ProtectSet::compile(&whitelist)
            .map_err(|e| anyhow!("protect 编译失败: {e}"))?;

        Ok(Self {
            settings,
            blacklist,
            whitelist,
            protect,
        })
    }
}

/// 全局配置持有者 (Arc<RwLock> 支持热替换)
pub type ConfigHandle = Arc<RwLock<Config>>;

/// 创建配置句柄
pub fn init_config(config_dir: PathBuf) -> Result<ConfigHandle> {
    let cfg = Config::load(&config_dir)?;
    Ok(Arc::new(RwLock::new(cfg)))
}

/// 热重载配置 (SIGHUP 或 tarn reload 触发)
///
/// 返回 Ok(()) 表示重载成功, Err 表示失败 (旧配置保留)
pub fn reload(handle: &ConfigHandle, config_dir: PathBuf) -> Result<()> {
    let new_cfg = Config::load(&config_dir)?;
    *handle.write() = new_cfg;
    Ok(())
}
