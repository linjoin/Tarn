//! 保护层: 用户自定义白名单匹配
//!
//! 保护判断顺序 (全部由用户在 whitelist.toml 配置):
//! 1. protect_path (prefix/glob)
//! 2. protect_package
//! 3. protect_ext
//! 4. protect_mtime
//! 5. 都没命中 → 允许删除
//!
//! 注: 不再有硬编码路径限制或允许根前缀校验。
//! 用户对清理目标负全责, 可清理任意路径。

use crate::config::Whitelist;
use std::collections::HashSet;
use std::path::Path;
use std::time::SystemTime;

/// 路径前缀匹配: 严格路径组件匹配, 避免字符串前缀旁路
///
/// 问题: `"/data/adb/tarn/rules_evil".starts_with("/data/adb/tarn/rules")` 返回 true,
/// 导致 `/data/adb/tarn/rules_evil` 被误判为放行路径。
///
/// 修复: 必须是完整路径相等, 或后面紧贴路径分隔符 `/`。
fn path_in_prefix(path: &str, prefix: &str) -> bool {
    if path == prefix {
        return true;
    }
    // 必须以 `prefix + "/"` 开头, 避免子字符串误匹配
    let prefix_with_slash = if prefix.ends_with('/') {
        prefix.to_string()
    } else {
        format!("{}/", prefix)
    };
    path.starts_with(&prefix_with_slash)
}

/// 编译后的保护集合
#[derive(Debug, Clone)]
pub struct ProtectSet {
    /// prefix 匹配 (含硬编码 + protect_path match=prefix)
    prefix: HashSet<String>,
    /// glob 匹配 (DFA)
    glob: globset::GlobSet,
    /// 包名保护 (包名 → 仅子目录列表, None=全保护)
    packages: std::collections::HashMap<String, Option<HashSet<String>>>,
    /// 扩展名保护 (小写, 无点) → scope (global=空串 或 路径前缀)
    exts: Vec<(HashSet<String>, String)>,
    /// mtime 保护 (within_days, scope)
    mtime: Vec<(u32, String)>,
}

impl ProtectSet {
    /// 从 whitelist.conf 编译用户自定义保护集
    pub fn compile(wl: &Whitelist) -> Result<Self, String> {
        let mut prefix: HashSet<String> = HashSet::new();
        let mut glob_patterns: Vec<globset::Glob> = Vec::new();

        // 1. protect_path (path 自动判断 glob/prefix)
        //    - path 含通配符 (* ? [) → glob 匹配 (用 globset DFA)
        //    - 否则 → prefix 匹配 (最常用, 保护该目录及其所有子内容)
        for pp in &wl.protect {
            if pp.is_glob() {
                let g = globset::Glob::new(&pp.path)
                    .map_err(|e| format!("glob 编译失败 {}: {}", pp.path, e))?;
                glob_patterns.push(g);
            } else {
                prefix.insert(pp.path.clone());
            }
        }

        let mut glob_builder = globset::GlobSetBuilder::new();
        for g in &glob_patterns {
            glob_builder.add(g.clone());
        }
        let glob = glob_builder
            .build()
            .map_err(|e| format!("GlobSet 构建失败: {}", e))?;

        // 3. protect_package
        let mut packages: std::collections::HashMap<String, Option<HashSet<String>>> =
            std::collections::HashMap::new();
        for pk in &wl.protect_package {
            let only = if pk.only.is_empty() {
                None
            } else {
                Some(pk.only.iter().cloned().collect())
            };
            packages.insert(pk.package.clone(), only);
        }

        // 4. protect_ext
        let mut exts: Vec<(HashSet<String>, String)> = Vec::new();
        for pe in &wl.protect_ext {
            let set: HashSet<String> = pe
                .extensions
                .iter()
                .map(|e| e.trim_start_matches('.').to_lowercase())
                .collect();
            let scope = if pe.scope == "global" {
                String::new()
            } else {
                pe.scope.clone()
            };
            exts.push((set, scope));
        }

        // 5. protect_mtime
        let mut mtime: Vec<(u32, String)> = Vec::new();
        for pm in &wl.protect_mtime {
            let scope = if pm.scope == "global" {
                String::new()
            } else {
                pm.scope.clone()
            };
            mtime.push((pm.within_days, scope));
        }

        Ok(Self {
            prefix,
            glob,
            packages,
            exts,
            mtime,
        })
    }

    /// 检查给定路径是否被保护
    ///
    /// 返回 Some(reason) 表示被保护, None 表示可删
    pub fn check(&self, path: &Path, mtime: Option<SystemTime>) -> Option<&'static str> {
        let path_str = path.to_string_lossy();

        // 1. prefix 匹配 (protect_path prefix)
        for p in &self.prefix {
            if path_in_prefix(&path_str, p) {
                return Some("blocked_prefix");
            }
        }

        // 2. glob 匹配
        if self.glob.is_match(path) {
            return Some("blocked_glob");
        }

        // 3. protect_package: 匹配 /data/data/<pkg>/ 或 /data/user/0/<pkg>/
        if let Some(pkg) = extract_package_from_path(&path_str) {
            if let Some(only) = self.packages.get(&pkg) {
                match only {
                    None => return Some("blocked_package"),
                    Some(subs) => {
                        // 检查子目录是否在 only 列表
                        if let Some(subdir) = extract_subdir_from_path(&path_str, &pkg) {
                            if subs.contains(&subdir) {
                                return Some("blocked_package");
                            }
                        }
                    }
                }
            }
        }

        // 4. protect_ext
        // 修复 R6: scope 用 path_in_prefix 严格路径组件匹配, 避免
        // scope="/data/data/com.foo" 误匹配 "/data/data/com.foobar/..."
        if let Some(ext) = path.extension().and_then(|e| e.to_str()) {
            let ext_lower = ext.to_lowercase();
            for (set, scope) in &self.exts {
                if set.contains(&ext_lower) {
                    if scope.is_empty() || path_in_prefix(&path_str, scope) {
                        return Some("blocked_ext");
                    }
                }
            }
        }

        // 5. protect_mtime (同样修复 R6: scope 用 path_in_prefix)
        if let Some(mtime_val) = mtime {
            if let Ok(now) = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH) {
                if let Ok(file_age) = mtime_val.duration_since(SystemTime::UNIX_EPOCH) {
                    for (within_days, scope) in &self.mtime {
                        let age_sec = now.as_secs().saturating_sub(file_age.as_secs());
                        let within_sec = (*within_days as u64) * 86400;
                        if age_sec < within_sec {
                            if scope.is_empty() || path_in_prefix(&path_str, scope) {
                                return Some("blocked_mtime");
                            }
                        }
                    }
                }
            }
        }

        None
    }
}

/// 从路径提取包名 (支持 /data/data/<pkg>/... 和 /data/user/0/<pkg>/...)
fn extract_package_from_path(path: &str) -> Option<String> {
    if let Some(rest) = path.strip_prefix("/data/data/") {
        let pkg = rest.split('/').next()?;
        return Some(pkg.to_string());
    }
    if let Some(rest) = path.strip_prefix("/data/user/") {
        // /data/user/0/<pkg>/...
        let parts: Vec<&str> = rest.splitn(3, '/').collect();
        if parts.len() >= 2 {
            return Some(parts[1].to_string());
        }
    }
    None
}

/// 从 /data/data/<pkg>/<subdir>/... 或 /data/user/<id>/<pkg>/<subdir>/... 提取 subdir
/// (修复 M4: 支持任意 user_id, 不再硬编码 0)
fn extract_subdir_from_path(path: &str, pkg: &str) -> Option<String> {
    let prefix = format!("/data/data/{}/", pkg);
    if let Some(rest) = path.strip_prefix(&prefix) {
        let subdir = rest.split('/').next()?;
        return Some(subdir.to_string());
    }
    // /data/user/<任意 id>/<pkg>/...
    if let Some(rest) = path.strip_prefix("/data/user/") {
        let parts: Vec<&str> = rest.splitn(3, '/').collect();
        // parts[0] = user_id, parts[1] = pkg, parts[2] = rest
        if parts.len() >= 3 && parts[1] == pkg {
            let subdir = parts[2].split('/').next()?;
            return Some(subdir.to_string());
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_path_in_prefix_strict() {
        // 完全相等
        assert!(path_in_prefix("/data/adb/tarn/rules", "/data/adb/tarn/rules"));
        // 正常子路径
        assert!(path_in_prefix("/data/adb/tarn/rules/x.toml", "/data/adb/tarn/rules"));
        assert!(path_in_prefix("/data/adb/tarn/rules/sub/y.toml", "/data/adb/tarn/rules"));
        // 关键: 字符串前缀但非路径组件必须返回 false (C3 修复回归)
        assert!(!path_in_prefix("/data/adb/tarn/rules_evil", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("/data/adb/tarn/rulessecret", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("/data/adb/tarn/logs_evil/x", "/data/adb/tarn/logs"));
        // 空路径
        assert!(!path_in_prefix("/", "/data/adb/tarn/rules"));
        assert!(!path_in_prefix("", "/data/adb/tarn/rules"));
    }

    #[test]
    fn test_extract_subdir_multi_user() {
        // /data/data/<pkg>/<sub>/...
        assert_eq!(
            extract_subdir_from_path("/data/data/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        // /data/user/0/<pkg>/<sub>/... (M4: 任意 user_id)
        assert_eq!(
            extract_subdir_from_path("/data/user/0/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        // M4 修复: user_id=10 也能匹配
        assert_eq!(
            extract_subdir_from_path("/data/user/10/com.foo/cache/x.tmp", "com.foo"),
            Some("cache".to_string())
        );
        assert_eq!(
            extract_subdir_from_path("/data/user/11/com.foo/files/y.db", "com.foo"),
            Some("files".to_string())
        );
        // 包名不匹配
        assert_eq!(
            extract_subdir_from_path("/data/user/0/com.bar/cache/x.tmp", "com.foo"),
            None
        );
    }
}
