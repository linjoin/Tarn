//! 状态持久化: JSON 文件 + 原子写 (tmp + fsync + rename)

use crate::executor::RunResult;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use parking_lot::RwLock;

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct State {
    pub schema_version: u32,
    pub last_updated: String,
    pub totals: Totals,
    pub last_run: Option<LastRun>,
    pub rules: HashMap<String, RuleState>,
    /// 最近运行历史 (最多 50 条, 先进先出)
    #[serde(default)]
    pub history: Vec<HistoryEntry>,
    /// [v0.2.5] 统计轮转归档历史 (FIFO, 最多 keep_rotation_history 份)
    ///
    /// 每次 totals 达到阈值被清零时, 旧 totals 快照存到这里。
    /// 让用户能查看每个"周期"的清理量, 而不是只看累计。
    #[serde(default)]
    pub rotation_history: Vec<RotationEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Totals {
    pub total_runs: u64,
    pub total_freed_bytes: u64,
    pub total_files_deleted: u64,
    /// [v0.2.5] 累计清理的空目录数
    #[serde(default)]
    pub total_dirs_removed: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct LastRun {
    pub run_id: String,
    pub ts_start: String,
    pub ts_end: String,
    pub trigger: String,
    pub freed_bytes: u64,
    pub files_deleted: u64,
    pub status: String,
    pub exit_code: i32,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RuleState {
    pub last_run: String,
    pub last_freed_bytes: u64,
    pub last_status: String,
    pub run_count: u64,
    /// 累计释放字节 (所有运行总和)
    #[serde(default)]
    pub total_freed_bytes: u64,
    /// 累计删除文件数
    #[serde(default)]
    pub total_files_deleted: u64,
    /// 成功次数 (last_status == "ok")
    #[serde(default)]
    pub success_count: u64,
    /// 失败次数 (last_status == "failed")
    #[serde(default)]
    pub fail_count: u64,
    /// 累计扫描文件数
    #[serde(default)]
    pub total_files_scanned: u64,
    /// 累计拦截文件数 (白名单保护)
    #[serde(default)]
    pub total_files_blocked: u64,
    /// [v0.2.5] 累计清理的空目录数
    #[serde(default)]
    pub total_dirs_removed: u64,
    /// 最近一次运行的 run_id
    #[serde(default)]
    pub last_run_id: String,
}

/// 历史记录单条 (轻量, 用于 WebUI 概览页趋势/时间线)
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct HistoryEntry {
    pub run_id: String,
    pub ts_start: String,
    pub ts_end: String,
    pub trigger: String,
    pub freed_bytes: u64,
    pub files_deleted: u64,
    pub files_scanned: u64,
    /// [v0.2.5] 本次清理的空目录数
    #[serde(default)]
    pub dirs_removed: u64,
    pub duration_ms: u64,
    pub dry_run: bool,
    pub exit_code: i32,
    /// Top 规则简表 (rule_id → freed_bytes, 最多 5 条)
    #[serde(default)]
    pub top_rules: Vec<(String, u64)>,
    /// 本次运行包含的所有规则 ID (用于规则详情历史过滤)
    #[serde(default)]
    pub rule_ids: Vec<String>,
    /// 每规则的状态简表 (rule_id → "ok"/"failed"/"skipped"/"blocked")
    #[serde(default)]
    pub rule_statuses: Vec<(String, String)>,
}

const MAX_HISTORY: usize = 50;

/// [v0.2.5] 统计轮转归档条目
///
/// 当 totals 达到阈值时, 把当前 totals 快照存为一条 RotationEntry,
/// 然后把 totals 清零开始新一轮统计。
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RotationEntry {
    /// 轮转发生时间 (RFC3339 CST)
    pub rotated_at: String,
    /// 触发轮转的原因: "files" (文件数达阈) / "bytes" (字节数达阈)
    pub reason: String,
    /// 本轮累计运行次数
    pub total_runs: u64,
    /// 本轮累计释放字节
    pub total_freed_bytes: u64,
    /// 本轮累计删除文件数
    pub total_files_deleted: u64,
    /// 本轮累计清理空目录数
    pub total_dirs_removed: u64,
}

/// 状态管理器 (线程安全)
pub struct StateManager {
    path: PathBuf,
    inner: Arc<RwLock<State>>,
}

impl StateManager {
    pub fn new(path: PathBuf) -> Self {
        let state = if path.exists() {
            std::fs::read_to_string(&path)
                .ok()
                .and_then(|s| serde_json::from_str(&s).ok())
                .unwrap_or_default()
        } else {
            State::default()
        };

        Self {
            path,
            inner: Arc::new(RwLock::new(state)),
        }
    }

    /// 记录一次运行结果
    pub fn record_run(&self, result: &RunResult) {
        let mut s = self.inner.write();
        s.totals.total_runs += 1;
        s.totals.total_freed_bytes += result.freed_bytes;
        s.totals.total_files_deleted += result.files_deleted;
        // [v0.2.5] 累计空目录清理数
        s.totals.total_dirs_removed += result.dirs_removed;

        s.last_run = Some(LastRun {
            run_id: result.run_id.clone(),
            ts_start: result.ts_start.clone(),
            ts_end: result.ts_end.clone(),
            trigger: result.trigger.clone(),
            freed_bytes: result.freed_bytes,
            files_deleted: result.files_deleted,
            status: if result.exit_code == 0 { "completed".to_string() } else { "failed".to_string() },
            exit_code: result.exit_code,
        });

        for rr in &result.rules {
            let entry = s.rules.entry(rr.rule_id.clone()).or_default();
            entry.last_run = result.ts_start.clone();
            entry.last_freed_bytes = rr.freed_bytes;
            entry.last_status = format!("{:?}", rr.status).to_lowercase();
            entry.last_run_id = result.run_id.clone();
            entry.run_count += 1;
            entry.total_freed_bytes += rr.freed_bytes;
            entry.total_files_deleted += rr.files_deleted;
            entry.total_files_scanned += rr.files_scanned;
            entry.total_files_blocked += rr.files_blocked;
            // [v0.2.5] 累计空目录清理数
            entry.total_dirs_removed += rr.dirs_removed;
            // 成功/失败计数 (ok = 成功, failed = 失败, skipped/blocked 不计)
            match rr.status {
                crate::executor::RuleStatus::Ok => entry.success_count += 1,
                crate::executor::RuleStatus::Failed => entry.fail_count += 1,
                _ => {}
            }
        }

        // 历史记录 (FIFO, 最多 MAX_HISTORY 条)
        let mut top_rules: Vec<(String, u64)> = result.rules.iter()
            .map(|rr| (rr.rule_id.clone(), rr.freed_bytes))
            .filter(|(_, b)| *b > 0)
            .collect();
        top_rules.sort_by(|a, b| b.1.cmp(&a.1));
        top_rules.truncate(5);
        // 所有规则 ID + 每规则状态 (用于规则详情历史过滤)
        let rule_ids: Vec<String> = result.rules.iter().map(|rr| rr.rule_id.clone()).collect();
        let rule_statuses: Vec<(String, String)> = result.rules.iter()
            .map(|rr| (rr.rule_id.clone(), format!("{:?}", rr.status).to_lowercase()))
            .collect();
        s.history.push(HistoryEntry {
            run_id: result.run_id.clone(),
            ts_start: result.ts_start.clone(),
            ts_end: result.ts_end.clone(),
            trigger: result.trigger.clone(),
            freed_bytes: result.freed_bytes,
            files_deleted: result.files_deleted,
            files_scanned: result.files_scanned,
            dirs_removed: result.dirs_removed,
            duration_ms: result.duration_ms,
            dry_run: result.dry_run,
            exit_code: result.exit_code,
            top_rules,
            rule_ids,
            rule_statuses,
        });
        if s.history.len() > MAX_HISTORY {
            let drop_n = s.history.len() - MAX_HISTORY;
            s.history.drain(0..drop_n);
        }

        s.last_updated = now_iso();
        drop(s);
        let _ = self.save();
    }

    /// [v0.2.5] 带轮转检查的运行记录
    ///
    /// 与 `record_run` 相同, 但在累加 totals 后检查是否达到轮转阈值。
    /// 达到则归档当前 totals 到 rotation_history 并清零 (history 数组保留)。
    /// 返回 Some(rotation_entry) 表示发生了轮转, 调用方可记日志/更新 module.prop。
    pub fn record_run_with_rotation(
        &self,
        result: &RunResult,
        rotate_after_files: u64,
        rotate_after_bytes: u64,
        keep_rotation_history: u32,
    ) -> Option<RotationEntry> {
        // 先复用 record_run 的累加逻辑
        self.record_run(result);

        // 再检查轮转
        let mut s = self.inner.write();
        let files = s.totals.total_files_deleted;
        let bytes = s.totals.total_freed_bytes;
        let need_rotate = (rotate_after_files > 0 && files >= rotate_after_files)
            || (rotate_after_bytes > 0 && bytes >= rotate_after_bytes);
        if !need_rotate {
            return None;
        }

        let reason = if rotate_after_files > 0 && files >= rotate_after_files {
            "files".to_string()
        } else {
            "bytes".to_string()
        };
        let entry = RotationEntry {
            rotated_at: now_iso(),
            reason: reason.clone(),
            total_runs: s.totals.total_runs,
            total_freed_bytes: s.totals.total_freed_bytes,
            total_files_deleted: s.totals.total_files_deleted,
            total_dirs_removed: s.totals.total_dirs_removed,
        };

        // 归档 (FIFO, 保留 keep_rotation_history 份; 0 = 不保留仅清零)
        if keep_rotation_history > 0 {
            s.rotation_history.push(entry.clone());
            let max = keep_rotation_history as usize;
            if s.rotation_history.len() > max {
                let drop_n = s.rotation_history.len() - max;
                s.rotation_history.drain(0..drop_n);
            }
        }

        // 清零 totals (history + rules 保留, 仅累计 totals 清零)
        s.totals = Totals::default();
        s.last_updated = now_iso();
        drop(s);
        let _ = self.save();
        Some(entry)
    }

    /// 原子写入磁盘
    pub fn save(&self) -> std::io::Result<()> {
        let s = self.inner.read().clone();
        let json = serde_json::to_string_pretty(&s).map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))?;
        atomic_write(&self.path, &json)
    }

    /// 获取快照
    pub fn snapshot(&self) -> State {
        self.inner.read().clone()
    }
}

/// 原子写: tmp + fsync 文件 + fsync 父目录 + rename
///
/// 修复 M10: 父目录未 fsync, 掉电后 rename 可能丢失 (state.json 变空或旧)
pub fn atomic_write(path: &Path, content: &str) -> std::io::Result<()> {
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, content)?;
    let f = std::fs::File::open(&tmp)?;
    f.sync_all()?;
    drop(f);
    std::fs::rename(&tmp, path)?;
    // 修复 M10: fsync 父目录确保 rename 的 dirent 落盘
    if let Some(parent) = path.parent() {
        if let Ok(pf) = std::fs::File::open(parent) {
            let _ = pf.sync_all();
        }
    }
    Ok(())
}

fn now_iso() -> String {
    crate::timeutil::now_cst_rfc3339()
}
