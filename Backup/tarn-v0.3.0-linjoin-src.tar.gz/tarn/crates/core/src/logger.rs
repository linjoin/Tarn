//! 异步日志: crossbeam-channel + 后台线程 + 实时 flush + 轮转
//!
//! 设计目标:
//! - 主线程 log 纳秒级返回 (channel.send),IO 压力转移到后台线程
//! - 有界通道防 OOM,满时丢日志但不阻塞主线程 (清理任务优先)
//! - 纯文本格式, 简洁清晰, 便于实时查看与 grep
//! - 实时 flush: 每条日志写入后立即 flush, 保证小白用户能立即看到
//! - 按大小轮转: 超阈值 → rename .1 → 旧 .1→.2 → 删最旧 → 新建
//! - 字段 (key-value) 以 [k=v] 形式追加到行尾, 不破坏可读性
//! - 支持 stdout 镜像 (调试用)
//! - 时间精确到秒, 固定 UTC+8 时区 (CST), 格式 YYYY-MM-DD HH:MM:SS
//!   (Android root 环境下系统时区可能不可靠, 统一用 UTC+8 避免日志时间错乱)
//!
//! 日志行格式 (v0.2.1: 级别不补空格, 避免 `[INFO ]` 空格问题):
//! ```text
//! [2024-06-17 14:23:45] [INFO] daemon Tarn daemon 启动
//! [2024-06-17 14:23:46] [INFO] daemon pidfile 写入: /data/adb/tarn/run/tarn.pid [pid=12345]
//! [2024-06-17 14:23:47] [WARN] daemon wake_lock 获取失败, 降级运行
//! ```

use crate::timeutil::now_cst_sec;
use crossbeam_channel::{bounded, Sender};
use parking_lot::Mutex;
use std::fs::OpenOptions;
use std::io::Write;
use std::path::PathBuf;
use std::thread::JoinHandle;
use std::time::Duration;

// ============================================================
// 日志级别
// ============================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum LogLevel {
    Trace,
    Debug,
    Info,
    Warn,
    Error,
}

impl LogLevel {
    pub fn as_str(&self) -> &'static str {
        match self {
            LogLevel::Trace => "TRACE",
            LogLevel::Debug => "DEBUG",
            LogLevel::Info => "INFO",
            LogLevel::Warn => "WARN",
            LogLevel::Error => "ERROR",
        }
    }

    /// 5 字符对齐前缀 (v0.2.1 已废弃, 保留仅为向后兼容)
    ///
    /// v0.2.1 前 INFO/WARN 会补尾随空格对齐, 但产生 `[INFO ]` 这种不美观的输出。
    /// 现已改为不补空格, 直接用 [`Self::as_str`]。此方法保留仅为避免破坏外部调用。
    #[deprecated(note = "使用 as_str() 代替, padded 会产生 [INFO ] 空格问题")]
    pub fn as_str_padded(&self) -> &'static str {
        self.as_str()
    }

    pub fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "trace" => LogLevel::Trace,
            "debug" => LogLevel::Debug,
            "info" => LogLevel::Info,
            "warn" | "warning" => LogLevel::Warn,
            "error" | "err" => LogLevel::Error,
            _ => LogLevel::Info,
        }
    }
}

// ============================================================
// 日志条目
// ============================================================

#[derive(Debug, Clone)]
pub struct LogEntry {
    /// UTC+8 时间字符串, 精确到秒 (YYYY-MM-DD HH:MM:SS)
    pub ts: String,
    pub level: LogLevel,
    pub target: String,
    pub message: String,
    pub fields: Vec<(String, String)>,
}

impl LogEntry {
    pub fn new(level: LogLevel, target: &str, message: &str) -> Self {
        Self {
            ts: now_local_sec(),
            level,
            target: target.to_string(),
            message: message.to_string(),
            fields: vec![],
        }
    }

    pub fn with_field(mut self, key: &str, val: &str) -> Self {
        self.fields.push((key.to_string(), val.to_string()));
        self
    }
}

// ============================================================
// 异步日志器
// ============================================================

/// 异步日志器
///
/// 后台线程从 channel 取条目 → 格式化 → 写文件 → flush (实时) → 轮转。
/// 主线程的 log_xxx() 调用纳秒级返回。
pub struct AsyncLogger {
    /// 用 Option<Sender> 让 Drop 时能显式 drop tx, 触发后台线程退出
    /// (修复 M11 + Drop 死锁: tx 在 self 里, 若不显式 take, join 永远等不到 Disconnected)
    tx: Mutex<Option<Sender<LogEntry>>>,
    handle: Mutex<Option<JoinHandle<()>>>,
    min_level: LogLevel,
    mirror_stdout: bool,
    dropped_count: Mutex<u64>,
}

impl AsyncLogger {
    /// 创建日志器, 启动后台写线程
    ///
    /// - `log_dir`: 日志目录 (会自动创建)
    /// - `file_name`: 日志文件名 (如 tarn.log)
    /// - `capacity`: channel 容量 (满时丢日志)
    /// - `min_level`: 最低输出级别
    ///
    /// 日志策略: 运行时只追加不轮转 (无论多大), 轮转只发生在开机备份 (service.sh 0.2 段)。
    pub fn new(
        log_dir: PathBuf,
        file_name: &str,
        capacity: usize,
        min_level: LogLevel,
    ) -> std::io::Result<Self> {
        std::fs::create_dir_all(&log_dir)?;
        let log_path = log_dir.join(file_name);

        let (tx, rx) = bounded::<LogEntry>(capacity);

        let mirror_stdout = std::env::var("TARN_LOG_STDOUT").is_ok();
        let mirror_clone = mirror_stdout;

        let handle = std::thread::Builder::new()
            .name("tarn-logger".to_string())
            .stack_size(128 * 1024)
            .spawn(move || {
                // flush 不等于 fsync, flush 仅刷到内核 page cache (纳秒级),
                // 进程崩溃不丢, 内核崩溃才丢, 是性能与数据安全的最佳平衡
                let mut file = match OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(&log_path)
                {
                    Ok(f) => Some(f),
                    Err(_) => None,
                };
                // 修复 busy-wait: 用阻塞 recv() 代替 recv_timeout(500ms)
                // 无日志时线程彻底睡眠 (0 CPU), 收到日志或 channel 关闭才醒
                // fsync 策略改为惰性: 每条写完只 flush (page cache),
                // 脏数据累积或 channel 关闭时才 fsync (持久化到磁盘)
                const FSYNC_INTERVAL: Duration = Duration::from_secs(30);
                let mut last_fsync = std::time::Instant::now();
                let mut dirty = false;

                loop {
                    match rx.recv() {
                        Ok(entry) => {
                            let line = format_entry(&entry);

                            if let Some(ref mut f) = file {
                                if f.write_all(line.as_bytes()).is_ok() {
                                    // 实时 flush: 每条日志立即刷到内核 page cache
                                    // 让 tail -f / WebUI SSE 能立即看到
                                    let _ = f.flush();
                                    dirty = true;
                                }
                            }

                            // stdout 镜像 (调试)
                            if mirror_clone {
                                let _ = std::io::stdout().write_all(line.as_bytes());
                                let _ = std::io::stdout().flush();
                            }

                            // 惰性 fsync: 距上次 fsync 超过 30s 且有脏数据时才 fsync
                            // 避免空闲时频繁 fsync 占 CPU/IO
                            if dirty && last_fsync.elapsed() >= FSYNC_INTERVAL {
                                if let Some(ref mut f) = file {
                                    let _ = f.sync_all();
                                }
                                last_fsync = std::time::Instant::now();
                                dirty = false;
                            }
                        }
                        Err(_) => {
                            // channel 关闭 (所有 sender drop), flush + fsync 后退出
                            if let Some(mut f) = file.take() {
                                let _ = f.flush();
                                let _ = f.sync_all();
                            }
                            break;
                        }
                    }
                }
            })?;

        Ok(Self {
            tx: Mutex::new(Some(tx)),
            handle: Mutex::new(Some(handle)),
            min_level,
            mirror_stdout,
            dropped_count: Mutex::new(0),
        })
    }

    /// 记录日志 (纳秒级返回)
    pub fn log(&self, level: LogLevel, target: &str, message: &str) {
        if level < self.min_level {
            return;
        }
        let entry = LogEntry::new(level, target, message);
        // 有界通道满时丢弃, 不阻塞
        let tx_guard = self.tx.lock();
        if let Some(tx) = tx_guard.as_ref() {
            if tx.try_send(entry).is_err() {
                *self.dropped_count.lock() += 1;
            }
        }
    }

    /// 记录带字段的日志
    pub fn log_with(&self, level: LogLevel, target: &str, message: &str, fields: Vec<(&str, String)>) {
        if level < self.min_level {
            return;
        }
        let mut entry = LogEntry::new(level, target, message);
        entry.fields = fields
            .into_iter()
            .map(|(k, v)| (k.to_string(), v))
            .collect();
        let tx_guard = self.tx.lock();
        if let Some(tx) = tx_guard.as_ref() {
            let _ = tx.try_send(entry);
        }
    }

    pub fn trace(&self, target: &str, msg: &str) {
        self.log(LogLevel::Trace, target, msg);
    }
    pub fn debug(&self, target: &str, msg: &str) {
        self.log(LogLevel::Debug, target, msg);
    }
    pub fn info(&self, target: &str, msg: &str) {
        self.log(LogLevel::Info, target, msg);
    }
    pub fn warn(&self, target: &str, msg: &str) {
        self.log(LogLevel::Warn, target, msg);
    }
    pub fn error(&self, target: &str, msg: &str) {
        self.log(LogLevel::Error, target, msg);
    }

    /// 丢弃的日志数 (channel 满时)
    pub fn dropped_count(&self) -> u64 {
        *self.dropped_count.lock()
    }

    /// 是否镜像到 stdout
    pub fn is_mirror_stdout(&self) -> bool {
        self.mirror_stdout
    }

    /// 优雅关闭 (修复 M11)
    ///
    /// 显式 drop tx, 让后台线程检测到 Disconnected 后退出, 然后 join。
    /// 调用后无法再 log, 所有 log_xxx 方法会静默丢弃。
    pub fn shutdown(&self) {
        // take 出 tx 并 drop, 后台线程的 recv_timeout 会返回 Disconnected
        if let Some(tx) = self.tx.lock().take() {
            drop(tx);
        }
        // join 后台线程
        if let Some(h) = self.handle.lock().take() {
            let _ = h.join();
        }
    }
}

impl Drop for AsyncLogger {
    fn drop(&mut self) {
        // 修复 M11 + Drop 死锁: 必须先 drop tx, 让后台线程检测到 Disconnected 退出, 再 join
        // 否则 join 永远等不到线程退出 (tx 还在 self 里, channel 不会断)
        if let Some(tx) = self.tx.lock().take() {
            drop(tx);
        }
        if let Some(h) = self.handle.lock().take() {
            let _ = h.join();
        }
    }
}

// ============================================================
// 日志格式化 (纯文本)
// ============================================================

/// 格式化为纯文本日志行
///
/// 格式: `[YYYY-MM-DD HH:MM:SS] [LEVEL] target message [k1=v1] [k2=v2]`
fn format_entry(entry: &LogEntry) -> String {
    let mut s = String::with_capacity(256);
    s.push('[');
    s.push_str(&entry.ts);
    s.push_str("] [");
    s.push_str(entry.level.as_str());
    s.push_str("] ");
    if !entry.target.is_empty() {
        s.push_str(&entry.target);
        s.push(' ');
    }
    s.push_str(&entry.message);
    for (k, v) in &entry.fields {
        s.push_str(" [");
        s.push_str(k);
        s.push('=');
        s.push_str(v);
        s.push(']');
    }
    s.push('\n');
    s
}

/// 解析纯文本日志行, 返回 LogEntry (用于 WebUI tail log)
///
/// 兼容旧 JSON 格式 (如果检测到 { 开头, 走 JSON 解析)。
pub fn parse_line(line: &str) -> Option<LogEntry> {
    let line = line.trim();
    if line.is_empty() {
        return None;
    }
    // 兼容旧 JSON 日志
    if line.starts_with('{') {
        return parse_json_line(line);
    }
    // 纯文本: [ts] [LEVEL] target message [k=v]...
    // 依次找出前两个 [...] 区间
    let close1 = line.find(']')?;
    let ts = line.get(1..close1)?.trim().to_string();
    let after1 = line.get(close1 + 1..)?.trim_start();
    if !after1.starts_with('[') {
        return None;
    }
    let close2 = after1.find(']')?;
    let level_str = after1.get(1..close2)?.trim();
    let level = LogLevel::from_str(level_str);
    let rest = after1.get(close2 + 1..)?.trim_start();
    // target + message
    let (target, message_with_fields) = if let Some(sp) = rest.find(' ') {
        (rest[..sp].to_string(), rest[sp..].trim_start().to_string())
    } else {
        (String::new(), rest.to_string())
    };
    // 分离 message 和 fields
    let mut message = String::new();
    let mut fields: Vec<(String, String)> = Vec::new();
    let chars: Vec<char> = message_with_fields.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c == '[' {
            // 后面到 ] 之间有 = 才是字段
            let mut j = i + 1;
            let mut found_eq = false;
            let mut found_close = false;
            while j < chars.len() {
                if chars[j] == '=' {
                    found_eq = true;
                }
                if chars[j] == ']' {
                    found_close = true;
                    break;
                }
                j += 1;
            }
            if found_eq && found_close {
                // 字段: 提取 k=v
                let inner: String = chars[i+1..j].iter().collect();
                if let Some(eq) = inner.find('=') {
                    let k = inner[..eq].trim().to_string();
                    let v = inner[eq+1..].trim().to_string();
                    if !k.is_empty() {
                        fields.push((k, v));
                    }
                }
                i = j + 1;
            } else {
                message.push(c);
                i += 1;
            }
        } else {
            message.push(c);
            i += 1;
        }
    }
    Some(LogEntry {
        ts,
        level,
        target,
        message: message.trim().to_string(),
        fields,
    })
}

/// 解析旧 JSON 格式日志行 (向后兼容)
fn parse_json_line(line: &str) -> Option<LogEntry> {
    let v = serde_json::from_str::<serde_json::Value>(line).ok()?;
    let entry = LogEntry {
        ts: v.get("ts").and_then(|x| x.as_str()).unwrap_or("").to_string(),
        level: LogLevel::from_str(
            v.get("level").and_then(|x| x.as_str()).unwrap_or("info"),
        ),
        target: v.get("target").and_then(|x| x.as_str()).unwrap_or("").to_string(),
        message: v.get("msg").and_then(|x| x.as_str()).unwrap_or("").to_string(),
        fields: v
            .as_object()
            .map(|obj| {
                obj.iter()
                    .filter(|(k, _)| !matches!(k.as_str(), "ts" | "level" | "target" | "msg"))
                    .map(|(k, v)| (k.clone(), v.to_string()))
                    .collect()
            })
            .unwrap_or_default(),
    };
    Some(entry)
}

/// 当前 UTC+8 时间, 精确到秒, 格式 YYYY-MM-DD HH:MM:SS
///
/// 委托给 [`crate::timeutil::now_cst_sec`], 统一时区来源。
fn now_local_sec() -> String {
    now_cst_sec()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_log_level_from_str() {
        assert_eq!(LogLevel::from_str("info"), LogLevel::Info);
        assert_eq!(LogLevel::from_str("DEBUG"), LogLevel::Debug);
        assert_eq!(LogLevel::from_str("warning"), LogLevel::Warn);
        assert_eq!(LogLevel::from_str("xyz"), LogLevel::Info); // fallback
    }

    #[test]
    fn test_log_level_order() {
        assert!(LogLevel::Error > LogLevel::Warn);
        assert!(LogLevel::Warn > LogLevel::Info);
        assert!(LogLevel::Info > LogLevel::Debug);
        assert!(LogLevel::Debug > LogLevel::Trace);
    }

    #[test]
    fn test_format_entry_text() {
        let e = LogEntry::new(LogLevel::Info, "daemon", "Tarn daemon 启动");
        let s = format_entry(&e);
        assert!(s.contains("[INFO"));
        assert!(s.contains("daemon Tarn daemon 启动"));
        assert!(s.ends_with("]\n") || s.ends_with("\n"));
    }

    #[test]
    fn test_format_entry_with_fields() {
        let mut e = LogEntry::new(LogLevel::Info, "exec", "deleted");
        e.fields.push(("rule".to_string(), "wx_cache".into()));
        e.fields.push(("count".to_string(), "42".into()));
        let s = format_entry(&e);
        assert!(s.contains("[rule=wx_cache]"));
        assert!(s.contains("[count=42]"));
    }

    #[test]
    fn test_parse_text_line() {
        let line = "[2024-06-17 14:23:45] [INFO] daemon Tarn daemon 启动 [pid=12345]";
        let e = parse_line(line).expect("解析失败");
        assert_eq!(e.ts, "2024-06-17 14:23:45");
        assert_eq!(e.level, LogLevel::Info);
        assert_eq!(e.target, "daemon");
        assert_eq!(e.message, "Tarn daemon 启动");
        assert_eq!(e.fields.len(), 1);
        assert_eq!(e.fields[0], ("pid".to_string(), "12345".to_string()));
    }

    #[test]
    fn test_parse_json_line_compat() {
        let line = r#"{"ts":"2024-06-17T14:23:45+08:00","level":"INFO","target":"daemon","msg":"启动"}"#;
        let e = parse_line(line).expect("JSON 解析失败");
        assert_eq!(e.level, LogLevel::Info);
        assert_eq!(e.target, "daemon");
        assert_eq!(e.message, "启动");
    }

    #[test]
    fn test_async_logger_write() {
        let tmp = std::env::temp_dir().join("tarn_log_test");
        let _ = std::fs::remove_dir_all(&tmp);
        let log = AsyncLogger::new(
            tmp.clone(),
            "test.log",
            64,
            LogLevel::Debug,
        )
        .unwrap();
        for i in 0..50 {
            log.info("test", &format!("line {}", i));
        }
        // drop 会等后台线程退出
        drop(log);
        let content = std::fs::read_to_string(tmp.join("test.log")).unwrap();
        assert!(content.contains("line 0"));
        assert!(content.contains("line 49"));
        let _ = std::fs::remove_dir_all(&tmp);
    }

    #[test]
    fn test_async_logger_with_fields() {
        let tmp = std::env::temp_dir().join("tarn_log_field_test");
        let _ = std::fs::remove_dir_all(&tmp);
        let log = AsyncLogger::new(tmp.clone(), "f.log", 32, LogLevel::Trace).unwrap();
        log.log_with(
            LogLevel::Info,
            "exec",
            "deleted",
            vec![("rule", "wx_cache".into()), ("count", "42".into())],
        );
        drop(log);
        let content = std::fs::read_to_string(tmp.join("f.log")).unwrap();
        assert!(content.contains("[rule=wx_cache]"));
        assert!(content.contains("[count=42]"));
        let _ = std::fs::remove_dir_all(&tmp);
    }
}
