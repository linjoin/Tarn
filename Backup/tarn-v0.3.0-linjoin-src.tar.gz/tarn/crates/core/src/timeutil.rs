//! 时间工具: 统一使用 UTC+8 (中国标准时间 CST) 固定时区
//!
//! 设计原因:
//! - Magisk 模块运行环境时区可能不可靠 (recovery/容器/某些 ROM 未设 TZ)
//! - chrono::Local 依赖 /etc/localtime 与 TZ 环境变量, Android root 环境下不保证存在
//! - 用户明确要求日志统一 UTC+8, 这里集中管理, 避免散落各处的 Local/Utc 混用
//! - FixedOffset 不依赖系统时区数据库, 二进制内嵌, 0 外部依赖, 适合 Magisk 模块
//!
//! 所有对外时间 API:
//! - [`now_cst`]: 当前 UTC+8 时刻 (DateTime<FixedOffset>)
//! - [`now_cst_sec`]: "YYYY-MM-DD HH:MM:SS" 字符串 (日志行用)
//! - [`now_cst_rfc3339`]: RFC3339 字符串 (state.json / run_id 时间戳用)

use chrono::{DateTime, Datelike, FixedOffset, SecondsFormat, Timelike};

/// UTC+8 固定偏移 (8 * 3600 秒)
pub const CST_OFFSET_SECS: i32 = 8 * 3600;

/// UTC+8 FixedOffset (线程安全, 无需初始化)
pub fn cst_offset() -> FixedOffset {
    // east_opt 在 chrono 0.4.35+ 取代已废弃的 east(), 秒数合法时返回 Some
    FixedOffset::east_opt(CST_OFFSET_SECS).expect("8*3600 is valid offset")
}

/// 当前 UTC+8 时刻
pub fn now_cst() -> DateTime<FixedOffset> {
    chrono::Utc::now().with_timezone(&cst_offset())
}

/// 当前 UTC+8 时间, 精确到秒, 格式 "YYYY-MM-DD HH:MM:SS"
///
/// 用于日志行的前导时间戳字段。
/// 注意: 不带时区后缀 (用户要求"时间精确到秒", 简洁清晰),
/// 时区固定为 UTC+8, 由本模块统一保证, 无需在每行日志重复标注。
pub fn now_cst_sec() -> String {
    let t = now_cst();
    format!(
        "{:04}-{:02}-{:02} {:02}:{:02}:{:02}",
        t.year(),
        t.month(),
        t.day(),
        t.hour(),
        t.minute(),
        t.second(),
    )
}

/// 当前 UTC+8 时间, RFC3339 格式 (含时区偏移 +08:00)
///
/// 用于 state.json / executor 的 ISO 时间戳字段, 保留时区信息便于后续解析。
pub fn now_cst_rfc3339() -> String {
    now_cst().to_rfc3339_opts(SecondsFormat::Secs, true)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cst_offset_is_plus_8() {
        let now = now_cst();
        assert_eq!(now.offset().local_minus_utc(), 8 * 3600);
    }

    #[test]
    fn test_now_cst_sec_format() {
        let s = now_cst_sec();
        // YYYY-MM-DD HH:MM:SS 共 19 字符
        assert_eq!(s.len(), 19, "格式应为 YYYY-MM-DD HH:MM:SS, 实际: {}", s);
        assert_eq!(s.chars().nth(4), Some('-'));
        assert_eq!(s.chars().nth(7), Some('-'));
        assert_eq!(s.chars().nth(10), Some(' '));
        assert_eq!(s.chars().nth(13), Some(':'));
        assert_eq!(s.chars().nth(16), Some(':'));
    }

    #[test]
    fn test_now_cst_rfc3339_has_offset() {
        let s = now_cst_rfc3339();
        assert!(s.ends_with("+08:00"), "RFC3339 应以 +08:00 结尾, 实际: {}", s);
    }

    #[test]
    fn test_cst_ahead_of_utc_by_8_hours() {
        use chrono::Timelike;
        // 注意: DateTime<Utc> 与 DateTime<FixedOffset> 若表示同一时刻,
        // signed_duration_since 返回 0 (它们是同一 instant).
        // 正确验证方式: 比较两者的"墙上时钟小时数", CST 应比 UTC 快 8 小时 (mod 24)。
        let utc = chrono::Utc::now();
        let cst = now_cst();
        let expected_hour = (utc.hour() as i32 + 8) % 24;
        assert_eq!(cst.hour() as i32, expected_hour,
            "CST 小时应为 (UTC+8) mod 24, UTC hour={}, CST hour={}", utc.hour(), cst.hour());
    }
}
