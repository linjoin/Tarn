//! 配置层: 三文件 schema 与加载
//!
//! 三文件:
//! - `blacklist.toml`: 清理规则 (要删什么)
//! - `whitelist.toml`: 保护规则 (不删什么)
//! - `settings.toml`: 引擎全局设置 (怎么跑)
//!
//! 设计原则: 只暴露真正生效的字段, 不保留"看起来能配实际不读"的死配置。
//!
//! 简化原则:
//!   - Rule 不含 desc/author/version/category/tags (展示字段引擎不读)
//!   - RuleTrigger 不含 min_interval_min (半死字段, 未实现)
//!   - Target 不含 action (永远 delete, 配置项误导)
//!   - ProtectPath 合并 path/pattern 为单一 path, 不含 desc/match_type
//!     (path 含通配符 * ? [ 自动当通配符, 否则 prefix; exact 极少用)
//!   - ProtectPackage 不含 reason
//!   - ProtectExt 不含 desc
//!   - ProtectMtime 不含 reason

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use thiserror::Error;

// ============================================================
// 错误类型
// ============================================================

#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("配置文件不存在: {0}")]
    NotFound(PathBuf),
    #[error("读取配置失败 {path}: {source}")]
    Read { path: PathBuf, source: std::io::Error },
    #[error("解析 TOML 失败 {path}: {source}")]
    Parse { path: PathBuf, source: toml::de::Error },
    #[error("配置校验失败: {0}")]
    Validate(String),
}

// ============================================================
// Settings (settings.toml) - 引擎全局设置
// ============================================================
//
// 段落说明:
// - [engine]    并行/批量/IO 限速/低功耗/遍历选项
// - [schedule]  规则默认超时
// - [run]       自适应限速开关
// - [log]       日志级别/轮转
// - [webui]     绑定地址/端口/socket
//
// 不暴露的死配置 (引擎不读, 用户无需配置):
// - [general]      language / schema_version (硬编码常量)
// - [schedule]     boot_delay_sec / boot_enabled / min_interval_min (daemon 不读)
// - [run]          default_risk / default_dry_run / force_protect / avoid_foreground_app (硬编码)
// - [log]          format / dir / async_writer / redact_paths (硬编码)
// - [state]        backend / path / save_interval_sec (硬编码 config_dir/state.json)
// - [webui]        enabled / token_file / auto_open / cors_enabled / force_dry_run_before_save
// - [trash]        全段 (功能未实现)
// - [subscribe]    全段 (功能未实现)
//
// 合并字段:
// - use_ionice + use_nice → engine.low_power (ionice 不使用, 仅 nice + 绑核)

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub engine: EngineSection,
    pub schedule: ScheduleSection,
    pub run: RunSection,
    pub log: LogSection,
    pub webui: WebuiSection,
    /// 统计轮转配置 (累计数据达到阈值后归档并清零)
    pub state: StateSection,
}

impl Default for Settings {
    fn default() -> Self {
        Self {
            engine: EngineSection::default(),
            schedule: ScheduleSection::default(),
            run: RunSection::default(),
            log: LogSection::default(),
            webui: WebuiSection::default(),
            state: StateSection::default(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct EngineSection {
    /// 0 = 自动 (CPU 核数)
    pub parallel_workers: usize,
    /// 单批 unlink 文件数
    pub batch_size: usize,
    /// 每秒最多删 N 个文件 (0 = 不限)
    pub io_throttle_ops_per_sec: u64,
    /// 每秒最多删 N 字节 (0 = 不限)
    pub io_throttle_bytes_per_sec: u64,
    /// 一次性开关: 同时应用 nice 19 + 绑小核 (低功耗模式)
    ///
    /// 理论验证: nice(19) 在所有 Android 设备上有效 (CFS 调度器用 nice 值
    /// 计算时间片权重, weight = 1024 * 1.25^(-nice), nice 19 → weight ~15)。
    /// 不使用 ionice IDLE — CFQ 调度器内核 5.x 已删, Android 的
    /// mq-deadline/none/kyber 调度器忽略 ioprio, 是空操作, 保留无意义。
    ///
    /// CPU 亲和性 (sched_setaffinity) 绑核覆盖 per-thread 遗漏:
    /// 通过遍历 /proc/self/task/<tid> 对所有线程 (含 logger/webui/tokio worker) 设亲和性。
    /// cpu_affinity 为空时自动探测小核 (detect_little_cores)。
    pub low_power: bool,
    /// CPU 亲和性: 绑定到这些 CPU 核心 (big.LITTLE 上绑小核避免占大核)
    ///
    /// - 空 `[]` = 自动探测小核 (读 /sys/devices/system/cpu/cpu*/cpufreq/cpuinfo_max_freq,
    ///   取频率最低的那组, 容忍 ±5% 同频误差, 失败回退 [0,1,2,3])
    /// - 非空 `[0,1,2,3]` = 手动指定核心编号
    ///
    /// 仅当 `low_power = true` 时生效。绑定通过 /proc/self/task 遍历覆盖所有线程。
    #[serde(default)]
    pub cpu_affinity: Vec<usize>,
    pub walk_follow_symlink: bool,
    /// 0 = 不限
    pub walk_max_depth: usize,
    pub walk_skip_hidden: bool,
    /// 用 getdents64 直读 (快)
    pub use_getdents: bool,
    /// 用 unlinkat 合并调用 (快)
    pub use_unlinkat: bool,
    /// [v0.7.6] 文件系统感知限速: ext4 + discard mount 时删除自动降并发到 1
    ///
    /// 全网调研依据 (patrick-nagel.net/blog/archives/337, lwn.net/Articles/787272):
    /// ext4 + discard mount option 删一批小文件比无 discard 慢 64 倍 (同步 TRIM 阻塞每次 unlink)。
    /// 开启后, executor 在 run_rule 时探测 target.path 的 fs 类型 + mount option,
    /// 若 ext4+discard 则删除串行化 (并发降到 1), 避免 TRIM 风暴。
    /// f2fs / ext4 无 discard 不受影响, 保持正常并发。
    /// 探测结果在 rule 级别缓存 (同一 target.path 只 statfs + 解析 /proc/mounts 一次)。
    #[serde(default = "default_true")]
    pub fs_aware_throttle: bool,
    /// [v0.7.6] 用 openat2 + RESOLVE_NO_SYMLINKS 打开目录 (内核级防 symlink TOCTOU)
    ///
    /// 全网调研依据 (man7 openat2.2, lwn.net/Articles/1050887):
    /// openat2 在 Linux 5.6+ 支持, RESOLVE_NO_SYMLINKS 内核级杜绝 symlink 逃逸。
    /// 5.10 满足。运行时检测: openat2 不可用 (ENOSYS) 自动回退 openat + O_DIRECTORY。
    /// 安全增强: 即便 follow_symlink=false, openat2 提供更强的内核级保证。
    /// 关闭后回退到 openat (与 v0.7.5 行为一致)。
    #[serde(default = "default_true")]
    pub use_openat2: bool,
}

impl Default for EngineSection {
    fn default() -> Self {
        Self {
            parallel_workers: 0,
            batch_size: 500,
            io_throttle_ops_per_sec: 0,
            io_throttle_bytes_per_sec: 0,
            low_power: true,
            cpu_affinity: Vec::new(),
            walk_follow_symlink: false,
            walk_max_depth: 0,
            walk_skip_hidden: false,
            use_getdents: true,
            use_unlinkat: true,
            fs_aware_throttle: true,
            use_openat2: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ScheduleSection {
    /// 0 = 不限时
    pub default_rule_timeout_sec: u64,
}

impl Default for ScheduleSection {
    fn default() -> Self {
        Self {
            default_rule_timeout_sec: 0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct RunSection {
    /// 自适应限速 (前台忙才限速, 空闲全速)
    pub adaptive_rate_limit: bool,
}

impl Default for RunSection {
    fn default() -> Self {
        Self {
            adaptive_rate_limit: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct LogSection {
    pub level: String,
    pub file: String,
    /// 开机备份保留份数 (service.sh 读此值, 0 = 不备份, N = 保留 N 份历史)
    pub keep_files: u32,
    /// crossbeam-channel 容量 (满时丢日志不阻塞主线程)
    pub channel_capacity: usize,
}

impl Default for LogSection {
    fn default() -> Self {
        Self {
            level: "info".to_string(),
            file: "tarn.log".to_string(),
            keep_files: 3,
            channel_capacity: 8192,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct WebuiSection {
    /// daemon 启动时是否内嵌拉起 WebUI HTTP 服务
    /// - true: daemon 进程内 spawn 独立线程跑 axum, 端口监听 [bind]:[port]
    /// - false: 仅跑 cron 调度, WebUI 需用户手动 `tarn webui` 启动
    /// (daemon 内嵌 WebUI 时此字段决定是否自动拉起)
    pub enabled: bool,
    pub bind: String,
    pub port: u16,
    pub socket_file: String,
}

impl Default for WebuiSection {
    fn default() -> Self {
        Self {
            enabled: true,
            bind: "127.0.0.1".to_string(),
            port: 8080,
            // 运行时目录 (不污染数据目录根)
            // 实际路径 = <config_dir>/run/tarn.sock (run.rs::serve 会 join 相对路径)
            socket_file: "run/tarn.sock".to_string(),
        }
    }
}

/// 统计轮转配置
///
/// 当累计统计 (total_files_deleted / total_freed_bytes) 达到任一阈值时,
/// 把当前 totals 归档到 state.json 的 rotation_history 数组, 然后清零 totals
/// (history 数组保留, 仅 totals 归零), 让用户能跟踪每个"周期"的清理量。
///
/// 阈值 0 = 关闭该项轮转 (两个都为 0 时永不轮转)。
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct StateSection {
    /// 累计删除文件数达到此值时轮转 (0 = 不按文件数轮转)
    ///
    /// 例如 100000 表示每删 10 万个文件归档一次。
    pub rotate_after_files: u64,
    /// 累计清理字节数达到此值时轮转 (0 = 不按字节数轮转)
    ///
    /// 例如 10737418240 (10 GB) 表示每清理 10 GB 归档一次。
    pub rotate_after_bytes: u64,
    /// 保留多少份历史归档 (FIFO, 0 = 不保留, 仅清零)
    ///
    /// 每份归档约 200 字节, 默认 12 份 ≈ 2.4 KB, 无磁盘压力。
    pub keep_rotation_history: u32,
}

impl Default for StateSection {
    fn default() -> Self {
        Self {
            rotate_after_files: 0,
            rotate_after_bytes: 0,
            keep_rotation_history: 12,
        }
    }
}

// ============================================================
// Blacklist (blacklist.toml) - 清理规则
// ============================================================

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Blacklist {
    /// 所有规则, 取并集 (命中任一即纳入待删)
    #[serde(default)]
    pub rule: Vec<Rule>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Rule {
    /// 全局唯一, kebab-case
    pub id: String,
    pub name: String,
    #[serde(default = "default_true")]
    pub enabled: bool,
    /// 1-100, 影响执行顺序 (高优先先删)
    #[serde(default = "default_priority")]
    pub priority: u8,
    /// 风险等级标签: `low` | `medium` | `high` | `dangerous`, 仅作分类展示用, 不影响是否执行。
    ///
    /// 安全模型: 用户写完规则就必须能执行, `dry_run` 是唯一安全栅栏。
    /// 详见 [`crate::executor::RunOptions::dry_run`]。
    #[serde(default = "default_risk")]
    pub risk: String,
    /// 是否在删除文件后清理空目录 (规则级总开关, 默认 false)
    ///
    /// 启用后, 每个 target 删完文件会自底向上递归清理空目录:
    /// - 仅删真正空 (无文件无子目录) 的目录
    /// - 不删 target.path 本身 (除非 `clean_empty_dirs_include_root = true`)
    /// - 不向上跨越 target.path (避免误删 App 包目录 /data/data/com.foo)
    /// - 受 ProtectSet 约束 (受保护的目录不删)
    /// - 不跟随符号链接 (避免删到 /system)
    /// - dry_run 模式下只统计不真删
    ///
    /// 每个 target 可通过 `Target.clean_empty_dirs` 覆盖此默认值
    /// (None = 跟随 rule, Some(true/false) = 强制开/关)。
    #[serde(default)]
    pub clean_empty_dirs: bool,

    /// 空目录清理是否连 target.path 本身也删 (默认 false, 安全)
    ///
    /// 默认 false: target.path (通常是 App 数据根目录, 如 cache/) 即便变空也保留,
    /// 因为 App 可能仍持有该路径的 fd 或期望它存在, 删除会破坏 App。
    ///
    /// 设为 true: 如果删完文件后 target.path 本身也空了, 连 target.path 一起 rmdir。
    /// 适用场景: 临时目录 (如 /data/data/com.foo/files/.tmp_xxx) 应彻底清理。
    /// 风险: 对 App 主缓存目录开启可能导致 App 崩溃, 请谨慎。
    ///
    /// 每个 target 可通过 `Target.clean_empty_dirs_include_root` 覆盖。
    #[serde(default)]
    pub clean_empty_dirs_include_root: bool,

    /// 空目录清理的最大深度 (默认 0 = 不限)
    ///
    /// 0 = 不限深度, 递归清理所有空子目录 (受内部 64 层防御上限约束)。
    /// N > 0 = 只清理 target.path 下深度 <= N 的空目录。
    ///   深度 1 = target.path/子目录 (不递归更深层)
    ///   深度 2 = target.path/子目录/孙目录
    ///
    /// 用途: 限制清理范围, 避免在极深目录树中耗时遍历; 或避免误删深层结构。
    ///
    /// 每个 target 可通过 `Target.clean_empty_dirs_max_depth` 覆盖。
    #[serde(default)]
    pub clean_empty_dirs_max_depth: u32,

    #[serde(default)]
    pub trigger: RuleTrigger,
    #[serde(default)]
    pub targets: Vec<Target>,
}

fn default_true() -> bool { true }
fn default_priority() -> u8 { 50 }
fn default_risk() -> String { "low".to_string() }

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RuleTrigger {
    /// 触发类型列表, 可多选: `manual` | `boot` | `cron` | `event`
    ///
    /// - `manual` → 手动: WebUI 点「立即清理」或命令行 `tarn run` 时触发
    /// - `boot`   → 开机: 设备开机后由 tarn daemon 自动触发一次
    /// - `cron`   → 定时: 按 [`Self::cron_expr`] 表达式周期触发 (内核 timerfd + CLOCK_BOOTTIME_ALARM, 穿透 Doze)
    /// - `event`  → 事件: 外部触发 (如 `tarn trigger event` 或其他 App 调用); 预留扩展
    /// cron 表达式放在独立的 cron_expr 字段 (不放 on 字段, 避免 "cron" + "cron:*/5 * * * *" 双重约定)。
    /// 向后兼容: 仍解析 on 中的 "cron:<expr>" 形式 (兼容旧配置)。
    #[serde(default)]
    pub on: Vec<String>,
    /// 仅剩余空间 < N MB 才执行 (0 = 不限)
    #[serde(default)]
    pub min_free_mb: u64,
    /// cron 表达式 (5 字段: 分 时 日 月 周)
    ///
    /// 仅当 on 包含 "cron" 时生效。如 "0 3 * * *" 表示每天 3:00 触发。
    /// 若 on 包含旧式 "cron:<expr>" 也会被解析到这里 (向后兼容)。
    ///
    /// 示例:
    /// - `0 3 * * *`    每天 3:00
    /// - `*/30 * * * *` 每 30 分钟
    /// - `0 */6 * * *`  每 6 小时
    /// - `0 3 * * 1`    每周一 3:00
    #[serde(default)]
    pub cron_expr: Option<String>,
}

impl RuleTrigger {
    /// 提取 cron 表达式: 优先 cron_expr 字段, 回退解析 on 中的 "cron:<expr>" (兼容旧配置)
    pub fn get_cron_expr(&self) -> Option<&str> {
        if let Some(expr) = &self.cron_expr {
            return Some(expr);
        }
        // 向后兼容: 解析 on 中的 "cron:<expr>" 形式
        self.on
            .iter()
            .find_map(|t| t.strip_prefix("cron:"))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum TargetMode {
    /// 严格通配符: 只删匹配 pattern 的 File, 不动目录
    /// 例: glob=`**/*.log` → 删所有 .log 文件, 目录保留
    #[default]
    DeleteFiles,
    /// 清空匹配目录: pattern 命中的目录会被递归清空里面的文件, 但目录本身保留
    /// 例: glob=`*cache` → 匹配所有名字带 cache 的目录, 清空里面的文件
    /// 底层等价于自动追加 `<pattern>/**/*`, 但这是用户显式选的, 不是底层魔法
    ClearDirs,
    /// 删除整个目录: pattern 命中的目录连同内容一起删 (危险)
    /// 内部实现 = ClearDirs + 强制 clean_empty_dirs_include_root=true
    /// 例: glob=`*.tmp_dir` → 匹配并整个删除所有 .tmp_dir 目录
    DeleteDirs,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Target {
    pub path: String,
    /// 默认 **/* (* 不跨 /, ** 跨)
    #[serde(default = "default_glob")]
    pub glob: String,
    /// 处理方式: 决定 pattern 命中后的行为
    /// - `delete_files` (默认): 严格通配符, 只删匹配的文件
    /// - `clear_dirs`: 匹配到的目录, 清空里面的文件 (目录保留)
    /// - `delete_dirs`: 匹配到的目录连根删 (危险, 内部 = clear_dirs + 强制 include_root)
    #[serde(default)]
    pub mode: TargetMode,
    /// 仅删 N 天前的 (mtime), 0 = 不限
    #[serde(default)]
    pub older_than_days: u32,
    /// 仅删 >= N KB 的, 0 = 不限
    #[serde(default)]
    pub min_size_kb: u64,
    /// 本 target 内排除
    #[serde(default)]
    pub exclude: Vec<String>,
    /// 是否清理此 target 下的空目录 (target 级覆盖, 默认 None = 跟随 Rule.clean_empty_dirs)
    ///
    /// 三态语义:
    /// - `None` (字段缺省): 跟随 [`Rule::clean_empty_dirs`]
    /// - `Some(true)`: 强制开启 (即便 Rule 关闭)
    /// - `Some(false)`: 强制关闭 (即便 Rule 开启)
    ///
    /// 使用场景: 同一规则下不同 target 路径希望不同处理
    /// (如 cache 目录想清空目录, 但 files/Download 不想)。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub clean_empty_dirs: Option<bool>,
    /// 空目录清理是否连 target.path 本身也删 (target 级覆盖, None = 跟随 Rule)
    ///
    /// 详见 [`Rule::clean_empty_dirs_include_root`]。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub clean_empty_dirs_include_root: Option<bool>,
    /// 空目录清理最大深度 (target 级覆盖, None = 跟随 Rule)
    ///
    /// 详见 [`Rule::clean_empty_dirs_max_depth`]。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub clean_empty_dirs_max_depth: Option<u32>,
}

fn default_glob() -> String { "**/*".to_string() }

// ============================================================
// Whitelist (whitelist.toml) - 保护规则
// ============================================================
//
// 设计原则:
//   - 不含仅展示字段 (desc/reason)
//   - ProtectPath 用单一 path 字段 (path/pattern 合并), 不含 match_type:
//     path 含通配符 (* ? [) → 通配符匹配, 否则 → prefix 匹配 (前缀最常用)
//     exact 极少使用 (如有需要可用通配符表达式精确匹配)
//   - scope 留空或 "global" = 全局, 否则为路径前缀

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Whitelist {
    /// 路径保护 (path 含通配符 = 通配符, 否则 = prefix)
    #[serde(default)]
    pub protect: Vec<ProtectPath>,
    /// 按包名保护整个 App
    #[serde(default)]
    pub protect_package: Vec<ProtectPackage>,
    /// 按扩展名保护
    #[serde(default)]
    pub protect_ext: Vec<ProtectExt>,
    /// 按修改时间保护 (N 天内的)
    #[serde(default)]
    pub protect_mtime: Vec<ProtectMtime>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProtectPath {
    pub id: String,
    /// 路径或通配符模式 (保护该路径及其所有子内容不被清理)
    ///
    /// # 匹配规则 (与清理侧 [`Target::glob`] 语义统一)
    ///
    /// - 含通配符 `*` `?` `[` → **通配符匹配** (用 globset DFA, `literal_separator(true)`)
    /// - 否则 → **prefix 匹配** (最常用, 保护该目录及其所有子内容)
    ///
    /// # 通配符语义 (POSIX shell 直觉, 与 [`crate::matcher::Matcher`] 一致)
    ///
    /// | 写法 | 含义 | 示例 |
    /// |------|------|------|
    /// | `*` | 匹配**单段**路径名内的任意字符, **不跨 `/`** | `/sdcard/Download/*.pdf` 匹配 `report.pdf`, 不匹配 `sub/x.pdf` |
    /// | `**` | 跨**任意层**文件夹 (递归) | `/sdcard/Download/**/*.pdf` 匹配所有层级的 .pdf |
    /// | `?` | 单个任意字符 (不跨 `/`) | `?.log` 匹配 `a.log`, 不匹配 `ab.log` |
    /// | `[abc]` | 字符集 | `[abc].txt` 匹配 `a.txt`/`b.txt`/`c.txt` |
    ///
    /// **通配符匹配的是路径字符串, 文件和文件夹都匹配** — 到底匹配到什么取决于你写的模式:
    /// - 保护文件: 用 `*.后缀` (如 `/sdcard/Download/*.pdf` 保护 Download 下的 PDF)
    /// - 保护文件夹: 用 `*名字` (如 `/data/data/*cache` 保护所有名字含 cache 的目录)
    /// - 递归保护: 用 `**` (如 `/sdcard/Download/**` 保护 Download 下所有内容)
    ///
    /// # 跨路径形式自动归一化 (防 Android 别名绕过)
    ///
    /// Android 外置存储有 4 种字面入口形式, 指向同一份物理存储:
    /// `/sdcard` ↔ `/storage/emulated/0` ↔ `/storage/self/primary` ↔ `/data/media/0`
    ///
    /// 用户只需写一种形式 (如 `/sdcard/Download`), 引擎在 [`crate::protect::ProtectSet::compile`]
    /// 自动展开为全部 4 种等价形式, 防止 blacklist 用 `/storage/emulated/0/Download` 形式绕过保护。
    /// 通配符 protect_path (如 `/sdcard/Download/*.pdf`) 同样会跨 4 种形式归一化。
    ///
    /// # 常见示例
    ///
    /// ```toml
    /// [[protect_path]]
    /// id = "my_download"
    /// path = "/sdcard/Download"              # prefix: 保护整个 Download 目录
    ///
    /// [[protect_path]]
    /// id = "pdf_in_download"
    /// path = "/sdcard/Download/*.pdf"        # glob: 仅保护 Download 下的 PDF (不递归子目录)
    ///
    /// [[protect_path]]
    /// id = "all_pdf"
    /// path = "/sdcard/Download/**/*.pdf"     # glob: 递归保护所有层级 PDF
    ///
    /// [[protect_path]]
    /// id = "cache_dirs"
    /// path = "/data/data/*cache"             # glob: 保护所有名字含 cache 的目录本身 (不跨 /)
    /// ```
    pub path: String,
}

impl ProtectPath {
    /// 判断是否为通配符模式 (含 `*` `?` `[`)
    pub fn is_glob(&self) -> bool {
        self.path.chars().any(|c| matches!(c, '*' | '?' | '['))
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProtectPackage {
    pub package: String,
    /// 可选, 仅保护这些子目录 (空 = 全保护)
    #[serde(default)]
    pub only: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProtectExt {
    pub extensions: Vec<String>,
    /// 留空或 "global" = 全局, 否则为路径前缀
    #[serde(default)]
    pub scope: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProtectMtime {
    /// 保护 N 天内修改的文件
    pub within_days: u32,
    /// 留空或 "global" = 全局, 否则为路径前缀
    #[serde(default)]
    pub scope: String,
}

// ============================================================
// 加载函数
// ============================================================

impl Settings {
    pub fn load(path: &Path) -> Result<Self, ConfigError> {
        if !path.exists() {
            return Ok(Self::default());
        }
        let content = std::fs::read_to_string(path).map_err(|e| ConfigError::Read {
            path: path.to_path_buf(),
            source: e,
        })?;
        let s: Self = toml::from_str(&content).map_err(|e| ConfigError::Parse {
            path: path.to_path_buf(),
            source: e,
        })?;
        s.validate()?;
        Ok(s)
    }

    pub fn validate(&self) -> Result<(), ConfigError> {
        if self.engine.parallel_workers > 16 {
            return Err(ConfigError::Validate(format!(
                "engine.parallel_workers 越界 (1-16): {}",
                self.engine.parallel_workers
            )));
        }
        // cpu_affinity 边界校验, 防 CPU_SET 越界写 (UB)。
        // libc::CPU_SET(cpu, &set) 展开为 __bits[cpu/64] |= ..., CPU_SETSIZE=1024 位,
        // 若 cpu >= 1024 会越界写栈 → UB (可能栈溢出/crash)。
        for &cpu in &self.engine.cpu_affinity {
            if cpu >= 1024 {
                return Err(ConfigError::Validate(format!(
                    "engine.cpu_affinity 越界 (0-1023): {}", cpu
                )));
            }
        }
        // log.channel_capacity 不能为 0 (bounded(0) = rendezvous, 所有日志被丢)
        if self.log.channel_capacity == 0 {
            return Err(ConfigError::Validate(
                "log.channel_capacity 不能为 0 (会导致所有日志被丢弃)".to_string(),
            ));
        }
        Ok(())
    }
}

impl Blacklist {
    pub fn load(path: &Path) -> Result<Self, ConfigError> {
        if !path.exists() {
            return Ok(Self::default());
        }
        let content = std::fs::read_to_string(path).map_err(|e| ConfigError::Read {
            path: path.to_path_buf(),
            source: e,
        })?;
        toml::from_str(&content).map_err(|e| ConfigError::Parse {
            path: path.to_path_buf(),
            source: e,
        })
    }
}

impl Whitelist {
    pub fn load(path: &Path) -> Result<Self, ConfigError> {
        if !path.exists() {
            return Ok(Self::default());
        }
        let content = std::fs::read_to_string(path).map_err(|e| ConfigError::Read {
            path: path.to_path_buf(),
            source: e,
        })?;
        toml::from_str(&content).map_err(|e| ConfigError::Parse {
            path: path.to_path_buf(),
            source: e,
        })
    }
}
