# Tarn - 系统级文件治理引擎

> 系统级、高并发、低功耗、防雪崩的 Android 文件清理框架  
> Rust 内核 + Magisk 模块壳 + timerfd Doze 穿透 + Rayon 并行扫描

## 功能介绍

Tarn 是一个面向 Android root 用户的系统级文件治理引擎, 核心特性:

### 引擎能力
- **Rust 内核**: 编译为单二进制 (~2.6MB stripped), aarch64-linux-android 目标
- **双引擎**: Rayon (CPU 并行遍历) + Tokio (异步 IO)
- **timerfd + CLOCK_BOOTTIME_ALARM**: 内核级定时, 穿透 Doze 模式, 无需 root 服务常驻
- **低功耗调优**: nice / ionice / cpu_affinity 绑小核 / oom_score_adj=-1000 (完全豁免 OOM killer)
- **getdents64 + unlinkat**: 直接 syscall, 比 `std::fs` 快 3-5 倍

### 安全机制
- **硬编码保护**: 永远不删 `/data/adb` `/system` `/vendor` `/product` `/proc` `/sys`
- **6 种白名单**: path×3 (prefix/通配符/exact) + package + ext + mtime
- **风险分级**: low / medium / high / dangerous, 默认拒绝 high+ (需 `--force`)
- **两阶段执行**: 先标记 (dry-run) 后删除, 可中断
- **防雪崩**: 事前校验 + dry-run + force_protect + adaptive_rate_limit

### 配置体系
- **三文件配置**: `settings.toml` / `blacklist.toml` / `whitelist.toml` (TOML 格式)
- **社区规则包**: `rules/*.toml` 可订阅更新
- **热重载**: `tarn reload` 或 SIGHUP 信号, 不打断当前任务

### WebUI
- **axum 0.7** 后端 + **Vue3 单文件**前端 (无构建工具, CDN 加载)
- **Token 鉴权**: Bearer header 或 URL `?token=` 兜底 (兼容 EventSource)
- **SSE 实时日志**: Server-Sent Events 推送运行日志
- **5 大功能页**: Dashboard / Rules / Clean / Logs / Config

---

## 安装方法

### 前置要求
- Android 9+ (API 28+), 推荐 Android 11+
- arm64-v8a 架构 (其他架构需自行编译)
- Magisk 24+ (或 KernelSU / APatch 兼容层)

### 安装步骤
1. 下载 `tarn-vX.Y.Z.zip` 到设备
2. 打开 Magisk app → 模块 → 从本地安装 → 选择 zip
3. 等待 `customize.sh` 执行完成
4. 重启设备
5. 重启后 `service.sh` 自动启动 daemon (late_start service 模式)

### 验证安装
```sh
# 完整性校验
$MODDIR/verify.sh

# doctor 自检
$MODDIR/tarn doctor

# 查看版本
$MODDIR/tarn version
```

> `$MODDIR` 通常是 `/data/adb/modules/tarn`

---

## 自行编译 (源码包用户)

源码 tarball 内含 `Makefile` + `build.sh` 一键编译脚本, 3 行命令出包。

### 前置条件
1. **Rust 工具链** (rustup): https://rustup.rs
   ```sh
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   rustup target add aarch64-linux-android
   ```
2. **Android NDK r25+** (推荐 r27c): https://developer.android.com/ndk/downloads
   ```sh
   # 解压到 ~/Android/android-ndk-r27c (脚本自动检测此路径)
   # 或: export ANDROID_NDK_HOME=/path/to/ndk
   ```

### 3 行命令出包
```sh
tar xzf tarn-vX.Y.Z-linjoin-src.tar.gz
cd tarn-vX.Y.Z
./build.sh all          # 编译 + 打包 zip + 打包 src
# 或: make all          # 等价
```

产物:
- `dist/tarn-vX.Y.Z-linjoin.zip` — Magisk 模块包 (刷入设备)
- `dist/tarn-vX.Y.Z-linjoin-src.tar.gz` — 源码包 (分发)

### 子命令
| 命令 | 作用 |
|------|------|
| `./build.sh build` 或 `make build` | 仅编译 + 拷贝二进制到 module/tarn |
| `./build.sh zip` 或 `make zip` | 编译 + 打包 Magisk 模块 zip |
| `./build.sh src` 或 `make src` | 仅打包源码 tarball (不编译) |
| `./build.sh all` 或 `make all` | zip + src |
| `./build.sh clean` 或 `make clean` | cargo clean + 删 dist/ |
| `make check` | cargo check (只检查语法, 快) |
| `make test` | cargo test --lib (跑单元测试, 在 host 跑) |
| `make help` | 显示帮助 |

### NDK 路径优先级
`build.sh` 按以下顺序检测 NDK:
1. 命令行: `NDK=/path/to/ndk ./build.sh`
2. 环境变量: `ANDROID_NDK_HOME` 或 `ANDROID_NDK_ROOT`
3. 默认路径: `~/Android/android-ndk-r27c` (脚本自动检测 r27c/r27b/r27a/r26d/r26c/r25c)

### 注意事项
- `build.sh` 会自动生成 `.cargo/config.toml` (用当前 NDK 路径), 不要手动编辑
- 编译产物体积约 2.5-3.5 MB (release + opt-level=z + lto + strip)
- 首次编译约 1-2 分钟 (依赖编译), 增量编译约 10-30 秒
- 跨平台: Linux / macOS 均可 (脚本自动适配 NDK 工具链路径)

---

## 配置说明

### 目录结构
```
/data/adb/tarn/
├── config/              # 配置目录 (0700)
│   ├── settings.toml    # 引擎全局设置
│   ├── blacklist.toml   # 清理规则 (规则包)
│   └── whitelist.toml   # 保护规则 (6 种白名单)
├── rules/               # 规则包目录 (用户自行添加发现的规则)
├── logs/                # 日志目录
│   ├── tarn.log         # daemon 运行日志 (JSON 格式, 轮转)
│   └── boot.log         # 启动脚本日志
├── run/                 # 运行时目录
│   └── tarn.pid         # daemon pidfile (防多开)
├── trash/               # 回收站 (若启用)
├── state.json           # 累计统计 + 最近运行记录 (原子写)
├── token                # WebUI 鉴权 token (自动生成)
└── tarn.sock            # Unix socket (Phase 4)
```

### 三文件配置 schema

完整 schema 见 [docs/CONFIG-SPEC.md](https://github.com/tarn/tarn/blob/main/docs/CONFIG-SPEC.md)。

#### `settings.toml` 关键字段
```toml
[engine]
parallel_workers = 0              # 0=自动(CPU核数)
cpu_affinity = [0, 1, 2, 3]       # 绑小核 (big.LITTLE)
use_getdents = true
use_ionice = true
use_nice = true

[schedule]
boot_delay_sec = 60               # 开机后延迟执行 (避免 IO 争用)
boot_enabled = true
min_interval_min = 360            # 同一规则最小间隔 (防频繁触发)

[run]
default_risk = "low"              # 默认仅跑 low 风险
default_dry_run = false
force_protect = true              # 强制启用硬编码保护
avoid_foreground_app = true       # 跳过前台 App 数据

[webui]
enabled = true
bind = "127.0.0.1"                # 仅本机访问
port = 8080

[trash]
enabled = false                   # 默认直接删, 不入回收站
ttl_days = 7
```

#### `blacklist.toml` 规则结构
```toml
[[rule]]
id = "wechat-cache"               # 唯一 ID
name = "微信缓存清理"
desc = "清理微信 cache 目录, 不动聊天数据"
enabled = true
priority = 50                     # 数字越大优先级越高
risk = "low"                      # low / medium / high / dangerous
category = "social"
tags = ["wechat"]

[rule.trigger]
on = ["manual", "boot"]           # manual / boot / cron:<expr> / event
min_interval_min = 60             # 最小间隔

[[rule.targets]]
path = "/data/data/com.tencent.mm/cache"
glob = "**/*"
action = "delete"                 # delete / move_to_trash
older_than_days = 3
exclude = ["**/voice2/**"]        # 排除项
```

#### `whitelist.toml` 保护结构
```toml
# 1. 路径保护
[[protect]]
match_type = "prefix"             # prefix / glob / exact
path = "/data/data/com.tencent.mm/MicroMsg"

# 2. 包名保护
[[protect_package]]
package = "com.bank.app"
reason = "银行类 App 不清"

# 3. 扩展名保护
[[protect_ext]]
extensions = ["db", "db-journal", "db-wal"]
scope = "global"                  # global / 具体路径

# 4. 修改时间保护
[[protect_mtime]]
within_days = 7
scope = "global"
reason = "保护 7 天内修改的文件"
```

---

## 命令列表

```sh
# 基础
tarn version              # 版本
tarn doctor               # 自检 (root / timerfd / wakelock / 配置)
tarn list                 # 列出所有规则
tarn list --enabled-only  # 仅启用的
tarn show <rule_id>       # 规则详情
tarn stats                # 累计统计 + 最近运行

# 执行
tarn run                              # 默认 manual 触发
tarn run --dry-run --json             # 试运行 + JSON 输出
tarn run --rule wechat-cache          # 仅跑指定规则
tarn run --trigger boot               # 模拟 boot 触发
tarn run --force                      # 允许 high/dangerous 规则

# 启停
tarn daemon              # 启动 daemon (前台, 由 service.sh setsid detach)
tarn reload              # 热重载配置 (向 daemon 发 SIGHUP)
tarn webui               # 启动 WebUI 服务
tarn webui --port 9090   # 指定端口

# 配置
tarn config list         # 列出所有设置
tarn config get <key>    # 读取某项
tarn config set <key> <value>  # 写入

# 日志
tarn log --tail 50       # 查看最近 50 行日志
```

---

## 安全机制

### 永远不会删除的路径 (硬编码, 不可关闭)
- `/data/adb` - Magisk / Tarn 自身数据
- `/system` `/vendor` `/product` `/apex` - 系统分区
- `/proc` `/sys` `/dev` - 内核伪文件系统
- `/data/data/<pkg>/databases` - 所有 App 数据库 (除非规则显式排除)
- `/sdcard/Android/data/<pkg>` - App 外部数据 (谨慎)

### 6 种白名单 (whitelist.toml)
1. `protect` (prefix) - 路径前缀匹配
2. `protect` (通配符) - 通配符模式匹配
3. `protect` (exact) - 精确路径匹配
4. `protect_package` - 按 App 包名保护整个数据目录
5. `protect_ext` - 按扩展名保护 (全局或作用域)
6. `protect_mtime` - 按修改时间保护 (近期文件不动)

### 防雪崩设计
- **事前校验**: 配置加载时即检查规则合法性
- **dry-run**: 默认建议先 `tarn run --dry-run --json` 查看将删什么
- **force_protect**: 即使规则说删, 白名单永远赢
- **adaptive_rate_limit**: 自动限速避免 IO 风暴

---

## FAQ

### Q1: daemon 不启动?
1. 检查 `/data/adb/tarn/logs/boot.log` 中 service.sh 的输出
2. 检查 `/data/adb/tarn/logs/tarn.log` 中 daemon 的输出
3. 运行 `$MODDIR/verify.sh` 完整性校验
4. 运行 `$MODDIR/tarn doctor` 自检
5. 常见原因:
   - 二进制架构不匹配 (仅支持 arm64-v8a)
   - 配置文件 TOML 语法错误
   - 权限问题 (检查 0700/0600)

### Q2: 多个 daemon 实例同时运行?
不可能。pidfile + flock 双重防多开:
- 启动时 `sysutil::lock_pidfile()` flock 加锁, 失败立即退出
- service.sh 检测到旧 pidfile 会先 `kill -TERM` + 等 12s + 必要时 `kill -KILL`

### Q3: 重启后 daemon 会延迟启动?
是的, `service.sh` 在 `late_start service` 阶段执行 (zygote 已起, 系统基本就绪)。
然后 daemon 内部还有 `boot_delay_sec=60` 的 boot 触发延迟, 避免 IO 争用。

### Q4: 误删了重要文件怎么办?
1. 立即停止 daemon: `kill $(cat /data/adb/tarn/run/tarn.pid)`
2. 检查 `state.json` 中的 `recent_runs` 审计轨迹
3. 检查 `logs/tarn.log` 中的删除记录
4. 如启用了 `trash` (回收站), 文件在 `/data/adb/tarn/trash/`
5. **建议**: 永远先用 `tarn run --dry-run --json` 查看将删什么

### Q5: 如何禁用某条规则?
```sh
# 方法 1: 编辑 blacklist.toml, 设置 enabled = false
# 方法 2: 命令行
$MODDIR/tarn disable <rule_id>

# 方法 3: WebUI 中点击规则行的开关
```

### Q6: 如何添加自定义规则?
Tarn 不内置任何规则, 所有规则由用户自行寻找并添加:
1. 编辑 `/data/adb/tarn/config/blacklist.toml`, 添加 `[[rule]]` 段
2. 或创建 `/data/adb/tarn/rules/my-rules.toml` (规则包格式, 可通过 WebUI 一键安装到 blacklist.toml)
3. 重载: `$MODDIR/tarn reload` (无需重启 daemon)

### Q7: WebUI token 在哪?
首次启动 daemon 时自动生成到 `/data/adb/tarn/run/token` (0600 权限, 运行时目录)。
```sh
cat /data/adb/tarn/run/token
```

### Q8: 如何完全卸载?
1. Magisk app 中移除 Tarn 模块 (调用 `uninstall.sh` 杀 daemon + 删除数据目录)
2. `uninstall.sh` 会执行 `rm -rf /data/adb/tarn`, 彻底清除所有配置/日志/state/token
3. Magisk 自动删除模块目录 `/data/adb/modules/tarn`
4. 重启设备, 系统中不留任何 Tarn 痕迹

### Q9: 支持 KernelSU / APatch 吗?
理论上兼容, 因为脚本只用 POSIX sh + Magisk 标准变量。但未做完整测试, 推荐 Magisk 24+。

### Q10: 可以同时安装其他清理工具吗?
可以, 但建议:
- 不要让其他工具清理 `/data/adb/tarn/` (会丢失配置和 state)
- 在其他工具的排除列表中加入 Tarn 监控的路径, 避免重复清理

---

## 技术细节

### daemon 启动流程 (service.sh)
```
1. 读取 $MODDIR (脚本所在目录)
2. 检查 pidfile:
   - 存在 → 读 OLD_PID
   - kill -0 校验存活
   - /proc/$OLD_PID/cmdline 校验是 tarn (防 PID 复用)
   - SIGTERM + 等 12s (daemon 优雅退出)
   - 仍存活 → SIGKILL
3. setsid nohup "$BIN" daemon </dev/null >>log 2>&1 &
   - setsid: 新建会话, 脱离控制终端
   - nohup: 忽略 SIGHUP (双保险)
   - </dev/null: 防 stdin 阻塞
4. 轮询等待 pidfile 出现 (最多 5s)
5. 写入 boot.log, 退出 (daemon 已 detach 后台运行)
```

### daemon 主循环 (Rust 内核)
```
1. flock pidfile (防多开)
2. apply_low_power: nice + ionice + cpu_affinity
3. set_oom_score_adj(-900) (防 OOM kill)
4. install_signal_handlers: SIGHUP(reload) / SIGTERM(优雅退出) / SIGINT(立即退出)
5. boot 延迟 (timerfd 可被打断)
6. boot 触发清理 (acquire wakelock 5min 兜底)
7. 主循环:
   a. 计算 cron 下次触发
   b. timerfd arm
   c. poll(timerfd, signal_fd)
   d. 到点 → wakelock → 执行 → save state → release wakelock
   e. SIGHUP → reload config (不打断)
   f. SIGTERM → drain → save → remove pidfile → exit
```

### 文件权限
| 路径 | 权限 | 说明 |
|------|------|------|
| `/data/adb/tarn/` | 0700 | 数据根目录, 仅 root |
| `/data/adb/tarn/config/*.toml` | 0600 | 配置文件, 仅 root 读写 |
| `/data/adb/tarn/run/tarn.pid` | 0600 | pidfile, 仅 root |
| `/data/adb/tarn/run/token` | 0600 | WebUI token, 仅 root (运行时目录) |
| `/data/adb/modules/tarn/tarn` | 0755 | 二进制, root 拥有, 全可执行 |
| `/data/adb/modules/tarn/*.sh` | 0755 | 脚本, root 拥有, 全可执行 |

---

## 更新历史

### v0.6.5 (2026-06-20)

**修复清理后残留线程 (方案F 补完)** (v0.6.4 真机实测: 预览/真删除清理后多出 4 个 `tokio-rt-worker` 线程且不释放)

- **根因 1 — walker.rs 全局 rayon pool**: `parallel_workers=0` (默认) 时 `walk_parallel` 用 `rayon::scope`, 会初始化 **全局 rayon 线程池**, 其线程常驻永不退出 → 清理后残留。修复: 始终构建 **LOCAL rayon pool** (`.build()`), `parallel_workers=0` → `num_cpus()`。清理结束 pool drop, 线程全退。
- **根因 2 — api_clean spawn_blocking**: `tokio::task::spawn_blocking` 的线程进 tokio 阻塞池, 空闲 10s 才退出 (频繁触发会再生, 看似常驻)。修复: 改用裸 `std::thread` (`tarn-clean`) + `tokio::sync::oneshot` channel。`executor.run` 完成后线程立即退出, 不进阻塞池。
- **根因 3 — api_logs_recent spawn_blocking**: 同上。修复: 改用 `tarn-logread` 裸线程, 读完即退。
- **收益**: 清理后线程数**瞬时**回落到基线 (daemon 模式 4 线程), 无 `tokio-rt-worker` / rayon 全局 pool 常驻线程。

**验证**: host x86_64 实测 — 31 文件 real walk, dry-run (scanned 62/deleted 31) + 真删除 (scanned 41/deleted 31) 后线程数均保持 3 (tarn + tarn-logger + 1 启动期临时线程, 10s 后退到 2), **无新增常驻线程**; aarch64 交叉编译通过; 版本号全链路一致 (v0.6.5 / code 46)。

### v0.6.4 (2026-06-20)

**方案F: WebUI 降配常驻 (常驻线程 -3)** (作为 Plan A listener-handoff 之前的稳态降配)

- **tokio runtime 降配**: `webui::serve` 的 tokio runtime 由 `new_multi_thread().worker_threads(2)` 改为 `new_current_thread()`。消除 2 个 `tokio-rt-worker` 常驻线程, async 全跑在 `tarn-webui` 单线程上; `executor.run` 仍走 `spawn_blocking` (阻塞线程池按需创建, 空闲不占线程), 不阻塞 async loop。
- **修复重复 logger**: daemon 模式下 `webui::serve` 不再自建第二个 `AsyncLogger` writer 线程, 改为接收 daemon 传入的共享 logger (`Option<Arc<AsyncLogger>>`), 消除 1 个重复 writer 线程。standalone `tarn webui` 仍自建一个 (合法)。
- **零行为变化**: 8080 始终监听 (无 listener 接力), 首请求零延迟; API/配置/清理逻辑未动。收益: 常驻线程 -3 (2 tokio worker + 1 重复 logger), RSS 下降, 空闲 CPU 仍为 0。

**验证**: host `cargo check` 通过 (无 warning); aarch64 交叉编译通过; 版本号全链路一致 (v0.6.4 / code 45)。

### v0.6.3 (2025-06-20)

**WebUI: 通配符匹配预览支持自定义后缀 (动态生成虚拟示例)** (用户反馈: 自定义后缀显示"0 匹配"误导)

- **修复误导**: 用户输入自定义后缀 (如 `**/*.rs`) 时, 固定示例库里没此后缀文件, 一直显示"0 个示例匹配"+警告"检查通配符有没有写错", 让用户以为规则写错了, 实际上规则是能匹配的。
- **动态虚拟示例**: 新增 `extractExtensions` + `generateVirtualSamples` — 从用户输入的通配符反推能匹配的文件名 (提取后缀 `*.rs`→`.rs` / 纯名字 `cache` / `*name*` 形式 / `*suffix` 形式), 生成匹配的虚拟文件 (`sample.rs` / `sub/deep.rs` / `app_cache/file.rs` / `.hidden.rs` 等) 加入预览, 带「虚拟」标记, 证明规则对此后缀/名字有效。
- **扩充固定示例库**: 12 → 31 个, 新增 `.json`/`.xml`/`.dat`/`.bin`/`.bak`/`.pid`/`.db`/`.sqlite`/`.nomedia`/`.jpg`/`.png`/`.mp3`/`.mp4`/`.log.bak`/`.log.1` 等更多后缀和深层目录场景。
- **改进警告文案**: 仅当连虚拟示例都匹配不到时才提示语法问题, 文案列出常用写法 (`*.log` / `**/*.log` / `*cache`) 供参考; 虚拟示例匹配时加说明"实际清理时扫描真实文件, 不限于这些样例"。

**验证**: node 模拟 9 组测试用例 (`**/*.rs`/`*.log`/`**/*.json`/`**/*.log.bak`/`*cache`/`*cache*`/`cache`/`**/*`/`**/*.xyz`) 全部符合预期; `**/*.rs` 从"0 匹配+警告"变为"匹配 4 个示例 (含 4 个虚拟)"; host cargo check 通过 + aarch64 交叉编译通过 + 版本号全链路一致 (v0.6.3 / code 44)。

### v0.6.2 (2025-06-20)

**诊断脚本微调: 诊断包不再收集 customize.sh** (用户反馈: 去除 customize.sh 的收集)

- 诊断包 `meta/` 目录不再收集 `customize.sh`: `customize.sh` 是 Magisk 模块安装时脚本 (仅刷入/更新模块时运行一次), 与运行时诊断无关, 收集它对排查 daemon 问题无价值。
- `meta/` 仍保留 `module.prop` / `service.sh` / `uninstall.sh` (运行时/卸载相关, 有取证价值)。
- 其余诊断内容不变 (`diagnostic.txt` 不转储规则内容, `configs/rules/` 仍保留规则原样副本)。

**验证**: debug.sh `sh -n` 语法校验通过 + 模拟打包验证 (meta/ 无 customize.sh) + host cargo check 通过 + aarch64 交叉编译通过 + 版本号全链路一致 (v0.6.2 / code 43)。

### v0.6.1 (2025-06-20)

**诊断脚本 (debug.sh v4 → v5): diagnostic.txt 不再转储清理规则内容** (用户反馈: 清理规则转储进诊断文本占用过大)

- `diagnostic.txt` 不再转储用户清理规则的内容: 社区规则包可达数千行, 转储进诊断文本会撑爆体积且与 `configs/rules/` 重复。第 4 章改为只列清单 (文件名 / 行数 / 字节), 足以判断规则加载状态。移除 `dump_file_smart` 函数 (仅规则转储用, 已无用)。
- 压缩包 `configs/rules/` **仍保留**规则文件原样副本 (取证需要, 每个 `.toml` 附 `.meta` sidecar 记录源路径/权限/大小/md5)。需要看规则原文时, 解压 tar.gz 取 `configs/rules/` 即可。`settings/blacklist/whitelist.toml` 同样保留原样副本 (一直如此)。
- `diagnostic.txt` 其余内容保持 (用户要求: 保留必要的检测结果和适当的重复内容): `settings/blacklist/whitelist.toml` 仍内联转储 (小文件, 诊断必需, 与 `configs/` 适当重复); `boot.log/tarn.log` 仍按原阈值转储 (与 `logs/` 适当重复); 17 章检测结果 + 摘要全保留。
- `meta.txt` / stdout 包结构描述同步更新 (diagnostic.txt 标注"不含规则内容", configs/ 标注含 rules/)。

**验证**: debug.sh `sh -n` 语法校验通过 + 模拟打包验证 (压缩包 configs/rules/ 含规则原样副本, diagnostic.txt 规则部分仅清单无正文) + host cargo check 通过 + aarch64 交叉编译通过 + 版本号全链路一致 (v0.6.1 / code 42)。

### v0.6.0 (2025-06-20)

**版本号规则**: 采用 vx.b.c 语义化版本, 每 10 进一 (c 满 10 进位 b, 不出现 v0.5.10)。本次为补丁版本 (v0.5.9 的 c 满 10 进位)。

**诊断脚本 (debug.sh v3 → v4)**
- 输出从单一 `.txt` 改为 `tar.gz` 压缩包, 一个档案装全部:
  - `diagnostic.txt` — 完整诊断文本 (v3 的 17 章检测全保留)
  - `configs/` — 用户配置原样副本 (settings/blacklist/whitelist/rules/*.toml), 每个附 `.meta` sidecar (源路径/权限/大小/md5)
  - `logs/` — 日志副本 (boot.log >512KB 截尾, tarn.log >3000行截尾, debug-sh.err)
  - `state/` — state.json 全量 + run/ 元信息 (token 内容脱敏, 只存元信息不打包)
  - `system/` — 系统快照独立成文 (dmesg/mount/getprop/ps/SELinux avc denial)
  - `meta/` — 模块脚本 (module.prop/service.sh/customize.sh/uninstall.sh) + 环境元信息
  - `MANIFEST.txt` — 全文件清单 + 字节数
- busybox 检测增强: 覆盖 KSU/APatch/Magisk 三大框架 9 条路径, 优先级 KSU > APatch > Magisk > system > xbin > vendor > PATH。
- tar.gz 创建三级降级: busybox `tar -czf` > 系统 `tar -czf` > `tar -cf` + `gzip -c` 分步管道。打包失败保留暂存目录 + `.FAILED` 标记。

**日志去说教化**
- 全量审查 233 处日志调用, 清理 9 处"自以为贴心"的括号解释, 保留事实数据括号。
- 例: `nice(19) 成功 (CFS 调度器遵守, 所有设备有效)` → `nice(19) 成功`
- 例: `panic hook 已安装 (panic 时记录 stderr + 日志 + backtrace + 发通知 + 跑 debug.sh 后再 abort)` → `panic hook 已安装`
- 保留: `(不影响主流程)` / `(fd=5)` / `sleep 兜底` / `降级运行` 等事实/非致命提示。
- 低功耗调优日志精简: 删除 `value=19, CFS 调度器一定遵守` / `cores=[...], 遍历 /proc/self/task 覆盖所有线程` 等说教, 只留 `✓ 已应用` / `✗ 失败`。

**验证**: host cargo check 通过 + aarch64-linux-android release 交叉编译通过 + 二进制串校验 (9 说教串全清, 9 事实串保留) + dist zip/src 已重打。

### v0.5.9 (2025-06-20)

**安全修复**
- 修复 glob 类 `protect_path` 路径别名绕过 bug: 用户配 `/sdcard/Download/*.pdf` (通配符保护), blacklist 用 `/storage/emulated/0/Download/secret.pdf` 形式可绕过保护导致文件被清理。修复后 glob 分支也调用 `expand_sdcard_aliases` 展开 4 种等价路径形式 (与 prefix 分支一致)。
- 修复 `ProtectExt` / `ProtectMtime` 的 `scope` 字段路径别名绕过 bug: 用户配 `scope="/sdcard/Download"`, blacklist 用 `/storage/emulated/0/Download/` 形式可绕过扩展名/时间保护。修复后 scope 也归一化为 4 种路径形式集合, 任一命中即保护。
- 修复 protect/clean 通配符语义不一致: protect 侧 `*` 默认跨 `/`, 但 clean 侧 `*` 不跨 `/` (literal_separator)。统一为 `literal_separator(true)`, 两侧语义一致。
- 至此 `protect.rs` 所有用户可配路径字段 (`protect_path.path` / `protect_ext.scope` / `protect_mtime.scope`) 全部归一化, 4 种 sdcard 别名形式全覆盖。

**文档与 UI**
- `ProtectPath` 文档补全: 通配符语义表 (`*`/`**`/`?`/`[]`)、跨形式归一化说明、4 个常见示例。
- 保护侧 protect_path 编辑器: 简陋提示 → 富文本速查表 (6 行示例对照表 + 别名归一化说明)。
- 预览清理审计行: 文件名加 📄 图标 + 浅色背景 pill 突出 "要删的文件"; 紧凑模式目录路径用中间省略号 (保留头尾, 非尾部省略)。

**验证**: 113 单元测试全过 + aarch64-linux-android release 交叉编译通过。

### v0.5.8

- Download 移出内置用户媒体保护 (用户可按需在 whitelist.toml 自行保护)。
- debug.sh 诊断脚本重写 (775 行, 18 章)。
- Rust 侧 debug.sh 故障静默修复 (stderr 重定向 + spawn 失败兜底)。

---

## 许可证

MIT License - 见 [LICENSE](https://github.com/tarn/tarn/blob/main/LICENSE)

## 相关文档
- [配置 schema 完整文档](https://github.com/tarn/tarn/blob/main/docs/CONFIG-SPEC.md)
- [Magisk 模块开发文档](https://github.com/topjohnwu/Magisk/blob/master/docs/guides.md)
- [issue 反馈](https://github.com/tarn/tarn/issues)

## 致谢
- [Magisk](https://github.com/topjohnwu/Magisk) by topjohnwu
- [Rayon](https://github.com/rayon-rs/rayon) - 数据并行库
- [axum](https://github.com/tokio-rs/axum) - Web 框架
- [Vue 3](https://vuejs.org/) - 前端框架
