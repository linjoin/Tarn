//! 错误通知 + 诊断收集 (Rust 原生实现)
//!
//! ## 功能
//! 当 Tarn 出现错误时 (daemon 启动失败 / cron 清理失败 / panic / 配置重载失败等):
//! 1. 执行 `debug.sh` 收集诊断快照 (日志 / 配置 / 系统 / 进程信息)
//! 2. 发送 Android 系统通知提醒用户 (通过 `su 2000 -c "cmd notification post ..."`)
//!
//! ## 为什么用 Rust 原生而不是 shell
//! - daemon 运行时是独立进程, 无法依赖 service.sh 触发通知
//! - panic 发生时进程即将 abort, 必须用 spawn + setsid 完全脱离父进程
//!   才能让通知子进程在父进程死后继续完成投递
//! - shell 转义在 Rust 里可控, 避免双层 shell (su -c + 内层) 注入风险
//! - 统一入口: service.sh 检测到启动失败也调 `tarn notify-error` 走同一套代码
//!
//! ## 通知命令 (用户指定, 不可改动)
//! ```text
//! su 2000 -c "cmd notification post -S messaging \
//!   --conversation \"$title\" --message \"$title\":\"$msg\" \
//!   \"Tarn\" \"\$RANDOM\"" >/dev/null 2>&1 &
//! ```
//! - `su 2000`: 切到 shell 用户 (uid 2000), 有发通知权限
//! - `cmd notification post`: Android 原生通知命令
//! - `-S messaging`: 指定 source = messaging
//! - `--conversation <title>`: 会话标题
//! - `--message <title>:<msg>`: 消息体 (格式 "标题:详情")
//! - `Tarn`: 通知 tag
//! - `$RANDOM`: 通知 id (shell 生成随机数, 避免覆盖)
//!
//! ## 脱离父进程 (detached spawn)
//! 用 `pre_exec(setsid)` 让子进程成为新会话组长, 脱离控制终端 + 进程组,
//! 父进程 exit/abort 后子进程继续运行完成通知投递。
//! stdin/stdout/stderr 全部重定向到 /dev/null, 避免管道阻塞。
//!
//! ## 速率限制
//! 同一类错误短时间内可能反复触发 (如 cron 每分钟失败), 用文件时间戳限制:
//! 默认 5 分钟内最多 1 条通知, 避免通知轰炸。
//! debug.sh 不限速 (每次错误都收集, 方便排查)。

use anyhow::Result;
use std::fs;
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

/// MODPATH 固定路径 (与 module_prop.rs / webroot.rs 一致)
const MODPATH: &str = "/data/adb/modules/tarn";

/// debug.sh 路径
pub fn debug_sh_path() -> PathBuf {
    PathBuf::from(MODPATH).join("debug.sh")
}

/// 速率限制窗口 (秒): 同一错误 5 分钟内最多 1 条通知
const NOTIFY_RATE_LIMIT_SECS: u64 = 300;

/// shell 单引号转义: 把任意字符串安全包进单引号
///
/// 单引号内除 `'` 外所有字符都是字面量, `'` 用 `'\''` 结束-转义-重启单引号。
/// 例: `a'b` → `'a'\''b'`
fn shell_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('\'');
    for ch in s.chars() {
        if ch == '\'' {
            out.push_str("'\\''");
        } else {
            out.push(ch);
        }
    }
    out.push('\'');
    out
}

/// 构造通知命令的内层 shell 字符串
///
/// 返回的字符串会被 `su 2000 -c "<本字符串>"` 执行。
/// `$RANDOM` 由 su 启动的 shell 展开, 生成随机通知 id。
fn build_notification_cmd(title: &str, msg: &str) -> String {
    let t = shell_escape(title);
    let m = shell_escape(msg);
    format!(
        "cmd notification post -S messaging --conversation {t} --message {t}:{m} Tarn $RANDOM"
    )
}

/// 发送 Android 系统通知 (Rust 原生, 完全脱离父进程)
///
/// 内部: `su 2000 -c "cmd notification post ..."` + setsid + stdin/out/err → /dev/null
///
/// 非阻塞: spawn 后立即返回, 不等待通知投递完成。
/// 失败静默 (su 不存在 / 非 root / 通知服务不可用 都只返回 Err, 由调用方决定是否记日志)。
pub fn send_notification(title: &str, msg: &str) -> Result<()> {
    let inner = build_notification_cmd(title, msg);
    let mut cmd = Command::new("su");
    cmd.arg("2000").arg("-c").arg(&inner);
    cmd.stdin(std::process::Stdio::null());
    cmd.stdout(std::process::Stdio::null());
    cmd.stderr(std::process::Stdio::null());
    unsafe {
        cmd.pre_exec(|| {
            let _ = libc::setsid();
            Ok(())
        });
    }
    cmd.spawn()?;
    Ok(())
}

/// 执行 debug.sh 收集诊断快照 (脱离父进程, 非阻塞)
///
/// debug.sh 自身把输出写到 /data/adb/tarn/logs/debug-<ts>.txt,
/// 这里只负责 spawn, 不收集它的 stdout。
pub fn run_debug_sh() -> Result<()> {
    let script = debug_sh_path();
    if !script.exists() {
        return Err(anyhow::anyhow!("debug.sh 不存在: {}", script.display()));
    }
    let mut cmd = Command::new("sh");
    cmd.arg(&script);
    cmd.stdin(std::process::Stdio::null());
    cmd.stdout(std::process::Stdio::null());
    cmd.stderr(std::process::Stdio::null());
    unsafe {
        cmd.pre_exec(|| {
            let _ = libc::setsid();
            Ok(())
        });
    }
    cmd.spawn()?;
    Ok(())
}

/// 读取上次通知时间戳 (Unix 秒), 文件不存在返回 None
fn read_last_notify(config_dir: &Path) -> Option<u64> {
    let p = config_dir.join("run/last_notify.ts");
    fs::read_to_string(&p)
        .ok()
        .and_then(|s| s.trim().parse::<u64>().ok())
}

/// 写入当前通知时间戳
fn write_last_notify(config_dir: &Path) {
    let p = config_dir.join("run/last_notify.ts");
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let _ = fs::create_dir_all(p.parent().unwrap_or(Path::new(".")));
    let _ = fs::write(&p, now.to_string());
}

/// 判断是否在速率限制窗口内 (true = 被限速, 应跳过通知)
fn is_rate_limited(config_dir: &Path) -> bool {
    match read_last_notify(config_dir) {
        Some(last) => {
            let now = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0);
            now.saturating_sub(last) < NOTIFY_RATE_LIMIT_SECS
        }
        None => false,
    }
}

/// 错误聚合入口: 跑 debug.sh + 发通知 (带速率限制)
///
/// 调用场景: daemon 运行时检测到错误 (cron 失败 / 配置重载失败 / panic hook 等)。
///
/// 行为:
/// 1. 始终 spawn debug.sh (不限速, 每次错误都收集诊断)
/// 2. 速率限制窗口内 (默认 5 分钟) 跳过通知, 避免轰炸
/// 3. 通知失败只 log, 不影响主流程
///
/// `config_dir`: /data/adb/tarn, 用于读/写 last_notify.ts
/// `logger`: 可选, 用于记录通知发送情况 (None 时静默)
pub fn on_error(
    title: &str,
    msg: &str,
    config_dir: &Path,
    logger: Option<&crate::logger::AsyncLogger>,
) {
    if let Err(e) = run_debug_sh() {
        if let Some(l) = logger {
            l.warn("notify", &format!("debug.sh 启动失败: {}", e));
        }
    }

    if is_rate_limited(config_dir) {
        if let Some(l) = logger {
            l.debug(
                "notify",
                &format!("通知被速率限制 ({} 秒内已发过), 跳过: {}", NOTIFY_RATE_LIMIT_SECS, title),
            );
        }
        return;
    }

    match send_notification(title, msg) {
        Ok(()) => {
            write_last_notify(config_dir);
            if let Some(l) = logger {
                l.info("notify", &format!("已发送错误通知: {} - {}", title, msg));
            }
        }
        Err(e) => {
            if let Some(l) = logger {
                l.warn("notify", &format!("发送通知失败 (非 root / su 不可用 / 通知服务异常): {}", e));
            }
        }
    }
}

/// 强制发送通知 (不限速), 供 CLI `tarn notify-error` 手动触发用
pub fn send_notification_force(title: &str, msg: &str) -> Result<()> {
    send_notification(title, msg)
}

/// 清除速率限制 (供 `tarn notify-error` 手动触发时调用, 确保一定能发出)
pub fn reset_rate_limit(config_dir: &Path) {
    let p = config_dir.join("run/last_notify.ts");
    let _ = fs::remove_file(&p);
}

/// 距离上次通知的时长 (用于诊断), 返回 None 表示从未发过
pub fn time_since_last_notify(config_dir: &Path) -> Option<Duration> {
    let last = read_last_notify(config_dir)?;
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    Some(Duration::from_secs(now.saturating_sub(last)))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_shell_escape_empty() {
        assert_eq!(shell_escape(""), "''");
    }

    #[test]
    fn test_shell_escape_plain() {
        assert_eq!(shell_escape("hello"), "'hello'");
    }

    #[test]
    fn test_shell_escape_with_single_quote() {
        assert_eq!(shell_escape("a'b"), "'a'\\''b'");
    }

    #[test]
    fn test_shell_escape_with_special() {
        let s = shell_escape("hello $world `cmd` $(sub)");
        assert!(s.starts_with('\''));
        assert!(s.ends_with('\''));
        assert!(s.contains('$'));
    }

    #[test]
    fn test_build_notification_cmd_basic() {
        let cmd = build_notification_cmd("Tarn 启动失败", "daemon 退出");
        assert!(cmd.contains("cmd notification post -S messaging"));
        assert!(cmd.contains("--conversation"));
        assert!(cmd.contains("--message"));
        assert!(cmd.contains("Tarn"));
        assert!(cmd.contains("$RANDOM"));
    }

    #[test]
    fn test_build_notification_cmd_injection_safe() {
        let evil = "'; rm -rf /; echo '";
        let cmd = build_notification_cmd(evil, evil);
        let escaped = shell_escape(evil);
        assert_eq!(escaped, "''\\''; rm -rf /; echo '\\'''");
        assert!(cmd.contains(&escaped));
        assert!(!cmd.contains("\"'; rm"));
    }

    #[test]
    fn test_rate_limit_logic() {
        let tmp = std::env::temp_dir().join("tarn_notify_test_rl");
        let _ = std::fs::remove_dir_all(&tmp);
        std::fs::create_dir_all(tmp.join("run")).unwrap();
        assert!(!is_rate_limited(&tmp));
        write_last_notify(&tmp);
        assert!(is_rate_limited(&tmp));
        reset_rate_limit(&tmp);
        assert!(!is_rate_limited(&tmp));
        let _ = std::fs::remove_dir_all(&tmp);
    }
}
