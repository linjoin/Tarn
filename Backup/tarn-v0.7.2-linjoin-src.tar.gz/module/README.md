# Tarn - 系统级文件治理引擎

> 系统级、高并发、低功耗、防雪崩的 Android 文件清理框架  
> Rust 内核 + Magisk 模块壳 + timerfd Doze 穿透 + Rayon 并行扫描

## 功能介绍

Tarn 是一个面向 Android root 用户的系统级文件治理引擎, 核心特性:

### 引擎能力
- **Rust 内核**: 编译为单二进制 (~2.6MB stripped), aarch64-linux-android 目标
- **双引擎**: Rayon (CPU 并行遍历) + Tokio (异步 IO)
- **timerfd + CLOCK_BOOTTIME_ALARM**: 内核级定时, 穿透 Doze 模式, 无需 root 服务常驻
- **低功耗调优**: nice / ionice / cpu_affinity 绑小核 / oom_score_adj=-1000 (完全豁免 OOM killer)
- **getdents64 + unlinkat**: 直接 syscall, 比 `std::fs` 快 3-5 倍

### 安全机制
- **硬编码保护**: 永远不删 `/data/adb` `/system` `/vendor` `/product` `/proc` `/sys`
- **6 种白名单**: path×3 (prefix/通配符/exact) + package + ext + mtime
- **风险分级**: low / medium / high / dangerous, 默认拒绝 high+ (需 `--force`)
- **两阶段执行**: 先标记 (dry-run) 后删除, 可中断
- **防雪崩**: 事前校验 + dry-run + force_protect + adaptive_rate_limit

### 配置体系
- **三文件配置**: `settings.toml` / `blacklist.toml` / `whitelist.toml` (TOML 格式)
- **社区规则包**: `rules/*.toml` 可订阅更新
- **热重载**: `tarn reload` 或 SIGHUP 信号, 不打断当前任务

### WebUI
- **axum 0.7** 后端 + **Vue3 单文件**前端 (无构建工具, CDN 加载)
- **Token 鉴权**: Bearer header 或 URL `?token=` 兜底 (兼容 EventSource)
- **SSE 实时日志**: Server-Sent Events 推送运行日志
- **5 大功能页**: Dashboard / Rules / Clean / Logs / Config

---

## 安装方法

### 前置要求
- Android 9+ (API 28+), 推荐 Android 11+
- arm64-v8a 架构 (其他架构需自行编译)
- Magisk 24+ (或 KernelSU / APatch 兼容层)

### 安装步骤
1. 下载 `tarn-vX.Y.Z.zip` 到设备
2. 打开 Magisk app → 模块 → 从本地安装 → 选择 zip
3. 等待 `customize.sh` 执行完成
4. 重启设备
5. 重启后 `service.sh` 自动启动 daemon (late_start service 模式)

### 验证安装
```sh
# 完整性校验
$MODDIR/verify.sh

# doctor 自检
$MODDIR/tarn doctor

# 查看版本
$MODDIR/tarn version
```

> `$MODDIR` 通常是 `/data/adb/modules/tarn`

---

## 自行编译 (源码包用户)

源码 tarball 内含 `Makefile` + `build.sh` 一键编译脚本, 3 行命令出包。

### 前置条件
1. **Rust 工具链** (rustup): https://rustup.rs
   ```sh
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   rustup target add aarch64-linux-android
   ```
2. **Android NDK r25+** (推荐 r27c): https://developer.android.com/ndk/downloads
   ```sh
   # 解压到 ~/Android/android-ndk-r27c (脚本自动检测此路径)
   # 或: export ANDROID_NDK_HOME=/path/to/ndk
   ```

### 3 行命令出包
```sh
tar xzf tarn-vX.Y.Z-linjoin-src.tar.gz
cd tarn-vX.Y.Z
./build.sh all          # 编译 + 打包 zip + 打包 src
# 或: make all          # 等价
```

产物:
- `dist/tarn-vX.Y.Z-linjoin.zip` — Magisk 模块包 (刷入设备)
- `dist/tarn-vX.Y.Z-linjoin-src.tar.gz` — 源码包 (分发)

### 子命令
| 命令 | 作用 |
|------|------|
| `./build.sh build` 或 `make build` | 仅编译 + 拷贝二进制到 module/tarn |
| `./build.sh zip` 或 `make zip` | 编译 + 打包 Magisk 模块 zip |
| `./build.sh src` 或 `make src` | 仅打包源码 tarball (不编译) |
| `./build.sh all` 或 `make all` | zip + src |
| `./build.sh clean` 或 `make clean` | cargo clean + 删 dist/ |
| `make check` | cargo check (只检查语法, 快) |
| `make test` | cargo test --lib (跑单元测试, 在 host 跑) |
| `make help` | 显示帮助 |

### NDK 路径优先级
`build.sh` 按以下顺序检测 NDK:
1. 命令行: `NDK=/path/to/ndk ./build.sh`
2. 环境变量: `ANDROID_NDK_HOME` 或 `ANDROID_NDK_ROOT`
3. 默认路径: `~/Android/android-ndk-r27c` (脚本自动检测 r27c/r27b/r27a/r26d/r26c/r25c)

### 注意事项
- `build.sh` 会自动生成 `.cargo/config.toml` (用当前 NDK 路径), 不要手动编辑
- 编译产物体积约 2.5-3.5 MB (release + opt-level=z + lto + strip)
- 首次编译约 1-2 分钟 (依赖编译), 增量编译约 10-30 秒
- 跨平台: Linux / macOS 均可 (脚本自动适配 NDK 工具链路径)

---

## 配置说明

### 目录结构
```
/data/adb/tarn/
├── config/              # 配置目录 (0700)
│   ├── settings.toml    # 引擎全局设置
│   ├── blacklist.toml   # 清理规则 (规则包)
│   └── whitelist.toml   # 保护规则 (6 种白名单)
├── rules/               # 规则包目录 (用户自行添加发现的规则)
├── logs/                # 日志目录
│   ├── tarn.log         # daemon 运行日志 (JSON 格式, 轮转)
│   └── boot.log         # 启动脚本日志
├── run/                 # 运行时目录
│   └── tarn.pid         # daemon pidfile (防多开)
├── trash/               # 回收站 (若启用)
├── state.json           # 累计统计 + 最近运行记录 (原子写)
├── token                # WebUI 鉴权 token (自动生成)
└── tarn.sock            # Unix socket (Phase 4)
```

### 三文件配置 schema

完整 schema 见 [docs/CONFIG-SPEC.md](https://github.com/tarn/tarn/blob/main/docs/CONFIG-SPEC.md)。

#### `settings.toml` 关键字段
```toml
[engine]
parallel_workers = 0              # 0=自动(CPU核数)
cpu_affinity = [0, 1, 2, 3]       # 绑小核 (big.LITTLE)
use_getdents = true
use_ionice = true
use_nice = true

[schedule]
boot_delay_sec = 60               # 开机后延迟执行 (避免 IO 争用)
boot_enabled = true
min_interval_min = 360            # 同一规则最小间隔 (防频繁触发)

[run]
default_risk = "low"              # 默认仅跑 low 风险
default_dry_run = false
force_protect = true              # 强制启用硬编码保护
avoid_foreground_app = true       # 跳过前台 App 数据

[webui]
enabled = true
bind = "127.0.0.1"                # 仅本机访问
port = 8080

[trash]
enabled = false                   # 默认直接删, 不入回收站
ttl_days = 7
```

#### `blacklist.toml` 规则结构
```toml
[[rule]]
id = "wechat-cache"               # 唯一 ID
name = "微信缓存清理"
desc = "清理微信 cache 目录, 不动聊天数据"
enabled = true
priority = 50                     # 数字越大优先级越高
risk = "low"                      # low / medium / high / dangerous
category = "social"
tags = ["wechat"]

[rule.trigger]
on = ["manual", "boot"]           # manual / boot / cron:<expr> / event
min_interval_min = 60             # 最小间隔

[[rule.targets]]
path = "/data/data/com.tencent.mm/cache"
glob = "**/*"
action = "delete"                 # delete / move_to_trash
older_than_days = 3
exclude = ["**/voice2/**"]        # 排除项
```

#### `whitelist.toml` 保护结构
```toml
# 1. 路径保护
[[protect]]
match_type = "prefix"             # prefix / glob / exact
path = "/data/data/com.tencent.mm/MicroMsg"

# 2. 包名保护
[[protect_package]]
package = "com.bank.app"
reason = "银行类 App 不清"

# 3. 扩展名保护
[[protect_ext]]
extensions = ["db", "db-journal", "db-wal"]
scope = "global"                  # global / 具体路径

# 4. 修改时间保护
[[protect_mtime]]
within_days = 7
scope = "global"
reason = "保护 7 天内修改的文件"
```

---

## 命令列表

```sh
# 基础
tarn version              # 版本
tarn doctor               # 自检 (root / timerfd / wakelock / 配置)
tarn list                 # 列出所有规则
tarn list --enabled-only  # 仅启用的
tarn show <rule_id>       # 规则详情
tarn stats                # 累计统计 + 最近运行

# 执行
tarn run                              # 默认 manual 触发
tarn run --dry-run --json             # 试运行 + JSON 输出
tarn run --rule wechat-cache          # 仅跑指定规则
tarn run --trigger boot               # 模拟 boot 触发
tarn run --force                      # 允许 high/dangerous 规则

# 启停
tarn daemon              # 启动 daemon (前台, 由 service.sh setsid detach)
tarn reload              # 热重载配置 (向 daemon 发 SIGHUP)
tarn webui               # 启动 WebUI 服务
tarn webui --port 9090   # 指定端口

# 配置
tarn config list         # 列出所有设置
tarn config get <key>    # 读取某项
tarn config set <key> <value>  # 写入

# 日志
tarn log --tail 50       # 查看最近 50 行日志
```

---

## 安全机制

### 永远不会删除的路径 (硬编码, 不可关闭)
- `/data/adb` - Magisk / Tarn 自身数据
- `/system` `/vendor` `/product` `/apex` - 系统分区
- `/proc` `/sys` `/dev` - 内核伪文件系统
- `/data/data/<pkg>/databases` - 所有 App 数据库 (除非规则显式排除)
- `/sdcard/Android/data/<pkg>` - App 外部数据 (谨慎)

### 6 种白名单 (whitelist.toml)
1. `protect` (prefix) - 路径前缀匹配
2. `protect` (通配符) - 通配符模式匹配
3. `protect` (exact) - 精确路径匹配
4. `protect_package` - 按 App 包名保护整个数据目录
5. `protect_ext` - 按扩展名保护 (全局或作用域)
6. `protect_mtime` - 按修改时间保护 (近期文件不动)

### 防雪崩设计
- **事前校验**: 配置加载时即检查规则合法性
- **dry-run**: 默认建议先 `tarn run --dry-run --json` 查看将删什么
- **force_protect**: 即使规则说删, 白名单永远赢
- **adaptive_rate_limit**: 自动限速避免 IO 风暴

---

## FAQ

### Q1: daemon 不启动?
1. 检查 `/data/adb/tarn/logs/boot.log` 中 service.sh 的输出
2. 检查 `/data/adb/tarn/logs/tarn.log` 中 daemon 的输出
3. 运行 `$MODDIR/verify.sh` 完整性校验
4. 运行 `$MODDIR/tarn doctor` 自检
5. 常见原因:
   - 二进制架构不匹配 (仅支持 arm64-v8a)
   - 配置文件 TOML 语法错误
   - 权限问题 (检查 0700/0600)

### Q2: 多个 daemon 实例同时运行?
不可能。pidfile + flock 双重防多开:
- 启动时 `sysutil::lock_pidfile()` flock 加锁, 失败立即退出
- service.sh 检测到旧 pidfile 会先 `kill -TERM` + 等 12s + 必要时 `kill -KILL`

### Q3: 重启后 daemon 会延迟启动?
是的, `service.sh` 在 `late_start service` 阶段执行 (zygote 已起, 系统基本就绪)。
然后 daemon 内部还有 `boot_delay_sec=60` 的 boot 触发延迟, 避免 IO 争用。

### Q4: 误删了重要文件怎么办?
1. 立即停止 daemon: `kill $(cat /data/adb/tarn/run/tarn.pid)`
2. 检查 `state.json` 中的 `recent_runs` 审计轨迹
3. 检查 `logs/tarn.log` 中的删除记录
4. 如启用了 `trash` (回收站), 文件在 `/data/adb/tarn/trash/`
5. **建议**: 永远先用 `tarn run --dry-run --json` 查看将删什么

### Q5: 如何禁用某条规则?
```sh
# 方法 1: 编辑 blacklist.toml, 设置 enabled = false
# 方法 2: 命令行
$MODDIR/tarn disable <rule_id>

# 方法 3: WebUI 中点击规则行的开关
```

### Q6: 如何添加自定义规则?
Tarn 不内置任何规则, 所有规则由用户自行寻找并添加:
1. 编辑 `/data/adb/tarn/config/blacklist.toml`, 添加 `[[rule]]` 段
2. 或创建 `/data/adb/tarn/rules/my-rules.toml` (规则包格式, 可通过 WebUI 一键安装到 blacklist.toml)
3. 重载: `$MODDIR/tarn reload` (无需重启 daemon)

### Q7: WebUI token 在哪?
首次启动 daemon 时自动生成到 `/data/adb/tarn/run/token` (0600 权限, 运行时目录)。
```sh
cat /data/adb/tarn/run/token
```

### Q8: 如何完全卸载?
1. Magisk app 中移除 Tarn 模块 (调用 `uninstall.sh` 杀 daemon + 删除数据目录)
2. `uninstall.sh` 会执行 `rm -rf /data/adb/tarn`, 彻底清除所有配置/日志/state/token
3. Magisk 自动删除模块目录 `/data/adb/modules/tarn`
4. 重启设备, 系统中不留任何 Tarn 痕迹

### Q9: 支持 KernelSU / APatch 吗?
理论上兼容, 因为脚本只用 POSIX sh + Magisk 标准变量。但未做完整测试, 推荐 Magisk 24+。

### Q10: 可以同时安装其他清理工具吗?
可以, 但建议:
- 不要让其他工具清理 `/data/adb/tarn/` (会丢失配置和 state)
- 在其他工具的排除列表中加入 Tarn 监控的路径, 避免重复清理

---

## 技术细节

### daemon 启动流程 (service.sh)
```
1. 读取 $MODDIR (脚本所在目录)
2. 检查 pidfile:
   - 存在 → 读 OLD_PID
   - kill -0 校验存活
   - /proc/$OLD_PID/cmdline 校验是 tarn (防 PID 复用)
   - SIGTERM + 等 12s (daemon 优雅退出)
   - 仍存活 → SIGKILL
3. setsid nohup "$BIN" daemon </dev/null >>log 2>&1 &
   - setsid: 新建会话, 脱离控制终端
   - nohup: 忽略 SIGHUP (双保险)
   - </dev/null: 防 stdin 阻塞
4. 轮询等待 pidfile 出现 (最多 5s)
5. 写入 boot.log, 退出 (daemon 已 detach 后台运行)
```

### daemon 主循环 (Rust 内核)
```
1. flock pidfile (防多开)
2. apply_low_power: nice + ionice + cpu_affinity
3. set_oom_score_adj(-900) (防 OOM kill)
4. install_signal_handlers: SIGHUP(reload) / SIGTERM(优雅退出) / SIGINT(立即退出)
5. boot 延迟 (timerfd 可被打断)
6. boot 触发清理 (acquire wakelock 5min 兜底)
7. 主循环:
   a. 计算 cron 下次触发
   b. timerfd arm
   c. poll(timerfd, signal_fd)
   d. 到点 → wakelock → 执行 → save state → release wakelock
   e. SIGHUP → reload config (不打断)
   f. SIGTERM → drain → save → remove pidfile → exit
```

### 文件权限
| 路径 | 权限 | 说明 |
|------|------|------|
| `/data/adb/tarn/` | 0700 | 数据根目录, 仅 root |
| `/data/adb/tarn/config/*.toml` | 0600 | 配置文件, 仅 root 读写 |
| `/data/adb/tarn/run/tarn.pid` | 0600 | pidfile, 仅 root |
| `/data/adb/tarn/run/token` | 0600 | WebUI token, 仅 root (运行时目录) |
| `/data/adb/modules/tarn/tarn` | 0755 | 二进制, root 拥有, 全可执行 |
| `/data/adb/modules/tarn/*.sh` | 0755 | 脚本, root 拥有, 全可执行 |

---

## 更新历史

### v0.7.2 (2026-06-21)

**WebUI 预览保护检查 + 白名单表格溢出修复 + 引擎遍历选项说明**

**Bug 1 — 白名单页卡片超出屏幕边缘, 无法删除白名单**:
- 4 个白名单表格 (路径/包名/扩展名/mtime) 的操作列 (col-actions) 宽度只有 64px, 容不下「编辑 + 删除」两个按钮 (约需 100px), `white-space:nowrap` 导致表格整体溢出屏幕, 删除按钮不可见/不可点。
- 修复 (前端 CSS): `col-actions` 宽度增至 120px (桌面) / 104px (≤600px) / 92px (≤380px); 表格外层加 `.wl-table-wrap` 滚动容器 (`overflow-x:auto`) 兜底极窄屏; 所有 4 个表格用 wrap 包裹。

**Bug 2 — 前端预览不显示白名单保护状态 (用户误以为保护失效)**:
- 用户添加包名保护后, 规则编辑器的通配符实时预览仍显示该包文件「会匹配」, 误以为保护失效。实际后端保护逻辑正确 (33 个测试全通过), 问题是前端预览信息不完整 — 只做 glob 匹配, 不检查白名单保护。
- 修复 (后端): 新增 `POST /api/protect/check` 端点, 批量检查路径是否被白名单保护, 返回 `{ path, protected, reason, reason_cn }`。纯内存 DFA 匹配, 50 路径 < 50μs。
- 修复 (前端): 预览面板集成保护检查 — 被保护的示例显示 🛡 徽章 + 保护原因; 顶部显示保护摘要 (N 个示例被白名单保护, 实际清理会被拦下); `watch` target glob/path/mode 变化时防抖拉取保护状态 (300ms); 白名单增删改后清空缓存。

**改进 1 — 引擎遍历选项添加详细说明**:
- 用户反馈「引擎遍历选项」不知道有什么用。原 UI 只有简短提示。
- 改进: 加可折叠的「📖 这些选项有什么用?」详情区, 逐条解释 5 个选项 (遍历最大深度 / 跟随符号链接 / 跳过隐藏文件 / 使用 getdents64 / 批量删除), 含使用场景、风险说明、建议值。

**验证**:
- `host cargo build --package tarn-webui` — 0 error
- `host cargo test --package tarn-core --lib protect::` — 33 passed, 0 failed
- 白名单表格 CSS 在 360px / 375px / 414px / 768px 宽度下按钮完整可见

---

### v0.7.1 (2026-06-20)

**WebUI 功能性 bug 修复** (用户实测反馈 4 类问题)

**Bug 1 — 规则命名不支持中文**:
- 旧版 `slugify` 把中文字符段替换成 `'rule'`, 导致所有中文名规则 id 都是 `rule` → 碰撞无法保存。
- 修复: 保留中文字符 (TOML / Rust String 都支持 UTF-8), 规则名「清微信缓存」→ id「清微信缓存」, 不再碰撞。
- 新增中文名规则可正常创建/保存/编辑/删除。

**Bug 2 — 路径通配符预览与实际不一致 + `.sh` 无前缀文件匹配**:
- 用户反馈: 路径 `/storage/emulated/0/测试/` 通配符 `*.sh`, web 预览显示能删 `app_cache/file.sh`, 但实际预览删除删不掉; 且匹配不到 `.sh` 这种无前缀文件。
- 根因分析 (host cargo test 验证): 后端 globset `*.sh` **能**匹配 `.sh` (✓ 正确), `app_cache/file.sh` 在 delete_files 模式**不**匹配 (✓ 正确, `*` 不跨 `/`)。问题在前端预览面板的虚拟示例生成。
- 修复 (前端 `generateVirtualSamples`):
  - 加无前缀文件示例 (`pathTrim + ext` → `.sh` / `.db`), 证明 `*.sh` 能匹配 `.sh`, 不再让用户误以为匹配不到。
  - 虚拟示例改为**模式感知**: delete_files 模式不生成子目录示例 (它们不会匹配, 显示出来误导); clear_dirs/delete_dirs 模式才生成 `sub/deep.ext` / `app_cache/file.ext`。
  - 预览面板加模式说明条: 明确告知 delete_files 模式 `*` 不跨 `/` 只删直接文件, clear_dirs 模式递归子目录。
  - 强化「虚拟示例」note: 明确「实际清理扫描真实文件, 虚拟样例不一定真存在, 预览删除只列真实存在的文件」, 消除「预览说能删但实际删不掉」的误解。

**Bug 3 — 白名单包名保护对外置存储 Android/data 失效**:
- 用户反馈: 添加包名保护 `com.ss.android.ugc.aweme.mobile` (抖音), 规则路径 `/storage/emulated/0/Android/data/` 通配符 `*/cache`, 预览删除仍能删该包 cache。
- 根因: `extract_package_from_path` 只认 `/data/data/<pkg>` 和 `/data/user/<id>/<pkg>`, **不认**外置存储的 4 种别名形式 (`/sdcard/Android/data/<pkg>` / `/storage/emulated/<id>/Android/data/<pkg>` / `/storage/self/primary/Android/data/<pkg>` / `/data/media/<id>/Android/data/<pkg>`) → 包名提取返回 None → 保护失效。
- 修复: `extract_package_from_path` / `extract_subdir_from_path` 扩展支持 `Android/data/<pkg>` 和 `Android/obb/<pkg>` 段, 覆盖全部 4 种 sdcard 别名形式 (含多用户 id)。Android/media 保守不认 (避免误判)。
- 新增 4 个回归测试 (extract_package / extract_subdir / ProtectSet::check 跨 4 种路径形式), 全部通过。

**Bug 4 — 白名单扩展名保护不保护 `.db` 无前缀文件**:
- 用户反馈: 拓展名保护不能保护无前缀但有后缀的文件比如 `.db`。
- 根因: Rust 标准库 `Path::extension()` 对 `.db` (单点隐藏文件) 返回 `None` (把它当无扩展名的隐藏文件), 导致 `protect_ext=["db"]` 时 `.db` 不被保护。
- 修复: 新增 `extract_ext` helper, 比 `Path::extension()` 更宽松 — `.db` → `db`, `.sqlite` → `sqlite`, `.nomedia` → `nomedia` (单点隐藏文件当作有扩展名)。`file.db` / `.hidden.db` / `archive.tar.gz` 行为与 `Path::extension()` 一致 (不回归)。
- 新增 2 个回归测试 (extract_ext 单元 + ProtectSet::check `.db` 保护), 全部通过。

**Bug 5 — 白名单保存后无法修改**:
- 用户反馈: web 端的白名单保护保存后竟然都不能修改, 没有任何的修改按钮和按键。
- 根因: 后端只有 add/delete 端点, 无 update; 前端只有「+ 新增」和「删除」按钮, 无「编辑」。
- 修复 (后端): 新增 4 个 PUT 更新端点 (原子写 whitelist.toml):
  - `PUT /api/whitelist/protect/:id` (body: ProtectPath, 可改 id 和 path)
  - `PUT /api/whitelist/package/:package` (body: ProtectPackage, 可改 package 和 only)
  - `PUT /api/whitelist/ext` (body: old_extensions+old_scope+extensions+scope, 复合 key)
  - `PUT /api/whitelist/mtime` (body: old_within_days+old_scope+within_days+scope, 复合 key)
  - 改 key 时检查新 key 不与其他条目冲突, 原子替换不丢失数据。
- 修复 (前端): 4 个白名单表格每行加「编辑」按钮; 4 个编辑器加 `isEdit` + 原始 key 追踪; 标题动态「新增/编辑」; 保存时按 isEdit 调 POST(新增) 或 PUT(更新)。

**验证**:
- host `cargo test --package tarn-core --lib protect::` — 33 passed (含 4 个新回归测试), 0 failed。
- host `cargo test --package tarn-core` 全量 — 全部通过。
- 4 种白名单编辑流程 (protect/package/ext/mtime) 后端端点 + 前端 UI 完整。
- 中文规则名创建/保存不再碰撞。

### v0.7.0 (2026-06-20)

**WebUI 终审 QA + 动效一致性收尾** (用户要求: 最后再重点检查 web, 升级 v0.7.0)

**静态审查 (派 subagent 逐行核对 7531 行)**:
- 23 个 `@keyframes` 全部审计: 0 个动画 layout 属性 (全部 transform/opacity/box-shadow), 全 GPU 合成层。
- 标签平衡 100% (div 624=624, details 6=6, summary 6=6, button 111=111, Transition 0=0)。
- 白名单折叠动画 (grid 0fr↔1fr) 纯 CSS 驱动, 无残留 `<Transition>`+`v-show`。
- 日志级别筛选 5 按钮并排, 旧"全选/全不选" UI 已从模板移除。
- `prefers-reduced-motion` 守卫全覆盖。

**修复 3 个 MEDIUM bug**:
1. `setAllLogLevels` 死代码 (旧"全选/全不选"函数, UI 重设计后无人调用) — 删除函数 + 从 setup() return 移除。
2. `runSingleRule` 里残留 `auditExpanded.value = ...` 自动赋值 — 与 v0.6.8 L7 修复冲突 (单规则不写 lastCleanResult, 但 auditExpanded 仍读旧快速清理结果 → 展开按钮状态与审计内容错位) — 删除该行, auditExpanded 改为用户手动控制。
3. 重复的 `.collapse` CSS 定义 (动画规则在顶部, 视觉样式在中部, 两块 `.collapse {}` 选择器分散) — 合并为单一定义, 清晰可维护。

**修复 5 个 LOW + 1 个 QA 发现的 bug**:
4. 17 处 `transition: all .Xs` → 显式合成属性列表 (`transform`/`color`/`background-color`/`border-color`/`box-shadow`/`opacity`), 杜绝 `all` hook 未来 layout 属性。
5. 2 处永久 `will-change` (tabIndicator + details 子元素) 移除, 避免常驻 GPU 层内存压力。
6. 死代码 `.animated-num` + `@keyframes countUp` (0 处模板引用) 删除。
7. **审计展开区改为 grid-collapse 动画** (与白名单折叠同款): 旧 `v-if`+`auditExpand` keyframe 只有进场动画, 退场瞬间消失。改为 `.audit-collapse` 单行 grid `1fr↔0fr` 高度动画, 进出场一致平滑。
8. **[QA 发现] 审计 collapse 的 `grid-row:1` bug**: 初版 CSS 把 `.audit-collapse-body` 放在 `grid-row:1` (auto 行), 但折叠行是 row 2 (0fr), 导致折叠时高度不坍缩 (398px 保持不变)。改为单行模式 `grid-template-rows: 1fr ↔ 0fr`, body 自动占唯一行, 折叠时高度正确归零。

**agent-browser 视觉 QA 验证 (全链路)**:
- 概览页: 4 统计卡片 + 趋势图 + 时间线 + Top5 全部渲染, 无报错。
- 规则页: 3 卡片 × 5 按钮 (预览/真删/详情/编辑/删除) 层次清晰, 无重叠。
- 白名单页: 4 折叠区 (路径/包名/扩展名/mtime), 展开↔折叠动画宽度恒定 (desktop 870px, mobile 343px, 折叠前后完全一致), 横向零变动 ✓。
- 日志页: 5 级别筛选按钮 (带数量徽章) 并排, 切换 ERROR 隐藏对应日志 (6→5→6 行) ✓。
- 审计展开: 折叠↔展开高度动画 398→0→398, 宽度恒定 1190px ✓。
- 设置页: 引擎参数/并发限速/遍历/日志/WebUI/轮转 全部渲染。
- 移动端 (375px): 布局自适应, 折叠动画正常。
- 全程 console 零报错, 零 page error。

**验证**: host `cargo check` 通过; div 标签平衡 624=624; JS `node --check` 通过; agent-browser 全页面交互验证通过; 版本号全链路一致 (v0.7.0 / code 52)。

### v0.6.10 (2026-06-20)

**白名单折叠动画重做 + 动效流畅性优化** (用户反馈: 展开横向变动, 卡片越长动画越难看)

**白名单折叠动画重做**:
- 彻底换掉旧的 `translateY`+`opacity` 动画 (导致展开时横向距离变动 + 长卡片动画畸变)。
- 改用 `grid-template-rows` `0fr↔1fr` 高度展开动画 (与高级选项 details 同款): `.collapse` 容器做 grid, 第一行 `collapse-head` (auto), 第二行 `collapse-body-wrap` (0fr/1fr), 配合 `min-height:0` + `overflow:hidden` 实现平滑高度过渡。
- 移除 Vue `<Transition>` + `v-show` 方案 (`v-show` 切 `display` 无法平滑高度, leave 时绝对定位会导致下方内容跳动), 改为 `:class` 切换 `.collapsed` 状态, body 始终渲染, 纯 CSS 驱动。
- 内容 `opacity` 淡入 (`.2s`) 配合高度展开, 双层过渡更自然。
- 动画与内容高度无关: 无论卡片 1 行还是 50 行, 展开速度/质感完全一致, 不再"越长越难看"。
- 横向零变动: 只动高度 (grid-row) + opacity, 不动 transform/width, 表格列宽稳定不跳。

**动效流畅性优化**:
- `tabIndicator`: `width` 动画 (触发 layout 重排) → `transform scaleX` (GPU 合成), 零重排。
- 全局 `transition: all` → 显式合成属性 (`transform`/`color`/`background-color`/`border-color`/`box-shadow`/`opacity`), 避免 `all` hook 全部属性触发 layout 检查。
- `details` grid 展开加 `contain: content`, 隔离内部 reflow 不触发整页重排。
- 全部 24 个 `@keyframes` 审计: 0 个动画 layout 属性 (全部 transform/opacity), 全 GPU 合成层。

**验证**: host `cargo check` 通过 (无 warning); aarch64-linux-android release 编译通过; div 标签平衡 623=623; 二进制 ELF aarch64 ✓; 动画审计 0 个 layout 属性; 版本号全链路一致 (v0.6.10 / code 51)。

### v0.6.9 (2026-06-20)

**WebUI UX/动效全面升级** (用户反馈: 全局动效太少, 细节不到位, 大致看得过去细都不行)

针对用户反馈的 WebUI 前端细节缺失, 系统性补齐动效与交互:

**动效/交互**:
- **规则 Tab 加载动画**: 从其他 Tab 切到规则页不再卡顿空白, 加骨架屏 (`skeleton-shimmer`) + 卡片错落淡入 (`cardStagger`), 切换更顺滑。
- **重新生成 Token 登出过渡**: 生成成功后先 toast 新 token 预览, 延迟 350ms 平滑淡出登录页 (登录覆盖层 `fadeIn`), 不再硬切。
- **退出登录二次确认**: `doLogout` 加确认对话框 ("退出后需重新输入 Token 才能再次进入管理面板。确认退出吗?"), `confirmVariant=danger`, 防误触。
- **规则卡片多操作按钮**: 每条规则卡片除预览外, 补"运行/详情/编辑/删除"四个 action 按钮 (`ra-preview`/`ra-run`/`ra-detail`/`ra-edit`/`ra-delete`), 悬浮上移 `translateY(-1px)` + 按下缩放 `scale(.96)` 反馈, 删除按钮 danger 红色。
- **日志级别按钮重做**: 旧小按钮太丑 → 改 segmented toggle 风格 (`.llf-chip`), 带圆点状态指示 (`llf-dot`) + 计数徽章 (`llf-count`) + active 高亮背景, 触感更佳。
- **全局动效补强**: 25+ `@keyframes` (`pageEnter`/`tabIndicator`/`cardStagger`/`loginEnter`/`loginCardEnter`/`toastIn`/`toastOut`/`modalIn`/`collapseOpen`/`numIn`/`pulse`/`pulseWarn`/`panelDrop`/`skeleton-shimmer`/`countUp`/`slideInRight`/`fadeIn`/`slideUp`/`slideIn`/`spin`/`shimmer`/`batchBarIn`/`toastSlideIn`) + 91 处 `transition`, 覆盖页面切换/卡片错落入场/按钮反馈/抽屉滑入/Toast/模态框/数字滚动。

**安全/状态**:
- **冲突检测面板懒加载拆分**: `ensureConflictsLoaded` (懒加载不开面板不 toast) / `loadConflicts` (用户主动触发才开面板 + toast + 自动跳白名单页), 横幅不再每次切页强制重开。
- **单规则真删二次确认**: 抽屉真删按钮前加 `window.confirm`, 卡片按钮强制预览 (`forceDryRun=true`), `openRuleDetail` 每次重置 `singleRuleDryRun=true`, 防状态污染误删。
- **confirmDialog 确认按钮** async 期间 `loading` 禁用, 防重复点击 (批量删除/删除规则/重新生成 token)。
- **重新生成 Token** 读 `token_preview` + `hint` (后端不回传明文, 写 `run/token` 0600 root-only), 主动登出提示 `cat run/token`。

**验证**: host `cargo check` 通过 (无 warning); aarch64-linux-android release 编译通过 (NDK r27c, rustc 1.96.0); div 标签平衡 620=620; 二进制 ELF aarch64 ✓ (3.4M, strip + LTO + opt-level=z); WebUI UX 全量核对到位; 版本号全链路一致 (v0.6.9 / code 50)。

### v0.6.8 (2026-06-20)

**WebUI 前端重度审查 — 修 23 处 bug** (用户反馈: 改了这么多都不检查的吗)

深度审查 WebUI 前端 `index.html` (7090 行) 与后端 `lib.rs` (2261 行) 的连接性 + 状态管理 + 交互逻辑, 派 subagent 逐行核对 28 处 `apiRequest` + 1 处裸 `fetch` 的 URL/方法/body shape/响应字段, 发现并修复 23 处 bug:

**严重 (2)**:
- **重新生成 Token 完全失效**: 后端返回 `{ok, token_preview, hint}` (不出明文 token, 写入 run/token 文件), 但前端读 `data.token` (不存在) → if 块跳过 → 不 toast/不更新/不登出 → 旧 token 已失效 → 下次任意 API 调用 401 → 用户被踢回登录页完全不知新 token 在哪。修复: 读 `token_preview` + `hint` + 主动登出 + 提示 `cat run/token`。
- **单规则"真删"状态污染**: `singleRuleDryRun` 是共享 ref, 抽屉里切到🔥真删后关抽屉, 点另一规则的"▶运行"卡片按钮 → 直接真删该规则匹配的文件, 无二次确认。修复: 卡片按钮改"▶预览"强制 `forceDryRun=true`; 抽屉按钮真删前 `window.confirm` 二次确认; `openRuleDetail` 每次重置 `singleRuleDryRun=true`。

**中等 (6)**:
- **规则详情历史运行缺字段**: `ruleDetailHistory` computed 只返回 `{ts_start, trigger, dry_run, freed_bytes, duration_ms, status}`, 但模板引用 `h.files_deleted`/`h.dirs_removed` → 显示"· 删  ·释放 X"空数字。补字段。
- **冲突横幅关不掉 (v0.6.6 修复被打回)**: `watch(activePage)` 每次切到 rules/whitelist 都调 `loadConflicts()` → 无条件 `conflictPanelOpen=true` → 用户点✕关闭后切页又自动弹。拆成 `ensureConflictsLoaded` (懒加载, 不开面板不 toast) + `loadConflicts` (用户点按钮才开面板 + toast + 自动跳白名单页)。
- **openRuleDetail 每次 toast "✓无冲突"**: 每打开一条规则就弹 toast 骚扰。改用 `ensureConflictsLoaded` (不 toast)。
- **规则页"检测冲突"看不到面板**: 冲突面板只在白名单页渲染, 规则页点"检测冲突"只看到 toast。`loadConflicts` 现在 `activePage !== 'whitelist'` 时自动跳过去。
- **导出 401 不登出**: `doExport` 用裸 `fetch` 不走 `apiRequest`, token 过期时只弹"导出失败"不跳登录页。补 401 分支处理。
- **loadAllowedRoots 无 token 就调**: `onMounted` 立即调 → 401 弹 toast 骚扰登录页; 登录后不重载 → 路径白名单空 → 路径校验降级。加 token 守卫 + `checkAuth` 成功后补调。

**低 (15)**: loadRules 缺 catch; daemonAction 读 data.message (不存在) + 死 else; cronPreview/doImport 死 else; 并发 401 toast 刷屏 (apiRequest 加 isLoggedIn 守卫去重); confirmDialog 确认按钮 async 期间可重复点 (批量删除/删除规则/重新生成 token 加 loading 禁用); lastCleanResult 在快速清理和单规则间共享污染 (单规则不再写); saveRule 不校验 target 路径非空/至少一个触发方式 (补校验); 时间线 run_id.slice 防御; 等。

**验证**: host `cargo check` 通过 (无 warning); host x86_64 release 编译通过; div 标签平衡 616=616; API 连接性全部核对一致; 版本号全链路一致 (v0.6.8 / code 49)。

### v0.6.7 (2026-06-20)

**修规则详情卡片重合 + 动效精简保流畅** (用户反馈: 规则详情页卡片重合; 不要一直加动效, 保证流畅度)

- **修复规则详情抽屉卡片重合**: "次要统计"区块用了 `class="grid grid-cols-2 gap-2"` 但 `.grid`/`.grid-cols-2` **根本没定义 CSS** (只有 `.gap-2` 有定义), 导致 3 个 `.stat-block` 不是网格而是默认 block 堆叠, 且 `margin:0` 覆盖了 `.stat-block` 的 `margin-bottom:12px`, 紧贴重合。修复: 补 `.grid { display:grid }` / `.grid-cols-2 { grid-template-columns:repeat(2,1fr) }` / `.grid-cols-3` 定义, 真正两列布局。
- **动效精简保流畅** (v0.6.6 动效加太多, 用户反馈影响流畅度):
  - 移除 `.card:hover` 全局抬升 (影响所有卡片, 包括抽屉内"清理目标"的 `.card`, 窄空间 hover 重合感)
  - 移除 `.rule-card` stagger 入场动画 (`cardEnter` + `nth-child` 1-6+ 错开 delay, 低端机规则多时连续重排卡顿)
  - 移除 `.stat-value` `countUp` 动画
  - 移除底部 tab `tabPop` 弹跳 (cubic-bezier 弹性曲线, 多余且每次切 tab 都触发)
  - 移除 `.btn:hover` translateY + 光晕、`.stat-card-mini:hover` 抬升
  - 删除重复的 `.rule-card:hover` 定义 (旧 2029 行 + 新 1499 行, 冗余)
  - `panelDrop`/`conflict-panel` 入场: `opacity+translateY` → 仅 `opacity` (避免重排)
  - **保留轻量动效**: `page-view` 页面切换淡入 (.22s, 仅 opacity 无 transform)、`.btn:active` scale .97、`.rule-card:hover` border+shadow 变化 (无位移)、`.llf-chip:hover` 1px、`prefers-reduced-motion` 兜底

**验证**: host `cargo check` 通过 (无 warning); div 标签平衡 616=616; 源文件 grep 确认 `.card:hover`/`cardEnter`/`tabPop`/`countUp`(stat-value) 全部移除, `.grid`/`.grid-cols-2` 定义已补; aarch64 交叉编译通过; 版本号全链路一致 (v0.6.7 / code 48)。

### v0.6.6 (2026-06-20)

**WebUI 体验优化 (5 项)** (用户真机反馈: 日志页拥挤、无动效、冲突横幅不消失、规则只能预览、快速清理放错位置)

- **日志页顶部重排**: 标题/操作按钮/级别筛选由「两行挤压」改为「卡片内分行」, 不再拥挤; 级别筛选由 checkbox+文字 改为胶囊 chip + 彩色圆点, 激活态高亮, 呼吸感更强。
- **全局动效系统**: 新增 `.page-view` 页面切换淡入上滑 (每次切 tab 触发)、`.card:hover` 抬升 + 阴影、`.btn` press (scale .97)、底部 tab 选中弹跳 (tabPop)、统计数字 `countUp`、规则卡片 `cardEnter` stagger 入场 (nth-child 错开 delay); 尊重 `prefers-reduced-motion`。
- **白名单冲突横幅可关闭**: 新增 `conflictPanelOpen` 状态 (默认 false), 检测后面板带 ✕ 关闭按钮 (hover 旋转 90°), 不再常驻; 关闭后回无横幅状态, 重新检测再出现。面板入场 `panelDrop` 动画。
- **规则详情执行模式**: 「运行此规则」由写死 `dry_run:true` 改为预览/真删切换 (`singleRuleDryRun` ref + `.single-run-mode` 切换组); 真删模式按钮变红 (`--risk-dangerous`) + 警告色, 文案随模式变 (▶ 预览此规则 / 🔥 真删此规则)。
- **快速清理卡片迁移**: 整块「快速清理」卡片 (181 行) 从概览页移到规则页顶部 (Python 脚本按 div 深度切片精确迁移); 概览页保留「最近一次运行」摘要 + 趋势图 + Top 规则, 聚焦看状态; 规则页聚焦管规则+执行, 标题改「⚡ 立即执行清理」。

**验证**: host `cargo check` 通过 (无 warning); aarch64 交叉编译通过; 版本号全链路一致 (v0.6.6 / code 47)。

### v0.6.5 (2026-06-20)

**修复清理后残留线程 (方案F 补完)** (v0.6.4 真机实测: 预览/真删除清理后多出 4 个 `tokio-rt-worker` 线程且不释放)

- **根因 1 — walker.rs 全局 rayon pool**: `parallel_workers=0` (默认) 时 `walk_parallel` 用 `rayon::scope`, 会初始化 **全局 rayon 线程池**, 其线程常驻永不退出 → 清理后残留。修复: 始终构建 **LOCAL rayon pool** (`.build()`), `parallel_workers=0` → `num_cpus()`。清理结束 pool drop, 线程全退。
- **根因 2 — api_clean spawn_blocking**: `tokio::task::spawn_blocking` 的线程进 tokio 阻塞池, 空闲 10s 才退出 (频繁触发会再生, 看似常驻)。修复: 改用裸 `std::thread` (`tarn-clean`) + `tokio::sync::oneshot` channel。`executor.run` 完成后线程立即退出, 不进阻塞池。
- **根因 3 — api_logs_recent spawn_blocking**: 同上。修复: 改用 `tarn-logread` 裸线程, 读完即退。
- **收益**: 清理后线程数**瞬时**回落到基线 (daemon 模式 4 线程), 无 `tokio-rt-worker` / rayon 全局 pool 常驻线程。

**验证**: host x86_64 实测 — 31 文件 real walk, dry-run (scanned 62/deleted 31) + 真删除 (scanned 41/deleted 31) 后线程数均保持 3 (tarn + tarn-logger + 1 启动期临时线程, 10s 后退到 2), **无新增常驻线程**; aarch64 交叉编译通过; 版本号全链路一致 (v0.6.5 / code 46)。

### v0.6.4 (2026-06-20)

**方案F: WebUI 降配常驻 (常驻线程 -3)** (作为 Plan A listener-handoff 之前的稳态降配)

- **tokio runtime 降配**: `webui::serve` 的 tokio runtime 由 `new_multi_thread().worker_threads(2)` 改为 `new_current_thread()`。消除 2 个 `tokio-rt-worker` 常驻线程, async 全跑在 `tarn-webui` 单线程上; `executor.run` 仍走 `spawn_blocking` (阻塞线程池按需创建, 空闲不占线程), 不阻塞 async loop。
- **修复重复 logger**: daemon 模式下 `webui::serve` 不再自建第二个 `AsyncLogger` writer 线程, 改为接收 daemon 传入的共享 logger (`Option<Arc<AsyncLogger>>`), 消除 1 个重复 writer 线程。standalone `tarn webui` 仍自建一个 (合法)。
- **零行为变化**: 8080 始终监听 (无 listener 接力), 首请求零延迟; API/配置/清理逻辑未动。收益: 常驻线程 -3 (2 tokio worker + 1 重复 logger), RSS 下降, 空闲 CPU 仍为 0。

**验证**: host `cargo check` 通过 (无 warning); aarch64 交叉编译通过; 版本号全链路一致 (v0.6.4 / code 45)。

### v0.6.3 (2025-06-20)

**WebUI: 通配符匹配预览支持自定义后缀 (动态生成虚拟示例)** (用户反馈: 自定义后缀显示"0 匹配"误导)

- **修复误导**: 用户输入自定义后缀 (如 `**/*.rs`) 时, 固定示例库里没此后缀文件, 一直显示"0 个示例匹配"+警告"检查通配符有没有写错", 让用户以为规则写错了, 实际上规则是能匹配的。
- **动态虚拟示例**: 新增 `extractExtensions` + `generateVirtualSamples` — 从用户输入的通配符反推能匹配的文件名 (提取后缀 `*.rs`→`.rs` / 纯名字 `cache` / `*name*` 形式 / `*suffix` 形式), 生成匹配的虚拟文件 (`sample.rs` / `sub/deep.rs` / `app_cache/file.rs` / `.hidden.rs` 等) 加入预览, 带「虚拟」标记, 证明规则对此后缀/名字有效。
- **扩充固定示例库**: 12 → 31 个, 新增 `.json`/`.xml`/`.dat`/`.bin`/`.bak`/`.pid`/`.db`/`.sqlite`/`.nomedia`/`.jpg`/`.png`/`.mp3`/`.mp4`/`.log.bak`/`.log.1` 等更多后缀和深层目录场景。
- **改进警告文案**: 仅当连虚拟示例都匹配不到时才提示语法问题, 文案列出常用写法 (`*.log` / `**/*.log` / `*cache`) 供参考; 虚拟示例匹配时加说明"实际清理时扫描真实文件, 不限于这些样例"。

**验证**: node 模拟 9 组测试用例 (`**/*.rs`/`*.log`/`**/*.json`/`**/*.log.bak`/`*cache`/`*cache*`/`cache`/`**/*`/`**/*.xyz`) 全部符合预期; `**/*.rs` 从"0 匹配+警告"变为"匹配 4 个示例 (含 4 个虚拟)"; host cargo check 通过 + aarch64 交叉编译通过 + 版本号全链路一致 (v0.6.3 / code 44)。

### v0.6.2 (2025-06-20)

**诊断脚本微调: 诊断包不再收集 customize.sh** (用户反馈: 去除 customize.sh 的收集)

- 诊断包 `meta/` 目录不再收集 `customize.sh`: `customize.sh` 是 Magisk 模块安装时脚本 (仅刷入/更新模块时运行一次), 与运行时诊断无关, 收集它对排查 daemon 问题无价值。
- `meta/` 仍保留 `module.prop` / `service.sh` / `uninstall.sh` (运行时/卸载相关, 有取证价值)。
- 其余诊断内容不变 (`diagnostic.txt` 不转储规则内容, `configs/rules/` 仍保留规则原样副本)。

**验证**: debug.sh `sh -n` 语法校验通过 + 模拟打包验证 (meta/ 无 customize.sh) + host cargo check 通过 + aarch64 交叉编译通过 + 版本号全链路一致 (v0.6.2 / code 43)。

### v0.6.1 (2025-06-20)

**诊断脚本 (debug.sh v4 → v5): diagnostic.txt 不再转储清理规则内容** (用户反馈: 清理规则转储进诊断文本占用过大)

- `diagnostic.txt` 不再转储用户清理规则的内容: 社区规则包可达数千行, 转储进诊断文本会撑爆体积且与 `configs/rules/` 重复。第 4 章改为只列清单 (文件名 / 行数 / 字节), 足以判断规则加载状态。移除 `dump_file_smart` 函数 (仅规则转储用, 已无用)。
- 压缩包 `configs/rules/` **仍保留**规则文件原样副本 (取证需要, 每个 `.toml` 附 `.meta` sidecar 记录源路径/权限/大小/md5)。需要看规则原文时, 解压 tar.gz 取 `configs/rules/` 即可。`settings/blacklist/whitelist.toml` 同样保留原样副本 (一直如此)。
- `diagnostic.txt` 其余内容保持 (用户要求: 保留必要的检测结果和适当的重复内容): `settings/blacklist/whitelist.toml` 仍内联转储 (小文件, 诊断必需, 与 `configs/` 适当重复); `boot.log/tarn.log` 仍按原阈值转储 (与 `logs/` 适当重复); 17 章检测结果 + 摘要全保留。
- `meta.txt` / stdout 包结构描述同步更新 (diagnostic.txt 标注"不含规则内容", configs/ 标注含 rules/)。

**验证**: debug.sh `sh -n` 语法校验通过 + 模拟打包验证 (压缩包 configs/rules/ 含规则原样副本, diagnostic.txt 规则部分仅清单无正文) + host cargo check 通过 + aarch64 交叉编译通过 + 版本号全链路一致 (v0.6.1 / code 42)。

### v0.6.0 (2025-06-20)

**版本号规则**: 采用 vx.b.c 语义化版本, 每 10 进一 (c 满 10 进位 b, 不出现 v0.5.10)。本次为补丁版本 (v0.5.9 的 c 满 10 进位)。

**诊断脚本 (debug.sh v3 → v4)**
- 输出从单一 `.txt` 改为 `tar.gz` 压缩包, 一个档案装全部:
  - `diagnostic.txt` — 完整诊断文本 (v3 的 17 章检测全保留)
  - `configs/` — 用户配置原样副本 (settings/blacklist/whitelist/rules/*.toml), 每个附 `.meta` sidecar (源路径/权限/大小/md5)
  - `logs/` — 日志副本 (boot.log >512KB 截尾, tarn.log >3000行截尾, debug-sh.err)
  - `state/` — state.json 全量 + run/ 元信息 (token 内容脱敏, 只存元信息不打包)
  - `system/` — 系统快照独立成文 (dmesg/mount/getprop/ps/SELinux avc denial)
  - `meta/` — 模块脚本 (module.prop/service.sh/customize.sh/uninstall.sh) + 环境元信息
  - `MANIFEST.txt` — 全文件清单 + 字节数
- busybox 检测增强: 覆盖 KSU/APatch/Magisk 三大框架 9 条路径, 优先级 KSU > APatch > Magisk > system > xbin > vendor > PATH。
- tar.gz 创建三级降级: busybox `tar -czf` > 系统 `tar -czf` > `tar -cf` + `gzip -c` 分步管道。打包失败保留暂存目录 + `.FAILED` 标记。

**日志去说教化**
- 全量审查 233 处日志调用, 清理 9 处"自以为贴心"的括号解释, 保留事实数据括号。
- 例: `nice(19) 成功 (CFS 调度器遵守, 所有设备有效)` → `nice(19) 成功`
- 例: `panic hook 已安装 (panic 时记录 stderr + 日志 + backtrace + 发通知 + 跑 debug.sh 后再 abort)` → `panic hook 已安装`
- 保留: `(不影响主流程)` / `(fd=5)` / `sleep 兜底` / `降级运行` 等事实/非致命提示。
- 低功耗调优日志精简: 删除 `value=19, CFS 调度器一定遵守` / `cores=[...], 遍历 /proc/self/task 覆盖所有线程` 等说教, 只留 `✓ 已应用` / `✗ 失败`。

**验证**: host cargo check 通过 + aarch64-linux-android release 交叉编译通过 + 二进制串校验 (9 说教串全清, 9 事实串保留) + dist zip/src 已重打。

### v0.5.9 (2025-06-20)

**安全修复**
- 修复 glob 类 `protect_path` 路径别名绕过 bug: 用户配 `/sdcard/Download/*.pdf` (通配符保护), blacklist 用 `/storage/emulated/0/Download/secret.pdf` 形式可绕过保护导致文件被清理。修复后 glob 分支也调用 `expand_sdcard_aliases` 展开 4 种等价路径形式 (与 prefix 分支一致)。
- 修复 `ProtectExt` / `ProtectMtime` 的 `scope` 字段路径别名绕过 bug: 用户配 `scope="/sdcard/Download"`, blacklist 用 `/storage/emulated/0/Download/` 形式可绕过扩展名/时间保护。修复后 scope 也归一化为 4 种路径形式集合, 任一命中即保护。
- 修复 protect/clean 通配符语义不一致: protect 侧 `*` 默认跨 `/`, 但 clean 侧 `*` 不跨 `/` (literal_separator)。统一为 `literal_separator(true)`, 两侧语义一致。
- 至此 `protect.rs` 所有用户可配路径字段 (`protect_path.path` / `protect_ext.scope` / `protect_mtime.scope`) 全部归一化, 4 种 sdcard 别名形式全覆盖。

**文档与 UI**
- `ProtectPath` 文档补全: 通配符语义表 (`*`/`**`/`?`/`[]`)、跨形式归一化说明、4 个常见示例。
- 保护侧 protect_path 编辑器: 简陋提示 → 富文本速查表 (6 行示例对照表 + 别名归一化说明)。
- 预览清理审计行: 文件名加 📄 图标 + 浅色背景 pill 突出 "要删的文件"; 紧凑模式目录路径用中间省略号 (保留头尾, 非尾部省略)。

**验证**: 113 单元测试全过 + aarch64-linux-android release 交叉编译通过。

### v0.5.8

- Download 移出内置用户媒体保护 (用户可按需在 whitelist.toml 自行保护)。
- debug.sh 诊断脚本重写 (775 行, 18 章)。
- Rust 侧 debug.sh 故障静默修复 (stderr 重定向 + spawn 失败兜底)。

---

## 许可证

MIT License - 见 [LICENSE](https://github.com/tarn/tarn/blob/main/LICENSE)

## 相关文档
- [配置 schema 完整文档](https://github.com/tarn/tarn/blob/main/docs/CONFIG-SPEC.md)
- [Magisk 模块开发文档](https://github.com/topjohnwu/Magisk/blob/master/docs/guides.md)
- [issue 反馈](https://github.com/tarn/tarn/issues)

## 致谢
- [Magisk](https://github.com/topjohnwu/Magisk) by topjohnwu
- [Rayon](https://github.com/rayon-rs/rayon) - 数据并行库
- [axum](https://github.com/tokio-rs/axum) - Web 框架
- [Vue 3](https://vuejs.org/) - 前端框架
