#!/bin/sh
# ============================================================
# Tarn 一键交叉编译脚本 (aarch64-linux-android)
# ============================================================
# 用法:
#   ./build.sh           # 编译 + 拷贝二进制到 module/tarn
#   ./build.sh zip       # 编译 + 打包 Magisk 模块 zip 到 dist/
#   ./build.sh src       # 打包源码 tarball 到 dist/ (不编译)
#   ./build.sh all       # 编译 + zip + src
#   ./build.sh clean     # cargo clean + 删 dist/
#
# 前置条件:
#   1. Rust 工具链 (rustup), 安装 aarch64-linux-android target:
#        rustup target add aarch64-linux-android
#   2. Android NDK r25+ (推荐 r27c), 以下任一方式告知脚本位置:
#        a) 环境变量: export ANDROID_NDK_HOME=/path/to/ndk
#        b) 默认路径: ~/Android/android-ndk-r27c (脚本自动检测)
#        c) 命令行: NDK=/path/to/ndk ./build.sh
#
# NDK 下载: https://developer.android.com/ndk/downloads
# 推荐版本: r27c (https://dl.google.com/android/repository/android-ndk-r27c-linux.zip)
# ============================================================

set -e  # 任何命令失败立即退出

# ---- 颜色输出 (终端才用颜色, 管道/重定向用纯文本) ----
if [ -t 1 ]; then
    GREEN='\033[0;32m'; YELLOW='\033[0;33m'; RED='\033[0;31m'; BLUE='\033[0;34m'; NC='\033[0m'
else
    GREEN=''; YELLOW=''; RED=''; BLUE=''; NC=''
fi
info()  { printf "${GREEN}[INFO]${NC} %s\n"  "$1"; }
warn()  { printf "${YELLOW}[WARN]${NC} %s\n"  "$1"; }
error() { printf "${RED}[ERROR]${NC} %s\n" "$1"; }
title() { printf "${BLUE}=== %s ===${NC}\n" "$1"; }

# ---- 项目根目录 (脚本所在目录) ----
cd "$(dirname "$0")"
PROJECT_ROOT="$(pwd)"
info "项目根目录: $PROJECT_ROOT"

# ---- 定位 NDK ----
title "1. 检测 Android NDK"
NDK="${NDK:-${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}}"
if [ -z "$NDK" ] || [ ! -d "$NDK" ]; then
    # 尝试常见路径
    for candidate in \
        "$HOME/Android/android-ndk-r27c" \
        "$HOME/Android/android-ndk-r27b" \
        "$HOME/Android/android-ndk-r27a" \
        "$HOME/Android/android-ndk-r26d" \
        "$HOME/Android/android-ndk-r26c" \
        "$HOME/Android/android-ndk-r25c" \
        "/opt/android-ndk" \
        "/usr/local/android-ndk"; do
        if [ -d "$candidate" ]; then
            NDK="$candidate"
            break
        fi
    done
fi

if [ -z "$NDK" ] || [ ! -d "$NDK" ]; then
    error "未找到 Android NDK!"
    error "请安装 NDK r25+ 并通过以下任一方式告知脚本位置:"
    error "  a) export ANDROID_NDK_HOME=/path/to/ndk  (推荐)"
    error "  b) NDK=/path/to/ndk ./build.sh"
    error "  c) 解压到 ~/Android/android-ndk-r27c (脚本自动检测)"
    error ""
    error "NDK 下载: https://developer.android.com/ndk/downloads"
    error "推荐版本: r27c"
    exit 1
fi
info "NDK 路径: $NDK"

# NDK 工具链路径 (linux-x86_64 为主, macOS 自动适配)
OS_TAG="linux-x86_64"
case "$(uname -s)" in
    Darwin) OS_TAG="darwin-x86_64" ;;
esac
TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$OS_TAG"
if [ ! -d "$TOOLCHAIN" ]; then
    error "NDK 工具链目录不存在: $TOOLCHAIN"
    error "请检查 NDK 版本是否为 r25+ (旧版 NDK 工具链路径不同)"
    exit 1
fi
CLANG="$TOOLCHAIN/bin/aarch64-linux-android24-clang"
AR="$TOOLCHAIN/bin/llvm-ar"
if [ ! -x "$CLANG" ]; then
    error "NDK clang 不可执行: $CLANG"
    exit 1
fi
info "工具链: $TOOLCHAIN"

# ---- 检查 Rust 工具链 ----
title "2. 检查 Rust 工具链"
if ! command -v cargo >/dev/null 2>&1; then
    error "未找到 cargo! 请先安装 Rust 工具链:"
    error "  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
    exit 1
fi
info "cargo: $(cargo --version)"
info "rustc: $(rustc --version)"

# 检查 aarch64-linux-android target
if ! rustup target list --installed 2>/dev/null | grep -q '^aarch64-linux-android'; then
    warn "未安装 aarch64-linux-android target, 正在安装..."
    rustup target add aarch64-linux-android
fi
info "target aarch64-linux-android: 已安装"

# ---- 生成 .cargo/config.toml (用当前 NDK 路径) ----
title "3. 配置 cargo 交叉编译 linker"
mkdir -p .cargo
cat > .cargo/config.toml <<EOF
# 自动生成 by build.sh — 不要手动编辑
# 重新运行 ./build.sh 会覆盖此文件

[target.aarch64-linux-android]
linker = "$CLANG"
ar     = "$AR"

[profile.release]
opt-level = "z"        # 体积优先 (清理任务 IO bound)
lto = true             # 全链接时优化
panic = "abort"        # 省 unwinding 表 (关键路径全用 Result, 不 panic)
strip = true           # 剥离调试符号
codegen-units = 1      # 单 codegen unit, 更好优化
incremental = false
EOF
info ".cargo/config.toml 已生成 (linker=$CLANG)"

# ---- 编译 ----
title "4. 编译 release (aarch64-linux-android)"
info "运行: cargo build --release --target aarch64-linux-android"
cargo build --release --target aarch64-linux-android
info "编译完成"

# ---- 拷贝二进制 ----
title "5. 拷贝二进制到 module/tarn"
BINARY="target/aarch64-linux-android/release/tarn"
if [ ! -f "$BINARY" ]; then
    error "二进制不存在: $BINARY"
    error "编译可能失败, 请检查上方输出"
    exit 1
fi
cp -f "$BINARY" module/tarn
chmod 755 module/tarn
BINARY_SIZE=$(du -h module/tarn | cut -f1)
info "二进制已拷贝: module/tarn ($BINARY_SIZE)"

# 验证 ELF aarch64
ELF_INFO=$(file module/tarn 2>/dev/null || echo "unknown")
case "$ELF_INFO" in
    *ARM*aarch64*) info "ELF 验证: aarch64 ✓" ;;
    *) warn "ELF 验证: 非 aarch64 ($ELF_INFO)" ;;
esac

# ---- 子命令处理 ----
ACTION="${1:-build}"
case "$ACTION" in
    build)
        title "完成"
        info "二进制: module/tarn ($BINARY_SIZE)"
        info "如需打包 Magisk 模块 zip: ./build.sh zip"
        ;;

    zip)
        title "6. 打包 Magisk 模块 zip"
        mkdir -p dist
        # 读版本号
        VERSION=$(grep '^version=' module/module.prop | cut -d= -f2)
        ZIP_NAME="dist/tarn-${VERSION}-linjoin.zip"
        info "打包: $ZIP_NAME"
        # 进 module 目录打包 (zip 内根目录就是 module 内容)
        (cd module && zip -r9 -X "../$ZIP_NAME" . -x '*.DS_Store' -x '*/.git*')
        ZIP_SIZE=$(du -h "$ZIP_NAME" | cut -f1)
        info "模块 zip: $ZIP_NAME ($ZIP_SIZE)"
        ;;

    src)
        title "6. 打包源码 tarball"
        mkdir -p dist
        VERSION=$(grep '^version=' module/module.prop | cut -d= -f2)
        SRC_NAME="dist/tarn-${VERSION}-linjoin-src.tar.gz"
        info "打包: $SRC_NAME"
        # 排除编译产物 / 二进制 / .git / dist 自身
        tar --exclude='./target' \
            --exclude='./dist' \
            --exclude='./.git' \
            --exclude='./tarn-data' \
            --exclude='./module/tarn' \
            --exclude='./module/webroot/index.html' \
            --exclude='./public' \
            -czf "$SRC_NAME" \
            .
        SRC_SIZE=$(du -h "$SRC_NAME" | cut -f1)
        info "源码包: $SRC_NAME ($SRC_SIZE)"
        ;;

    all)
        title "6. 打包 zip + src"
        mkdir -p dist
        VERSION=$(grep '^version=' module/module.prop | cut -d= -f2)
        ZIP_NAME="dist/tarn-${VERSION}-linjoin.zip"
        SRC_NAME="dist/tarn-${VERSION}-linjoin-src.tar.gz"
        info "打包: $ZIP_NAME"
        (cd module && zip -r9 -X "../$ZIP_NAME" . -x '*.DS_Store' -x '*/.git*')
        info "打包: $SRC_NAME"
        tar --exclude='./target' \
            --exclude='./dist' \
            --exclude='./.git' \
            --exclude='./tarn-data' \
            --exclude='./module/tarn' \
            --exclude='./module/webroot/index.html' \
            --exclude='./public' \
            -czf "$SRC_NAME" \
            .
        ZIP_SIZE=$(du -h "$ZIP_NAME" | cut -f1)
        SRC_SIZE=$(du -h "$SRC_NAME" | cut -f1)
        info "模块 zip: $ZIP_NAME ($ZIP_SIZE)"
        info "源码包: $SRC_NAME ($SRC_SIZE)"
        ;;

    clean)
        title "清理"
        info "cargo clean + 删除 dist/"
        cargo clean
        rm -rf dist/
        info "清理完成"
        ;;

    *)
        error "未知子命令: $ACTION"
        error "用法: ./build.sh [build|zip|src|all|clean]"
        exit 1
        ;;
esac

title "完成 ✓"
