//! 热重载: SIGHUP / tarn reload 命令触发, 重新加载三文件
//!
//! 重载时:
//! 1. 标记 reload_requested
//! 2. 若当前有任务在跑: 不打断, 任务结束后加载
//! 3. 若无任务: 立即加载新配置
//! 4. 加载失败 (语法错): 保留旧配置, 记 ERROR

use crate::config::{Blacklist, Settings, Whitelist};
use crate::protect::ProtectSet;
use anyhow::{anyhow, Result};
use parking_lot::RwLock;
use std::path::PathBuf;
use std::sync::Arc;

/// 全局配置 (热重载替换)
#[derive(Clone)]
pub struct Config {
    pub settings: Settings,
    pub blacklist: Blacklist,
    pub whitelist: Whitelist,
    pub protect: ProtectSet,
}

impl Config {
    pub fn load(config_dir: &PathBuf) -> Result<Self> {
        // 配置文件统一在 config/ 子目录 (与 customize.sh 部署位置一致)
        let settings_path = config_dir.join("config/settings.toml");
        let blacklist_path = config_dir.join("config/blacklist.toml");
        let whitelist_path = config_dir.join("config/whitelist.toml");

        let settings = Settings::load(&settings_path)
            .map_err(|e| anyhow!("settings 加载失败: {e}"))?;
        let blacklist = Blacklist::load(&blacklist_path)
            .map_err(|e| anyhow!("blacklist 加载失败: {e}"))?;
        let whitelist = Whitelist::load(&whitelist_path)
            .map_err(|e| anyhow!("whitelist 加载失败: {e}"))?;

        let protect = ProtectSet::compile(&whitelist)
            .map_err(|e| anyhow!("protect 编译失败: {e}"))?;

        Ok(Self {
            settings,
            blacklist,
            whitelist,
            protect,
        })
    }
}

/// 全局配置持有者 (Arc<RwLock> 支持热替换)
pub type ConfigHandle = Arc<RwLock<Config>>;

/// 创建配置句柄
///
/// 配置文件解析失败时回退到默认值, 而非返回 Err 终止 daemon。
///
/// 若 `Config::load` 在任一配置文件 (settings/blacklist/whitelist) 语法错误时
/// 返回 Err 并传播出去, run_daemon_cmd 会退出 → daemon 不启动 → WebUI 永远
/// 连不上 → 用户"卡在启动界面"无法通过 WebUI 修复配置, 形成死锁。
///
/// 因此这里捕获 Config::load 错误, 逐文件回退到默认值 (Settings::default /
/// Blacklist::default / Whitelist::default), 用 eprintln 明确告知用户哪个文件
/// 解析失败 + 回退到默认。daemon 总能启动, 用户可通过 WebUI 修复配置
/// (inotify 自动热重载)。硬编码保护 (/data/adb /system 等) 不依赖 whitelist,
/// 即使 whitelist 解析失败也仍然生效, 不会误删系统文件。
pub fn init_config(config_dir: PathBuf) -> Result<ConfigHandle> {
    match Config::load(&config_dir) {
        Ok(cfg) => Ok(Arc::new(RwLock::new(cfg))),
        Err(e) => {
            // 回退到全默认配置, 保证 daemon 可启动 + WebUI 可访问
            eprintln!("[Tarn] ⚠ 配置加载失败, 回退到默认配置 (daemon 仍会启动): {}", e);
            eprintln!("[Tarn]   请通过 WebUI 或手动编辑修复配置文件, 保存后自动热重载");
            eprintln!("[Tarn]   配置目录: {}", config_dir.join("config").display());
            let default_whitelist = Whitelist::default();
            let protect = ProtectSet::compile(&default_whitelist)
                .map_err(|e| anyhow!("protect 编译失败 (默认 whitelist): {e}"))?;
            let cfg = Config {
                settings: Settings::default(),
                blacklist: Blacklist::default(),
                whitelist: default_whitelist,
                protect,
            };
            Ok(Arc::new(RwLock::new(cfg)))
        }
    }
}

/// 热重载配置 (SIGHUP 或 tarn reload 触发)
///
/// 返回 Ok(()) 表示重载成功, Err 表示失败 (旧配置保留)
pub fn reload(handle: &ConfigHandle, config_dir: PathBuf) -> Result<()> {
    let new_cfg = Config::load(&config_dir)?;
    *handle.write() = new_cfg;
    Ok(())
}
