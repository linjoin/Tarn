//! DFA 通配符匹配引擎
//!
//! 使用 globset 将所有通配符模式编译成单一 DFA,
//! 匹配 O(路径长度), 与模式数无关。
//!
//! ## 设计原则: 严格通配符语义, 不做隐式扩展
//!
//! Matcher 只负责"按通配符字面语义匹配路径", 不替用户做任何决定。
//! 想要"清空匹配目录里的文件"这种意图, 由 [`crate::config::TargetMode`]
//! 在 executor 层显式表达 (用户在 WebUI 选「处理方式」)。
//!
//! 这样懂通配符的人看到的 `*cache` 严格匹配单段名字含 cache 的路径,
//! 不会被底层偷偷加 `/**/*` 搞混。
//!
//! `literal_separator(true)`: `*` 不跨 `/` (符合 POSIX shell 直觉),
//! `**` 仍可跨 `/` (globset 对 `**` 特殊处理, 不受此选项影响)。

use globset::{GlobBuilder, GlobSet, GlobSetBuilder};
use std::path::Path;

/// 编译后的匹配器
#[derive(Debug, Clone)]
pub struct Matcher {
    /// include 通配符集合 (命中即纳入待删)
    include: GlobSet,
    /// exclude 通配符集合 (命中即排除)
    exclude: GlobSet,
    /// 原始模式 (调试用)
    include_patterns: Vec<String>,
    exclude_patterns: Vec<String>,
}

impl Matcher {
    /// 从通配符模式列表编译
    ///
    /// 严格通配符语义, 不做任何隐式扩展。
    /// 调用方 (executor) 负责根据 [`crate::config::TargetMode`] 决定
    /// 是否追加 `<pattern>/**/*` 等额外模式。
    pub fn new(include: &[String], exclude: &[String]) -> Result<Self, String> {
        let mut inc_builder = GlobSetBuilder::new();
        let mut inc_patterns = Vec::new();
        for p in include {
            // literal_separator(true): * 不跨 / (符合 POSIX shell 直觉)
            // 这样 *cache 只匹配单段名字含 cache 的路径, 不匹配 com.example/cache
            // ** 仍然跨 / (globset 对 ** 特殊处理, 不受此选项影响)
            let g = GlobBuilder::new(p)
                .literal_separator(true)
                .build()
                .map_err(|e| format!("include 通配符编译失败 {p}: {e}"))?;
            inc_builder.add(g);
            inc_patterns.push(p.clone());
        }
        let include = inc_builder
            .build()
            .map_err(|e| format!("include GlobSet 构建失败: {e}"))?;

        let mut exc_builder = GlobSetBuilder::new();
        let mut exc_patterns = Vec::new();
        for p in exclude {
            let g = GlobBuilder::new(p)
                .literal_separator(true)
                .build()
                .map_err(|e| format!("exclude 通配符编译失败 {p}: {e}"))?;
            exc_builder.add(g);
            exc_patterns.push(p.clone());
        }
        let exclude = exc_builder
            .build()
            .map_err(|e| format!("exclude GlobSet 构建失败: {e}"))?;

        Ok(Self {
            include,
            exclude,
            include_patterns: inc_patterns,
            exclude_patterns: exc_patterns,
        })
    }

    /// 检查路径是否匹配 (命中 include 且不命中 exclude)
    pub fn matches(&self, path: &Path) -> bool {
        if !self.include.is_match(path) {
            return false;
        }
        if self.exclude.is_match(path) {
            return false;
        }
        true
    }

    pub fn include_patterns(&self) -> &[String] {
        &self.include_patterns
    }

    pub fn exclude_patterns(&self) -> &[String] {
        &self.exclude_patterns
    }
}

/// 默认匹配器 (匹配 **/*, 无 exclude)
impl Default for Matcher {
    fn default() -> Self {
        Self::new(&["**/*".to_string()], &[]).expect("默认 matcher 编译失败")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;

    /// 辅助: 编译单个 include pattern 的 matcher
    fn matcher_from(pattern: &str) -> Matcher {
        Matcher::new(&[pattern.to_string()], &[]).expect("matcher 编译失败")
    }

    // === 严格通配符语义, *cache 只匹配名字含 cache 的单段路径 ===
    #[test]
    fn test_strict_glob_star_cache_only_matches_dir_itself() {
        let m = matcher_from("/data/data/*cache");
        // *cache 匹配 cache 目录本身 (单段名字)
        assert!(m.matches(Path::new("/data/data/cache")));
        assert!(m.matches(Path::new("/data/data/com.foo.cache")));
        // *cache 严格不匹配目录里面的文件 (literal_separator)
        assert!(!m.matches(Path::new("/data/data/cache/foo.txt")));
        assert!(!m.matches(Path::new("/data/data/cache/sub/bar.log")));
        // 不匹配其他目录
        assert!(!m.matches(Path::new("/data/data/com.foo/files/secret.txt")));
        // 不跨 / (com.foo/cache 不被 *cache 匹配, 因为 * 不跨 /)
        assert!(!m.matches(Path::new("/data/data/com.foo/cache")));
    }

    // === ** 仍然跨 / ===
    #[test]
    fn test_double_star_crosses_separator() {
        let m = matcher_from("/data/data/**/cache/**");
        assert!(m.matches(Path::new("/data/data/com.foo/cache/x.txt")));
        assert!(m.matches(Path::new("/data/data/a/b/c/cache/y.log")));
        assert!(m.matches(Path::new("/data/data/cache/foo")));
        // 末尾 /** 要求至少有一个 /, 不匹配 cache 目录本身
        assert!(!m.matches(Path::new("/data/data/com.foo/cache")));
    }

    // === 精确路径不匹配子内容 ===
    #[test]
    fn test_exact_path_no_match_children() {
        let m = matcher_from("/data/data/com.foo");
        assert!(m.matches(Path::new("/data/data/com.foo")));
        assert!(!m.matches(Path::new("/data/data/com.foo/cache/x.txt")));
        assert!(!m.matches(Path::new("/data/data/com.bar")));
    }

    // === **/* 默认匹配所有文件 ===
    #[test]
    fn test_default_pattern_matches_all() {
        let m = Matcher::default();
        assert!(m.matches(Path::new("/any/path/file.txt")));
        assert!(m.matches(Path::new("/a/b/c/d.log")));
        // include_patterns 应只有 1 个 (**/*, 未扩展)
        assert_eq!(m.include_patterns().len(), 1);
    }

    // === patterns 数量: 严格语义不扩展 ===
    #[test]
    fn test_patterns_count_no_implicit_expand() {
        // *cache → 严格 1 个 pattern (无隐式扩展)
        let m = matcher_from("/data/data/*cache");
        assert_eq!(m.include_patterns().len(), 1);
        assert_eq!(m.include_patterns()[0], "/data/data/*cache");

        // **/cache/** → 1 个
        let m2 = matcher_from("/data/data/**/cache/**");
        assert_eq!(m2.include_patterns().len(), 1);

        // 精确路径 → 1 个
        let m3 = matcher_from("/data/data/com.foo");
        assert_eq!(m3.include_patterns().len(), 1);
    }

    // === exclude 严格语义 ===
    #[test]
    fn test_exclude_strict_semantics() {
        let m = Matcher::new(
            &["/data/data/**/*".to_string()],
            &["/data/data/*cache".to_string()],
        )
        .expect("matcher 编译失败");

        // exclude 只匹配 cache 目录本身, 不匹配其下文件 (严格语义)
        // 所以 cache 目录下的文件不会被 exclude, 仍会被 include 删
        assert!(m.matches(Path::new("/data/data/cache/foo.txt")));
        assert!(!m.matches(Path::new("/data/data/cache"))); // cache 被 exclude
        assert_eq!(m.exclude_patterns().len(), 1);
    }

    // === 多 pattern 编译 ===
    #[test]
    fn test_multiple_patterns() {
        let m = Matcher::new(
            &[
                "/data/data/**/*.log".to_string(),
                "/data/data/**/*.tmp".to_string(),
            ],
            &[],
        )
        .expect("matcher 编译失败");
        assert!(m.matches(Path::new("/data/data/com.foo/a.log")));
        assert!(m.matches(Path::new("/data/data/com.foo/sub/b.tmp")));
        assert!(!m.matches(Path::new("/data/data/com.foo/c.txt")));
        assert_eq!(m.include_patterns().len(), 2);
    }
}
