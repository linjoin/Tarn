//! Tarn WebUI 后端 (axum 0.7)
//!
//! 设计要点:
//! - TCP (token 鉴权, 浏览器入口) + Unix socket (peer_cred 鉴权, 本地 App 入口) 双监听
//! - axum 0.7 的 serve 泛型化到 Listener trait, TcpListener + UnixListener 都实现
//! - 用 tokio::select! 并发跑两个 axum::serve (方案 A, 零依赖最简)
//! - Unix socket: bind 前 unlink 旧文件 → bind → chmod 0600
//! - 日志: 手动刷新 /api/logs/recent (不做 SSE 实时流, 消除空闲轮询)
//! - 前端: include_str! 嵌入单文件 index.html
//! - Token: subtle::ConstantTimeEq 常量时间比较 (防时序攻击)
//!
//! 完整 API (面向小白用户配置修改):
//! - GET  /                        前端首页
//! - GET  /api/status              引擎状态 + 累计统计
//! - GET  /api/rules               列所有规则
//! - GET  /api/rules/:id           规则详情
//! - POST /api/rules               新增规则
//! - PUT  /api/rules/:id           修改规则
//! - DELETE /api/rules/:id         删除规则
//! - POST /api/rules/:id/toggle    切换规则启用状态
//! - POST /api/clean               执行清理 (dry_run / trigger / rules)
//! - GET  /api/state               完整状态 JSON
//! - GET  /api/config              读三文件原始 TOML
//! - GET  /api/config/structured   结构化配置 (settings + rules + protects)
//! - POST /api/config/settings     保存 settings.toml (body = TOML 字符串 或 JSON)
//! - POST /api/config/blacklist    保存 blacklist.toml
//! - POST /api/config/whitelist    保存 whitelist.toml
//! - GET  /api/whitelist           列所有白名单 (4 种)
//! - POST /api/whitelist/protect   新增路径保护
//! - DELETE /api/whitelist/protect/:id  删除路径保护
//! - POST /api/whitelist/package   新增包名保护
//! - DELETE /api/whitelist/package/:package  删除包名保护
//! - POST /api/whitelist/ext       新增扩展名保护
//! - DELETE /api/whitelist/ext     删除扩展名保护 (body 提供 extensions+scope)
//! - POST /api/whitelist/mtime     新增 mtime 保护
//! - DELETE /api/whitelist/mtime   删除 mtime 保护 (body 提供 within_days+scope)
//! - GET  /api/daemon/status       daemon 运行状态 (pid/存活/cmdline)
//! - POST /api/daemon/reload       发 SIGHUP 热重载
//! - POST /api/daemon/stop         发 SIGTERM 优雅停止
//! - POST /api/daemon/start        提示用户用 CLI 启动 (无法从 webui 启动 daemon)
//! - GET  /api/packs               列 rules/ 目录下的规则包
//! - POST /api/packs/:name/install 安装规则包 (复制到 blacklist.toml)
//! - POST /api/token/regenerate    重新生成 token
//! - GET  /api/logs/recent        最近 N 行日志 (手动刷新, 不做 SSE)
//! - GET  /api/logs/recent         最近 N 条历史日志

use anyhow::Result;
use axum::{
    extract::{Path, Query, State},
    http::{header::AUTHORIZATION, StatusCode},
    response::{IntoResponse, Response},
    routing::{delete, get, post},
    Json, Router,
};
use hyper_util::rt::TokioIo;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;
use tarn_core::{
    config::{Blacklist, ProtectExt, ProtectMtime, ProtectPackage, ProtectPath, Rule, Settings, Whitelist},
    daemon,
    executor::{Executor, RunOptions, Trigger},
    logger::{parse_line, AsyncLogger, LogLevel},
    reload::ConfigHandle,
    state::StateManager,
    sysutil,
    ALLOWED_ROOTS, CONFIG_SCHEMA_VERSION, VERSION, is_target_allowed,
};
use tokio::net::UnixListener;

// 嵌入前端单文件 (编译时打包进二进制)
const INDEX_HTML: &str = include_str!("../static/index.html");

// ============================================================
// 应用状态
// ============================================================

pub struct WebuiState {
    pub config_dir: PathBuf,
    pub config: ConfigHandle,
    pub token: parking_lot::RwLock<String>,
    pub state: Arc<StateManager>,
    /// 共享 logger (api_clean 触发的清理也写日志文件)
    pub logger: Option<Arc<AsyncLogger>>,
}

// ============================================================
// 启动入口
// ============================================================

pub fn serve(config_dir: PathBuf, config: ConfigHandle, bind: String, port: u16) -> Result<()> {
    let rt = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(2)
        .enable_all()
        .build()?;

    rt.block_on(async move {
        let token = load_or_create_token(&config_dir)?;
        let state_path = config_dir.join("state.json");
        let state = Arc::new(StateManager::new(state_path));

        // 创建共享 logger (与 cli/run.rs make_logger 一致)
        // WebUI 触发的清理也写日志文件, 用户可通过 /api/logs/recent 手动刷新查看
        // 日志改为手动刷新, 彻底消除 WebUI 空闲时的周期性 CPU 唤醒 (不做后台轮询)
        let logger = {
            let cfg = config.read();
            make_logger(&config_dir, &cfg.settings)
        };

        let socket_path = {
            let cfg = config.read();
            cfg.settings.webui.socket_file.clone()
        };
        // 路径解析策略 (防御性兜底):
        // 1. 绝对路径且等于 <config_dir>/tarn.sock (历史默认值)
        //    → 强制改写到 <config_dir>/run/tarn.sock (避免污染数据目录根)
        // 2. 绝对路径 (其他, 用户自定义) → 原样使用
        // 3. 相对路径 → join config_dir (如 "run/tarn.sock" → <config_dir>/run/tarn.sock)
        let socket_path = {
            let p = PathBuf::from(&socket_path);
            if p.is_absolute() {
                // 检测绝对路径残留: <config_dir>/tarn.sock
                let legacy_root_sock = config_dir.join("tarn.sock");
                if p == legacy_root_sock {
                    eprintln!("[WARN] 检测到绝对路径 socket_file ({}), 自动迁移到 run/ 子目录",
                              p.display());
                    config_dir.join("run").join("tarn.sock")
                } else {
                    p
                }
            } else {
                config_dir.join(&socket_path)
            }
        };

        let state = Arc::new(WebuiState {
            config_dir: config_dir.clone(),
            config,
            token: parking_lot::RwLock::new(token.clone()),
            state,
            logger,
        });

        let tcp_app = build_tcp_app(state.clone());
        let tcp_addr = format!("{}:{}", bind, port);
        // 用 TcpSocket 显式设 SO_REUSEADDR, 避免 daemon 重启后端口 TIME_WAIT
        // 导致 WebUI bind 失败 (TcpListener::bind 不保证 SO_REUSEADDR)。
        // daemon 被 kill 后, 8080 端口可能进入 TIME_WAIT (最长 60s),
        // 新轮 daemon bind 失败 → WebUI 线程退出 → 用户连不上。
        let tcp_listener = bind_tcp_with_reuseaddr(&tcp_addr)?;
        println!("[OK] TCP 监听: http://{} (SO_REUSEADDR)", tcp_addr);
        println!("     token: {}", token);

        let uds_app = build_uds_app(state.clone());
        let uds_listener = match bind_uds(&socket_path).await {
            Ok(l) => {
                println!("[OK] Unix socket 监听: {}", socket_path.display());
                Some(l)
            }
            Err(e) => {
                eprintln!("[WARN] Unix socket 绑定失败 (不影响 TCP): {}", e);
                None
            }
        };

        let tcp_handle = axum::serve(
            tcp_listener,
            tcp_app.into_make_service_with_connect_info::<std::net::SocketAddr>(),
        );

        if let Some(uds) = uds_listener {
            let uds_handle = tokio::spawn(async move {
                serve_uds(uds, uds_app).await;
            });
            tokio::select! {
                r = tcp_handle => {
                    if let Err(e) = r {
                        eprintln!("[ERROR] TCP 服务错误: {}", e);
                    }
                }
                _ = uds_handle => {
                    eprintln!("[WARN] UDS 服务退出");
                }
            }
        } else {
            if let Err(e) = tcp_handle.await {
                eprintln!("[ERROR] TCP 服务错误: {}", e);
            }
        }

        Ok::<(), anyhow::Error>(())
    })?;
    Ok(())
}

// ============================================================
// 路由构建
// ============================================================

fn build_tcp_app(state: Arc<WebuiState>) -> Router {
    use tower_http::cors::CorsLayer;

    let state_for_mw = state.clone();
    Router::new()
        .route("/", get(index_html))
        .route("/index.html", get(index_html))
        // 状态与统计
        .route("/api/status", get(api_status))
        .route("/api/state", get(api_state))
        .route("/api/history", get(api_history))
        // 规则管理 (CRUD)
        .route("/api/rules", get(api_rules_list).post(api_rules_create))
        .route("/api/rules/stats", get(api_rules_stats))
        .route("/api/rules/export", get(api_rules_export))
        .route("/api/rules/import", post(api_rules_import))
        .route("/api/rules/:id", get(api_rules_get).put(api_rules_update).delete(api_rules_delete))
        .route("/api/rules/:id/toggle", post(api_rule_toggle))
        .route("/api/allowed-roots", get(api_allowed_roots))
        // 清理执行
        .route("/api/clean", post(api_clean))
        // 冲突检测 + cron 预览
        .route("/api/conflicts", get(api_conflicts))
        .route("/api/cron/preview", get(api_cron_preview))
        // 配置 (raw + structured)
        .route("/api/config", get(api_config))
        .route("/api/config/structured", get(api_config_structured))
        .route("/api/config/settings", post(api_config_save_settings))
        .route("/api/config/blacklist", post(api_config_save_blacklist))
        .route("/api/config/whitelist", post(api_config_save_whitelist))
        // 白名单管理 (CRUD)
        .route("/api/whitelist", get(api_whitelist_list))
        .route("/api/whitelist/protect", post(api_whitelist_add_protect).delete(api_whitelist_del_protect_by_query))
        .route("/api/whitelist/protect/:id", delete(api_whitelist_del_protect))
        .route("/api/whitelist/package", post(api_whitelist_add_package).delete(api_whitelist_del_package_by_query))
        .route("/api/whitelist/package/:package", delete(api_whitelist_del_package))
        .route("/api/whitelist/ext", post(api_whitelist_add_ext).delete(api_whitelist_del_ext))
        .route("/api/whitelist/mtime", post(api_whitelist_add_mtime).delete(api_whitelist_del_mtime))
        // daemon 控制
        .route("/api/daemon/status", get(api_daemon_status))
        .route("/api/daemon/reload", post(api_daemon_reload))
        .route("/api/daemon/stop", post(api_daemon_stop))
        .route("/api/daemon/start", post(api_daemon_start))
        // 规则包
        .route("/api/packs", get(api_packs_list))
        .route("/api/packs/:name/install", post(api_packs_install))
        // token
        .route("/api/token/regenerate", post(api_token_regenerate))
        // 日志 (手动刷新 /api/logs/recent, 不做 SSE 实时流)
        .route("/api/logs/recent", get(api_logs_recent))
        .layer(axum::middleware::from_fn_with_state(
            state_for_mw,
            token_auth_middleware,
        ))
        .with_state(state)
        .layer(
            // CORS 配置安全加固:
            // 仅当 TARN_CORS 环境变量为显式非空值 (且非 "0"/"false") 时启用 permissive 模式,
            // 避免空字符串误触发 CSRF 攻击面。permissive 模式仍依赖 token 头鉴权 (非 cookie),
            // 实际 CSRF 风险有限, 但仍收紧判断防误开。
            if std::env::var("TARN_CORS")
                .map(|v| !v.is_empty() && v != "0" && v != "false")
                .unwrap_or(false)
            {
                CorsLayer::permissive()
            } else {
                CorsLayer::new()
            },
        )
}

fn build_uds_app(state: Arc<WebuiState>) -> Router {
    Router::new()
        .route("/", get(index_html))
        .route("/index.html", get(index_html))
        .route("/api/status", get(api_status))
        .route("/api/state", get(api_state))
        .route("/api/history", get(api_history))
        .route("/api/rules", get(api_rules_list).post(api_rules_create))
        .route("/api/rules/stats", get(api_rules_stats))
        .route("/api/rules/export", get(api_rules_export))
        .route("/api/rules/import", post(api_rules_import))
        .route("/api/rules/:id", get(api_rules_get).put(api_rules_update).delete(api_rules_delete))
        .route("/api/rules/:id/toggle", post(api_rule_toggle))
        .route("/api/allowed-roots", get(api_allowed_roots))
        .route("/api/clean", post(api_clean))
        .route("/api/conflicts", get(api_conflicts))
        .route("/api/cron/preview", get(api_cron_preview))
        .route("/api/config", get(api_config))
        .route("/api/config/structured", get(api_config_structured))
        .route("/api/config/settings", post(api_config_save_settings))
        .route("/api/config/blacklist", post(api_config_save_blacklist))
        .route("/api/config/whitelist", post(api_config_save_whitelist))
        .route("/api/whitelist", get(api_whitelist_list))
        .route("/api/whitelist/protect", post(api_whitelist_add_protect).delete(api_whitelist_del_protect_by_query))
        .route("/api/whitelist/protect/:id", delete(api_whitelist_del_protect))
        .route("/api/whitelist/package", post(api_whitelist_add_package).delete(api_whitelist_del_package_by_query))
        .route("/api/whitelist/package/:package", delete(api_whitelist_del_package))
        .route("/api/whitelist/ext", post(api_whitelist_add_ext).delete(api_whitelist_del_ext))
        .route("/api/whitelist/mtime", post(api_whitelist_add_mtime).delete(api_whitelist_del_mtime))
        .route("/api/daemon/status", get(api_daemon_status))
        .route("/api/daemon/reload", post(api_daemon_reload))
        .route("/api/daemon/stop", post(api_daemon_stop))
        .route("/api/daemon/start", post(api_daemon_start))
        .route("/api/packs", get(api_packs_list))
        .route("/api/packs/:name/install", post(api_packs_install))
        .route("/api/token/regenerate", post(api_token_regenerate))
        // 日志 (手动刷新, 不做 SSE)
        .route("/api/logs/recent", get(api_logs_recent))
        .with_state(state)
}

// ============================================================
// 鉴权中间件
// ============================================================

async fn token_auth_middleware(
    axum::extract::State(state): axum::extract::State<Arc<WebuiState>>,
    req: axum::extract::Request,
    next: axum::middleware::Next,
) -> Result<Response, StatusCode> {
    let path = req.uri().path();
    if path == "/" || path == "/index.html" {
        return Ok(next.run(req).await);
    }

    let auth = req
        .headers()
        .get(AUTHORIZATION)
        .and_then(|h| h.to_str().ok())
        .and_then(|s| {
            // RFC 7235 规定 auth scheme 大小写不敏感, 接受 "Bearer "/"bearer "/"BEARER " 等写法。
            let (scheme, rest) = s.split_once(' ')?;
            if scheme.eq_ignore_ascii_case("bearer") {
                Some(rest)
            } else {
                None
            }
        })
        .unwrap_or("");

    let token_from_url = req
        .uri()
        .query()
        .and_then(|q| {
            q.split('&').find_map(|kv| {
                let mut it = kv.splitn(2, '=');
                if it.next() == Some("token") {
                    Some(it.next().unwrap_or(""))
                } else {
                    None
                }
            })
        })
        .unwrap_or("");

    let provided = if !auth.is_empty() { auth } else { token_from_url };
    let expected = state.token.read().clone();

    use subtle::ConstantTimeEq;
    if provided.as_bytes().ct_eq(expected.as_bytes()).into() {
        Ok(next.run(req).await)
    } else {
        Err(StatusCode::UNAUTHORIZED)
    }
}

// ============================================================
// 首页
// ============================================================

async fn index_html() -> impl IntoResponse {
    (
        [(axum::http::header::CONTENT_TYPE, "text/html; charset=utf-8")],
        INDEX_HTML,
    )
}

// ============================================================
// 状态与统计
// ============================================================

#[derive(Serialize)]
struct StatusResponse {
    version: &'static str,
    schema_version: u32,
    rules_count: usize,
    protects_count: usize,
    totals: tarn_core::state::Totals,
    last_run: Option<tarn_core::state::LastRun>,
    daemon: DaemonStatusInfo,
    config_dir: String,
    token_preview: String,
    /// 低功耗调优诊断 (nice/affinity 是否真正生效)
    /// (不做 ionice IDLE — 绝大多数 Android 设备上是空操作)
    tuning: TuningStatus,
    /// 统计轮转配置 (用户可配的阈值)
    rotation_config: RotationConfig,
    /// 统计轮转归档历史 (最近 N 份)
    rotation_history: Vec<tarn_core::state::RotationEntry>,
}

/// 统计轮转配置 (从 settings.state 抽取, 给前端展示)
#[derive(Serialize, Clone)]
struct RotationConfig {
    rotate_after_files: u64,
    rotate_after_bytes: u64,
    keep_rotation_history: u32,
}

/// 低功耗调优诊断信息
///
/// 让用户在 WebUI 看到 nice/affinity 的真实生效情况, 而不是 "调用了就当生效"。
/// - nice: 读 /proc/<pid>/stat 的实际 nice 值 (铁证)
/// - affinity: 读 /proc/<pid>/status 的 Cpus_allowed_list (铁证)
///
/// (不做 ionice IDLE — CFQ 调度器内核 5.x 已删, Android 的
/// mq-deadline/none/kyber 调度器忽略 ioprio, 是空操作, 保留无意义。)
#[derive(Serialize, Clone)]
struct TuningStatus {
    /// 配置中 low_power 是否开启
    low_power_enabled: bool,
    /// 配置中的 cpu_affinity (空=自动探测)
    cpu_affinity_config: Vec<usize>,
    /// daemon 进程的实际 nice 值 (从 /proc 读取, None = daemon 未运行或读取失败)
    daemon_nice: Option<i32>,
    /// daemon 进程的 CPU 亲和性 (从 /proc 读取, 如 "0-3")
    daemon_cpus_allowed: Option<String>,
    /// nice 值是否符合预期 (19 = 最低优先级)
    nice_ok: bool,
}

#[derive(Serialize, Clone)]
struct DaemonStatusInfo {
    running: bool,
    pid: Option<i32>,
    cmdline: Option<String>,
    pidfile: String,
}

async fn api_status(
    State(state): State<Arc<WebuiState>>,
) -> Json<StatusResponse> {
    let cfg = state.config.read();
    let snap = state.state.snapshot();
    let pidfile = state.config_dir.join("run/tarn.pid");
    let daemon_info = read_daemon_status(&pidfile);
    let token_preview = {
        let t = state.token.read().clone();
        if t.len() > 8 {
            format!("{}…{}", &t[..4], &t[t.len()-4..])
        } else {
            t
        }
    };

    // 低功耗调优诊断 (仅 nice + 绑核, 不做 ionice)
    let tuning = {
        // 读 daemon 实际 nice + cpus_allowed (铁证)
        let (daemon_nice, daemon_cpus) = if let Some(pid) = daemon_info.pid {
            if daemon_info.running {
                (
                    sysutil::read_proc_nice(pid),
                    sysutil::read_proc_cpus_allowed_list(pid),
                )
            } else {
                (None, None)
            }
        } else {
            (None, None)
        };
        let nice_ok = daemon_nice
            .map(|n| n >= 19)
            .unwrap_or(false);
        TuningStatus {
            low_power_enabled: cfg.settings.engine.low_power,
            cpu_affinity_config: cfg.settings.engine.cpu_affinity.clone(),
            daemon_nice,
            daemon_cpus_allowed: daemon_cpus,
            nice_ok,
        }
    };

    Json(StatusResponse {
        version: VERSION,
        schema_version: CONFIG_SCHEMA_VERSION,
        rules_count: cfg.blacklist.rule.len(),
        protects_count: cfg.whitelist.protect.len()
            + cfg.whitelist.protect_package.len()
            + cfg.whitelist.protect_ext.len()
            + cfg.whitelist.protect_mtime.len(),
        totals: snap.totals,
        last_run: snap.last_run,
        daemon: daemon_info,
        config_dir: state.config_dir.display().to_string(),
        token_preview,
        tuning,
        rotation_config: RotationConfig {
            rotate_after_files: cfg.settings.state.rotate_after_files,
            rotate_after_bytes: cfg.settings.state.rotate_after_bytes,
            keep_rotation_history: cfg.settings.state.keep_rotation_history,
        },
        rotation_history: snap.rotation_history.clone(),
    })
}

async fn api_state(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let s = state.state.snapshot();
    Json(serde_json::json!(s))
}

/// /api/history - 返回最近运行历史 (用于概览页时间线 + 趋势图)
///
/// 返回最近 N 条运行记录 (默认 50, 上限 50), 按 ts_start 降序。
/// 同时返回按 trigger 分组的统计 + 按 rule_id 累计释放空间 Top 5。
async fn api_history(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let s = state.state.snapshot();
    let mut entries: Vec<_> = s.history.iter().rev().cloned().collect();

    // 按 trigger 聚合统计
    let mut by_trigger: std::collections::BTreeMap<String, u64> = std::collections::BTreeMap::new();
    let mut total_freed_last_50: u64 = 0;
    let mut total_files_last_50: u64 = 0;
    let mut total_dirs_last_50: u64 = 0;
    let mut total_duration_ms: u64 = 0;
    for e in &entries {
        *by_trigger.entry(e.trigger.clone()).or_default() += 1;
        if !e.dry_run {
            total_freed_last_50 += e.freed_bytes;
            total_files_last_50 += e.files_deleted;
            total_dirs_last_50 += e.dirs_removed;
        }
        total_duration_ms += e.duration_ms;
    }

    // 累计规则释放 Top 5 (从历史中聚合)
    let mut rule_freed: std::collections::HashMap<String, u64> = std::collections::HashMap::new();
    for e in &entries {
        if e.dry_run { continue; }
        for (rid, freed) in &e.top_rules {
            *rule_freed.entry(rid.clone()).or_default() += freed;
        }
    }
    let mut top_rules: Vec<(String, u64)> = rule_freed.into_iter().collect();
    top_rules.sort_by(|a, b| b.1.cmp(&a.1));
    top_rules.truncate(5);

    // 最近 7 天按天聚合 (用于趋势条形图)
    // ts_start 格式: 2026-06-17T19:55:34+08:00, 取前 10 字符为日期
    let mut by_day: std::collections::BTreeMap<String, (u64, u64, u64)> = std::collections::BTreeMap::new();
    for e in &entries {
        if e.dry_run { continue; }
        let day = e.ts_start.get(..10).unwrap_or("").to_string();
        if day.is_empty() { continue; }
        let entry = by_day.entry(day).or_insert((0, 0, 0));
        entry.0 += 1;          // 运行次数
        entry.1 += e.freed_bytes;  // 释放字节
        entry.2 += e.files_deleted; // 删除文件数
    }
    let by_day: Vec<serde_json::Value> = by_day.into_iter()
        .map(|(day, (runs, freed, files))| serde_json::json!({
            "day": day, "runs": runs, "freed_bytes": freed, "files_deleted": files
        }))
        .collect();

    // 截断历史返回 (避免大 payload)
    entries.truncate(50);

    Json(serde_json::json!({
        "entries": entries,
        "by_trigger": by_trigger.into_iter().collect::<Vec<_>>(),
        "top_rules": top_rules.into_iter().map(|(id, freed)| {
            serde_json::json!({"rule_id": id, "freed_bytes": freed})
        }).collect::<Vec<_>>(),
        "by_day": by_day,
        "summary": {
            "total_entries": s.history.len(),
            "total_freed_last_50": total_freed_last_50,
            "total_files_last_50": total_files_last_50,
            "total_dirs_last_50": total_dirs_last_50,
            "total_duration_ms": total_duration_ms,
        }
    }))
}

// ============================================================
// 规则 CRUD
// ============================================================

async fn api_rules_list(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let cfg = state.config.read();
    let snapshot = state.state.snapshot();
    let rules: Vec<_> = cfg
        .blacklist
        .rule
        .iter()
        .map(|r| {
            let mut j = rule_to_json(r);
            // 内联统计 (如有)
            if let Some(rs) = snapshot.rules.get(&r.id) {
                j["stats"] = rule_stats_to_json(rs);
            }
            j
        })
        .collect();
    Json(serde_json::json!({ "rules": rules }))
}

/// 每规则统计聚合端点: GET /api/rules/stats
async fn api_rules_stats(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let cfg = state.config.read();
    let snapshot = state.state.snapshot();
    let stats: Vec<_> = cfg
        .blacklist
        .rule
        .iter()
        .map(|r| {
            let rs = snapshot.rules.get(&r.id);
            serde_json::json!({
                "id": r.id,
                "name": r.name,
                "enabled": r.enabled,
                "stats": rs.map(rule_stats_to_json).unwrap_or(serde_json::json!({
                    "run_count": 0,
                    "total_freed_bytes": 0,
                    "total_files_deleted": 0,
                    "total_files_scanned": 0,
                    "total_files_blocked": 0,
                    "success_count": 0,
                    "fail_count": 0,
                    "last_status": "never",
                    "last_run": "",
                    "last_run_id": "",
                    "last_freed_bytes": 0,
                })),
            })
        })
        .collect();
    // 全局汇总
    let total_runs: u64 = stats.iter().filter_map(|s| s["stats"]["run_count"].as_u64()).sum();
    let total_freed: u64 = stats.iter().filter_map(|s| s["stats"]["total_freed_bytes"].as_u64()).sum();
    Json(serde_json::json!({
        "rules": stats,
        "summary": {
            "rules_count": stats.len(),
            "total_runs": total_runs,
            "total_freed_bytes": total_freed,
        }
    }))
}

fn rule_stats_to_json(rs: &tarn_core::state::RuleState) -> serde_json::Value {
    let success_rate = if rs.run_count > 0 {
        (rs.success_count as f64 * 100.0 / rs.run_count as f64) as u64
    } else {
        0
    };
    serde_json::json!({
        "run_count": rs.run_count,
        "total_freed_bytes": rs.total_freed_bytes,
        "total_files_deleted": rs.total_files_deleted,
        "total_files_scanned": rs.total_files_scanned,
        "total_files_blocked": rs.total_files_blocked,
        "total_dirs_removed": rs.total_dirs_removed,
        "success_count": rs.success_count,
        "fail_count": rs.fail_count,
        "success_rate": success_rate,
        "last_status": rs.last_status,
        "last_run": rs.last_run,
        "last_run_id": rs.last_run_id,
        "last_freed_bytes": rs.last_freed_bytes,
    })
}

async fn api_rules_get(
    State(state): State<Arc<WebuiState>>,
    Path(rule_id): Path<String>,
) -> Response {
    let cfg = state.config.read();
    match cfg.blacklist.rule.iter().find(|r| r.id == rule_id) {
        Some(r) => Json(rule_to_json(r)).into_response(),
        None => Json(serde_json::json!({ "ok": false, "error": format!("规则不存在: {}", rule_id) })).into_response(),
    }
}

#[derive(Deserialize)]
struct RulePayload {
    rule: Rule,
}

async fn api_rules_create(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<RulePayload>,
) -> Json<serde_json::Value> {
    let rule = payload.rule;
    if rule.id.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "规则 id 不能为空" }));
    }
    // 路径白名单校验: 所有 target.path 必须落在 ALLOWED_ROOTS 下
    for t in &rule.targets {
        if let Err(reason) = is_target_allowed(&t.path) {
            return Json(serde_json::json!({
                "ok": false,
                "error": format!("target 路径不被允许: {}\n{}", t.path, reason),
            }));
        }
    }
    let path = state.config_dir.join("config/blacklist.toml");
    match modify_blacklist(&path, |bl| {
        if bl.rule.iter().any(|r| r.id == rule.id) {
            return Err(format!("规则 id 已存在: {}", rule.id));
        }
        bl.rule.push(rule.clone());
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "rule_id": rule.id }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_rules_update(
    State(state): State<Arc<WebuiState>>,
    Path(rule_id): Path<String>,
    Json(payload): Json<RulePayload>,
) -> Json<serde_json::Value> {
    let mut new_rule = payload.rule;
    new_rule.id = rule_id.clone();
    // 路径白名单校验: 所有 target.path 必须落在 ALLOWED_ROOTS 下
    for t in &new_rule.targets {
        if let Err(reason) = is_target_allowed(&t.path) {
            return Json(serde_json::json!({
                "ok": false,
                "error": format!("target 路径不被允许: {}\n{}", t.path, reason),
            }));
        }
    }
    let path = state.config_dir.join("config/blacklist.toml");
    match modify_blacklist(&path, |bl| {
        let idx = bl.rule.iter().position(|r| r.id == rule_id)
            .ok_or_else(|| format!("规则不存在: {}", rule_id))?;
        bl.rule[idx] = new_rule.clone();
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "rule_id": rule_id }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_rules_delete(
    State(state): State<Arc<WebuiState>>,
    Path(rule_id): Path<String>,
) -> Json<serde_json::Value> {
    let path = state.config_dir.join("config/blacklist.toml");
    match modify_blacklist(&path, |bl| {
        let before = bl.rule.len();
        bl.rule.retain(|r| r.id != rule_id);
        if bl.rule.len() == before {
            return Err(format!("规则不存在: {}", rule_id));
        }
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "rule_id": rule_id }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_rule_toggle(
    State(state): State<Arc<WebuiState>>,
    Path(rule_id): Path<String>,
) -> Json<serde_json::Value> {
    let path = state.config_dir.join("config/blacklist.toml");
    let mut new_enabled = false;
    match modify_blacklist(&path, |bl| {
        let r = bl.rule.iter_mut().find(|r| r.id == rule_id)
            .ok_or_else(|| format!("规则不存在: {}", rule_id))?;
        r.enabled = !r.enabled;
        new_enabled = r.enabled;
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "enabled": new_enabled, "rule_id": rule_id }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

// ============================================================
// 规则导入导出 (Task 21)
// ============================================================

/// GET /api/rules/export?format=toml|json
/// 导出全部规则为 TOML (兼容 blacklist.toml 格式) 或 JSON
async fn api_rules_export(
    State(state): State<Arc<WebuiState>>,
    Query(params): Query<ExportParams>,
) -> Response {
    let cfg = state.config.read();
    let format = params.format.as_deref().unwrap_or("toml");
    if format == "json" {
        let rules: Vec<_> = cfg.blacklist.rule.iter().map(rule_to_json).collect();
        let body = serde_json::json!({
            "version": CONFIG_SCHEMA_VERSION,
            "exported_at": tarn_core::timeutil::now_cst_rfc3339(),
            "rules": rules,
        });
        return (
            StatusCode::OK,
            [
                (axum::http::header::CONTENT_TYPE, "application/json; charset=utf-8".to_string()),
                (axum::http::header::CONTENT_DISPOSITION, "attachment; filename=\"tarn-rules-export.json\"".to_string()),
            ],
            Json(body).into_response().into_body(),
        ).into_response();
    }
    // TOML: 直接序列化 Blacklist (与 blacklist.toml 完全兼容)
    let toml_str = match toml::to_string_pretty(&cfg.blacklist) {
        Ok(s) => s,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("序列化失败: {}", e) })).into_response(),
    };
    let header = format!(
        "# Tarn 规则导出\n# 导出时间: {}\n# 规则数: {}\n# 格式: blacklist.toml 兼容 (可直接粘贴覆盖)\n\n",
        tarn_core::timeutil::now_cst_rfc3339(),
        cfg.blacklist.rule.len(),
    );
    let body = header + &toml_str;
    (
        StatusCode::OK,
        [
            (axum::http::header::CONTENT_TYPE, "text/plain; charset=utf-8".to_string()),
            (axum::http::header::CONTENT_DISPOSITION, "attachment; filename=\"tarn-rules-export.toml\"".to_string()),
        ],
        body,
    ).into_response()
}

#[derive(Deserialize)]
struct ExportParams {
    format: Option<String>,
}

/// GET /api/allowed-roots
/// 返回允许清理的根目录列表 (路径白名单), 供前端展示给用户。
async fn api_allowed_roots() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "roots": ALLOWED_ROOTS,
    }))
}

#[derive(Deserialize)]
struct ImportPayload {
    /// TOML 或 JSON 字符串
    content: String,
    /// "toml" | "json"
    format: String,
    /// "merge" (默认, 跳过已存在的 id) | "replace" (删掉所有再导入)
    mode: Option<String>,
}

/// POST /api/rules/import
/// 批量导入规则 (TOML 或 JSON), 返回导入/跳过/失败计数
async fn api_rules_import(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<ImportPayload>,
) -> Json<serde_json::Value> {
    let mode = payload.mode.as_deref().unwrap_or("merge");
    // 解析输入
    let imported_rules: Vec<Rule> = if payload.format == "json" {
        // JSON: 期望 { rules: [Rule, ...] } 或 [Rule, ...]
        let parsed: serde_json::Value = match serde_json::from_str(&payload.content) {
            Ok(v) => v,
            Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("JSON 解析失败: {}", e) })),
        };
        let arr = parsed.get("rules").and_then(|v| v.as_array())
            .or_else(|| parsed.as_array())
            .cloned();
        match arr {
            Some(a) => a.iter().filter_map(|v| serde_json::from_value::<Rule>(v.clone()).ok()).collect(),
            None => return Json(serde_json::json!({ "ok": false, "error": "JSON 缺少 rules 数组" })),
        }
    } else {
        // TOML: 期望 Blacklist 格式
        let bl: Blacklist = match toml::from_str(&payload.content) {
            Ok(b) => b,
            Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("TOML 解析失败: {}", e) })),
        };
        bl.rule
    };

    // 路径白名单校验: 先检查所有规则的 target.path, 任何一个不合格都不导入 (原子)
    for (idx, r) in imported_rules.iter().enumerate() {
        for t in &r.targets {
            if let Err(reason) = is_target_allowed(&t.path) {
                return Json(serde_json::json!({
                    "ok": false,
                    "error": format!(
                        "第 {} 条规则 (id={}) 的 target 路径不被允许: {}\n{}",
                        idx + 1, r.id, t.path, reason
                    ),
                    "imported": 0,
                    "skipped": 0,
                    "failed": 0,
                }));
            }
        }
    }

    let path = state.config_dir.join("config/blacklist.toml");
    let mut imported = 0usize;
    let mut skipped = 0usize;
    let mut total_before = 0usize;
    let mut total_after = 0usize;
    let result = modify_blacklist(&path, |bl| {
        total_before = bl.rule.len();
        // replace 模式下若导入规则为空, 拒绝清空 (防误操作)
        if mode == "replace" {
            if imported_rules.is_empty() {
                return Err("replace 模式下导入规则列表为空, 拒绝清空现有规则 (防误操作)".to_string());
            }
            bl.rule.clear();
        }
        for r in &imported_rules {
            if mode != "replace" && bl.rule.iter().any(|x| x.id == r.id) {
                skipped += 1;
                continue;
            }
            bl.rule.push(r.clone());
            imported += 1;
        }
        total_after = bl.rule.len(); // 真实最终规则数
        Ok(())
    });
    match result {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            let errors: Vec<String> = Vec::new();
            Json(serde_json::json!({
                "ok": true,
                "imported": imported,
                "skipped": skipped,
                "failed": 0,
                "errors": errors,
                "total_before": total_before,
                "total_after": total_after,
            }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

// ============================================================
// 白名单冲突检测 (Task 21)
// ============================================================

#[derive(Deserialize)]
struct ConflictParams {
    /// 可选, 只检测指定规则 ID (不传 = 全部规则)
    rule_id: Option<String>,
}

/// GET /api/conflicts?rule_id=xxx
/// 检测 blacklist 规则 target 与 whitelist protect 的重叠
/// 返回每个冲突: { rule_id, target_path, protect_id, protect_path, match_type }
async fn api_conflicts(
    State(state): State<Arc<WebuiState>>,
    Query(params): Query<ConflictParams>,
) -> Json<serde_json::Value> {
    let cfg = state.config.read();
    let conflicts = detect_conflicts(&cfg.blacklist, &cfg.whitelist, params.rule_id.as_deref());
    let by_rule: std::collections::HashMap<String, usize> = conflicts.iter()
        .fold(std::collections::HashMap::new(), |mut acc, c| {
            *acc.entry(c["rule_id"].as_str().unwrap_or("").to_string()).or_insert(0) += 1;
            acc
        });
    Json(serde_json::json!({
        "conflicts": conflicts,
        "summary": {
            "total": conflicts.len(),
            "rules_affected": by_rule.len(),
            "by_rule": by_rule,
        }
    }))
}

/// 冲突检测核心: 判断 target.path 是否被 protect.path 覆盖 (prefix 或通配符匹配)
fn detect_conflicts(bl: &Blacklist, wl: &Whitelist, rule_filter: Option<&str>) -> Vec<serde_json::Value> {
    let mut out = Vec::new();
    // 编译 whitelist 通配符模式
    let glob_patterns: Vec<(String, globset::Glob)> = wl.protect.iter()
        .filter(|p| p.is_glob())
        .filter_map(|p| globset::Glob::new(&p.path).ok().map(|g| (p.id.clone(), g)))
        .collect();
    let glob_set: globset::GlobSet = {
        let mut b = globset::GlobSetBuilder::new();
        for (_, g) in &glob_patterns { b.add(g.clone()); }
        b.build().unwrap_or_else(|_| globset::GlobSet::empty())
    };

    for rule in &bl.rule {
        if let Some(rid) = rule_filter { if rid != rule.id { continue; } }
        for target in &rule.targets {
            let tp = &target.path;
            // 1. prefix 匹配
            for pp in &wl.protect {
                if pp.is_glob() { continue; }
                if path_overlaps(tp, &pp.path) {
                    out.push(serde_json::json!({
                        "rule_id": rule.id,
                        "rule_name": rule.name,
                        "target_path": tp,
                        "protect_id": pp.id,
                        "protect_path": pp.path,
                        "match_type": "prefix",
                    }));
                }
            }
            // 2. 通配符匹配
            if glob_set.is_match(tp) {
                // 找出具体匹配哪个通配符
                for (pid, g) in &glob_patterns {
                    if g.compile_matcher().is_match(tp) {
                        // 避免重复 (如果已经因 prefix 报过同一个 protect_id 则跳过)
                        let already = out.iter().any(|c| {
                            c["rule_id"].as_str() == Some(rule.id.as_str())
                                && c["target_path"].as_str() == Some(tp.as_str())
                                && c["protect_id"].as_str() == Some(pid.as_str())
                        });
                        if !already {
                            out.push(serde_json::json!({
                                "rule_id": rule.id,
                                "rule_name": rule.name,
                                "target_path": tp,
                                "protect_id": pid,
                                "protect_path": g.glob(),
                                "match_type": "glob",
                            }));
                        }
                    }
                }
            }
        }
    }
    out
}

/// 判断两个路径是否有重叠 (互为前缀)
fn path_overlaps(a: &str, b: &str) -> bool {
    if a == b { return true; }
    let norm = |s: &str| -> String {
        let t = s.trim_end_matches('/');
        if t.is_empty() { "/".to_string() } else { t.to_string() }
    };
    let a = norm(a);
    let b = norm(b);
    a.starts_with(&format!("{}/", b)) || b.starts_with(&format!("{}/", a))
}

// ============================================================
// cron 调度预览 (Task 21)
// ============================================================

#[derive(Deserialize)]
struct CronPreviewParams {
    /// cron 表达式
    expr: String,
    /// 计算多少次下次触发 (默认 5)
    count: Option<usize>,
}

/// GET /api/cron/preview?expr=0 3 * * *&count=5
/// 计算下 N 次触发时间 (CST 时区), 用于规则详情抽屉调度预览
async fn api_cron_preview(
    Query(params): Query<CronPreviewParams>,
) -> Json<serde_json::Value> {
    let count = params.count.unwrap_or(5).min(20);
    match tarn_core::scheduler::CronSchedule::parse(&params.expr) {
        Ok(sched) => {
            let mut next_times: Vec<String> = Vec::new();
            let mut from = tarn_core::timeutil::now_cst();
            for _ in 0..count {
                match sched.next_after(from) {
                    Some(t) => {
                        next_times.push(t.format("%Y-%m-%d %H:%M:%S %z").to_string());
                        from = t;
                    }
                    None => break,
                }
            }
            // 人类可读摘要: 距下次多久
            let next_duration_human = if !next_times.is_empty() {
                let next = sched.next_after(tarn_core::timeutil::now_cst());
                next.map(|t| {
                    let diff = t.signed_duration_since(tarn_core::timeutil::now_cst());
                    let secs = diff.num_seconds().max(0);
                    if secs < 60 { format!("{} 秒后", secs) }
                    else if secs < 3600 { format!("{} 分钟后", secs / 60) }
                    else if secs < 86400 { format!("{} 小时后", secs / 3600) }
                    else { format!("{} 天后", secs / 86400) }
                })
            } else { None };
            Json(serde_json::json!({
                "ok": true,
                "expr": params.expr,
                "next_times": next_times,
                "next_in": next_duration_human,
            }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

// ============================================================
// 清理执行
// ============================================================

async fn api_clean(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    // 唯一安全栅栏 = dry_run。force 字段不再控制 risk 过滤, 仅作分类标签。
    let dry_run = payload.get("dry_run").and_then(|v| v.as_bool()).unwrap_or(false);
    let trigger_str = payload.get("trigger").and_then(|v| v.as_str()).unwrap_or("manual");
    let rule_filter: Option<Vec<String>> = payload
        .get("rules")
        .and_then(|v| v.as_array())
        .map(|arr| arr.iter().filter_map(|x| x.as_str().map(|s| s.to_string())).collect());

    let trigger = match trigger_str {
        "boot" => Trigger::Boot,
        "cron" => Trigger::Cron,
        "event" => Trigger::Event,
        _ => Trigger::Manual,
    };

    let (settings, blacklist, protect) = {
        let cfg = state.config.read();
        (cfg.settings.clone(), cfg.blacklist.clone(), cfg.protect.clone())
    };
    let mut executor = Executor::new(settings, blacklist, protect);
    if let Some(log) = &state.logger {
        executor = executor.with_logger(log.clone());
    }
    let opts = RunOptions {
        dry_run,
        trigger,
        rule_filter,
        verbose: true,
        ..Default::default()
    };
    // executor.run 是同步阻塞 (Rayon + 文件 IO), 用 spawn_blocking
    // 避免 tokio worker 线程被占满 (默认仅 2 个 worker)
    //
    // 跨进程清理互斥锁: 防止与 daemon cron 并发清理同一路径。
    // 锁在 spawn_blocking 内获取并持有到清理 + record_run 结束 (RAII)。
    // 失败返回 HTTP 409 Conflict, 前端提示"另一清理正在进行"。
    let config_dir_for_lock = state.config_dir.clone();
    let logger_for_lock = state.logger.clone();
    let result = tokio::task::spawn_blocking(move || {
        let lock_path = config_dir_for_lock.join("run/cleaning.lock");
        let _cleaning_lock = match sysutil::try_lock_cleaning(&lock_path) {
            Ok(f) => f,
            Err(e) => {
                if let Some(ref logger) = logger_for_lock {
                    logger.warn("webui", &format!("api_clean 跳过 (另一清理正在进行): {}", e));
                }
                let mut r = tarn_core::executor::RunResult::default();
                r.exit_code = 2; // 2 = 清理冲突 (另一清理正在进行)
                r.ts_end = tarn_core::timeutil::now_cst_rfc3339();
                r.rules.push(tarn_core::executor::RuleResult {
                    rule_id: "__cleaning_lock__".to_string(),
                    rule_name: "清理互斥锁".to_string(),
                    status: tarn_core::executor::RuleStatus::Skipped,
                    error: Some(format!("另一清理正在进行: {}", e)),
                    ..Default::default()
                });
                return r;
            }
        };
        executor.run(&opts)
    })
    .await
    .unwrap_or_else(|e| {
        // spawn_blocking panic 时返回一个失败的 RunResult
        let mut r = tarn_core::executor::RunResult::default();
        r.exit_code = 1;
        r.ts_end = tarn_core::timeutil::now_cst_rfc3339();
        r.rules.push(tarn_core::executor::RuleResult {
            rule_id: "spawn_blocking".to_string(),
            rule_name: "tokio".to_string(),
            status: tarn_core::executor::RuleStatus::Failed,
            error: Some(format!("{:?}", e)),
            ..Default::default()
        });
        r
    });

    // 清理冲突 (exit_code=2): 不记录统计, 直接返回冲突提示
    if result.exit_code == 2 {
        return Json(serde_json::json!({
            "ok": false,
            "error": "另一清理正在进行, 请稍后重试",
            "conflict": true,
        }));
    }

    // 带轮转检查的 record_run (与 daemon cron 路径一致)
    let (rotate_files, rotate_bytes, keep_rot) = {
        let cfg = state.config.read();
        (
            cfg.settings.state.rotate_after_files,
            cfg.settings.state.rotate_after_bytes,
            cfg.settings.state.keep_rotation_history,
        )
    };
    let rotation = state.state.record_run_with_rotation(
        &result, rotate_files, rotate_bytes, keep_rot,
    );
    if let Some(ref r) = rotation {
        if let Some(ref logger) = state.logger {
            logger.info(
                "webui",
                &format!(
                    "=== 统计轮转触发 (reason={}) === 本轮: 删 {} 文件 / 释放 {} / 跑 {} 次. totals 已清零",
                    r.reason,
                    r.total_files_deleted,
                    tarn_core::module_prop::format_bytes(r.total_freed_bytes),
                    r.total_runs,
                ),
            );
        }
    }

    // WebUI 触发的清理也更新 module.prop description (累计数据变了)
    // 通过 pidfile 检测 daemon 实际状态 (不能用 current_pid(), 那是 webui 进程 PID,
    // 独立 tarn webui 时会错误显示"运行中"并写入 webui PID):
    // daemon 运行 → running=true, pid=daemon pid; 未运行 → running=false, pid=None。
    let snap = state.state.snapshot();
    let freed_bytes = snap.totals.total_freed_bytes;
    let files_deleted = snap.totals.total_files_deleted;
    let pidfile = state.config_dir.join("run/tarn.pid");
    let daemon_info = read_daemon_status(&pidfile);
    let (running, pid) = if daemon_info.running {
        (true, daemon_info.pid.map(|p| p as u32))
    } else {
        (false, None)
    };
    let _ = tarn_core::module_prop::update_from_state(running, pid, files_deleted, freed_bytes);
    if let Some(ref logger) = state.logger {
        logger.info("webui", &format!("api_clean 完成, module.prop 已更新 (累计已清理 {} / 删 {} 文件)", tarn_core::module_prop::format_bytes(freed_bytes), files_deleted));
    }

    Json(serde_json::json!({
        "run_id": result.run_id,
        "trigger": result.trigger,
        "dry_run": result.dry_run,
        "ts_start": result.ts_start,
        "ts_end": result.ts_end,
        "freed_bytes": result.freed_bytes,
        "files_deleted": result.files_deleted,
        "files_blocked": result.files_blocked,
        "files_scanned": result.files_scanned,
        "dirs_removed": result.dirs_removed,
        "duration_ms": result.duration_ms,
        "rules_planned": result.rules_planned,
        "rules_executed": result.rules_executed,
        "rules_failed": result.rules_failed,
        "rules": result.rules.iter().map(|r| serde_json::json!({
            "id": r.rule_id,
            "name": r.rule_name,
            "status": r.status.as_str(),
            "freed_bytes": r.freed_bytes,
            "files_deleted": r.files_deleted,
            "files_blocked": r.files_blocked,
            "files_skipped": r.files_skipped,
            "files_scanned": r.files_scanned,
            "dirs_removed": r.dirs_removed,
            "dirs_skipped": r.dirs_skipped,
            "duration_ms": r.duration_ms,
            "error": r.error,
        })).collect::<Vec<_>>(),
        "audit": result.audit_trail.iter().map(|a| serde_json::json!({
            "action": a.action,
            "path": a.path,
            "size": a.size,
            "rule_id": a.rule_id,
            "reason": a.reason,
            "ts": a.ts,
        })).collect::<Vec<_>>(),
    }))
}

// ============================================================
// 配置 (raw + structured + save)
// ============================================================

async fn api_config(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let read_file = |name: &str| -> String {
        std::fs::read_to_string(state.config_dir.join("config").join(name)).unwrap_or_default()
    };
    Json(serde_json::json!({
        "settings": read_file("settings.toml"),
        "blacklist": read_file("blacklist.toml"),
        "whitelist": read_file("whitelist.toml"),
    }))
}

async fn api_config_structured(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let cfg = state.config.read();
    let settings_json = serde_json::to_value(&cfg.settings).unwrap_or(serde_json::Value::Null);
    let rules: Vec<_> = cfg.blacklist.rule.iter().map(rule_to_json).collect();
    let protects: Vec<_> = cfg.whitelist.protect.iter().map(|p| serde_json::json!({
        "id": p.id, "path": p.path, "is_glob": p.is_glob(),
    })).collect();
    let packages: Vec<_> = cfg.whitelist.protect_package.iter().map(|p| serde_json::json!({
        "package": p.package, "only": p.only,
    })).collect();
    let exts: Vec<_> = cfg.whitelist.protect_ext.iter().map(|p| serde_json::json!({
        "extensions": p.extensions, "scope": p.scope,
    })).collect();
    let mtimes: Vec<_> = cfg.whitelist.protect_mtime.iter().map(|p| serde_json::json!({
        "within_days": p.within_days, "scope": p.scope,
    })).collect();
    Json(serde_json::json!({
        "settings": settings_json,
        "rules": rules,
        "whitelist": {
            "protect": protects,
            "protect_package": packages,
            "protect_ext": exts,
            "protect_mtime": mtimes,
        }
    }))
}

#[derive(Deserialize)]
struct ConfigTextPayload {
    /// TOML 字符串
    content: String,
}

async fn api_config_save_settings(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<ConfigTextPayload>,
) -> Json<serde_json::Value> {
    // 先解析校验, 失败拒绝保存
    let _settings: Settings = match toml::from_str(&payload.content) {
        Ok(s) => s,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("TOML 解析失败: {}", e) })),
    };
    let path = state.config_dir.join("config/settings.toml");
    match atomic_write(&path, &payload.content) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "path": path.display().to_string() }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("写入失败: {}", e) })),
    }
}

async fn api_config_save_blacklist(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<ConfigTextPayload>,
) -> Json<serde_json::Value> {
    let _bl: Blacklist = match toml::from_str(&payload.content) {
        Ok(b) => b,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("TOML 解析失败: {}", e) })),
    };
    let path = state.config_dir.join("config/blacklist.toml");
    match atomic_write(&path, &payload.content) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "path": path.display().to_string() }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("写入失败: {}", e) })),
    }
}

async fn api_config_save_whitelist(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<ConfigTextPayload>,
) -> Json<serde_json::Value> {
    let _wl: Whitelist = match toml::from_str(&payload.content) {
        Ok(w) => w,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("TOML 解析失败: {}", e) })),
    };
    let path = state.config_dir.join("config/whitelist.toml");
    match atomic_write(&path, &payload.content) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "path": path.display().to_string() }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("写入失败: {}", e) })),
    }
}

// ============================================================
// 白名单 CRUD
// ============================================================

async fn api_whitelist_list(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let cfg = state.config.read();
    Json(serde_json::json!({
        "protect": cfg.whitelist.protect.iter().map(|p| serde_json::json!({
            "id": p.id, "path": p.path, "is_glob": p.is_glob(),
        })).collect::<Vec<_>>(),
        "protect_package": cfg.whitelist.protect_package.iter().map(|p| serde_json::json!({
            "package": p.package, "only": p.only,
        })).collect::<Vec<_>>(),
        "protect_ext": cfg.whitelist.protect_ext.iter().map(|p| serde_json::json!({
            "extensions": p.extensions, "scope": p.scope,
        })).collect::<Vec<_>>(),
        "protect_mtime": cfg.whitelist.protect_mtime.iter().map(|p| serde_json::json!({
            "within_days": p.within_days, "scope": p.scope,
        })).collect::<Vec<_>>(),
    }))
}

async fn api_whitelist_add_protect(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<ProtectPath>,
) -> Json<serde_json::Value> {
    let p = payload;
    if p.id.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "id 不能为空" }));
    }
    let path = state.config_dir.join("config/whitelist.toml");
    match modify_whitelist(&path, |wl| {
        if wl.protect.iter().any(|x| x.id == p.id) {
            return Err(format!("id 已存在: {}", p.id));
        }
        wl.protect.push(p.clone());
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "id": p.id }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_whitelist_del_protect(
    State(state): State<Arc<WebuiState>>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let path = state.config_dir.join("config/whitelist.toml");
    match modify_whitelist(&path, |wl| {
        let before = wl.protect.len();
        wl.protect.retain(|x| x.id != id);
        if wl.protect.len() == before {
            return Err(format!("id 不存在: {}", id));
        }
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "id": id }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_whitelist_del_protect_by_query(
    State(state): State<Arc<WebuiState>>,
    Query(params): Query<std::collections::HashMap<String, String>>,
) -> Json<serde_json::Value> {
    let id = match params.get("id") {
        Some(v) => v.clone(),
        None => return Json(serde_json::json!({ "ok": false, "error": "缺少 id 参数" })),
    };
    api_whitelist_del_protect(State(state), Path(id)).await
}

async fn api_whitelist_add_package(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<ProtectPackage>,
) -> Json<serde_json::Value> {
    let p = payload;
    if p.package.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "package 不能为空" }));
    }
    let path = state.config_dir.join("config/whitelist.toml");
    match modify_whitelist(&path, |wl| {
        if wl.protect_package.iter().any(|x| x.package == p.package) {
            return Err(format!("package 已存在: {}", p.package));
        }
        wl.protect_package.push(p.clone());
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "package": p.package }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_whitelist_del_package(
    State(state): State<Arc<WebuiState>>,
    Path(package): Path<String>,
) -> Json<serde_json::Value> {
    let path = state.config_dir.join("config/whitelist.toml");
    match modify_whitelist(&path, |wl| {
        let before = wl.protect_package.len();
        wl.protect_package.retain(|x| x.package != package);
        if wl.protect_package.len() == before {
            return Err(format!("package 不存在: {}", package));
        }
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "package": package }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_whitelist_del_package_by_query(
    State(state): State<Arc<WebuiState>>,
    Query(params): Query<std::collections::HashMap<String, String>>,
) -> Json<serde_json::Value> {
    let package = match params.get("package") {
        Some(v) => v.clone(),
        None => return Json(serde_json::json!({ "ok": false, "error": "缺少 package 参数" })),
    };
    api_whitelist_del_package(State(state), Path(package)).await
}

async fn api_whitelist_add_ext(
    State(state): State<Arc<WebuiState>>,
    Json(mut payload): Json<ProtectExt>,
) -> Json<serde_json::Value> {
    // 规范化扩展名: 去 . 转小写
    payload.extensions = payload.extensions.iter()
        .map(|s| s.trim_start_matches('.').to_lowercase())
        .collect();
    if payload.extensions.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "extensions 不能为空" }));
    }
    if payload.scope.is_empty() {
        payload.scope = "global".to_string();
    }
    let path = state.config_dir.join("config/whitelist.toml");
    let ext_key = payload.extensions.join(",");
    let scope_key = payload.scope.clone();
    match modify_whitelist(&path, |wl| {
        if wl.protect_ext.iter().any(|x| x.extensions == payload.extensions && x.scope == payload.scope) {
            return Err(format!("ext 已存在: {} (scope={})", ext_key, scope_key));
        }
        wl.protect_ext.push(payload.clone());
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "extensions": ext_key, "scope": scope_key }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_whitelist_del_ext(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let extensions: Vec<String> = payload.get("extensions")
        .and_then(|v| v.as_array())
        .map(|arr| arr.iter().filter_map(|x| x.as_str().map(|s| s.trim_start_matches('.').to_lowercase())).collect())
        .unwrap_or_default();
    let scope = payload.get("scope").and_then(|v| v.as_str()).unwrap_or("global").to_string();
    if extensions.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "extensions 不能为空" }));
    }
    let path = state.config_dir.join("config/whitelist.toml");
    match modify_whitelist(&path, |wl| {
        let before = wl.protect_ext.len();
        wl.protect_ext.retain(|x| !(x.extensions == extensions && x.scope == scope));
        if wl.protect_ext.len() == before {
            return Err(format!("ext 不存在: {:?} (scope={})", extensions, scope));
        }
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "extensions": extensions, "scope": scope }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_whitelist_add_mtime(
    State(state): State<Arc<WebuiState>>,
    Json(mut payload): Json<ProtectMtime>,
) -> Json<serde_json::Value> {
    if payload.within_days == 0 {
        return Json(serde_json::json!({ "ok": false, "error": "within_days 必须 > 0" }));
    }
    if payload.scope.is_empty() {
        payload.scope = "global".to_string();
    }
    let path = state.config_dir.join("config/whitelist.toml");
    let days = payload.within_days;
    let scope = payload.scope.clone();
    match modify_whitelist(&path, |wl| {
        if wl.protect_mtime.iter().any(|x| x.within_days == payload.within_days && x.scope == payload.scope) {
            return Err(format!("mtime 已存在: {} 天 (scope={})", days, scope));
        }
        wl.protect_mtime.push(payload.clone());
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "within_days": days, "scope": scope }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

async fn api_whitelist_del_mtime(
    State(state): State<Arc<WebuiState>>,
    Json(payload): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let within_days = payload.get("within_days").and_then(|v| v.as_u64()).unwrap_or(0) as u32;
    let scope = payload.get("scope").and_then(|v| v.as_str()).unwrap_or("global").to_string();
    if within_days == 0 {
        return Json(serde_json::json!({ "ok": false, "error": "within_days 不能为 0" }));
    }
    let path = state.config_dir.join("config/whitelist.toml");
    match modify_whitelist(&path, |wl| {
        let before = wl.protect_mtime.len();
        wl.protect_mtime.retain(|x| !(x.within_days == within_days && x.scope == scope));
        if wl.protect_mtime.len() == before {
            return Err(format!("mtime 不存在: {} 天 (scope={})", within_days, scope));
        }
        Ok(())
    }) {
        Ok(_) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "within_days": within_days, "scope": scope }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

// ============================================================
// daemon 控制
// ============================================================

async fn api_daemon_status(
    State(state): State<Arc<WebuiState>>,
) -> Json<DaemonStatusInfo> {
    let pidfile = state.config_dir.join("run/tarn.pid");
    Json(read_daemon_status(&pidfile))
}

async fn api_daemon_reload(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let pidfile = state.config_dir.join("run/tarn.pid");
    match daemon::signal_daemon(&pidfile, libc::SIGHUP) {
        Ok(_) => Json(serde_json::json!({ "ok": true, "signal": "SIGHUP" })),
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("{}", e) })),
    }
}

async fn api_daemon_stop(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let pidfile = state.config_dir.join("run/tarn.pid");
    match daemon::signal_daemon(&pidfile, libc::SIGTERM) {
        Ok(_) => Json(serde_json::json!({ "ok": true, "signal": "SIGTERM" })),
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("{}", e) })),
    }
}

async fn api_daemon_start() -> Json<serde_json::Value> {
    // WebUI 进程不能直接 fork daemon (会变成 daemon 的子进程被 Magisk 监管误判)
    // 提示用户用 CLI 启动
    Json(serde_json::json!({
        "ok": false,
        "error": "WebUI 不能直接启动 daemon, 请在终端执行: setsid nohup tarn daemon &",
        "hint": "也可重启设备让 Magisk service.sh 自动启动 daemon"
    }))
}

// ============================================================
// 规则包
// ============================================================

async fn api_packs_list(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    let rules_dir = state.config_dir.join("rules");
    let mut packs: Vec<serde_json::Value> = Vec::new();
    if let Ok(entries) = std::fs::read_dir(&rules_dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().and_then(|s| s.to_str()) != Some("toml") {
                continue;
            }
            let name = path.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_string();
            let content = std::fs::read_to_string(&path).unwrap_or_default();
            let rule_count = toml::from_str::<Blacklist>(&content)
                .map(|b| b.rule.len())
                .unwrap_or(0);
            let size = content.len();
            packs.push(serde_json::json!({
                "name": name,
                "file": path.file_name().and_then(|s| s.to_str()).unwrap_or(""),
                "rules": rule_count,
                "size": size,
                "preview": content.chars().take(500).collect::<String>(),
            }));
        }
    }
    Json(serde_json::json!({ "packs": packs }))
}

async fn api_packs_install(
    State(state): State<Arc<WebuiState>>,
    Path(name): Path<String>,
) -> Json<serde_json::Value> {
    // 安全: 仅允许文件名, 不允许路径分隔符
    if name.contains('/') || name.contains('\\') || name.contains("..") {
        return Json(serde_json::json!({ "ok": false, "error": "非法包名" }));
    }
    let pack_path = state.config_dir.join("rules").join(format!("{}.toml", name));
    if !pack_path.exists() {
        return Json(serde_json::json!({ "ok": false, "error": format!("规则包不存在: {}", name) }));
    }
    let pack_content = match std::fs::read_to_string(&pack_path) {
        Ok(c) => c,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("读取失败: {}", e) })),
    };
    let pack_bl: Blacklist = match toml::from_str(&pack_content) {
        Ok(b) => b,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("解析失败: {}", e) })),
    };
    // 把包里的规则合并到 blacklist.toml (同 id 跳过)
    let bl_path = state.config_dir.join("config/blacklist.toml");
    match modify_blacklist(&bl_path, |bl| {
        let mut added = 0;
        let mut skipped = 0;
        for r in &pack_bl.rule {
            if bl.rule.iter().any(|x| x.id == r.id) {
                skipped += 1;
            } else {
                bl.rule.push(r.clone());
                added += 1;
            }
        }
        Ok(format!("添加 {} 条, 跳过 {} 条 (id 重复)", added, skipped))
    }) {
        Ok(msg) => {
            let _ = tarn_core::reload::reload(&state.config, state.config_dir.clone());
            Json(serde_json::json!({ "ok": true, "pack": name, "message": msg }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

// ============================================================
// token
// ============================================================

async fn api_token_regenerate(
    State(state): State<Arc<WebuiState>>,
) -> Json<serde_json::Value> {
    match regenerate_token(&state.config_dir) {
        Ok(new_token) => {
            *state.token.write() = new_token.clone();
            // 不在响应体明文返回 token (防代理/日志泄露)。
            // 用户需从 run/token 文件读取新 token (权限 0600, 仅 root 可读)。
            // 保留 token_preview 字段返回前 4 位 + 后 4 位, 供用户确认是哪个 token。
            let preview = if new_token.len() >= 8 {
                format!("{}...{}", &new_token[..4], &new_token[new_token.len()-4..])
            } else {
                "****".to_string()
            };
            Json(serde_json::json!({
                "ok": true,
                "token_preview": preview,
                "hint": "新 token 已写入 run/token 文件 (0600 权限), 请用 'cat run/token' 读取"
            }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("{}", e) })),
    }
}

// ============================================================
// 日志
// ============================================================

#[derive(Deserialize)]
struct LogRecentQuery {
    #[serde(default = "default_recent_lines")]
    lines: usize,
}
fn default_recent_lines() -> usize { 200 }

async fn api_logs_recent(
    State(state): State<Arc<WebuiState>>,
    Query(q): Query<LogRecentQuery>,
) -> Json<serde_json::Value> {
    let log_path = state.config_dir.join("logs/tarn.log");
    let lines = q.lines.max(1).min(5000);
    // 反向读取尾部 N 行 (避免整文件入内存 OOM) + spawn_blocking (避免阻塞 async runtime)
    let entries = tokio::task::spawn_blocking(move || read_log_tail(&log_path, lines))
        .await
        .unwrap_or_default();
    Json(serde_json::json!({ "entries": entries }))
}

/// 读取日志文件尾部 N 行, 解析为 JSON entries (同步, 供 spawn_blocking 调用)
///
/// 反向 seek 实现: 只读足够覆盖最后 N 行的尾部字节。
/// 整文件 read_to_string + lines 会对几十 MB 日志整体读入内存再 split, 高内存压力下可能 OOM。
fn read_log_tail(path: &std::path::Path, n: usize) -> Vec<serde_json::Value> {
    let file = match std::fs::File::open(path) {
        Ok(f) => f,
        Err(_) => return Vec::new(),
    };
    let lines = read_tail_lines(file, n);
    lines.iter()
        .filter_map(|line| parse_line(line))
        .map(|e| serde_json::json!({
            "ts": e.ts,
            "level": e.level.as_str(),
            "target": e.target,
            "msg": e.message,
            "fields": e.fields.into_iter().map(|(k, v)| serde_json::json!({"k": k, "v": v})).collect::<Vec<_>>(),
        }))
        .collect()
}

/// 从文件末尾反向读取最后 n 行
///
/// 算法: 反向按块 (8KB) seek + read, 统计换行符, 找到第 n+1 个换行后,
/// 从该位置顺序读到文件末尾, 再 split lines。只读必要尾部字节, 内存友好。
fn read_tail_lines(mut file: std::fs::File, n: usize) -> Vec<String> {
    use std::io::{Read, Seek, SeekFrom};
    let file_size = match file.metadata() {
        Ok(m) => m.len(),
        Err(_) => return Vec::new(),
    } as i64;
    if file_size == 0 {
        return Vec::new();
    }
    const BLOCK: usize = 8192;
    let mut pos = file_size;
    let mut newline_count: usize = 0;

    // 反向扫描, 找到第 n+1 个换行符
    while pos > 0 {
        let read_size = std::cmp::min(BLOCK as i64, pos) as usize;
        let block_start = pos - read_size as i64;
        if file.seek(SeekFrom::Start(block_start as u64)).is_err() {
            break;
        }
        let mut buf = vec![0u8; read_size];
        let read = file.read(&mut buf).unwrap_or(0);
        if read == 0 {
            break;
        }
        buf.truncate(read);
        // 反向扫描换行符
        for i in (0..read).rev() {
            if buf[i] == b'\n' {
                newline_count += 1;
                if newline_count > n {
                    // 第 n+1 个换行符之后就是最后 n 行的起点
                    let start = block_start + i as i64 + 1;
                    let _ = file.seek(SeekFrom::Start(start as u64));
                    let mut content = Vec::with_capacity((file_size - start) as usize);
                    let _ = file.read_to_end(&mut content);
                    let text = String::from_utf8_lossy(&content);
                    return text.lines().map(|s| s.to_string()).collect();
                }
            }
        }
        pos = block_start;
    }

    // 到达文件头, 换行数不足 n, 返回全部内容
    let _ = file.seek(SeekFrom::Start(0));
    let mut content = Vec::with_capacity(file_size as usize);
    let _ = file.read_to_end(&mut content);
    let text = String::from_utf8_lossy(&content);
    text.lines().map(|s| s.to_string()).collect()
}

// 日志采用手动刷新: 前端调 /api/logs/recent → 直接读日志文件 → 返回最近 N 行
// 不做 SSE 实时流 + 后台轮询 (300ms/5s tail 会违反 "空闲时零 CPU" 原则)
// 空闲时 WebUI 无任何后台轮询, 彻底零 CPU。

// ============================================================
// 辅助函数
// ============================================================

fn rule_to_json(r: &Rule) -> serde_json::Value {
    serde_json::json!({
        "id": r.id,
        "name": r.name,
        "enabled": r.enabled,
        "priority": r.priority,
        "risk": r.risk,
        "clean_empty_dirs": r.clean_empty_dirs,
        "clean_empty_dirs_include_root": r.clean_empty_dirs_include_root,
        "clean_empty_dirs_max_depth": r.clean_empty_dirs_max_depth,
        "trigger": {
            "on": r.trigger.on,
            "min_free_mb": r.trigger.min_free_mb,
            "cron_expr": r.trigger.cron_expr,
        },
        "targets": r.targets.iter().map(|t| serde_json::json!({
            "path": t.path,
            "glob": t.glob,
            "mode": t.mode,
            "older_than_days": t.older_than_days,
            "min_size_kb": t.min_size_kb,
            "exclude": t.exclude,
            "clean_empty_dirs": t.clean_empty_dirs,
            "clean_empty_dirs_include_root": t.clean_empty_dirs_include_root,
            "clean_empty_dirs_max_depth": t.clean_empty_dirs_max_depth,
        })).collect::<Vec<_>>(),
    })
}

fn read_daemon_status(pidfile: &std::path::Path) -> DaemonStatusInfo {
    let pidfile_str = pidfile.display().to_string();
    match sysutil::read_pidfile(pidfile) {
        Some(pid) if sysutil::pid_alive(pid) => {
            let cmdline = if sysutil::pid_cmdline_contains(pid, "tarn") {
                std::fs::read_to_string(format!("/proc/{}/cmdline", pid))
                    .ok()
                    .map(|s| s.replace('\0', " "))
            } else {
                None
            };
            let running = cmdline.is_some();
            DaemonStatusInfo {
                running,
                pid: Some(pid),
                cmdline,
                pidfile: pidfile_str,
            }
        }
        _ => DaemonStatusInfo {
            running: false,
            pid: None,
            cmdline: None,
            pidfile: pidfile_str,
        },
    }
}

/// 对配置文件加排它锁 (旁路 .lock 文件 + flock), 防并发修改丢失更新
///
/// 为何用旁路锁文件而非锁 path 本身: atomic_write 用 tmp+rename 换 inode,
/// 对 path 本身 flock 会被 rename 释放 (锁跟随旧 inode), 失去保护。
/// 旁路 .lock 文件 inode 稳定, flock 持续有效。所有修改者都走 with_file_lock,
/// 即可串行化。File drop 时自动释放 flock。
fn with_file_lock<R>(path: &std::path::Path, f: impl FnOnce() -> Result<R, String>) -> Result<R, String> {
    use std::os::unix::io::AsRawFd;
    let lock_path = path.with_extension("lock");
    let lock_file = match std::fs::OpenOptions::new()
        .create(true)
        .write(true)
        .open(&lock_path)
    {
        Ok(f) => f,
        Err(e) => return Err(format!("打开锁文件失败 {}: {}", lock_path.display(), e)),
    };
    // flock LOCK_EX (阻塞直到拿到锁, 串行化并发修改)
    let r = unsafe { libc::flock(lock_file.as_raw_fd(), libc::LOCK_EX) };
    if r != 0 {
        return Err(format!("flock 失败: {}", std::io::Error::last_os_error()));
    }
    // 拿到锁, 执行操作 (lock_file drop 时自动释放 flock)
    f()
}

fn modify_blacklist<F, R>(path: &std::path::Path, f: F) -> Result<R, String>
where
    F: FnOnce(&mut Blacklist) -> Result<R, String>,
{
    // 旁路锁 + flock 串行化, 防并发修改丢失更新
    with_file_lock(path, || {
        let content = std::fs::read_to_string(path).unwrap_or_default();
        let mut bl: Blacklist = toml::from_str(&content).map_err(|e| format!("解析失败: {}", e))?;
        let ret = f(&mut bl)?;
        let new_content = toml::to_string_pretty(&bl).map_err(|e| format!("序列化失败: {}", e))?;
        atomic_write(path, &new_content).map_err(|e| format!("写入失败: {}", e))?;
        Ok(ret)
    })
}

fn modify_whitelist<F, R>(path: &std::path::Path, f: F) -> Result<R, String>
where
    F: FnOnce(&mut Whitelist) -> Result<R, String>,
{
    // 旁路锁 + flock 串行化, 防并发修改丢失更新
    with_file_lock(path, || {
        let content = std::fs::read_to_string(path).unwrap_or_default();
        let mut wl: Whitelist = toml::from_str(&content).map_err(|e| format!("解析失败: {}", e))?;
        let ret = f(&mut wl)?;
        let new_content = toml::to_string_pretty(&wl).map_err(|e| format!("序列化失败: {}", e))?;
        atomic_write(path, &new_content).map_err(|e| format!("写入失败: {}", e))?;
        Ok(ret)
    })
}

/// 原子写: tmp + fsync 文件 + fsync 父目录 + rename
///
/// 与 core/state.rs 的 atomic_write 保持一致 (含 fsync 文件 + fsync 父目录),
/// 掉电场景下避免 rename 已生效但内容为空 (metadata 先于 data 落盘)
fn atomic_write(path: &std::path::Path, content: &str) -> std::io::Result<()> {
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, content)?;
    // fsync 文件内容
    {
        let f = std::fs::File::open(&tmp)?;
        f.sync_all()?;
    }
    std::fs::rename(&tmp, path)?;
    // fsync 父目录 (确保 rename 的 dirent 落盘)
    if let Some(parent) = path.parent() {
        if let Ok(pf) = std::fs::File::open(parent) {
            let _ = pf.sync_all();
        }
    }
    Ok(())
}

/// 绑定 TCP 监听并显式设 SO_REUSEADDR
///
/// `tokio::net::TcpListener::bind` 不保证设置 SO_REUSEADDR。daemon 被 kill
/// 后, 8080 端口可能进入 TIME_WAIT (最长 60s), 下一轮 daemon bind 会失败
/// (EADDRINUSE), WebUI 线程退出, 用户连不上 WebUI。
///
/// 用 `TcpSocket` 显式 `set_reuseaddr(true)` 再 bind+listen, 保证端口
/// TIME_WAIT 时也能立即复用。SO_REUSEADDR 在 Linux 上只允许复用 TIME_WAIT 状态
/// 的端口 (不允许复用 LISTEN 状态, 不会造成双绑)。
fn bind_tcp_with_reuseaddr(addr: &str) -> std::io::Result<tokio::net::TcpListener> {
    let socket_addr: std::net::SocketAddr = addr.parse().map_err(|e| {
        std::io::Error::new(
            std::io::ErrorKind::InvalidInput,
            format!("TCP 地址解析失败 '{}': {}", addr, e),
        )
    })?;
    let socket = if socket_addr.is_ipv4() {
        tokio::net::TcpSocket::new_v4()
    } else {
        tokio::net::TcpSocket::new_v6()
    }?;
    // SO_REUSEADDR: 允许复用 TIME_WAIT 端口 (Linux 不允许复用 LISTEN 端口, 安全)
    if let Err(e) = socket.set_reuseaddr(true) {
        eprintln!("[WARN] set_reuseaddr 失败 (继续 bind): {}", e);
    }
    socket.bind(socket_addr)?;
    // backlog=1024: 应对突发连接 (KSU WebUI + 多浏览器标签)
    let listener = socket.listen(1024)?;
    Ok(listener)
}

/// 绑定 Unix socket: unlink 旧 → umask 077 → bind (避免 TOCTOU 竞态)
///
/// bind 后才 chmod 0600 时, bind→chmod 窗口内 socket 权限受 umask 影响 (通常 0755,
/// world-connectable), 恶意进程可在此窗口 connect 后持续占连接。
/// bind 前设 umask=0o077, 保证 socket 创建即 0600, 无竞态窗口。
async fn bind_uds(path: &std::path::Path) -> std::io::Result<UnixListener> {
    if let Some(parent) = path.parent() {
        tokio::fs::create_dir_all(parent).await.ok();
    }
    let _ = tokio::fs::remove_file(path).await;
    // bind 前收紧 umask, 保证 socket 文件创建即 0600 (无 chmod 竞态窗口)
    let old_umask = unsafe { libc::umask(0o077) };
    let l = UnixListener::bind(path);
    unsafe { libc::umask(old_umask); } // 恢复 umask
    let l = l?;
    // 双保险: 仍显式 set_permissions 0600 (umask 在某些平台/容器可能被忽略)
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = tokio::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600)).await;
    }
    Ok(l)
}

/// 用 hyper 底层 API 服务 Unix socket (axum 0.7.9 的 serve 不支持 UnixListener)
///
/// SO_PEERCRED 鉴权: 仅允许 root (uid=0) 连接 UDS。
/// 非 root 进程一律拒绝, 防止任何进程无 token 调用所有 API (含 /api/daemon/stop
/// /api/clean 等高危端点)。
async fn serve_uds(listener: UnixListener, app: Router) {
    use std::os::unix::io::AsRawFd;
    use tower::Service;
    // 限制并发 UDS 连接数, 防 fd 耗尽
    // (SO_PEERCRED 已限 root, 但 root 进程仍可 fork 炸连接; Semaphore 兜底背压)
    const MAX_CONCURRENT_UDS: usize = 64;
    let sem = Arc::new(tokio::sync::Semaphore::new(MAX_CONCURRENT_UDS));
    loop {
        match listener.accept().await {
            Ok((stream, _addr)) => {
                // SO_PEERCRED 鉴权 — 仅允许 root (uid=0) 连接 UDS
                // (非 root 连接直接关闭, 不服务)
                let peer_uid = {
                    let raw_fd = stream.as_raw_fd();
                    let mut cred: libc::ucred = unsafe { std::mem::zeroed() };
                    let mut len = std::mem::size_of::<libc::ucred>() as libc::socklen_t;
                    let r = unsafe {
                        libc::getsockopt(
                            raw_fd,
                            libc::SOL_SOCKET,
                            libc::SO_PEERCRED,
                            &mut cred as *mut _ as *mut libc::c_void,
                            &mut len,
                        )
                    };
                    if r < 0 { None } else { Some(cred.uid) }
                };
                if peer_uid != Some(0) {
                    // 非 root 连接或 getsockopt 失败, 保守拒绝 (不 spawn task, 不服务)
                    continue;
                }
                // 获取 permit (连接满时背压等待, 不拒绝合法 root 请求)
                let permit = match sem.clone().acquire_owned().await {
                    Ok(p) => p,
                    Err(_) => continue, // Semaphore 关闭 (不应发生)
                };
                let io = TokioIo::new(stream);
                let app_clone = app.clone();
                tokio::spawn(async move {
                    let _permit = permit; // 持有 permit 直到连接结束, drop 释放
                    let svc = hyper::service::service_fn(move |req| {
                        let mut app = app_clone.clone();
                        async move { app.call(req).await }
                    });
                    let _ = hyper::server::conn::http1::Builder::new()
                        .serve_connection(io, svc)
                        .await;
                });
            }
            Err(e) => {
                eprintln!("[WARN] UDS accept 失败: {}", e);
                tokio::time::sleep(Duration::from_millis(100)).await;
            }
        }
    }
}

// 日志采用手动刷新: 前端调 /api/logs/recent → 直接读日志文件 → 返回最近 N 行
// 不做后台 tail 轮询 (300ms/5s tail 违反零 CPU 原则)

/// 加载或创建 token
///
/// token 存放在 `<config_dir>/run/token` (运行时目录, 0600 root-only),
/// 不污染数据目录根。run/ 目录由 service.sh / ensure_config_dir
/// 预先创建 (0700), 这里只兜底确保存在。
fn load_or_create_token(config_dir: &PathBuf) -> Result<String> {
    use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
    let run_dir = config_dir.join("run");
    std::fs::create_dir_all(&run_dir)?;
    let token_path = run_dir.join("token");
    if token_path.exists() {
        let token = std::fs::read_to_string(&token_path)?.trim().to_string();
        if !token.is_empty() {
            return Ok(token);
        }
    }
    let mut bytes = [0u8; 32];
    use std::io::Read;
    let mut f = std::fs::File::open("/dev/urandom")?;
    f.read_exact(&mut bytes)?;
    let token = URL_SAFE_NO_PAD.encode(bytes);
    std::fs::write(&token_path, &token)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&token_path, std::fs::Permissions::from_mode(0o600))?;
    }
    println!("[OK] 生成新 token: {}", token);
    Ok(token)
}

/// 重新生成 token
///
/// 写入 `<config_dir>/run/token` (同 load_or_create_token)。
fn regenerate_token(config_dir: &PathBuf) -> Result<String> {
    use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
    let run_dir = config_dir.join("run");
    std::fs::create_dir_all(&run_dir)?;
    let token_path = run_dir.join("token");
    let mut bytes = [0u8; 32];
    use std::io::Read;
    let mut f = std::fs::File::open("/dev/urandom")?;
    f.read_exact(&mut bytes)?;
    let token = URL_SAFE_NO_PAD.encode(bytes);
    std::fs::write(&token_path, &token)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&token_path, std::fs::Permissions::from_mode(0o600))?;
    }
    Ok(token)
}

// 抑制未使用警告
#[allow(dead_code)]
fn _suppress() {
    let _ = tarn_core::scheduler::DozeTimer::now_boottime();
}

/// 创建共享 AsyncLogger (与 cli/run.rs make_logger 一致)
///
/// WebUI 触发的清理也写日志文件, 用户可通过 /api/logs/recent 手动刷新查看。
/// 不做后台 tail 轮询 (零 CPU)。
/// 失败时返回 None (WebUI 仍能工作, 只是不写日志文件)。
fn make_logger(config_dir: &PathBuf, settings: &Settings) -> Option<Arc<AsyncLogger>> {
    let log_dir = config_dir.join("logs");
    let log_dir = if log_dir.is_absolute() {
        log_dir
    } else {
        std::env::current_dir().ok()?.join(&log_dir)
    };
    let file_name = if settings.log.file.is_empty() {
        "tarn.log"
    } else {
        &settings.log.file
    };
    AsyncLogger::new(
        log_dir,
        file_name,
        settings.log.channel_capacity,
        LogLevel::from_str(&settings.log.level),
    )
    .ok()
    .map(Arc::new)
}
