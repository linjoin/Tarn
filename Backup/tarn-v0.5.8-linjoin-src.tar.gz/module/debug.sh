#!/system/bin/sh

MODDIR=${0%/*}
DATADIR=/data/adb/tarn
BIN="$MODDIR/tarn"
LOGDIR="$DATADIR/logs"
TS=$(date '+%Y%m%d_%H%M%S' 2>/dev/null)
OUT="$LOGDIR/debug-${TS}.txt"

detect_bb() {
  for cand in \
    /data/adb/ksu/bin/busybox \
    /data/adb/ap/bin/busybox \
    /data/adb/magisk/busybox \
    /system/bin/busybox \
    /system/xbin/busybox; do
    [ -x "$cand" ] && { echo "$cand"; return 0; }
  done
  command -v busybox 2>/dev/null && return 0
  echo ""
  return 1
}

BB=$(detect_bb)
bb_wrap() {
  cmd=$1
  shift
  if [ -n "$BB" ]; then
    "$BB" "$cmd" "$@"
  else
    "$cmd" "$@"
  fi
}

mkdir -p "$LOGDIR" 2>/dev/null

section() {
  echo "" >> "$OUT" 2>/dev/null
  echo "========================================================" >> "$OUT" 2>/dev/null
  echo "  $1" >> "$OUT" 2>/dev/null
  echo "========================================================" >> "$OUT" 2>/dev/null
}

run_cmd() {
  echo "$ $*" >> "$OUT" 2>/dev/null
  "$@" >> "$OUT" 2>&1
  echo "" >> "$OUT" 2>/dev/null
}

run_sh() {
  echo "$ $1" >> "$OUT" 2>/dev/null
  sh -c "$1" >> "$OUT" 2>&1
  echo "" >> "$OUT" 2>/dev/null
}

dump_file() {
  _f=$1
  _label=${2:-$_f}
  echo "--- $_label ---" >> "$OUT" 2>/dev/null
  if [ -f "$_f" ]; then
    cat "$_f" >> "$OUT" 2>/dev/null
  else
    echo "(文件不存在: $_f)" >> "$OUT" 2>/dev/null
  fi
  echo "" >> "$OUT" 2>/dev/null
  unset _f _label
}

dump_file_tail() {
  _f=$1
  _n=${2:-200}
  _label=${3:-$_f}
  echo "--- $_label (tail $_n) ---" >> "$OUT" 2>/dev/null
  if [ -f "$_f" ]; then
    bb_wrap tail -n "$_n" "$_f" >> "$OUT" 2>/dev/null
  else
    echo "(文件不存在: $_f)" >> "$OUT" 2>/dev/null
  fi
  echo "" >> "$OUT" 2>/dev/null
  unset _f _n _label
}

{
  echo "========================================================"
  echo "  Tarn 诊断快照"
  echo "  生成时间: $(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
  echo "  模块目录: $MODDIR"
  echo "  数据目录: $DATADIR"
  echo "========================================================"
} > "$OUT" 2>/dev/null

section "1. 版本与模块信息"
run_cmd "$BIN" version
dump_file "$MODDIR/module.prop" "module.prop"

section "2. 进程信息"
PIDFILE="$DATADIR/run/tarn.pid"
if [ -f "$PIDFILE" ]; then
  DPID=$(cat "$PIDFILE" 2>/dev/null | tr -d '[:space:]')
  echo "pidfile 内容: $DPID" >> "$OUT" 2>/dev/null
  if [ -n "$DPID" ] && [ "$DPID" -gt 0 ] 2>/dev/null; then
    if kill -0 "$DPID" 2>/dev/null; then
      dump_file "/proc/$DPID/status" "/proc/$DPID/status"
      dump_file "/proc/$DPID/cmdline" "/proc/$DPID/cmdline"
      run_sh "ls -la /proc/$DPID/fd/ 2>/dev/null"
    else
      echo "进程 $DPID 已不存活" >> "$OUT" 2>/dev/null
    fi
  fi
else
  echo "pidfile 不存在 (daemon 未运行)" >> "$OUT" 2>/dev/null
fi

echo "" >> "$OUT" 2>/dev/null
echo "--- ps (tarn 相关) ---" >> "$OUT" 2>/dev/null
if [ -n "$BB" ]; then
  "$BB" ps 2>/dev/null | bb_wrap grep -E '[t]arn' >> "$OUT" 2>/dev/null
else
  ps -A -o pid,ppid,cmd 2>/dev/null | bb_wrap grep -E '[t]arn' >> "$OUT" 2>/dev/null
fi
echo "" >> "$OUT" 2>/dev/null

section "3. 日志文件"
dump_file "$DATADIR/logs/boot.log" "boot.log (完整)"
dump_file_tail "$DATADIR/logs/tarn.log" 300 "tarn.log (tail 300)"

section "4. 配置文件"
dump_file "$DATADIR/config/settings.toml" "settings.toml"
dump_file "$DATADIR/config/blacklist.toml" "blacklist.toml"
dump_file "$DATADIR/config/whitelist.toml" "whitelist.toml"

echo "--- rules/ 目录列表 ---" >> "$OUT" 2>/dev/null
if [ -d "$DATADIR/rules" ]; then
  ls -la "$DATADIR/rules/" >> "$OUT" 2>/dev/null
  for rf in "$DATADIR/rules"/*.toml; do
    [ -f "$rf" ] || continue
    dump_file "$rf" "rules/$(basename "$rf")"
  done
else
  echo "(rules/ 目录不存在)" >> "$OUT" 2>/dev/null
fi

section "5. 状态与运行时"
dump_file "$DATADIR/state.json" "state.json"
echo "--- run/ 目录列表 ---" >> "$OUT" 2>/dev/null
ls -la "$DATADIR/run/" >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null

section "6. 数据目录结构"
run_sh "ls -laR $DATADIR/ 2>/dev/null | head -200"

section "7. 系统信息"
run_cmd uname -a
run_sh "uptime 2>/dev/null"
run_sh "cat /proc/loadavg 2>/dev/null"
echo "--- /proc/meminfo ---" >> "$OUT" 2>/dev/null
bb_wrap head -n 15 /proc/meminfo >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null
echo "--- /proc/cpuinfo (前 30 行) ---" >> "$OUT" 2>/dev/null
bb_wrap head -n 30 /proc/cpuinfo >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null

section "8. Android 属性"
for prop in \
  ro.build.version.release \
  ro.build.version.sdk \
  ro.build.version.incremental \
  ro.product.model \
  ro.product.brand \
  ro.product.manufacturer \
  ro.product.cpu.abi \
  ro.hardware \
  ro.boot.slot_suffix \
  ro.boot.verifiedbootstate \
  ro.boot.flash.locked; do
  run_sh "getprop $prop 2>/dev/null"
done

section "9. Root 管理器检测"
run_sh "ls -la /data/adb/ksu/ 2>/dev/null | head -10"
run_sh "ls -la /data/adb/ap/ 2>/dev/null | head -10"
run_sh "ls -la /data/adb/magisk/ 2>/dev/null | head -10"
run_sh "getprop ro.magisk.version 2>/dev/null"
run_sh "cat /data/adb/ksu/version 2>/dev/null"
run_sh "cat /data/adb/apd/version 2>/dev/null"

section "10. SELinux 与权限"
run_sh "getenforce 2>/dev/null"
run_sh "id 2>/dev/null"
run_sh "ls -la /sys/power/wake_lock 2>/dev/null"
run_sh "ls -la /sys/power/wake_unlock 2>/dev/null"

section "11. 存储与挂载"
run_sh "df -h /data 2>/dev/null"
echo "--- mount (tarn 相关) ---" >> "$OUT" 2>/dev/null
bb_wrap mount 2>/dev/null | bb_wrap grep -iE 'tarn|/data ' >> "$OUT" 2>/dev/null
echo "" >> "$OUT" 2>/dev/null

section "12. doctor 自检"
if [ -x "$BIN" ]; then
  run_cmd "$BIN" doctor
else
  echo "(二进制不可执行: $BIN)" >> "$OUT" 2>/dev/null
fi

section "13. 通信端点"
SOCK="$DATADIR/run/tarn.sock"
run_sh "ls -la $SOCK 2>/dev/null"
TOKEN="$DATADIR/run/token"
if [ -f "$TOKEN" ]; then
  echo "token 文件存在 (大小 $(wc -c < "$TOKEN" 2>/dev/null | tr -d ' ') 字节, 内容已脱敏)" >> "$OUT" 2>/dev/null
else
  echo "token 文件不存在" >> "$OUT" 2>/dev/null
fi

section "14. 内核日志 (dmesg, 尾部)"
run_sh "dmesg 2>/dev/null | tail -50"

section "诊断完成"
echo "诊断快照已写入: $OUT" >> "$OUT" 2>/dev/null
echo "文件大小: $(wc -c < "$OUT" 2>/dev/null | tr -d ' ') 字节" >> "$OUT" 2>/dev/null

KEEP_DAYS=7
find "$LOGDIR" -name 'debug-*.txt' -mtime +${KEEP_DAYS} -delete 2>/dev/null
COUNT=$(ls -1 "$LOGDIR"/debug-*.txt 2>/dev/null | wc -l | tr -d ' ')
echo "当前 debug 快照数: $COUNT (保留 ${KEEP_DAYS} 天)" >> "$OUT" 2>/dev/null

exit 0
